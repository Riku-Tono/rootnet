from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ecosystem import FusaEcosystem


def _payload(ecosystem: FusaEcosystem) -> dict[str, Any]:
    return {
        "day": ecosystem.day,
        "cambrian": ecosystem.cambrian.to_dict(),
        "nodes": ecosystem.lineage_tree_data(),
        "movements": ecosystem.movement_history,
        "outbreaks": ecosystem.outbreak_history,
        "severed_links": ecosystem.severed_links,
        "life_journal": [event.to_dict() for event in ecosystem.life_journal],
        "biological_history": ecosystem.biological_history,
    }


def write_lineage_tree(ecosystem: FusaEcosystem, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(_payload(ecosystem), ensure_ascii=False).replace("<", "\\u003c")
    template = """<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RootNet v5.8.0 Biological Model</title>
<style>
:root { color-scheme: light dark; --bg:#f4f7f2; --fg:#183020; --panel:#ffffff; --line:#8ca68f; --l:#3a8f5b; --d:#8759ad; --dead:#8b8b8b; --accent:#d9eadb; }
@media (prefers-color-scheme: dark) { :root { --bg:#101712; --fg:#e7f2e8; --panel:#19231c; --line:#78927d; --l:#68c486; --d:#c99aee; --dead:#888; --accent:#294333; } }
* { box-sizing:border-box; }
body { margin:0; font-family:system-ui,"Yu Gothic UI",sans-serif; background:var(--bg); color:var(--fg); }
header { padding:16px 18px 8px; }
h1 { margin:0 0 6px; font-size:1.35rem; font-weight:600; }
#status { color:var(--fg); opacity:.78; }
.controls { display:flex; flex-wrap:wrap; gap:12px; padding:10px 18px 14px; align-items:end; }
label { display:grid; gap:4px; font-size:.86rem; }
select,input { font:inherit; padding:6px 8px; border:1px solid var(--line); border-radius:7px; background:var(--panel); color:var(--fg); }
.legend { display:flex; gap:12px; align-items:center; font-size:.86rem; }
.dot { width:10px; height:10px; border-radius:50%; display:inline-block; margin-right:4px; }
.tree-wrap { overflow:auto; border-top:1px solid var(--line); border-bottom:1px solid var(--line); background:var(--panel); min-height:460px; }
svg { display:block; }
.edge { stroke:var(--line); stroke-width:1.4; fill:none; opacity:.72; }
.node { cursor:pointer; }
.node rect { fill:var(--panel); stroke-width:2; rx:9; }
.node.l rect { stroke:var(--l); }
.node.d rect { stroke:var(--d); }
.node.dead { opacity:.48; }
.node text { fill:var(--fg); font-size:12px; pointer-events:none; }
.node .small { font-size:10px; opacity:.78; }
#detail { margin:14px 18px 20px; padding:12px 14px; background:var(--panel); border:1px solid var(--line); border-radius:10px; min-height:54px; }
#detail strong { font-weight:600; }
</style>
</head>
<body>
<header>
  <h1>🌳🍄 RootNet v5.8.0 Biological Model</h1>
  <p>Carbon, water, and nitrogen balances and resource transport for fungi, algae, and symbiotic organisms</p>
  <div id="status"></div>
</header>
<div class="controls">
  <label>Chirality
    <select id="chirality"><option value="all">All L/D forms</option><option value="L">Standard L form</option><option value="D">Mirror-image D form</option></select>
  </label>
  <label>Status
    <select id="life"><option value="all">Living and dead</option><option value="alive">Living</option><option value="dead">Dead</option></select>
  </label>
  <label>Name / ability
    <input id="search" type="search" placeholder="bioluminescence, parasitism, name">
  </label>
  <div class="legend"><span><i class="dot" style="background:var(--l)"></i>L form</span><span><i class="dot" style="background:var(--d)"></i>D form</span><span><i class="dot" style="background:var(--dead)"></i>Dead</span></div>
</div>
<div class="tree-wrap"><svg id="tree" role="img" aria-label="Lineage tree of fungi, algae, and symbiotic organisms"></svg></div>
<div id="detail">Select an organism to view its functional group, physiological traits, resource levels, and movement history.</div>
<script>
const DATA = __TREE_DATA__;
const svg = document.getElementById("tree");
const ns = "http://www.w3.org/2000/svg";
const chirality = document.getElementById("chirality");
const life = document.getElementById("life");
const search = document.getElementById("search");
const detail = document.getElementById("detail");
document.getElementById("status").textContent =
  `Day ${DATA.day} / ${DATA.nodes.length} organisms / ` +
  (DATA.cambrian.active ? `Fusacambrian period (started on day ${DATA.cambrian.started_day})` : "Before the Fusacambrian period");

function el(name, attrs={}) {
  const node = document.createElementNS(ns, name);
  for (const [key,value] of Object.entries(attrs)) node.setAttribute(key, value);
  return node;
}
function visible(n) {
  if (chirality.value !== "all" && n.chirality !== chirality.value) return false;
  if (life.value === "alive" && !n.alive) return false;
  if (life.value === "dead" && n.alive) return false;
  const q = search.value.trim().toLowerCase();
  const hay = [n.name,n.plant_id,n.lineage,...(n.active_traits||[]),...(n.active_abilities||[])].join(" ").toLowerCase();
  return !q || hay.includes(q);
}
function render() {
  svg.replaceChildren();
  const shown = DATA.nodes.filter(visible);
  const shownIds = new Set(shown.map(n=>n.plant_id));
  const byGen = new Map();
  shown.forEach(n => {
    const g = n.generation || 1;
    if (!byGen.has(g)) byGen.set(g, []);
    byGen.get(g).push(n);
  });
  [...byGen.values()].forEach(items => items.sort((a,b)=>a.plant_id.localeCompare(b.plant_id)));
  const positions = new Map();
  let maxRows = 1;
  for (const [g,items] of byGen) {
    maxRows = Math.max(maxRows, items.length);
    items.forEach((n,i)=>positions.set(n.plant_id,{x:40+(g-1)*250,y:42+i*92}));
  }
  const maxGen = Math.max(1,...shown.map(n=>n.generation||1));
  svg.setAttribute("width", Math.max(760, maxGen*250+80));
  svg.setAttribute("height", Math.max(460, maxRows*92+80));
  shown.forEach(n => {
    if (!n.parent_id || !shownIds.has(n.parent_id)) return;
    const a=positions.get(n.parent_id), b=positions.get(n.plant_id);
    const path=el("path",{class:"edge",d:`M ${a.x+180} ${a.y+25} C ${a.x+215} ${a.y+25}, ${b.x-35} ${b.y+25}, ${b.x} ${b.y+25}`});
    svg.appendChild(path);
  });
  shown.forEach(n => {
    const p=positions.get(n.plant_id);
    const g=el("g",{class:`node ${n.chirality==="D"?"d":"l"} ${n.alive?"":"dead"}`,transform:`translate(${p.x},${p.y})`});
    g.appendChild(el("rect",{width:180,height:58}));
    const t1=el("text",{x:10,y:19}); t1.textContent=`${n.alive?"🌿":"🍂"} ${n.name}`; g.appendChild(t1);
    const t2=el("text",{x:10,y:37,class:"small"}); t2.textContent=`Generation ${n.generation} / ${n.chirality} form / ${n.lineage}`; g.appendChild(t2);
    const groupLabel={fungus:"fungus",alga:"alga",symbiotic:"symbiotic"}[n.functional_group]||"symbiotic";
    const r=n.resources||{carbon:0,water:0,nitrogen:0};
    const lifeText=`${groupLabel} / C${r.carbon.toFixed(2)} W${r.water.toFixed(2)} N${r.nitrogen.toFixed(2)}`;
    const t3=el("text",{x:10,y:51,class:"small"}); t3.textContent=lifeText; g.appendChild(t3);
    g.addEventListener("click",()=>showDetail(n));
    svg.appendChild(g);
  });
}
function showDetail(n) {
  const moves=DATA.movements.filter(m=>m.subject_id===n.plant_id || m.plant_id===n.plant_id);
  const traits=(n.active_traits||[]).join(" / ")||"baseline traits";
  const abilities=(n.active_abilities||[]).join(" / ")||"weakly expressed";
  const hazard=n.biohazard_load>=0.05 ? `hazard load ${n.biohazard_load.toFixed(2)}` : "no hazard load";
  const quarantine=n.quarantine_until>DATA.day ? `quarantined until day ${n.quarantine_until}` : "not quarantined";
  const physiology=n.biological_traits||{};
  const resources=n.resources||{carbon:0,water:0,nitrogen:0,carbon_deficit_days:0,water_deficit_days:0,nitrogen_deficit_days:0};
  const groupLabel={fungus:"fungus",alga:"alga",symbiotic:"symbiotic"}[n.functional_group]||"symbiotic";
  const journal=(DATA.life_journal||[]).filter(e=>e.plant_id===n.plant_id).slice(-3);
  const moveText=moves.length ? moves.map(m=>`day ${m.day}: ${m.from}→${m.to}`).join(" / ") : "no movement records";
  detail.replaceChildren();
  const strong=document.createElement("strong"); strong.textContent=`${n.name} (${n.plant_id})`; detail.appendChild(strong);
  detail.appendChild(document.createTextNode(`  Parent: ${n.parent_id||"founder"}  Founder: ${n.ancestor_id}  L/D: ${n.chirality}  ${n.alive?"living":"dead"}`));
  detail.appendChild(document.createElement("br"));
  detail.appendChild(document.createTextNode(`Traits: ${traits}  Abilities: ${abilities}`));
  detail.appendChild(document.createElement("br"));
  detail.appendChild(document.createTextNode(`Biosecurity: ${hazard} / ${quarantine}`));
  detail.appendChild(document.createElement("br"));
  detail.appendChild(document.createTextNode(
    `Physiology: ${groupLabel} / carbon ${resources.carbon.toFixed(2)} / water ${resources.water.toFixed(2)} / nitrogen ${resources.nitrogen.toFixed(2)} / deficit days C${resources.carbon_deficit_days}/W${resources.water_deficit_days}/N${resources.nitrogen_deficit_days}`
  ));
  detail.appendChild(document.createElement("br"));
  detail.appendChild(document.createTextNode(
    `Transport traits: sharing ${(physiology.resource_sharing||0).toFixed(2)} / fusion compatibility ${(physiology.fusion_compatibility||0).toFixed(2)} / desiccation tolerance ${(physiology.desiccation_tolerance||0).toFixed(2)}`
  ));
  detail.appendChild(document.createElement("br"));
  detail.appendChild(document.createTextNode(`Movement: ${moveText}`));
  if (journal.length) {
    detail.appendChild(document.createElement("br"));
    detail.appendChild(document.createTextNode(
      `Journal: ${journal.map(event=>event.narrative).join(" / ")}`
    ));
  }
}
[chirality,life].forEach(control=>control.addEventListener("change",render));
search.addEventListener("input",render);
render();
</script>
</body>
</html>
"""
    path.write_text(template.replace("__TREE_DATA__", data), encoding="utf-8")

