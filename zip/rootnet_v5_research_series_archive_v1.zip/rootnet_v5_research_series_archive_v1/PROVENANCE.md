# Provenance

この外側アーカイブは、2026-08-18に提供されたRootNet v5系列ZIPから作成しました。採用した元ZIPは展開・編集・再圧縮せず、バイト列をそのまま `sealed_packages/` に収録しています。

## 採用した10パッケージ

```text
5b8dd3f01074bc5dd3d5dca063d0c6046e95a5495a8faab3ec396aca48dc21a3  fusa_rootnet_v5_mirror_succession_royal_seal.zip  25,861 bytes
ba81fe3a4a50e3f05d52ff1ba5063bf46d36163f52eb4561908b849d6e7a64d3  fusa_rootnet_v5_5_cambrian_royal_seal.zip  32,852 bytes
001590deb253566d43dc00bf9dc0a66b2fd682562d9abd50c7fc3fd9b05dbb2c  fusa_rootnet_v5_6_ecology_royal_seal.zip  36,261 bytes
3f7aeda06d87b68aa80dae5b1a790ca74e1e944d7da146c082c8eb18752868fa  fusa_rootnet_v5_6_1_biosecurity_royal_seal.zip  40,157 bytes
8c35ec0374e0f12381de151de3dcd3233b80f37200680648cee2279a8627c4ee  fusa_rootnet_v5_7_living_presence_royal_seal.zip  48,448 bytes
7bb964464bfd3eb40b00626ac168d873547513e7bfeaab0cf33bbf64e509b604  fusa_rootnet_v5_7_1_environment_lifelog_royal_seal.zip  52,673 bytes
d904c31adb0beb3b15682d54c257231f47efee5e6e4dc95751143aab2947ec50  fusa_rootnet_v5_7_2_cooperation_experiment_harness.zip  103,362 bytes
42151553d3b7062643064f94714663c1b4163b58af1bfa40e72d1a443b918496  fusa_rootnet_v5_7_2_cooperation_ab_100pairs_results.zip  140,436 bytes
1c3c638414cfab2a424ede8d2fd42a8ce40fb7932494207962a72115a9490fb9  fusa_rootnet_v5_8_0_biological_model_royal_seal.zip  72,742 bytes
1e5ea8d4114c5736ec41664b963b41290d62b5c868b7047cd62139e7a5c597d8  fusa_rootnet_v5_8_0_biological_model_english_royal_seal.zip  69,378 bytes
```

## 重複と未収録物

`fusa_rootnet_v5_7_2_cooperation_experiment_harness (1).zip` は無印harnessと同じ103,362 bytes、同じSHA-256 `d904c31a...47ec50` でした。重複バイト列を二重収録せず、無印だけを採用しました。

以前のファイル一覧にあった `fusa_rootnet_v5_7_2_split_rng_royal_seal.zip` は今回提供されたファイルとDownloads内に存在しませんでした。収録したharnessはv5.7.2分離乱数モデル本体、テスト、検証、協調性実験コードを含むため実行可能ですが、欠けた別名ZIPのハッシュや同一性を推定していません。

## 外側に追加したもの

- 系列READMEと版索引;
- 元ZIP用 `SHA256SUMS.txt`;
- 全外側ファイル用 `MANIFEST_SHA256.txt`;
- ZIP整合性、全版テスト、封印検証、A/B再解析を行う `verify_archive.py`;
- manifest生成用 `make_manifest.py`;
- 決定的ZIP生成用 `build_release.py`;
- Git設定とGitHub Actionsワークフロー。

外側の追加物は内側モデルの力学を変更しません。
