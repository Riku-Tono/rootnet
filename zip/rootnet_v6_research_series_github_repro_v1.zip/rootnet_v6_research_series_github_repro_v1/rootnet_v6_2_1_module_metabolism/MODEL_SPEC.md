# RootNet v6.2.1 model specification

v6.2.1 retains the v6.2 mechanism and random-stream derivation. It lowers only the extra reserves required before extension (`energy=0.004`, `water=0.0`) and changes default observer pacing. The full extension cost and water cost are still paid; a tip cannot spend more than it holds.

## Fixed scope

v6.2 adds per-module metabolism, fixed-conductance local translocation, gradual weakening, partial necrosis, graph fragmentation, detritus, recycling, and delayed space release. It does not add adaptive conductance or continuous coordinates.

## Tick order

1. Environmental substrate and water recover; detritus occupancy decays.
2. Viable spores may establish new genets and one-node ramets.
3. Every living module absorbs substrate, water, and light locally.
4. Energy and water move over explicit within-ramet edges for a fixed number of rounds.
5. Each module pays maintenance; unmet demand lowers vitality, while fully met demand permits recovery.
6. Vitality-zero modules necrose. Incident edges are removed, limited structural substrate is recycled, and detritus is deposited.
7. Disconnected components become separate living ramets of the same genet. No component is deleted because it is small.
8. Surviving tips may grow. Parent-child edges are explicit; additional same-ramet anastomoses are probabilistic, not implied by adjacency.
9. Mature ramets may pay a local energy cost to release spores. Parents persist.
10. Touching ramets of the same genet may re-anastomose; different genets form a non-self boundary.

## Conservative transport approximation

For each edge, provisional flux is proportional to the donor-receiver stock difference and a fixed conductance. All provisional outgoing fluxes from a donor are summed. If they exceed its available stock, they are proportionally scaled. The resulting deltas are committed simultaneously. This prevents negative donors and edge-order dependence and conserves the transported quantity to floating-point tolerance.

This is not a Kirchhoff pressure solution, fluid model, Physarum reproduction, or optimal-route guarantee. Conductance does not adapt in v6.2.

## Death semantics

Age is recorded but never causes death. A module dies only after resource deficits reduce vitality to zero. A ramet dies only when it has zero living modules. A genet becomes extinct when it has no living ramets. Spore establishment failure is recorded separately from all three.

## Space release and recycling

Necrosis deposits detritus occupancy of one. It decays by a fixed amount per tick. Growth and germination are blocked while occupancy is at or above the configured threshold. A fixed structural biomass amount is multiplied by recycling efficiency, but substrate is capped at the local environmental capacity; the log records the amount actually added.

## Identity

`genet_id` denotes an established reproductive genetic individual. `ramet_id` denotes a currently connected physiological component. Fragmentation creates another ramet with the same genet ID. A spore creates a new genet ID and inherits a lineage ID from its parent.
