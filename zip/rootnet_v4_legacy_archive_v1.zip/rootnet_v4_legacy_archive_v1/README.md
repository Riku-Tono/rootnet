# RootNet v4 Legacy Archive

**Archive version:** v1  
**Assembled:** 2026-08-18

この配布物は、RootNet v4公認修正版とRootNet v4.1「太陽と海・生命循環編」を一つに整理したGitHub向け保全アーカイブです。

## 重要な区別

これは二つのモデルを一つの実装へ合成したものではありません。元の封印ZIPを一切変更せず、版ごとの独立性を保ったまま外側の索引・ハッシュ・検証装置でまとめています。

```text
RootNet v4 公認修正版
  └─▶ RootNet v4.1 太陽と海・生命循環編
```

- **v4公認修正版**は、複数株、地下RootNet、環境記憶、保存再開、世代交代、老化・死亡を備えた基礎版です。
- **v4.1**はv4公認修正版を継承し、実体種子、親子・系統樹、枯株と土壌還元、太陽・月・潮・海・珊瑚・海底RootNetを追加した後継版です。

詳しい比較は [`VERSION_INDEX.md`](VERSION_INDEX.md) を参照してください。

## 収録された封印パッケージ

- [`sealed_packages/v4_fixed/fusa_rootnet_v4_fixed_royal_seal.zip`](sealed_packages/v4_fixed/fusa_rootnet_v4_fixed_royal_seal.zip)
- [`sealed_packages/v4_1_sun_sea/fusa_rootnet_v4_1_sun_sea_royal_seal.zip`](sealed_packages/v4_1_sun_sea/fusa_rootnet_v4_1_sun_sea_royal_seal.zip)

元ZIPのSHA-256は [`SHA256SUMS.txt`](SHA256SUMS.txt)、来歴は [`PROVENANCE.md`](PROVENANCE.md) に記録しています。

## 一括検証

外側manifest、元ZIPのSHA-256、ZIP内部CRC、Pythonコンパイル、両版のユニットテストを一括確認します。

```powershell
python verify_archive.py
```

ハッシュとZIP整合性だけを高速確認する場合:

```powershell
python verify_archive.py --integrity-only
```

確認済みテスト数:

- v4公認修正版: 4件
- v4.1: 6件
- 合計: 10件

## 実行

使用したい内側ZIPだけを別ディレクトリへ展開してください。二つを同じフォルダーへ上書き展開しないでください。

### v4公認修正版

```powershell
python main.py --days 30 --seed 42
python -m unittest -v test_rootnet.py
```

### v4.1

```powershell
py -3 main.py --days 10 --seed 42
py -3 -m unittest -v test_rootnet_v4_1.py
```

同じ保存ファイルで再実行すると、各版のREADMEに記載された保存状態から再開します。

## 決定的ZIPの再生成

```powershell
python build_release.py
```

ファイル順、日時、権限、格納方式を固定しているため、同じファイル内容からは同じ外側ZIPとSHA-256が生成されます。

## 主張範囲

このアーカイブは人工生態系モデルの保全資料です。実在するフサリウム、生態系、海洋、珊瑚、量子生物学を較正・予測するモデルではありません。v4.1の `quantum_harvest` は物語用の簡易的な光捕集効率指標であり、量子状態の計算や量子生物学上の証明ではありません。

ライセンスは推測で追加していません。第三者の再利用を許可する場合は、公開前に明示的な `LICENSE` を選択してください。
