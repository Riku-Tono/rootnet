from __future__ import annotations

import argparse
import hashlib
import zipfile
from pathlib import Path

from make_manifest import IGNORED_PARTS, IGNORED_SUFFIXES, ROOT
from verify_archive import verify_outer_manifest


ARCHIVE_NAME = f"{ROOT.name}.zip"
FIXED_TIMESTAMP = (2026, 8, 18, 0, 0, 0)


def archive_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in IGNORED_PARTS for part in relative.parts):
            continue
        if path.suffix.lower() in IGNORED_SUFFIXES:
            continue
        if path.name == ARCHIVE_NAME:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def write_deterministic_zip(output: Path) -> None:
    temporary = output.with_suffix(output.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_STORED) as archive:
        for path in archive_files():
            relative = path.relative_to(ROOT).as_posix()
            archive_name = f"{ROOT.name}/{relative}"
            info = zipfile.ZipInfo(archive_name, date_time=FIXED_TIMESTAMP)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = (0o100755 if path.suffix == ".py" else 0o100644) << 16
            info.flag_bits |= 0x800
            archive.writestr(info, path.read_bytes())
    temporary.replace(output)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the deterministic RootNet v5 archive ZIP")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT.parent / ARCHIVE_NAME,
        help="output ZIP path; defaults to the archive's parent directory",
    )
    options = parser.parse_args()
    output = options.output.resolve()

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("Refusing to build from an unverified tree")
        return 1

    write_deterministic_zip(output)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(f"Built: {output}")
    print(f"Files: {len(archive_files())}")
    print(f"Bytes: {output.stat().st_size}")
    print(f"SHA-256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
