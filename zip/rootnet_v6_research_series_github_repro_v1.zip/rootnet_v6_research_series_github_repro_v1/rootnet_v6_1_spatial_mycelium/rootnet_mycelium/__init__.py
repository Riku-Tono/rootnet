"""RootNet v6.1 spatial mycelium research kernel."""

from .model import Colony, Genome, Phenotype, Spore, TRAIT_NAMES
from .simulation import MyceliumSimulation, SimulationConfig

__all__ = [
    "Colony",
    "Genome",
    "MyceliumSimulation",
    "Phenotype",
    "SimulationConfig",
    "Spore",
    "TRAIT_NAMES",
]

__version__ = "6.1.0"
