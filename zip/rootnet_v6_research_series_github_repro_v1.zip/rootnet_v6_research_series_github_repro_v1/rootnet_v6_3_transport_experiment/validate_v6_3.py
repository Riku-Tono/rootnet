from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from experiment_v6_3 import derive_evaluation_seeds, run_experiment
from rootnet_v63 import ModuleSimulation, SimulationConfig, TRANSPORT_MODES


def run_validation() -> dict[str, object]:
    mode_results = {}
    replays = {}
    for mode in TRANSPORT_MODES:
        config = SimulationConfig(master_seed=620, ticks=120, transport_mode=mode)
        first = ModuleSimulation(config)
        summary = first.run()
        replay = ModuleSimulation(config)
        replay.run()
        mode_results[mode] = {
            "state_sha256": first.state_digest(),
            "energy_moved": round(sum(r["energy_translocated"] for r in first.tick_records), 12),
            "water_moved": round(sum(r["water_translocated"] for r in first.tick_records), 12),
            "max_abs_energy_transport_error": summary["max_abs_energy_transport_error"],
            "max_abs_water_transport_error": summary["max_abs_water_transport_error"],
            "ever_occupied_cells": summary["ever_occupied_cells"],
            "final_living_modules": summary["final_metrics"]["total_modules"],
        }
        replays[mode] = first.state_digest() == replay.state_digest()

    smoke = run_experiment([620, 621], ticks=60, width=24, height=12, founders=2)
    seeds = derive_evaluation_seeds()
    checks = {
        "exact_replay_all_modes": all(replays.values()),
        "energy_transport_conserved_all_modes": all(
            result["max_abs_energy_transport_error"] < 1e-12
            for result in mode_results.values()
        ),
        "water_transport_conserved_all_modes": all(
            result["max_abs_water_transport_error"] < 1e-12
            for result in mode_results.values()
        ),
        "none_moves_zero_energy": mode_results["none"]["energy_moved"] == 0.0,
        "none_moves_zero_water": mode_results["none"]["water_moved"] == 0.0,
        "equalize_moves_resources": (
            mode_results["equalize"]["energy_moved"] > 0.0
            and mode_results["equalize"]["water_moved"] > 0.0
        ),
        "demand_moves_resources": (
            mode_results["demand"]["energy_moved"] > 0.0
            and mode_results["demand"]["water_moved"] > 0.0
        ),
        "modes_diverge": len({result["state_sha256"] for result in mode_results.values()}) == 3,
        "evaluation_seed_set_is_unique": len(seeds) == len(set(seeds)) == 30,
        "seen_seed_620_is_excluded": 620 not in seeds,
        "paired_smoke_has_all_conditions": set(smoke["runs"]) == set(TRANSPORT_MODES),
        "paired_smoke_has_both_comparisons": set(smoke["comparisons"]) == {"equalize", "demand"},
    }
    if not all(checks.values()):
        raise AssertionError([name for name, passed in checks.items() if not passed])
    return {
        "schema": "rootnet-v6.3-mechanical-validation-v1",
        "status": "PASS",
        "scope": "mechanical validation and development-seed smoke test; not the preregistered evaluation",
        "checks": checks,
        "development_seed_620": mode_results,
        "evaluation_seed_count": len(seeds),
        "evaluation_seed_list_sha256": hashlib.sha256(
            json.dumps(seeds, separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("validation_v6_3.json"))
    options = parser.parse_args()
    result = run_validation()
    options.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
