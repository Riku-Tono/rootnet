from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from make_manifest import MANIFEST, ROOT, included_files


CHECKSUMS = ROOT / "SHA256SUMS.txt"
PACKAGES = (
    (
        "sealed_packages/v4_fixed/fusa_rootnet_v4_fixed_royal_seal.zip",
        "fusa_rootnet_v4_fixed",
        "test_rootnet.py",
        4,
    ),
    (
        "sealed_packages/v4_1_sun_sea/fusa_rootnet_v4_1_sun_sea_royal_seal.zip",
        "fusa_rootnet_v4_1_sun_sea",
        "test_rootnet_v4_1.py",
        6,
    ),
)


def parse_hash_file(path: Path) -> tuple[dict[str, str], list[str]]:
    values: dict[str, str] = {}
    failures: list[str] = []
    if not path.is_file():
        return values, [f"missing hash file: {path.name}"]
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            digest, relative = line.split(" *", 1)
        except ValueError:
            failures.append(f"invalid {path.name} line {line_number}")
            continue
        values[relative] = digest.lower()
    return values, failures


def verify_outer_manifest() -> list[str]:
    expected, failures = parse_hash_file(MANIFEST)
    current = {
        path.relative_to(ROOT).as_posix(): path
        for path in included_files()
    }
    if set(expected) != set(current):
        missing = sorted(set(expected) - set(current))
        extra = sorted(set(current) - set(expected))
        if missing:
            failures.append(f"missing files: {missing}")
        if extra:
            failures.append(f"unmanifested files: {extra}")
    for relative in sorted(set(expected) & set(current)):
        actual = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if actual != expected[relative]:
            failures.append(f"hash mismatch: {relative}")
    return failures


def safe_members(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    members = archive.infolist()
    for member in members:
        path = PurePosixPath(member.filename.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise RuntimeError(f"unsafe ZIP member: {member.filename}")
    return members


def verify_sealed_packages(run_tests: bool) -> None:
    expected, failures = parse_hash_file(CHECKSUMS)
    package_paths = {relative for relative, _, _, _ in PACKAGES}
    if set(expected) != package_paths:
        failures.append("SHA256SUMS.txt package set does not match the archive index")

    for relative, package_root, test_file, expected_tests in PACKAGES:
        path = ROOT / relative
        if not path.is_file():
            failures.append(f"missing sealed package: {relative}")
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected.get(relative) != actual:
            failures.append(f"sealed ZIP hash mismatch: {relative}")
            continue
        with zipfile.ZipFile(path, "r") as archive:
            safe_members(archive)
            corrupt = archive.testzip()
            if corrupt is not None:
                failures.append(f"ZIP CRC failure in {relative}: {corrupt}")
                continue
            roots = {
                PurePosixPath(info.filename.replace("\\", "/")).parts[0]
                for info in archive.infolist()
                if info.filename
            }
            if roots != {package_root}:
                failures.append(f"unexpected top-level paths in {relative}: {sorted(roots)}")

    if failures:
        raise RuntimeError("; ".join(failures))
    print("Sealed ZIP hashes and CRCs: PASS")

    if not run_tests:
        return

    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    environment["PYTHONUTF8"] = "1"
    for relative, package_root, test_file, expected_tests in PACKAGES:
        print(f"\n=== Testing {package_root} ===", flush=True)
        with tempfile.TemporaryDirectory(prefix=f"{package_root}-") as temp_dir:
            with zipfile.ZipFile(ROOT / relative, "r") as archive:
                safe_members(archive)
                archive.extractall(temp_dir)
            package_dir = Path(temp_dir) / package_root
            commands = (
                [sys.executable, "-m", "compileall", "-q", "."],
                [sys.executable, "-m", "unittest", "-v", test_file],
            )
            for command in commands:
                completed = subprocess.run(
                    command,
                    cwd=package_dir,
                    env=environment,
                    check=False,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if completed.stdout:
                    print(completed.stdout.rstrip())
                if completed.stderr:
                    print(completed.stderr.rstrip(), file=sys.stderr)
                if completed.returncode != 0:
                    raise RuntimeError(
                        f"command failed ({completed.returncode}) in {package_root}: {' '.join(command)}"
                    )
            print(f"Expected test count documented for {package_root}: {expected_tests}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the RootNet v4 legacy archive")
    parser.add_argument(
        "--integrity-only",
        action="store_true",
        help="check manifests, inner hashes, and ZIP CRCs without running tests",
    )
    options = parser.parse_args()

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V4 ARCHIVE VERIFICATION: FAIL")
        return 1
    print("Outer manifest: PASS")

    try:
        verify_sealed_packages(run_tests=not options.integrity_only)
    except RuntimeError as error:
        print(f"FAIL: {error}")
        print("ROOTNET V4 ARCHIVE VERIFICATION: FAIL")
        return 1

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V4 ARCHIVE VERIFICATION: FAIL")
        return 1

    print("\nOuter manifest after execution: PASS")
    print("ROOTNET V4 ARCHIVE VERIFICATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
