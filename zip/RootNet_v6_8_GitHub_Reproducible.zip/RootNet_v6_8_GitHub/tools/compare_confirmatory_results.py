from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def scientific_payload(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload.pop("runtime_seconds", None)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare confirmatory outputs while ignoring runtime_seconds."
    )
    parser.add_argument("sealed", type=Path)
    parser.add_argument("reproduced", type=Path)
    args = parser.parse_args()
    matches = scientific_payload(args.sealed) == scientific_payload(args.reproduced)
    print(json.dumps({"scientific_payload": "PASS" if matches else "FAIL"}, indent=2))
    if not matches:
        sys.exit(1)


if __name__ == "__main__":
    main()

