"""RootNet v6.0 minimal evolutionary kernel."""

from .model import Genome, Habitat, Individual, Phenotype, TRAIT_NAMES
from .simulation import EvolutionSimulation, SimulationConfig

__all__ = [
    "EvolutionSimulation",
    "Genome",
    "Habitat",
    "Individual",
    "Phenotype",
    "SimulationConfig",
    "TRAIT_NAMES",
]

__version__ = "6.0.0"
