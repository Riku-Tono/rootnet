# RootNet v6.8 research boundaries

The confirmatory evaluation can establish only whether the fixed `+0.035`
candidate satisfies the predeclared artificial-system criteria in
`EVALUATION_ACCEPTANCE_CRITERIA.json` on completely unused seeds.

It cannot establish:

- a water level suitable for a real fungus;
- natural mortality, growth, branching, or network density;
- universal superiority of fixed or adaptive conductance;
- biological realism from terminal appearance alone;
- cross-platform byte-identical floating-point trajectories.

If any predeclared check fails, the only valid verdict is
`V6_8_LIFT_0_035_NOT_REPRODUCED`. The lift, thresholds, and confirmatory seeds
must not be altered after results are observed.
