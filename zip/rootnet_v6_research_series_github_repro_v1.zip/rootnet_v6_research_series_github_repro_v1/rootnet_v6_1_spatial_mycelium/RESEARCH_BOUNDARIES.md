# Research boundaries

## Implemented mechanisms

Persistent spatial colonies, local hyphal extension and branching, overlapping generations, local resource depletion and recovery, size-dependent maintenance, spore reproduction, immutable lifetime genomes, mutation at reproduction, ancestry, contact-mediated fusion, and conservative fusion transfer.

## Deliberately absent in v6.1

Real DNA or gene-regulatory networks, nuclei and heterokaryosis, meiosis and mating types, enzymes, explicit host organisms, symbiosis, disease, active transport along individual hyphal edges, senescence, tectonic or geological history, named species, and any switch that triggers a predetermined radiation or “Cambrian” event.

## Permitted claim

The package implements and tests a particular artificial spatial-mycelium mechanism with persistent parents and separately recorded colony death and spore establishment failure.

## Not permitted from the included validation run

The included run cannot establish that real fungi evolved by this mechanism, that a fungal-like strategy emerged, that diversity increased generally, or that a historical radiation was reproduced. Such claims require a preregistered comparison, sufficient independent replicates, sensitivity analysis, and an interpretation that stays within the abstraction.
