# RootNet v6.4 simple preregistered protocol

**状態: LOCALLY FROZEN — evaluation seeds sealed, evaluation not run.**

## 主比較

`adaptive-equalize`対`fixed-equalize`。`none`は記述的対照で、主判定に含めない。

## 固定設定

- 通常のv6.3環境
- 42×18
- founder 3
- 360 tick
- `alpha=0.10`
- `weight_min=0.25`
- `weight_max=4.0`
- 2 transport rounds

evaluation modeは、上記設定と以下のseed一覧以外をコード上で拒否する。

## 主指標

1. 全tickの平均生存module数。高い方を有利とする。
2. founder以外の新規占有セル数。高い方を有利とする。

## 解析

各seedで3条件を実行し、`adaptive-fixed`差を計算する。各主指標に両側exact sign testを用い、2検定をHolm補正する。調整p値`<=0.05`かつ有利方向なら`BENEFIT_SUPPORTED`、逆方向なら`HARM_SUPPORTED`、それ以外は`NO_CLEAR_DIFFERENCE`。

`none`との正式検定、環境interaction、ストレス回復解析、追加エンドポイントは行わない。

## Evaluation seed生成規則

namespace:

```text
rootnet-v6.4-simple-preregistered-evaluation-v1
```

zero-based index 0–29について`SHA-256(namespace|index)`を計算し、先頭8 byteをbig-endian整数として読み、`2^31-1`で剰余を取る。0なら1へ置換する。開発seed 640–641との重複とseed間衝突がないことを検査する。

seed-list SHA-256は、空白なしJSON配列のSHA-256として次に固定する。

```text
997ed7c7191e7411fbad7ff151851a599c5920bc5e0aea2f04c649bfc825527f
```

固定seed一覧:

```text
558658846, 1859143500, 35881298, 2076342242, 831379765,
1206319066, 1981507781, 43096249, 2030873992, 2102806815,
1283920925, 1398709744, 1582095204, 1989708013, 920413083,
962501055, 606993588, 747547106, 785455369, 1397622800,
202620881, 1949432271, 93492055, 1907367775, 2007916854,
930069854, 477024243, 390116216, 1849283713, 706639119
```

機械可読版は`evaluation_seeds_v6_4.json`に保存する。封印時点ではこれらのseedを一度もsimulationへ入力していない。

## 回帰と欠損

v6.3回帰は、離散値・ID・座標・イベント列をexact比較し、floatだけ`abs_tol=1e-9`, `rel_tol=0`でfixtureと項目比較する。巨大状態SHA一発判定は用いない。

実行失敗は削除・差し替えず、そのseedと条件を失敗として報告する。プロトコル変更が必要になった場合はevaluationを停止し、変更前後のhashと理由を公開する。

## 主張境界

結論は、この人工環境と更新式内の比較に限定する。実在菌類が同じ更新を行うとは主張しない。
