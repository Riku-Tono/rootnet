from __future__ import annotations

import math
from dataclasses import dataclass

from .geometry import rotate_point
from .model import Edge, Point
from .rng import keyed_rng


ENVIRONMENT_PROFILES = (
    "legacy", "persistent-patch", "slow-moving-patch",
    "abrupt-relocation", "edge-damage",
)
EXPERIMENT_ENVIRONMENTS = tuple(p for p in ENVIRONMENT_PROFILES if p != "legacy")


@dataclass(frozen=True)
class EnvironmentState:
    profile: str
    tick: int
    phase: str
    active_patch_center: Point | None
    previous_patch_center: Point | None
    damage_due: bool


def arena_center(width: int, height: int) -> Point:
    return ((width - 1) / 2.0, (height - 1) / 2.0)


def arena_radius(width: int, height: int, margin: float) -> float:
    return max(1.0, (min(width, height) - 1) / 2.0 - margin)


def in_circular_arena(point: Point, width: int, height: int, margin: float = 0.0) -> bool:
    return math.dist(point, arena_center(width, height)) <= arena_radius(width, height, margin)


def patch_endpoints(width: int, height: int, rotation_angle: float) -> tuple[Point, Point]:
    """Continuous endpoints rotated inside the isotropic assay arena."""

    center = arena_center(width, height)
    radius = arena_radius(width, height, 1.5)
    start = (center[0] - 0.45 * radius, center[1] + 0.25 * radius)
    end = (center[0] + 0.45 * radius, center[1] + 0.25 * radius)
    return (
        rotate_point(start, center, rotation_angle),
        rotate_point(end, center, rotation_angle),
    )


def state_for_tick(
    profile: str, tick: int, *, width: int, height: int,
    move_start_tick: int, move_end_tick: int, relocation_tick: int,
    damage_tick: int, rotation_angle: float,
) -> EnvironmentState:
    if profile not in ENVIRONMENT_PROFILES:
        raise ValueError(f"unknown environment profile: {profile!r}")
    tick = max(0, int(tick))
    start, end = patch_endpoints(width, height, rotation_angle)
    if profile == "legacy":
        return EnvironmentState(profile, tick, "legacy", None, None, False)
    if profile in ("persistent-patch", "edge-damage"):
        phase = "post-damage" if profile == "edge-damage" and tick >= damage_tick else "fixed"
        return EnvironmentState(profile, tick, phase, start, None,
                                profile == "edge-damage" and tick == damage_tick)
    if profile == "abrupt-relocation":
        moved = tick >= relocation_tick
        return EnvironmentState(profile, tick, "relocated" if moved else "pre-relocation",
                                end if moved else start, start if moved else None, False)
    if tick <= move_start_tick:
        center, phase = start, "pre-move"
    elif tick >= move_end_tick:
        center, phase = end, "post-move"
    else:
        fraction = (tick - move_start_tick) / max(1, move_end_tick - move_start_tick)
        center = (start[0] + (end[0] - start[0]) * fraction,
                  start[1] + (end[1] - start[1]) * fraction)
        phase = "moving"
    return EnvironmentState(profile, tick, phase, center,
                            start if math.dist(center, start) > 1e-12 else None, False)


def patch_capacity(base_capacity: float, point: Point, center: Point, *,
                   radius: float, background_scale: float, boost: float) -> float:
    local = max(0.0, 1.0 - math.dist(point, center) / max(radius, 1e-12))
    return max(0.05, min(1.0, base_capacity * background_scale + boost * local))


def in_patch(point: Point, center: Point | None, radius: float) -> bool:
    return center is not None and math.dist(point, center) <= radius


def edge_is_damaged(environment_stream_seed: int, edge: Edge, *,
                    event_tick: int, probability: float) -> bool:
    """Condition-independent failure keyed by stable node IDs, not float strings."""

    if probability <= 0.0:
        return False
    if probability >= 1.0:
        return True
    subject = f"edge-damage|{event_tick}|{edge[0]}|{edge[1]}"
    return keyed_rng(environment_stream_seed, subject).random() < probability
