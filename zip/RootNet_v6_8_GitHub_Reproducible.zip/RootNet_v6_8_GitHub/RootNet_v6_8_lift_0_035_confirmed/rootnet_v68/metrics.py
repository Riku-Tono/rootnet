from __future__ import annotations

import math
import statistics
from collections import Counter

from .model import Genet, Point, Ramet, TRAIT_NAMES


def _mean(values) -> float:
    values = list(values)
    return statistics.fmean(values) if values else 0.0


def _convex_hull(points: list[Point]) -> list[Point]:
    unique = sorted(set(points))
    if len(unique) <= 1:
        return unique

    def cross(o: Point, a: Point, b: Point) -> float:
        return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])

    lower: list[Point] = []
    for point in unique:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0.0:
            lower.pop()
        lower.append(point)
    upper: list[Point] = []
    for point in reversed(unique):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0.0:
            upper.pop()
        upper.append(point)
    return lower[:-1] + upper[:-1]


def _polygon_area(points: list[Point]) -> float:
    if len(points) < 3:
        return 0.0
    return 0.5 * abs(sum(
        points[i][0] * points[(i+1) % len(points)][1]
        - points[(i+1) % len(points)][0] * points[i][1]
        for i in range(len(points))
    ))


def _spatial_shape(points: list[Point]) -> tuple[float, float, float]:
    if not points:
        return 0.0, 0.0, 0.0
    cx, cy = _mean(p[0] for p in points), _mean(p[1] for p in points)
    xx = _mean((p[0]-cx)**2 for p in points)
    yy = _mean((p[1]-cy)**2 for p in points)
    xy = _mean((p[0]-cx)*(p[1]-cy) for p in points)
    trace = xx + yy
    root = math.sqrt(max(0.0, (xx-yy)**2 + 4.0*xy**2))
    major, minor = (trace + root) / 2.0, (trace - root) / 2.0
    anisotropy = (major - minor) / max(major + minor, 1e-15)
    radius_of_gyration = math.sqrt(max(0.0, trace))
    max_radius = max(math.dist((cx, cy), point) for point in points)
    return radius_of_gyration, max_radius, anisotropy


def network_metrics(ramets: list[Ramet], genets: dict[str, Genet],
                    detritus: list[list[float]]) -> dict[str, object]:
    living = [r for r in ramets if r.alive and r.nodes]
    living_genet_ids = {r.genet_id for r in living}
    nodes = [node for ramet in living for node in ramet.nodes.values()]
    positions = [node.position for node in nodes]
    lengths = [
        math.dist(ramet.nodes[left].position, ramet.nodes[right].position)
        for ramet in living for left, right in ramet.edges
    ]
    degree_counts: Counter[tuple[str, str]] = Counter()
    branch_angles: list[float] = []
    for ramet in living:
        adjacency = {node_id: [] for node_id in ramet.nodes}
        for left, right in ramet.edges:
            degree_counts[(ramet.ramet_id, left)] += 1
            degree_counts[(ramet.ramet_id, right)] += 1
            adjacency[left].append(right)
            adjacency[right].append(left)
        for node_id, neighbors in adjacency.items():
            if len(neighbors) < 2:
                continue
            center = ramet.nodes[node_id].position
            headings = sorted(math.atan2(ramet.nodes[n].position[1]-center[1],
                                         ramet.nodes[n].position[0]-center[0])
                              for n in neighbors)
            for i in range(len(headings)):
                delta = (headings[(i+1) % len(headings)] - headings[i]) % (2.0*math.pi)
                branch_angles.append(math.degrees(delta))
    trait_means = {name: _mean(getattr(genets[g].genome, name) for g in living_genet_ids)
                   for name in TRAIT_NAMES}
    trait_variances = {name: _mean((getattr(genets[g].genome, name)-trait_means[name])**2
                                   for g in living_genet_ids)
                       for name in TRAIT_NAMES}
    radius_gyration, max_radius, anisotropy = _spatial_shape(positions)
    return {
        "living_genets": len(living_genet_ids), "living_ramets": len(living),
        "total_modules": len(nodes), "total_edges": len(lengths),
        "total_hyphal_length": round(sum(lengths), 9),
        "mean_edge_length": round(_mean(lengths), 9),
        "max_edge_length": round(max(lengths, default=0.0), 9),
        "total_tips": sum(len(r.tips) for r in living),
        "branch_modules": sum(degree >= 3 for degree in degree_counts.values()),
        "cycle_rank": sum(max(0, len(r.edges)-len(r.nodes)+1) for r in living),
        "convex_hull_area": round(_polygon_area(_convex_hull(positions)), 9),
        "radius_of_gyration": round(radius_gyration, 9),
        "max_radial_extent": round(max_radius, 9),
        "spatial_anisotropy": round(anisotropy, 9),
        "mean_branch_angle_degrees": round(_mean(branch_angles), 9),
        "weakened_modules": sum(node.vitality < 0.55 for node in nodes),
        "critical_modules": sum(node.vitality < 0.25 for node in nodes),
        "mean_vitality": round(_mean(node.vitality for node in nodes), 9),
        "mean_local_energy": round(_mean(node.energy for node in nodes), 9),
        "mean_local_water": round(_mean(node.water for node in nodes), 9),
        "oldest_module_age": max((node.age for node in nodes), default=0),
        "detritus_cells": sum(v > 0.0 for row in detritus for v in row),
        "blocked_detritus_cells": sum(v >= 0.20 for row in detritus for v in row),
        "extant_lineages": len({genets[g].lineage_id for g in living_genet_ids}),
        "trait_means": {name: round(value, 9) for name, value in trait_means.items()},
        "trait_variances": {name: round(value, 9) for name, value in trait_variances.items()},
        "phenotypic_disparity": round(math.sqrt(_mean(trait_variances.values())), 9),
    }
