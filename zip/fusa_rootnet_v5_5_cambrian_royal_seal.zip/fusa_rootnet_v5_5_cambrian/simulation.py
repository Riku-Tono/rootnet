from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

from models import (
    EnvironmentalMemory,
    CambrianAbilities,
    FusaGene,
    FusaSeed,
    FusaTraits,
    PlantCondition,
    MarineState,
    SensoryState,
    SolarState,
    StressRecord,
    Weather,
    clamp,
)


@dataclass
class DailyReport:
    plant_id: str
    day: int
    season: str
    weather: Weather
    stress: StressRecord | None
    growth: float
    fusa_level: float
    condition_before: PlantCondition
    condition_after: PlantCondition
    seed: FusaSeed | None
    senses: SensoryState
    population_pressure: float
    active_abilities: list[str]


class FusaPlant:
    SEASONS = ["🌱 芽吹き", "🌿 育ち", "🍀 実り", "🍂 休み"]
    DAYS_PER_SEASON = 30
    REPRODUCTION_MIN_AGE = 20
    REPRODUCTION_MIN_FUSA = 55.0
    REPRODUCTION_COOLDOWN = 12

    def __init__(
        self,
        name: str = "フサリ姫",
        generation: int = 1,
        genes: list[FusaGene] | None = None,
        memory: EnvironmentalMemory | None = None,
        rng_seed: int | None = None,
        plant_id: str | None = None,
        lineage: str = "memory",
        district: str = "中央庭園",
        elder: bool = False,
        parent_id: str | None = None,
        ancestor_id: str | None = None,
        birth_day: int = 0,
        chirality: str = "L",
        traits: FusaTraits | None = None,
        abilities: CambrianAbilities | None = None,
    ) -> None:
        self.name = name
        self.plant_id = plant_id or name
        self.lineage = lineage
        self.district = district
        self.elder = elder
        self.parent_id = parent_id
        self.ancestor_id = ancestor_id or self.plant_id
        self.birth_day = birth_day
        self.chirality = "D" if chirality == "D" else "L"
        self.child_ids: list[str] = []
        self.received_signals: dict[str, float] = {}
        self.alive = True
        self.death_day: int | None = None
        self.death_reason: str | None = None
        self.corpse_stage = "生存"
        self.decomposition_progress = 0.0
        self.soil_returned = 0.0
        self.last_senses = SensoryState()
        self.generation = generation
        self.age = 0
        self.day = 0
        self.fusa_level = 5.0
        self._rng = random.Random(rng_seed)
        self.genes = genes or [self._random_gene(self._rng) for _ in range(3)]
        self.traits = traits or self._random_traits(self._rng, lineage)
        self.traits.normalize()
        self.abilities = abilities or self._latent_abilities(
            self._rng,
            self.traits,
            lineage,
            self.chirality,
        )
        self.abilities.normalize()
        self.condition = PlantCondition()
        self.memory = memory or EnvironmentalMemory()
        self.weather_history: list[dict[str, Any]] = []
        self.stress_history: list[StressRecord] = []
        self.offspring: list[FusaSeed] = []
        self.last_reproduction_day = -10_000

    @staticmethod
    def _random_gene(rng: random.Random) -> FusaGene:
        gene = FusaGene(
            growth_speed=rng.gauss(1.0, 0.2),
            dew_affinity=rng.uniform(0.7, 1.3),
            wind_resistance=rng.uniform(0.7, 1.3),
            sunlight_love=rng.uniform(0.8, 1.5),
            patience=rng.uniform(0.9, 1.5),
        )
        gene.normalize()
        return gene

    @staticmethod
    def _random_traits(rng: random.Random, lineage: str) -> FusaTraits:
        traits = FusaTraits(
            mobility=rng.uniform(0.05, 0.48),
            armor=rng.uniform(0.12, 0.58),
            deep_rooting=rng.uniform(0.18, 0.68),
            symbiosis=rng.uniform(0.22, 0.72),
            thermal_regulation=rng.uniform(0.12, 0.56),
            signal_bridge=rng.uniform(0.02, 0.30),
        )
        if lineage == "sea":
            traits.mobility += 0.24
            traits.symbiosis += 0.18
        elif lineage == "coastal":
            traits.thermal_regulation += 0.16
            traits.mobility += 0.10
        elif lineage == "aqua":
            traits.deep_rooting += 0.16
        elif lineage == "amber":
            traits.armor += 0.14
        elif lineage == "elder":
            traits.deep_rooting += 0.25
            traits.signal_bridge += 0.18
        traits.normalize()
        return traits

    @staticmethod
    def _latent_abilities(
        rng: random.Random,
        traits: FusaTraits,
        lineage: str,
        chirality: str,
    ) -> CambrianAbilities:
        abilities = CambrianAbilities(
            mobility=traits.mobility * 0.70,
            armor=traits.armor * 0.70,
            parasitism=rng.uniform(0.02, 0.24),
            predation=rng.uniform(0.01, 0.20),
            bioluminescence=rng.uniform(0.03, 0.28),
            deep_rooting=traits.deep_rooting * 0.70,
            false_signal=rng.uniform(0.01, 0.22),
            mirror_bridge=traits.signal_bridge * 0.80,
        )
        if lineage == "sea":
            abilities.mobility += 0.18
            abilities.bioluminescence += 0.22
        elif lineage == "coastal":
            abilities.armor += 0.12
        elif lineage == "aqua":
            abilities.deep_rooting += 0.15
        elif lineage == "amber":
            abilities.armor += 0.16
        if chirality == "D":
            abilities.mirror_bridge += 0.18
            abilities.false_signal += 0.10
        abilities.normalize()
        return abilities

    @property
    def mean_gene(self) -> FusaGene:
        count = len(self.genes)
        return FusaGene(
            growth_speed=sum(g.growth_speed for g in self.genes) / count,
            dew_affinity=sum(g.dew_affinity for g in self.genes) / count,
            wind_resistance=sum(g.wind_resistance for g in self.genes) / count,
            sunlight_love=sum(g.sunlight_love for g in self.genes) / count,
            patience=sum(g.patience for g in self.genes) / count,
        )

    def generate_weather(self, season_index: int) -> Weather:
        bases = [
            (0.58, 0.65, 0.68, 0.35),
            (0.78, 0.92, 0.48, 0.42),
            (0.68, 0.72, 0.36, 0.58),
            (0.38, 0.42, 0.45, 0.72),
        ]
        temperature, sunlight, rainfall, wind = bases[season_index]
        return Weather(
            temperature=clamp(self._rng.gauss(temperature, 0.16), 0.0, 1.2),
            sunlight=clamp(self._rng.gauss(sunlight, 0.18), 0.0, 1.2),
            rainfall=clamp(self._rng.gauss(rainfall, 0.22), 0.0, 1.2),
            wind_speed=clamp(self._rng.gauss(wind, 0.20), 0.0, 1.3),
        )

    def sense_environment(
        self,
        weather: Weather,
        marine: MarineState | None,
    ) -> SensoryState:
        wave_touch = 0.0
        if marine is not None and self.lineage in {"sea", "coastal"}:
            wave_touch = marine.wave_strength * 0.7
        senses = SensoryState(
            warmth=clamp(weather.temperature, 0.0, 1.0),
            cold=clamp(1.0 - weather.temperature, 0.0, 1.0),
            touch=clamp(weather.wind_speed * 0.55 + wave_touch, 0.0, 1.0),
        )
        self.last_senses = senses
        return senses

    def detect_environmental_stress(
        self,
        weather: Weather,
        senses: SensoryState,
        marine: MarineState | None,
        cambrian_active: bool = False,
    ) -> StressRecord | None:
        candidates: list[tuple[str, str, float]] = []
        if weather.rainfall < 0.2:
            candidates.append(("drought", "🌵 乾燥", 1.0 - weather.rainfall))
        if weather.wind_speed > 0.75:
            candidates.append(("strong_wind", "🌬️ 強風", weather.wind_speed))
        if weather.sunlight < 0.25:
            candidates.append(("shade", "🌥️ 日陰", 1.0 - weather.sunlight))
        if weather.temperature > 0.8:
            candidates.append(("heat", "☀️ 猛暑", weather.temperature))
        if weather.temperature < 0.20:
            candidates.append(("cold", "❄️ 寒冷", 1.0 - weather.temperature))
        if senses.touch > 0.82:
            candidates.append(("touch", "〰️ 強い接触", senses.touch))
        if marine is not None and self.lineage in {"sea", "coastal"}:
            preferred = 0.70 if self.lineage == "sea" else 0.52
            salinity_gap = abs(marine.salinity - preferred)
            if salinity_gap > 0.18:
                candidates.append(("salinity", "🧂 塩分差", salinity_gap * 2.2))
        if not candidates:
            return None

        stress_type, display_name, intensity = max(candidates, key=lambda item: item[2])
        intensity = clamp(intensity, 0.1, 1.5)
        memory_level = self.memory.get(stress_type)
        trait_mitigation = self.traits.armor * 0.18
        if cambrian_active:
            trait_mitigation += self.abilities.armor * 0.24
        if stress_type in {"heat", "cold"}:
            trait_mitigation += self.traits.thermal_regulation * 0.28
        elif stress_type == "drought":
            trait_mitigation += self.traits.deep_rooting * 0.20
        elif stress_type in {"touch", "strong_wind"}:
            trait_mitigation += self.traits.mobility * 0.08
        effective = intensity * (1.0 - memory_level * 0.5) * (
            1.0 - clamp(trait_mitigation, 0.0, 0.65)
        )
        mitigation = 1.0 - (effective / intensity)
        return StressRecord(
            day=self.day,
            stress_type=stress_type,
            display_name=display_name,
            intensity=intensity,
            effective_intensity=effective,
            mitigation=mitigation,
        )

    def apply_stress_to_condition(self, stress: StressRecord) -> None:
        x = stress.effective_intensity
        if stress.stress_type == "drought":
            self.condition.hydration -= 0.30 * x
            self.condition.health -= 0.07 * x
        elif stress.stress_type == "strong_wind":
            resistance = clamp(self.mean_gene.wind_resistance / 1.4, 0.3, 1.0)
            self.condition.damage += 0.22 * x * (1.2 - resistance)
            self.condition.health -= 0.08 * x * (1.2 - resistance)
        elif stress.stress_type == "shade":
            self.condition.energy -= 0.28 * x
        elif stress.stress_type == "heat":
            self.condition.hydration -= 0.18 * x
            self.condition.energy -= 0.12 * x
            self.condition.health -= 0.05 * x
        elif stress.stress_type == "cold":
            self.condition.energy -= 0.18 * x
            self.condition.health -= 0.04 * x
        elif stress.stress_type == "touch":
            self.condition.damage += 0.08 * x
            self.condition.energy -= 0.04 * x
        elif stress.stress_type == "salinity":
            self.condition.hydration -= 0.16 * x
            self.condition.health -= 0.05 * x
        self.condition.normalize()

    def calculate_growth(
        self,
        season_index: int,
        weather: Weather,
        solar: SolarState | None,
        marine: MarineState | None,
        population_pressure: float,
        cambrian_active: bool,
    ) -> float:
        gene = self.mean_gene
        quantum_harvest = solar.quantum_harvest if solar is not None else 1.0
        daylight_factor = solar.day_length / 12.0 if solar is not None else 1.0
        light_gain = (
            weather.sunlight
            * gene.sunlight_love
            * 0.35
            * quantum_harvest
            * daylight_factor
        )
        water_gain = weather.rainfall * gene.dew_affinity * 0.28
        water_gain += self.traits.deep_rooting * 0.035
        if cambrian_active:
            water_gain += self.abilities.deep_rooting * 0.040
        marine_growth = 1.0
        if marine is not None and self.lineage == "sea":
            water_gain += 0.24
            marine_growth = 0.70 + marine.nutrients * 0.60
        elif marine is not None and self.lineage == "coastal":
            water_gain += marine.tide_level * 0.08
            marine_growth = 0.90 + marine.nutrients * 0.20
        self.condition.energy = clamp(self.condition.energy + light_gain, 0.0, 1.0)
        self.condition.hydration = clamp(self.condition.hydration + water_gain, 0.0, 1.0)

        season_factor = [1.1, 1.2, 0.9, 0.55][season_index]
        vitality = (
            self.condition.health
            * self.condition.hydration
            * self.condition.energy
            * (1.0 - self.condition.damage * 0.7)
        )
        crowding_factor = clamp(1.15 - population_pressure * 0.42, 0.30, 1.0)
        trait_growth = (
            0.92
            + self.traits.symbiosis * 0.16
            + self.traits.thermal_regulation * 0.05
            - self.traits.armor * 0.04
        )
        if cambrian_active:
            trait_growth += self.abilities.bioluminescence * 0.035
            trait_growth -= self.abilities.armor * 0.025
        desired = (
            gene.growth_speed
            * season_factor
            * vitality
            * 2.2
            * marine_growth
            * crowding_factor
            * trait_growth
        )
        energy_limited = self.condition.energy / 0.22
        growth = max(0.0, min(desired, energy_limited))

        self.condition.energy = clamp(self.condition.energy - growth * 0.22, 0.0, 1.0)
        self.condition.hydration = clamp(self.condition.hydration - growth * 0.10, 0.0, 1.0)
        self.fusa_level = min(100.0, self.fusa_level + growth)
        return growth

    def recover_condition(self, season_index: int) -> None:
        gene = self.mean_gene
        rest_factor = 1.5 if season_index == 3 else 1.0
        recovery = 0.025 * gene.patience * rest_factor
        self.condition.health += recovery
        self.condition.damage -= recovery * 0.8
        self.condition.hydration += 0.015 * rest_factor
        self.condition.energy += 0.012 * rest_factor
        self.condition.normalize()

    def natural_lifespan(self) -> int:
        """系統ごとの目安寿命。長老は既存の樹齢を十分に超えて生きられる。"""
        if self.elder or self.lineage == "elder":
            return int(600 * 365 * (1.0 + self.traits.thermal_regulation * 0.10))
        if self.lineage in {"aqua", "amber"}:
            return int(720 * (1.0 + self.traits.thermal_regulation * 0.12))
        return int(540 * (1.0 + self.traits.thermal_regulation * 0.12))

    def apply_aging(self) -> None:
        lifespan = self.natural_lifespan()
        aging_start = int(lifespan * 0.72)
        if self.age > aging_start:
            progress = (self.age - aging_start) / max(1, lifespan - aging_start)
            self.condition.health -= 0.003 + 0.012 * clamp(progress, 0.0, 1.5)
            self.condition.damage += 0.002 + 0.008 * clamp(progress, 0.0, 1.5)
            self.condition.normalize()

        if self.age >= lifespan:
            self.mark_dead("寿命を全うした")
        elif self.condition.health <= 0.02:
            self.mark_dead("体力が尽きた")

    def mark_dead(self, reason: str) -> None:
        if not self.alive:
            return
        self.alive = False
        self.death_day = self.day
        self.death_reason = reason
        self.corpse_stage = "新しい枯株"

    def create_seed(self) -> FusaSeed:
        inherited: list[FusaGene] = []
        for parent_gene in self.genes:
            child = FusaGene(
                growth_speed=parent_gene.growth_speed + self._rng.gauss(0.0, abs(parent_gene.growth_speed) * 0.05),
                dew_affinity=parent_gene.dew_affinity + self._rng.gauss(0.0, abs(parent_gene.dew_affinity) * 0.05),
                wind_resistance=parent_gene.wind_resistance + self._rng.gauss(0.0, abs(parent_gene.wind_resistance) * 0.05),
                sunlight_love=parent_gene.sunlight_love + self._rng.gauss(0.0, abs(parent_gene.sunlight_love) * 0.05),
                patience=parent_gene.patience + self._rng.gauss(0.0, abs(parent_gene.patience) * 0.04),
            )
            child.normalize()
            inherited.append(child)

        seed_number = len(self.offspring) + 1
        return FusaSeed(
            name=f"{self.name}の種{seed_number}",
            parent_name=self.name,
            generation=self.generation + 1,
            genes=inherited,
            memory=self.memory.primed_copy(0.15),
            born_day=self.day,
        )

    def attempt_reproduction(self, population_pressure: float = 0.0) -> FusaSeed | None:
        eligible = (
            self.age >= self.REPRODUCTION_MIN_AGE
            and self.fusa_level >= self.REPRODUCTION_MIN_FUSA
            and self.condition.health >= 0.75
            and self.condition.energy >= 0.35
            and self.day - self.last_reproduction_day >= self.REPRODUCTION_COOLDOWN
        )
        reproduction_chance = 0.28 * clamp(1.25 - population_pressure * 0.55, 0.05, 1.0)
        if not eligible or self._rng.random() >= reproduction_chance:
            return None
        seed = self.create_seed()
        self.offspring.append(seed)
        self.last_reproduction_day = self.day
        self.condition.energy = clamp(self.condition.energy - 0.18, 0.0, 1.0)
        return seed

    def receive_signal(self, signal_type: str, strength: float) -> None:
        self.received_signals[signal_type] = max(self.received_signals.get(signal_type, 0.0), strength)

    def apply_network_preparation(self) -> None:
        rain = self.received_signals.get("rain_coming", 0.0)
        drought = self.received_signals.get("water_shortage", 0.0)
        pests = self.received_signals.get("pest_alert", 0.0)
        season = self.received_signals.get("season_shift", 0.0)
        high_tide = self.received_signals.get("high_tide", 0.0)
        sea_nutrients = self.received_signals.get("sea_nutrients", 0.0)
        self.condition.hydration += rain * 0.025
        self.condition.hydration -= drought * 0.010
        self.condition.energy -= pests * 0.008
        self.condition.health += season * 0.004 * self.mean_gene.patience
        if self.lineage in {"sea", "coastal"}:
            self.condition.hydration += high_tide * 0.020
            self.condition.energy += sea_nutrients * 0.018
        self.condition.normalize()

    def daily_growth(
        self,
        weather: Weather | None = None,
        solar: SolarState | None = None,
        marine: MarineState | None = None,
        population_pressure: float = 0.0,
        cambrian_active: bool = False,
    ) -> DailyReport:
        if not self.alive:
            raise RuntimeError(f"死亡済みの株は成長できません: {self.plant_id}")

        self.day += 1
        season_index = ((self.day - 1) // self.DAYS_PER_SEASON) % len(self.SEASONS)
        season = self.SEASONS[season_index]
        before = PlantCondition.from_dict(self.condition.to_dict())

        self.apply_network_preparation()
        weather = weather or self.generate_weather(season_index)
        senses = self.sense_environment(weather, marine)
        stress = self.detect_environmental_stress(
            weather,
            senses,
            marine,
            cambrian_active,
        )
        if stress:
            self.apply_stress_to_condition(stress)
            self.memory.learn(stress.stress_type, stress.intensity)
            self.stress_history.append(stress)

        growth = self.calculate_growth(
            season_index,
            weather,
            solar,
            marine,
            population_pressure,
            cambrian_active,
        )
        self.recover_condition(season_index)
        self.age += 1
        self.apply_aging()
        seed = self.attempt_reproduction(population_pressure) if self.alive else None
        self.weather_history.append({"day": self.day, **weather.to_dict()})

        after = PlantCondition.from_dict(self.condition.to_dict())
        self.received_signals.clear()
        return DailyReport(
            plant_id=self.plant_id,
            day=self.day,
            season=season,
            weather=weather,
            stress=stress,
            growth=growth,
            fusa_level=self.fusa_level,
            condition_before=before,
            condition_after=after,
            seed=seed,
            senses=senses,
            population_pressure=population_pressure,
            active_abilities=(
                self.abilities.active_names()
                if cambrian_active
                else []
            ),
        )
