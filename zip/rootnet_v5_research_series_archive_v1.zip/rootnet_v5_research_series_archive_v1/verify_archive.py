from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from make_manifest import MANIFEST, ROOT, included_files


CHECKSUMS = ROOT / "SHA256SUMS.txt"


@dataclass(frozen=True)
class ModelPackage:
    relative_zip: str
    package_root: str
    expected_tests: int
    validation: str | None = None


MODEL_PACKAGES = (
    ModelPackage(
        "sealed_packages/v5_mirror_succession/fusa_rootnet_v5_mirror_succession_royal_seal.zip",
        "fusa_rootnet_v5_mirror_succession",
        7,
    ),
    ModelPackage(
        "sealed_packages/v5_5_cambrian/fusa_rootnet_v5_5_cambrian_royal_seal.zip",
        "fusa_rootnet_v5_5_cambrian",
        5,
    ),
    ModelPackage(
        "sealed_packages/v5_6_ecology/fusa_rootnet_v5_6_ecology_royal_seal.zip",
        "fusa_rootnet_v5_6_ecology",
        7,
    ),
    ModelPackage(
        "sealed_packages/v5_6_1_biosecurity/fusa_rootnet_v5_6_1_biosecurity_royal_seal.zip",
        "fusa_rootnet_v5_6_1_biosecurity",
        9,
    ),
    ModelPackage(
        "sealed_packages/v5_7_living_presence/fusa_rootnet_v5_7_living_presence_royal_seal.zip",
        "fusa_rootnet_v5_7_lifelog",
        17,
    ),
    ModelPackage(
        "sealed_packages/v5_7_1_environment_lifelog/fusa_rootnet_v5_7_1_environment_lifelog_royal_seal.zip",
        "fusa_rootnet_v5_7_1_lifelog",
        23,
    ),
    ModelPackage(
        "sealed_packages/v5_7_2_cooperation_experiment/fusa_rootnet_v5_7_2_cooperation_experiment_harness.zip",
        "fusa_rootnet_v5_7_2_cooperation_experiment",
        31,
        "v5.7.2",
    ),
    ModelPackage(
        "sealed_packages/v5_8_0_biological_model/fusa_rootnet_v5_8_0_biological_model_royal_seal.zip",
        "fusa_rootnet_v5_8_0_biological_model",
        36,
        "v5.8.0",
    ),
    ModelPackage(
        "sealed_packages/v5_8_0_biological_model/fusa_rootnet_v5_8_0_biological_model_english_royal_seal.zip",
        "fusa_rootnet_v5_8_0_biological_model_en",
        36,
        "v5.8.0",
    ),
)

RESULTS_ZIP = (
    "sealed_packages/v5_7_2_cooperation_experiment/"
    "fusa_rootnet_v5_7_2_cooperation_ab_100pairs_results.zip"
)
RESULTS_ROOT = "rootnet_v5_7_2_cooperation_ab_100pairs"


def parse_hash_file(path: Path) -> tuple[dict[str, str], list[str]]:
    values: dict[str, str] = {}
    failures: list[str] = []
    if not path.is_file():
        return values, [f"missing hash file: {path.name}"]
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            digest, relative = line.split(" *", 1)
        except ValueError:
            failures.append(f"invalid {path.name} line {line_number}")
            continue
        values[relative] = digest.lower()
    return values, failures


def verify_outer_manifest() -> list[str]:
    expected, failures = parse_hash_file(MANIFEST)
    current = {
        path.relative_to(ROOT).as_posix(): path
        for path in included_files()
    }
    if set(expected) != set(current):
        missing = sorted(set(expected) - set(current))
        extra = sorted(set(current) - set(expected))
        if missing:
            failures.append(f"missing files: {missing}")
        if extra:
            failures.append(f"unmanifested files: {extra}")
    for relative in sorted(set(expected) & set(current)):
        actual = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if actual != expected[relative]:
            failures.append(f"hash mismatch: {relative}")
    return failures


def safe_members(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    members = archive.infolist()
    for member in members:
        path = PurePosixPath(member.filename.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise RuntimeError(f"unsafe ZIP member: {member.filename}")
    return members


def run_command(command: list[str], cwd: Path) -> tuple[str, str]:
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    environment["PYTHONUTF8"] = "1"
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if completed.returncode != 0:
        if completed.stdout:
            print(completed.stdout.rstrip())
        if completed.stderr:
            print(completed.stderr.rstrip(), file=sys.stderr)
        raise RuntimeError(
            f"command failed ({completed.returncode}) in {cwd.name}: {' '.join(command)}"
        )
    return completed.stdout, completed.stderr


def verify_sealed_integrity() -> None:
    expected, failures = parse_hash_file(CHECKSUMS)
    package_roots = {
        package.relative_zip: package.package_root for package in MODEL_PACKAGES
    }
    package_roots[RESULTS_ZIP] = RESULTS_ROOT
    if set(expected) != set(package_roots):
        failures.append("SHA256SUMS.txt package set does not match the archive index")

    for relative, expected_root in package_roots.items():
        path = ROOT / relative
        if not path.is_file():
            failures.append(f"missing sealed package: {relative}")
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected.get(relative) != actual:
            failures.append(f"sealed ZIP hash mismatch: {relative}")
            continue
        with zipfile.ZipFile(path, "r") as archive:
            safe_members(archive)
            corrupt = archive.testzip()
            if corrupt is not None:
                failures.append(f"ZIP CRC failure in {relative}: {corrupt}")
                continue
            roots = {
                PurePosixPath(info.filename.replace("\\", "/")).parts[0]
                for info in archive.infolist()
                if info.filename
            }
            if roots != {expected_root}:
                failures.append(f"unexpected top-level paths in {relative}: {sorted(roots)}")
    if failures:
        raise RuntimeError("; ".join(failures))
    print("Sealed ZIP hashes and CRCs: PASS")


def verify_model_package(package: ModelPackage) -> None:
    print(f"\n=== Testing {package.package_root} ===", flush=True)
    with tempfile.TemporaryDirectory(prefix=f"{package.package_root}-") as temp_dir:
        with zipfile.ZipFile(ROOT / package.relative_zip, "r") as archive:
            safe_members(archive)
            archive.extractall(temp_dir)
        package_dir = Path(temp_dir) / package.package_root
        run_command([sys.executable, "-m", "compileall", "-q", "."], package_dir)
        stdout, stderr = run_command(
            [sys.executable, "-m", "unittest", "discover", "-v"], package_dir
        )
        match = re.search(r"Ran (\d+) tests? in", stdout + "\n" + stderr)
        if match is None or int(match.group(1)) != package.expected_tests:
            raise RuntimeError(
                f"unexpected test count for {package.package_root}: "
                f"expected {package.expected_tests}, output={match.group(1) if match else 'missing'}"
            )
        print(f"Unit tests: PASS ({package.expected_tests})")

        if package.validation == "v5.7.2":
            stdout, _ = run_command([sys.executable, "validate_v5_7_2.py"], package_dir)
            validation = json.loads(stdout)
            if validation.get("pass") is not True:
                raise RuntimeError("v5.7.2 sealed mechanism validation failed")
            print("v5.7.2 sealed mechanism validation: PASS")
        elif package.validation == "v5.8.0":
            stdout, _ = run_command([sys.executable, "validate_v5_8_0.py"], package_dir)
            validation = json.loads(stdout)
            if validation.get("all_checks_passed") is not True:
                raise RuntimeError(f"v5.8.0 validation failed for {package.package_root}")
            if validation.get("tests", {}).get("run") != 36:
                raise RuntimeError(f"v5.8.0 validation test count mismatch for {package.package_root}")
            print("v5.8.0 320-day sealed validation: PASS")


def verify_results_reanalysis() -> None:
    print("\n=== Reanalyzing v5.7.2 100-pair results ===", flush=True)
    expected_hashes = {
        "full_ab_100pairs_320days.json": "f314cce11d5b21559ccc7e2ced96f5be2fb9ed3f6f707970df45c446d54c70ee",
        "full_ab_100pairs_analysis.json": "7f3c6e81a43ff41495f964aa8f78ba6abdfd72d1767a5dca2a7c80e4011b874e",
        "FULL_AB_REPORT.md": "d4fb76fe4628a8eeff459fe519bbcee07032700e84a8422cc32dc6be679fa165",
    }
    with tempfile.TemporaryDirectory(prefix="rootnet-v572-results-") as temp_dir:
        with zipfile.ZipFile(ROOT / RESULTS_ZIP, "r") as archive:
            safe_members(archive)
            archive.extractall(temp_dir)
        results_dir = Path(temp_dir) / RESULTS_ROOT
        for name, expected in expected_hashes.items():
            actual = hashlib.sha256((results_dir / name).read_bytes()).hexdigest()
            if actual != expected:
                raise RuntimeError(f"sealed result hash mismatch: {name}")

        output_dir = Path(temp_dir) / "reanalysis"
        output_dir.mkdir()
        output_json = output_dir / "full_ab_100pairs_analysis.json"
        output_report = output_dir / "FULL_AB_REPORT.md"
        run_command(
            [
                sys.executable,
                "analyze_full_ab.py",
                "--input",
                "full_ab_100pairs_320days.json",
                "--repeat",
                "repeat_ab_seeds_0_29_81.json",
                "--output-json",
                str(output_json),
                "--output-md",
                str(output_report),
            ],
            results_dir,
        )
        if output_json.read_bytes() != (results_dir / output_json.name).read_bytes():
            raise RuntimeError("reproduced A/B analysis JSON differs from sealed file")
        if output_report.read_bytes() != (results_dir / output_report.name).read_bytes():
            raise RuntimeError("reproduced A/B report differs from sealed file")
    print("A/B analysis JSON and report exact reproduction: PASS")


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the RootNet v5 archive")
    parser.add_argument(
        "--integrity-only",
        action="store_true",
        help="check manifests, inner hashes, and ZIP CRCs without running models",
    )
    options = parser.parse_args()

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V5 ARCHIVE VERIFICATION: FAIL")
        return 1
    print("Outer manifest: PASS")

    try:
        verify_sealed_integrity()
        if not options.integrity_only:
            for package in MODEL_PACKAGES:
                verify_model_package(package)
            verify_results_reanalysis()
    except (RuntimeError, json.JSONDecodeError, zipfile.BadZipFile) as error:
        print(f"FAIL: {error}")
        print("ROOTNET V5 ARCHIVE VERIFICATION: FAIL")
        return 1

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V5 ARCHIVE VERIFICATION: FAIL")
        return 1

    print("\nOuter manifest after execution: PASS")
    print("ROOTNET V5 ARCHIVE VERIFICATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
