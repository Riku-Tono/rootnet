from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

from models import InfrastructureState, Weather, clamp
from network import RootNet, RootSignal
from simulation import DailyReport, FusaPlant


LINEAGE_NAMES = {
    "aqua": "💧 Aqua Fusa",
    "amber": "🔥 Amber Fusa",
    "memory": "🌿 Memory Fusa",
    "elder": "⚡ 長老フサ",
}


@dataclass
class EcosystemReport:
    day: int
    weather: Weather
    signals: list[RootSignal]
    plant_reports: list[DailyReport]
    water_cleaned: float
    fuel_collected: float
    pests_removed: float
    seeds_distributed: int
    new_plant_ids: list[str]
    deaths: list[tuple[str, str]]


class FusaEcosystem:
    MAX_LIVING_PLANTS = 200

    def __init__(self, name: str = "王立フサ生態基盤", rng_seed: int | None = None) -> None:
        self.name = name
        self.day = 0
        self.plants: dict[str, FusaPlant] = {}
        self.rootnet = RootNet()
        self.infrastructure = InfrastructureState()
        self.event_history: list[dict[str, Any]] = []
        self.next_plant_serial = 1
        self._rng = random.Random(rng_seed)

    @classmethod
    def demo(cls, rng_seed: int | None = None) -> "FusaEcosystem":
        eco = cls(rng_seed=rng_seed)
        specs = [
            ("elder-001", "北境の長老フサ", "elder", "北の森", True),
            ("aqua-001", "水路守アクア", "aqua", "水門区", False),
            ("aqua-002", "澄根ミズハ", "aqua", "下流水路", False),
            ("amber-001", "琥珀葉アンバー", "amber", "陽だまり丘", False),
            ("memory-001", "フサリ姫", "memory", "中央庭園", False),
            ("memory-002", "風聞きトフトフ", "memory", "西の野", False),
        ]
        for i, (pid, name, lineage, district, elder) in enumerate(specs):
            plant = FusaPlant(name=name, plant_id=pid, lineage=lineage, district=district,
                              elder=elder, rng_seed=None if rng_seed is None else rng_seed + i)
            if elder:
                plant.age = 300 * 365
                plant.fusa_level = 100.0
            eco.add_plant(plant)
        for left, right, conductivity in [
            ("elder-001", "aqua-001", 0.95), ("elder-001", "memory-001", 0.92),
            ("aqua-001", "aqua-002", 0.88), ("aqua-001", "amber-001", 0.72),
            ("memory-001", "memory-002", 0.84), ("memory-002", "amber-001", 0.76),
        ]:
            eco.rootnet.connect(left, right, conductivity)
        return eco

    def add_plant(self, plant: FusaPlant) -> None:
        self.plants[plant.plant_id] = plant
        if plant.alive:
            self.rootnet.add_node(plant.plant_id)

    def living_plants(self) -> list[FusaPlant]:
        return [plant for plant in self.plants.values() if plant.alive]

    def generate_shared_weather(self) -> Weather:
        season_index = (self.day - 1) % 4
        living = self.living_plants()
        if not living:
            raise RuntimeError("生存株がなく、共有天候を生成できません。")
        anchor = living[0]
        return anchor.generate_weather(season_index)

    def _elder_signals(self, weather: Weather) -> list[RootSignal]:
        elders = [p for p in self.living_plants() if p.elder]
        if not elders:
            return []
        origin = elders[0].plant_id
        candidates: list[RootSignal] = []
        if weather.rainfall > 0.72:
            candidates.append(RootSignal(self.day, "rain_coming", "北から雨。", weather.rainfall, origin, 5))
        if weather.rainfall < 0.22:
            candidates.append(RootSignal(self.day, "water_shortage", "水、浅し。", 1.0 - weather.rainfall, origin, 5))
        if self.infrastructure.pest_pressure > 0.58:
            candidates.append(RootSignal(self.day, "pest_alert", "葉裏、動く。", self.infrastructure.pest_pressure, origin, 4))
        if self.day % 4 == 1:
            candidates.append(RootSignal(self.day, "season_shift", "季、移る。", 0.55, origin, 5))
        return candidates[:2]

    def _broadcast(self, signals: list[RootSignal]) -> None:
        for signal in signals:
            for receipt in self.rootnet.broadcast(signal):
                plant = self.plants.get(receipt.plant_id)
                if plant is not None and plant.alive and receipt.distance > 0:
                    plant.receive_signal(receipt.signal_type, receipt.strength)

    def _infrastructure_cycle(self, weather: Weather, reports: list[DailyReport]) -> tuple[float, float, float, int]:
        living = self.living_plants()
        aqua = [p for p in living if p.lineage == "aqua"]
        amber = [p for p in living if p.lineage == "amber"]
        healthy = lambda p: p.condition.health * p.condition.energy

        water_cleaned = sum(0.012 * healthy(p) * p.mean_gene.dew_affinity for p in aqua)
        water_cost = sum(0.010 * (1.25 - p.condition.hydration) for p in aqua)
        self.infrastructure.water_quality += water_cleaned
        self.infrastructure.water_reserve += weather.rainfall * 0.06 - water_cost

        autumn = (self.day - 1) % 4 == 3
        fuel_collected = 0.0
        if autumn:
            fuel_collected = sum(0.8 * healthy(p) * p.mean_gene.sunlight_love for p in amber)
            self.infrastructure.amber_fuel += fuel_collected

        ladybeetle_activity = 0.020 * len(living) * self.infrastructure.pollination
        spider_warning_bonus = 0.008 * len(self.rootnet.signal_history[-3:])
        pests_removed = ladybeetle_activity + spider_warning_bonus
        self.infrastructure.pest_pressure += self._rng.uniform(-0.015, 0.045) - pests_removed
        self.infrastructure.pollination += 0.006 * len(amber) - 0.004 * self.infrastructure.pest_pressure

        born = sum(1 for report in reports if report.seed is not None)
        mouse_distributed = 0
        if born and self._rng.random() < 0.65:
            mouse_distributed = born

        self.infrastructure.normalize()
        return water_cleaned, fuel_collected, pests_removed, mouse_distributed

    def _germinate_seeds(
        self,
        parents: list[FusaPlant],
        reports: list[DailyReport],
        mouse_distributed: int,
    ) -> list[str]:
        born = [
            (parent, report.seed)
            for parent, report in zip(parents, reports)
            if report.seed is not None
        ]
        new_ids: list[str] = []
        for index, (parent, seed) in enumerate(born):
            if len(self.living_plants()) >= self.MAX_LIVING_PLANTS:
                self.infrastructure.seed_bank += 1
                continue

            plant_id = f"sprout-{self.next_plant_serial:06d}"
            self.next_plant_serial += 1
            moved_by_mouse = index < mouse_distributed
            district = f"{parent.district}外縁" if moved_by_mouse else parent.district
            child = FusaPlant(
                name=seed.name,
                plant_id=plant_id,
                lineage=parent.lineage,
                district=district,
                elder=False,
                generation=seed.generation,
                genes=seed.genes,
                # 種の記録は誕生時のスナップショットとして固定し、
                # 発芽後の学習で書き換わらないよう別オブジェクトにする。
                memory=seed.memory.primed_copy(1.0),
                rng_seed=self._rng.randrange(0, 2**63),
            )
            self.add_plant(child)
            self.rootnet.connect(
                parent.plant_id,
                child.plant_id,
                0.58 if moved_by_mouse else 0.78,
            )
            new_ids.append(child.plant_id)

        self.infrastructure.normalize()
        return new_ids

    def step(self) -> EcosystemReport:
        self.day += 1
        parents = self.living_plants()
        if not parents:
            raise RuntimeError("生存株がありません。王国の系統は途絶えました。")
        weather = self.generate_shared_weather()
        signals = self._elder_signals(weather)
        self._broadcast(signals)
        reports = [plant.daily_growth(weather=weather) for plant in parents]
        water, fuel, pests, seeds = self._infrastructure_cycle(weather, reports)
        new_plant_ids = self._germinate_seeds(parents, reports, seeds)
        deaths: list[tuple[str, str]] = []
        for plant in parents:
            if not plant.alive:
                reason = plant.death_reason or "不明"
                deaths.append((plant.plant_id, reason))
                self.rootnet.remove_node(plant.plant_id)
        self.event_history.append({
            "day": self.day,
            "signals": [signal.to_dict() for signal in signals],
            "water_quality": self.infrastructure.water_quality,
            "water_reserve": self.infrastructure.water_reserve,
            "amber_fuel": self.infrastructure.amber_fuel,
            "pest_pressure": self.infrastructure.pest_pressure,
            "seed_bank": self.infrastructure.seed_bank,
            "new_plant_ids": new_plant_ids,
            "deaths": [
                {"plant_id": plant_id, "reason": reason}
                for plant_id, reason in deaths
            ],
        })
        return EcosystemReport(
            self.day,
            weather,
            signals,
            reports,
            water,
            fuel,
            pests,
            seeds,
            new_plant_ids,
            deaths,
        )
