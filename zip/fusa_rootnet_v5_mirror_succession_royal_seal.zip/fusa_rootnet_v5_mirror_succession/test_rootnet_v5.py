from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from models import FusaTraits, SensoryState, StoredSeed, Weather
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV5Tests(unittest.TestCase):
    def test_mirror_founder_and_cross_chirality_link(self) -> None:
        ecosystem = FusaEcosystem.demo(42)
        mirror = ecosystem.plants["mirror-001"]
        self.assertEqual("D", mirror.chirality)
        conductivity = ecosystem.rootnet.links["elder-001"]["mirror-001"]
        self.assertLess(conductivity, 0.30)

    def test_mirror_seed_keeps_chirality_and_inherits_traits(self) -> None:
        ecosystem = FusaEcosystem.demo(1)
        parent = ecosystem.plants["mirror-001"]
        packet = StoredSeed(
            seed_id="mirror-seed-test",
            seed=parent.create_seed(),
            parent_id=parent.plant_id,
            lineage=parent.lineage,
            district=parent.district,
            stored_day=0,
            chirality=parent.chirality,
            traits=ecosystem._inherit_traits(parent),
        )
        ecosystem.seed_inventory.append(packet)
        ecosystem.day = 3
        ecosystem._rng.seed(1)
        new_ids = ecosystem._germinate_seed_inventory()
        self.assertEqual(1, len(new_ids))
        child = ecosystem.plants[new_ids[0]]
        self.assertEqual("D", child.chirality)
        self.assertEqual(parent.plant_id, child.parent_id)
        self.assertIsInstance(child.traits, FusaTraits)

    def test_dynamic_capacity_changes_with_environment(self) -> None:
        ecosystem = FusaEcosystem.demo(7)
        ecosystem.infrastructure.water_quality = 0.10
        ecosystem.infrastructure.water_reserve = 0.10
        ecosystem.infrastructure.soil_nutrients = 0.10
        ecosystem.infrastructure.pest_pressure = 0.95
        ecosystem.marine_state.nutrients = 0.10
        ecosystem.solar_state.irradiance = 0.10
        for coral in ecosystem.corals.values():
            coral.health = 0.10
        low = ecosystem.carrying_capacity()

        ecosystem.infrastructure.water_quality = 1.0
        ecosystem.infrastructure.water_reserve = 1.0
        ecosystem.infrastructure.soil_nutrients = 1.0
        ecosystem.infrastructure.pest_pressure = 0.0
        ecosystem.marine_state.nutrients = 1.0
        ecosystem.solar_state.irradiance = 1.0
        for coral in ecosystem.corals.values():
            coral.health = 1.0
        high = ecosystem.carrying_capacity()
        self.assertGreater(high, low)

    def test_armor_and_thermal_traits_reduce_stress(self) -> None:
        weather = Weather(temperature=0.95, sunlight=0.8, rainfall=0.5, wind_speed=0.3)
        senses = SensoryState(warmth=0.95, cold=0.05, touch=0.2)
        unarmored = FusaPlant(
            rng_seed=10,
            traits=FusaTraits(armor=0.0, thermal_regulation=0.0),
        )
        protected = FusaPlant(
            rng_seed=10,
            traits=FusaTraits(armor=1.0, thermal_regulation=1.0),
        )
        weak = unarmored.detect_environmental_stress(weather, senses, None)
        strong = protected.detect_environmental_stress(weather, senses, None)
        self.assertIsNotNone(weak)
        self.assertIsNotNone(strong)
        self.assertLess(strong.effective_intensity, weak.effective_intensity)

    def test_elder_death_elects_successor(self) -> None:
        ecosystem = FusaEcosystem.demo(17)
        elder = ecosystem.plants["elder-001"]
        elder.age = elder.natural_lifespan() - 1
        report = ecosystem.step()
        self.assertFalse(elder.alive)
        self.assertIsNotNone(report.elder_successor_id)
        successor = ecosystem.plants[report.elder_successor_id]
        self.assertTrue(successor.elder)
        self.assertTrue(successor.alive)

    def test_mirror_corpse_decomposes_more_slowly(self) -> None:
        ecosystem = FusaEcosystem.demo(33)
        normal = ecosystem.plants["memory-001"]
        mirror = ecosystem.plants["mirror-001"]
        normal.mark_dead("試験")
        mirror.mark_dead("試験")
        weather = Weather(temperature=0.6, sunlight=0.5, rainfall=0.5, wind_speed=0.2)
        ecosystem._decomposition_cycle(weather)
        self.assertLess(mirror.decomposition_progress, normal.decomposition_progress)

    def test_save_resume_matches_continuous_run(self) -> None:
        continuous = FusaEcosystem.demo(2718)
        for _ in range(60):
            continuous.step()

        split = FusaEcosystem.demo(2718)
        for _ in range(30):
            split.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "rootnet_v5.json"
            save_ecosystem_atomic(split, path)
            resumed = load_ecosystem(path, 2718)
            for _ in range(30):
                resumed.step()

        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))


if __name__ == "__main__":
    unittest.main()
