# RootNet v6.6 r2 preregistered rotation protocol

## Status and revision history

Implementation and development-only mechanism validation are complete.
Confirmatory evaluation remains `SEALED_NOT_RUN`; zero evaluation-seed runs have
been started.

v6.6 r2 is a provenance-only revision of sealed v6.6 r1. It adds the missing
machine-readable record of the development mechanism audit described below. No
model, statistic, geometry, ecological parameter, endpoint, or evaluation-seed
change was made.

During the r1 development mechanism
audit using only seeds 660–661 at confirmatory-equivalent geometry
(`360 ticks / 42×42 / 3 founders`), `cumulative_active_patch_uptake` was zero in
20/20 runs. It was therefore mechanically non-informative. This removal was made
before confirmatory evaluation and was not selected from a favorable effect size or
result. Patch position, patch radius, founder placement, arena geometry, and all
other ecological parameters remain unchanged. No replacement endpoint is added.

The uptake quantity remains recorded as an auxiliary diagnostic.

The 20-run audit is sealed as
`confirmatory_geometry_development_audit_v6_6_r2.json`. It covers exactly two
development seeds × two transport modes × five angles. The file records
`SEALED_NOT_RUN` and zero evaluation-seed runs.

## Conditions

- angles: `0, 22.5, 45, 67.5, 90` degrees;
- transport: `fixed-equalize`, `adaptive-equalize`;
- 30 paired seeds sealed in `evaluation_seeds_v6_6.json`;
- 360 ticks, 42×42 circular arena, 3 founders;
- total if later authorized: 300 condition runs.

The evaluation seeds must not be used for development, pilot, parameter selection,
or mechanism validation.

## Confirmatory primary endpoints

1. `mean_living_modules`;
2. `mean_total_hyphal_length`;
3. `mean_convex_hull_area`.

`cumulative_active_patch_uptake` is auxiliary only.

## Zero-safe equivalence rule

For each transport mode, nonzero angle, and primary endpoint, paired values are
compared with positive-only log ratios `log(rotated / baseline)`. No pseudocount is
used.

- Any `0 / 0`, `0 / positive`, or `positive / 0` pair makes that comparison
  `UNDEFINED_ZERO_ENDPOINT`; no log-ratio CI or equivalence classification is made.
- Otherwise the comparison requires at least 80% of all pairs and never fewer than
  two informative positive pairs: `max(2, ceil(0.80 × total_pairs))`.
- For the sealed 30-pair evaluation the minimum is therefore 24.
- Below the required count, classification is
  `INSUFFICIENT_INFORMATIVE_PAIRS` and no CI is reported.
- With sufficient positive pairs, the existing classifications remain
  `EQUIVALENT_WITHIN_5_PERCENT`, `OUTSIDE_5_PERCENT_MARGIN`, and `INCONCLUSIVE`.

Equivalence requires the normal 95% paired-log-ratio interval to lie fully inside
`[-log(1.05), +log(1.05)]`.

## Growth candidate RNG revision

Candidate heading offset and score jitter use a deterministic keyed stream:

```text
candidate | tick | ramet_id | tip_id | attempt | candidate_index
```

This prevents rejection of one candidate from advancing the draws of another
candidate in the same event. It is a local pairing improvement only; v6.6 r2 does
not claim complete history-wide common-random-number pairing after growth histories
diverge.
