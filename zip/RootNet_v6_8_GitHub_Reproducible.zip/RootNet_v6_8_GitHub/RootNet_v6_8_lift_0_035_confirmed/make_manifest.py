from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.txt"


def included_files(
    root: Path = ROOT,
    manifest: Path | None = None,
) -> list[Path]:
    manifest = manifest or root / MANIFEST.name
    return sorted(
        path for path in root.rglob("*")
        if path.is_file()
        and path != manifest
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
        and not path.name.startswith("RootNet_v6_8_lift_0_035_confirmed.zip")
        and not path.name.startswith("RootNet_v6_8_lift_0_035_confirmed_SHA256")
    )


def main() -> None:
    lines = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()} *{path.relative_to(ROOT).as_posix()}"
        for path in included_files(ROOT, MANIFEST)
    ]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"Wrote {len(lines)} RootNet v6.8 entries to {MANIFEST.name}")


if __name__ == "__main__":
    main()
