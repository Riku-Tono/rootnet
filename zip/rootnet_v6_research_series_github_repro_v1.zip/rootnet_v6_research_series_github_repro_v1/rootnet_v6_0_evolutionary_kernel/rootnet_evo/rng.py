from __future__ import annotations

import hashlib
import random


STREAM_NAMES = (
    "environment",
    "demography",
    "mutation",
    "dispersal",
    "density",
)


def derive_seed(master_seed: int, stream_name: str) -> int:
    payload = f"RootNet-v6.0|{int(master_seed)}|{stream_name}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def make_streams(master_seed: int) -> tuple[dict[str, int], dict[str, random.Random]]:
    seeds = {name: derive_seed(master_seed, name) for name in STREAM_NAMES}
    return seeds, {name: random.Random(seed) for name, seed in seeds.items()}
