# RootNet v6.8 `+0.035` candidate model specification

The candidate inherits the v6.6 r2 continuous-coordinate model and the v6.7
diagnostic implementation. The sole dynamics change from the `v66-radial`
control is:

```text
v68_water = clamp(v66_water + 0.035, 0.08, 1.00)
```

The identifier is `v68-radial-lift-0.035`. The lift applies to base water
capacity and the water stock initialized from that capacity. It does not alter
substrate, patch geometry, growth, branching, transport, conductance, local
metabolism, immediate necrosis, detritus, spores, fusion, rotation, or keyed
randomness.

The confirmatory comparison fixes `necrosis_grace_ticks=0`, a 42×42 circular
arena, three founders, 360 ticks, and rotation 0°. It pairs `v66-radial` and
`v68-radial-lift-0.035` under fixed and adaptive equalization transport.

`watch.py` draws edges and modules on a higher-width terminal canvas. The
observer is read-only and cannot alter dynamics.
