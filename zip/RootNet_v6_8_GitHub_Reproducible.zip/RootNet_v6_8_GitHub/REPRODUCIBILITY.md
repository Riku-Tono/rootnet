# Reproducibility

This repository bundles the exact sealed RootNet v6.8 confirmatory package,
its source code, predeclared protocol and acceptance criteria, critical-code
seal, unused seed list, all 120 run records, and validation tools.

The confirmed package is in `RootNet_v6_8_lift_0_035_confirmed/`.

## 1. Verify the repository and sealed package

From the repository root:

```powershell
python tools/verify_repository.py
```

This checks every repository file against `SHA256SUMS.txt`, then runs the
confirmed package's manifest check, 17 unit tests, sealed validation
reproduction, artifact-integrity check, and reference-runtime regression.

The reference runtime was Windows 11 x86-64 with CPython 3.14.5. Integrity and
numerical/runtime regression are intentionally reported separately.

## 2. Re-run the sealed confirmatory experiment

```powershell
cd RootNet_v6_8_lift_0_035_confirmed
python confirmatory_v6_8.py --output reproduced_confirmatory_evaluation_v6_8.json
cd ..
python tools/compare_confirmatory_results.py `
  RootNet_v6_8_lift_0_035_confirmed/confirmatory_evaluation_v6_8.json `
  RootNet_v6_8_lift_0_035_confirmed/reproduced_confirmatory_evaluation_v6_8.json
```

The comparison ignores only `runtime_seconds`, which necessarily varies by
machine. Every scientific result, individual run record, and acceptance check
must match. Delete the reproduced JSON afterward if you want the repository
checksum check to return to its sealed state.

## 3. Rebuild the GitHub archive byte-for-byte

```powershell
python tools/build_github_archive.py `
  --output RootNet_v6_8_GitHub_Reproducible.zip
```

The builder sorts paths and fixes the archive root, timestamps, UTF-8 flags,
and file permissions. Entries are deliberately stored without compression so
the ZIP bytes do not depend on a zlib version. An unchanged tree therefore
produces the same SHA-256 across repeated builds.

## Scope of the claim

The package confirms fixed artificial-system engineering criteria. It does
not calibrate RootNet to a real fungal species or establish a natural
mortality rate. The proposed temporal/spatial insurance framing remains an
interpretive hypothesis; connectivity was not tested as a causal mediator.

