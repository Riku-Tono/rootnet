import json
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt


def clamp(value: float, minimum: float, maximum: float) -> float:
    """値を指定範囲へ収める。"""
    return max(minimum, min(maximum, value))


@dataclass
class FusaGene:
    """環境ストレスへ応答するフサ遺伝子。"""

    growth_speed: float
    dew_affinity: float
    wind_resistance: float
    sunlight_love: float
    patience: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaGene":
        return cls(**data)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def apply_stress(
        self,
        stress_type: str,
        intensity: float,
    ) -> None:
        """
        環境ストレスによる一時的な損傷と適応を遺伝形質へ反映する。

        これは現実の遺伝学というより、獲得形質を含む
        王国式の育成シミュレーションである。
        """
        if stress_type == "drought":
            # 乾燥で朝露利用能力が一時的に損なわれる一方、
            # 忍耐力は少し高まる。
            self.dew_affinity -= intensity * 0.15
            self.patience += intensity * 0.08

        elif stress_type == "strong_wind":
            # 強風による損傷と、それに対抗する成長反応。
            self.wind_resistance -= intensity * 0.12
            self.growth_speed += intensity * 0.06

        elif stress_type == "shade":
            # 日陰環境へ適応し、少ない光でも待てるようになる。
            self.sunlight_love -= intensity * 0.18
            self.patience += intensity * 0.10

        elif stress_type == "heat":
            # 猛暑で成長が鈍るが、水分利用能力が少し高まる。
            self.growth_speed -= intensity * 0.10
            self.dew_affinity += intensity * 0.07

        self.normalize()

    def normalize(self) -> None:
        """遺伝形質が極端な値へ暴走しないよう制限する。"""
        self.growth_speed = clamp(self.growth_speed, 0.4, 1.8)
        self.dew_affinity = clamp(self.dew_affinity, 0.3, 1.8)
        self.wind_resistance = clamp(self.wind_resistance, 0.4, 1.8)
        self.sunlight_love = clamp(self.sunlight_love, 0.5, 2.0)
        self.patience = clamp(self.patience, 0.6, 2.0)


@dataclass
class StressRecord:
    """一日に発生した環境ストレスの記録。"""

    day: int
    stress_type: str
    display_name: str
    intensity: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StressRecord":
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class FusaPlant:
    """環境ストレスへ適応しながら育つ王国植物。"""

    STRESS_PROBABILITY = 0.45
    NORMAL_MUTATION_PROBABILITY = 0.07
    STRESS_MUTATION_PROBABILITY = 0.12

    SEASONS = [
        "🌱 芽吹き",
        "🌿 育ち",
        "🍀 実り",
        "🍂 休み",
    ]

    STRESSES = [
        ("drought", "🌵 乾燥"),
        ("strong_wind", "🌬️ 強風"),
        ("shade", "🌥️ 日陰"),
        ("heat", "☀️ 猛暑"),
    ]

    def __init__(
        self,
        name: str = "フサリ姫",
        save_file: str = "fusa_gene_stress.json",
    ):
        self.name = name
        self.save_file = Path(save_file)

        self.genes: list[FusaGene] = []
        self.fusa_level = 5.0
        self.history = [5.0]
        self.day = 0
        self.stress_history: list[StressRecord] = []

        self.load()

    def load(self) -> None:
        """保存済みの植物を読み込む。"""
        if not self.save_file.exists():
            self._initialize_new_plant()
            return

        try:
            with self.save_file.open("r", encoding="utf-8") as file:
                data = json.load(file)

            self.name = data.get("name", self.name)
            self.genes = [
                FusaGene.from_dict(gene_data)
                for gene_data in data["genes"]
            ]
            self.fusa_level = float(data.get("fusa_level", 5.0))
            self.history = [
                float(value)
                for value in data.get("history", [self.fusa_level])
            ]
            self.day = int(data.get("day", 0))
            self.stress_history = [
                StressRecord.from_dict(record)
                for record in data.get("stress_history", [])
            ]

            if len(self.genes) != 3:
                raise ValueError("フサ遺伝子は3系統必要です。")

            print(
                f"🌱 保存された {self.name} を読み込みました"
                f"（第{self.day}日）"
            )

        except (
            OSError,
            KeyError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ) as exc:
            print(f"⚠️ 保存データを読めませんでした: {exc}")
            print("🌱 新しいフサリ姫を育成します。")
            self._initialize_new_plant()

    def _initialize_new_plant(self) -> None:
        """新しい植物と三つの遺伝子を生成する。"""
        self.genes = [self._random_gene() for _ in range(3)]
        self.fusa_level = 5.0
        self.history = [5.0]
        self.day = 0
        self.stress_history = []

    @staticmethod
    def _random_gene() -> FusaGene:
        gene = FusaGene(
            growth_speed=random.gauss(1.0, 0.25),
            dew_affinity=random.uniform(0.6, 1.4),
            wind_resistance=random.uniform(0.7, 1.4),
            sunlight_love=random.uniform(0.8, 1.6),
            patience=random.uniform(0.9, 1.5),
        )
        gene.normalize()
        return gene

    def save(self) -> None:
        """一時ファイルを経由して安全に保存する。"""
        data = {
            "schema_version": 2,
            "name": self.name,
            "genes": [gene.to_dict() for gene in self.genes],
            "fusa_level": self.fusa_level,
            "history": self.history,
            "day": self.day,
            "stress_history": [
                record.to_dict()
                for record in self.stress_history
            ],
        }

        temporary_path = self.save_file.with_suffix(
            self.save_file.suffix + ".tmp"
        )

        try:
            with temporary_path.open("w", encoding="utf-8") as file:
                json.dump(data, file, ensure_ascii=False, indent=2)
                file.flush()

            temporary_path.replace(self.save_file)

        except OSError as exc:
            temporary_path.unlink(missing_ok=True)
            raise RuntimeError(
                f"{self.name} の保存に失敗しました。"
            ) from exc

        print(f"💾 {self.name} の遺伝子とストレス史を保存しました")

    def apply_environmental_stress(
        self,
    ) -> StressRecord | None:
        """一定確率で環境ストレスを発生させる。"""
        if random.random() >= self.STRESS_PROBABILITY:
            return None

        stress_type, display_name = random.choice(self.STRESSES)
        intensity = random.uniform(0.6, 1.4)

        print(
            f"⚠️ {display_name}ストレス発生！"
            f"（強さ {intensity:.1f}）"
        )

        for gene in self.genes:
            gene.apply_stress(stress_type, intensity)

        record = StressRecord(
            day=self.day,
            stress_type=stress_type,
            display_name=display_name,
            intensity=intensity,
        )
        self.stress_history.append(record)

        return record

    def calculate_growth(
        self,
        season_index: int,
        stress: StressRecord | None,
    ) -> float:
        """季節とストレスに基づく一日の成長量を計算する。"""
        total_growth = 0.0

        for gene in self.genes:
            expression = gene.growth_speed

            if season_index == 0:
                expression *= gene.dew_affinity

            elif season_index == 1:
                expression *= gene.sunlight_love

            elif season_index == 2:
                expression *= 0.9

            else:
                expression *= gene.patience * 0.6

            # 強風時は耐風性が成長維持率として働く。
            if stress and stress.stress_type == "strong_wind":
                expression *= clamp(
                    gene.wind_resistance,
                    0.4,
                    1.5,
                )

            # 乾燥時は朝露利用能力が高い個体ほど耐えやすい。
            elif stress and stress.stress_type == "drought":
                expression *= clamp(
                    gene.dew_affinity * 0.8,
                    0.3,
                    1.2,
                )

            # 日陰時は光への依存が強すぎる個体ほど不利になる。
            elif stress and stress.stress_type == "shade":
                shade_tolerance = 1.5 - gene.sunlight_love * 0.35
                expression *= clamp(shade_tolerance, 0.4, 1.1)

            # 猛暑時は忍耐力が成長維持に寄与する。
            elif stress and stress.stress_type == "heat":
                expression *= clamp(
                    gene.patience * 0.75,
                    0.4,
                    1.2,
                )

            total_growth += expression

        fluctuation = random.gauss(0.0, 0.4)
        return max(0.0, total_growth + fluctuation)

    def attempt_mutation(
        self,
        under_stress: bool,
    ) -> None:
        """通常時またはストレス下で突然変異を試みる。"""
        probability = (
            self.STRESS_MUTATION_PROBABILITY
            if under_stress
            else self.NORMAL_MUTATION_PROBABILITY
        )

        if random.random() >= probability:
            return

        index = random.randrange(len(self.genes))
        old_gene = self.genes[index]

        # 完全置換ではなく、親遺伝子を基礎に変異させる。
        mutation_scale = 0.14 if under_stress else 0.08

        new_gene = FusaGene(
            growth_speed=old_gene.growth_speed
            + random.gauss(0.0, mutation_scale),
            dew_affinity=old_gene.dew_affinity
            + random.gauss(0.0, mutation_scale),
            wind_resistance=old_gene.wind_resistance
            + random.gauss(0.0, mutation_scale),
            sunlight_love=old_gene.sunlight_love
            + random.gauss(0.0, mutation_scale),
            patience=old_gene.patience
            + random.gauss(0.0, mutation_scale * 0.7),
        )
        new_gene.normalize()
        self.genes[index] = new_gene

        if under_stress:
            print(
                f"🧬 ストレス下で第{index + 1}遺伝子が"
                "大きくフサリフサリ変化！"
            )
        else:
            print(
                f"🧬 第{index + 1}遺伝子に"
                "静かなフサリフサリ変異が発生。"
            )

    def daily_growth(self) -> tuple[float, str]:
        """王国植物を一日育てる。"""
        self.day += 1

        season_index = (self.day - 1) % len(self.SEASONS)
        current_season = self.SEASONS[season_index]

        stress = self.apply_environmental_stress()
        daily_fusa = self.calculate_growth(
            season_index,
            stress,
        )

        previous_fusa = self.fusa_level
        self.fusa_level = min(
            100.0,
            self.fusa_level + daily_fusa,
        )
        actual_growth = self.fusa_level - previous_fusa

        self.history.append(self.fusa_level)
        self.attempt_mutation(under_stress=stress is not None)

        if previous_fusa < 100.0 <= self.fusa_level:
            print("🍀 総フサ度100達成！ 王国全土に祝賀のトストス！")

        return actual_growth, current_season

    def visualize(self) -> None:
        """成長とストレス発生日をグラフへ記録する。"""
        days = list(range(len(self.history)))

        plt.figure(figsize=(12, 7))
        plt.plot(
            days,
            self.history,
            marker="o",
            linewidth=3,
            markersize=6,
            label="フサ度",
        )
        plt.axhline(
            y=100,
            linestyle="--",
            alpha=0.7,
            label="最大フサ度",
        )

        for record in self.stress_history:
            if 0 <= record.day < len(self.history):
                plt.axvline(
                    x=record.day,
                    alpha=0.3,
                    linestyle=":",
                )
                plt.text(
                    record.day,
                    min(self.history[record.day] + 2, 98),
                    record.display_name,
                    rotation=90,
                    fontsize=9,
                )

        plt.title(
            f"{self.name} のフサフサ成長記録"
            "（環境ストレス適応）\n"
            f"第{self.day}日　現在のフサ度: "
            f"{self.fusa_level:.1f}",
            fontsize=16,
        )
        plt.xlabel("日数")
        plt.ylabel("フサ度")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.fill_between(days, self.history, alpha=0.2)
        plt.tight_layout()
        plt.savefig("fusa_today.png", dpi=220)
        plt.close()

        print("📸 ストレス適応グラフを更新しました")


def read_days() -> int:
    """育成日数を安全に読み取る。"""
    raw_value = input(
        "何日育てますか？（ストレス多めがおすすめ） → "
    ).strip()

    if not raw_value:
        return 10

    try:
        days = int(raw_value)
    except ValueError:
        print("⚠️ 数字ではなかったため、10日育てます。")
        return 10

    return max(1, min(days, 365))


def main() -> None:
    print("🌱 王立フサ王国 環境ストレス研究所 🌱\n")

    plant = FusaPlant(name="フサリ姫")
    days = read_days()

    for _ in range(days):
        growth, season = plant.daily_growth()

        print(
            f"第{plant.day}日 {season} "
            f"→ +{growth:.2f}フサ "
            f"現在値: {plant.fusa_level:.1f}"
        )

        plant.visualize()
        time.sleep(0.7)

    plant.save()

    print(
        "\n🌿 今日も王国は環境ストレスに負けず、"
        "少しずつフサフサになりました。"
    )
    print("トストス。🌿")


if __name__ == "__main__":
    main()
