from __future__ import annotations

import argparse
import hashlib
import zipfile
from pathlib import Path

from make_manifest import MANIFEST, ROOT, included_files


ARCHIVE_ROOT = "RootNet_v6_8_lift_0_035_confirmed"


def build(output: Path) -> tuple[Path, Path, str]:
    if not MANIFEST.is_file():
        raise RuntimeError("MANIFEST_SHA256.txt is missing; run make_manifest.py first")
    files = included_files(ROOT, MANIFEST) + [MANIFEST]
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files):
            relative = path.relative_to(ROOT).as_posix()
            archive.write(path, f"{ARCHIVE_ROOT}/{relative}")
    digest = hashlib.sha256(output.read_bytes()).hexdigest().upper()
    checksum = output.with_name(output.stem+"_SHA256.txt")
    checksum.write_text(f"{digest}  {output.name}\n", encoding="ascii", newline="\n")
    return output, checksum, digest


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the RootNet v6.8 +0.035 package ZIP")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output, checksum, digest = build(args.output)
    print(f"ZIP: {output.resolve()}")
    print(f"SHA256: {digest}")
    print(f"Checksum: {checksum.resolve()}")


if __name__ == "__main__":
    main()
