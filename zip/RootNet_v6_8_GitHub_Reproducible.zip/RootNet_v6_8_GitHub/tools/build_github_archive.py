from __future__ import annotations

import argparse
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = "RootNet_v6_8_GitHub"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
EXCLUDED_DIRS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache"}
EXCLUDED_NAMES = {
    "RootNet_v6_8_GitHub_Reproducible.zip",
    "RootNet_v6_8_GitHub_Reproducible_SHA256.txt",
}


def included_files(output: Path) -> list[Path]:
    output = output.resolve()
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.resolve() == output:
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.name in EXCLUDED_NAMES or path.suffix in {".pyc", ".pyo"}:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def build(output: Path) -> None:
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "w", compression=ZIP_STORED) as archive:
        for path in included_files(output):
            relative = path.relative_to(ROOT).as_posix()
            info = ZipInfo(f"{ARCHIVE_ROOT}/{relative}", date_time=FIXED_TIME)
            info.compress_type = ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.flag_bits |= 0x800
            archive.writestr(info, path.read_bytes())
    print(output)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the deterministic GitHub ZIP.")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    build(args.output)


if __name__ == "__main__":
    main()

