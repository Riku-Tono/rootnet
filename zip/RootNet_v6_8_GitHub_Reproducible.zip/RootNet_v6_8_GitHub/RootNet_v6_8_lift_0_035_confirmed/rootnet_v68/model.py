from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


Point = tuple[float, float]
NodeId = str
Edge = tuple[NodeId, NodeId]

TRAIT_NAMES = (
    "extension_rate", "branching_rate", "light_investment",
    "substrate_investment", "desiccation_tolerance", "resource_sharing",
    "anastomosis_tendency", "spore_dispersal",
)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def canonical_edge(left: NodeId, right: NodeId) -> Edge:
    if left == right:
        raise ValueError("self edges are not allowed")
    return (left, right) if left < right else (right, left)


@dataclass(frozen=True)
class Genome:
    extension_rate: float = 0.46
    branching_rate: float = 0.28
    light_investment: float = 0.22
    substrate_investment: float = 0.58
    desiccation_tolerance: float = 0.34
    resource_sharing: float = 0.31
    anastomosis_tendency: float = 0.24
    spore_dispersal: float = 0.30

    def normalized(self) -> "Genome":
        return Genome(**{name: clamp(getattr(self, name)) for name in TRAIT_NAMES})

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Genome":
        defaults = cls()
        return cls(**{
            name: float(data.get(name, getattr(defaults, name)))
            for name in TRAIT_NAMES
        }).normalized()


@dataclass(frozen=True)
class Phenotype:
    extension_rate: float
    branching_rate: float
    light_capture: float
    substrate_absorption: float
    desiccation_tolerance: float
    energy_conductance: float
    water_conductance: float
    anastomosis_tendency: float
    spore_dispersal: float
    maintenance_energy: float
    maintenance_water: float
    extension_cost: float
    extension_water: float
    spore_cost: float

    @classmethod
    def from_genome(cls, genome: Genome) -> "Phenotype":
        genome = genome.normalized()
        light, substrate = genome.light_investment, genome.substrate_investment
        total = light + substrate
        if total > 1.0:
            light, substrate = light / total, substrate / total
        return cls(
            extension_rate=genome.extension_rate,
            branching_rate=genome.branching_rate,
            light_capture=light,
            substrate_absorption=substrate,
            desiccation_tolerance=genome.desiccation_tolerance,
            energy_conductance=0.035 + 0.16 * genome.resource_sharing,
            water_conductance=0.025 + 0.11 * genome.resource_sharing,
            anastomosis_tendency=genome.anastomosis_tendency,
            spore_dispersal=genome.spore_dispersal,
            maintenance_energy=(0.0092 + 0.0035 * genome.desiccation_tolerance**2
                                + 0.0020 * genome.resource_sharing**2),
            maintenance_water=0.0048 * (1.0 - 0.45 * genome.desiccation_tolerance),
            extension_cost=(0.070 + 0.018 * genome.extension_rate
                            + 0.012 * genome.branching_rate),
            extension_water=0.055,
            spore_cost=0.18 + 0.10 * genome.spore_dispersal,
        )


@dataclass
class HyphalNode:
    node_id: NodeId
    position: Point
    birth_tick: int
    heading: float
    energy: float = 0.34
    water: float = 0.24
    vitality: float = 1.0
    starvation_ticks: int = 0
    age: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id, "position": list(self.position),
            "birth_tick": self.birth_tick, "heading": self.heading,
            "energy": self.energy, "water": self.water, "vitality": self.vitality,
            "starvation_ticks": self.starvation_ticks, "age": self.age,
        }


@dataclass(frozen=True)
class Genet:
    genet_id: str
    parent_genet_id: str
    lineage_id: str
    birth_tick: int
    genome: Genome
    origin: Point

    @property
    def phenotype(self) -> Phenotype:
        return Phenotype.from_genome(self.genome)

    def to_dict(self) -> dict[str, Any]:
        return {
            "genet_id": self.genet_id, "parent_genet_id": self.parent_genet_id,
            "lineage_id": self.lineage_id, "birth_tick": self.birth_tick,
            "genome": self.genome.to_dict(), "origin": list(self.origin),
        }


@dataclass
class Ramet:
    ramet_id: str
    genet_id: str
    birth_tick: int
    origin_node_id: NodeId
    parent_ramet_id: str | None = None
    created_by: str = "germination"
    nodes: dict[NodeId, HyphalNode] = field(default_factory=dict)
    edges: set[Edge] = field(default_factory=set)
    edge_weights: dict[Edge, float] = field(default_factory=dict)
    tips: set[NodeId] = field(default_factory=set)
    alive: bool = True
    end_tick: int | None = None
    end_reason: str | None = None
    merged_into: str | None = None

    def __post_init__(self) -> None:
        if self.nodes and self.origin_node_id not in self.nodes:
            raise ValueError("origin_node_id must identify a node in the ramet")
        if not self.tips and self.nodes:
            self.tips.add(self.origin_node_id)

    @property
    def origin(self) -> Point:
        return self.nodes[self.origin_node_id].position

    def to_dict(self) -> dict[str, Any]:
        return {
            "ramet_id": self.ramet_id, "genet_id": self.genet_id,
            "birth_tick": self.birth_tick, "origin_node_id": self.origin_node_id,
            "origin": list(self.origin), "parent_ramet_id": self.parent_ramet_id,
            "created_by": self.created_by,
            "nodes": [self.nodes[node_id].to_dict() for node_id in sorted(self.nodes)],
            "edges": [list(edge) for edge in sorted(self.edges)],
            "edge_weights": [{"edge": list(edge), "weight": self.edge_weights.get(edge, 1.0)}
                             for edge in sorted(self.edges)],
            "tips": sorted(self.tips), "alive": self.alive,
            "end_tick": self.end_tick, "end_reason": self.end_reason,
            "merged_into": self.merged_into,
        }


@dataclass(frozen=True)
class Spore:
    spore_id: str
    parent_genet_id: str
    lineage_id: str
    genome: Genome
    position: Point
    released_tick: int
    expires_tick: int

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["genome"] = self.genome.to_dict()
        result["position"] = list(self.position)
        return result
