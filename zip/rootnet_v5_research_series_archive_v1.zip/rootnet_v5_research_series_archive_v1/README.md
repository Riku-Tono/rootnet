# RootNet v5 Research Series Archive

**Archive version:** v1  
**Assembled:** 2026-08-18  
**Frozen v5 endpoint:** v5.8.0 Biological Model

この配布物は、RootNet v5からv5.8.0までの封印パッケージとv5.7.2協調性A/B実験を、一つに整理したGitHub向け保全アーカイブです。

## 重要な区別

これは各版の実装を混ぜて一つのモデルにしたものではありません。提供された封印ZIPを変更せず内包し、系列索引、SHA-256、検証装置を外側に追加しています。

```text
v5 鏡界と継承
 └─▶ v5.5 フサカンブリア
      └─▶ v5.6 生態補正
           └─▶ v5.6.1 分断・防疫・再接続
                └─▶ v5.7 暮らしと気配
                     └─▶ v5.7.1 環境の一日
                          └─▶ v5.7.2 分離乱数＋協調性A/B実験
                               └─▶ v5.8.0 Biological Model
```

- **v5.8.0**がv5系列の凍結済み到達点です。
- **v6.0以降は別研究系列**であり、v5.8.0を上書きしたものではありません。
- 版をまたぐ数値は、単一パラメータだけが変わったA/B結果として直接比較できません。

詳しい版比較は [`VERSION_INDEX.md`](VERSION_INDEX.md) を参照してください。

## 収録構成

```text
sealed_packages/
├─ v5_mirror_succession/
├─ v5_5_cambrian/
├─ v5_6_ecology/
├─ v5_6_1_biosecurity/
├─ v5_7_living_presence/
├─ v5_7_1_environment_lifelog/
├─ v5_7_2_cooperation_experiment/
│  ├─ cooperation_experiment_harness.zip
│  └─ cooperation_ab_100pairs_results.zip
└─ v5_8_0_biological_model/
   ├─ Japanese royal seal.zip
   └─ English royal seal.zip
```

実際のファイル名とハッシュは [`SHA256SUMS.txt`](SHA256SUMS.txt) に記録しています。

## 一括検証

外側manifest、10本の元ZIPのSHA-256とCRC、Pythonコンパイル、全版171件のユニットテスト、v5.7.2とv5.8.0の封印検証、A/B解析の再生成を確認します。

```powershell
python verify_archive.py
```

ハッシュとZIP整合性だけを確認する場合:

```powershell
python verify_archive.py --integrity-only
```

完全なv5.7.2 A/B 100組・200世界・64,000世界日のシミュレーション自体は、通常のアーカイブ検証では再実行しません。保存済み生データから解析JSONと報告書を再生成し、バイト単位で一致することを確認します。実験harnessとprotocolは収録されています。

## v5.7.2協調性A/B結果

提供された結果パッケージの限定された結論は次のとおりです。

- 一株の協調性を0.10から0.90へ変更;
- seed 0–99の100対応組、各320日;
- 援助成功／1,000株日の平均差: **+12.634**;
- 対応差95% bootstrap CI: **[+9.020, +16.512]**;
- 増加79組、同値0組、減少21組;
- 外部天候一致100/100、world乱数状態一致100/100。

これは当該人工世界における下流を含む総効果です。直接効果の証明でも、現実の植物・菌類・社会への一般化でもありません。A/B両群の死亡は0であり、この実験の生存株差は死亡差ではなく主に増殖差です。

## v5.8.0の二言語版

日本語版と英語版は同じv5.8.0 Biological Modelの二言語配布物です。表示文・名前・文書・コード内文字列が翻訳されているためZIPやPythonファイルのバイト列は異なりますが、双方で36テストと320日検証がPASSし、人口、機能群、死亡日、物質収支などの機械的数値は一致しました。

## 実行方法

使用する内側ZIPだけを独立したディレクトリへ展開し、その版の `README.md` に従ってください。複数版を同じフォルダーへ上書き展開しないでください。

代表例:

```powershell
python main.py --days 10 --seed 42
python -m unittest discover -v
```

実際のセーブ名、個別テスト名、追加検証コマンドは版ごとに異なります。

## 決定的ZIPの再生成

```powershell
python build_release.py
```

ファイル順、日時、権限、格納方式を固定しているため、同じ内容からは同じ外側ZIPとSHA-256が生成されます。

## 収録上の注記

- `fusa_rootnet_v5_7_2_cooperation_experiment_harness.zip` と `(1).zip` はSHA-256が同一だったため、無印の1本だけを収録しました。
- 以前の一覧にあった独立 `fusa_rootnet_v5_7_2_split_rng_royal_seal.zip` は今回提供されたファイルおよびDownloads内にありませんでした。四分離乱数の実装、検査、検証記録は収録済みharness内に含まれますが、別名ZIPそのものの保全コピーではありません。

## 主張範囲

これらは人工生態系モデルとその機構・実験記録です。現実のフサリウム、植物群落、進化史、感染、防疫、協力行動を較正・予測するものではありません。v5.5の「フサカンブリア」やv5の鏡像生命はモデル内の規則・物語名です。

ライセンスは推測で追加していません。第三者の再利用を許可する場合は、公開前に明示的な `LICENSE` を選択してください。
