# Research boundaries

## Mechanisms actually implemented

Local stocks and uptake, fixed local transfer, maintenance demand, recoverable vitality, partial necrosis, graph disconnection, persistent fragments, explicit anastomosis, self/non-self identity rule, limited recycling, delayed space release, overlapping reproductive generations, and deterministic replay.

## Not implemented

Physical pressure, advection, cytoplasmic streaming, adaptive tube diameter, Kirchhoff or Navier–Stokes solvers, verified Physarum dynamics, real fungal self-incompatibility loci, nuclei, heterokaryosis, enzymes, host symbiosis, geological history, continuous geometry, aging mortality, or a programmed radiation event.

## Permitted claim

The package implements a testable artificial mechanism in which local starvation can remove part of a network without automatically killing every genetically related fragment, with conservative fixed-conductance resource transfer.

## Claims not supported by the included run

The validation run does not show that real fungi optimize transport, that fragmentation is adaptive, that a fungal species evolved, or that diversification occurs generally. Those require preregistered treatments and multiple independent seeds. A suitable next comparison is fixed conductance versus adaptive conductance while holding this v6.2 local-metabolism kernel fixed.
