# 環境記憶型フサリウム v1–v3 回収アーカイブ

失われていた初期系列を、残存原本と保存ログから整理したGitHub保管用パッケージです。

## 真正性の区分

| 版 | 区分 | 内容 |
|---|---|---|
| v1 | ログ復元・暫定版名 | 遺伝子、季節、突然変異を持つ最初期の完全な実行コード |
| v2 | ログ復元 | 環境ストレスと履歴保存を追加した「環境記憶型フサリウム第2版」 |
| v3 | 当時の原本ZIP | 体調・環境記憶・世代継承を分離した第3版 |

v1とv2は、当時のZIPが見つからなかったため `reconstructed` と明記しています。原本を装う `royal_seal` 表記は付けていません。v3は見つかったZIPを変更せず収録しています。

## 収録物

- `releases/fusa_memory_v1_genetic_growth_reconstructed.zip`
- `releases/fusa_memory_v2_environmental_memory_reconstructed.zip`
- `releases/fusa_memory_v3_generation.zip`
- `sources/`: v1・v2の復元ソース
- `provenance/RECOVERY_NOTES.md`: 復元根拠と境界
- `SHA256SUMS.txt`: 配布ZIPのSHA-256

## 実行

v1:

```bash
python fusa_memory_v1.py
```

v2:

```bash
python -m pip install -r requirements.txt
python fusa_memory_v2.py
```

v3はZIP内のREADMEを参照してください。

Windows PowerShellで絵文字出力が文字コードエラーになる場合は、実行前に次を指定します。

```powershell
$env:PYTHONIOENCODING = "utf-8"
```

## 注意

この系列は現実の植物遺伝学を厳密に再現するものではなく、遺伝・生理的順応・環境記憶を扱う育成シミュレーションです。v1・v2には乱数シード用CLIがないため、実行結果そのものは毎回同一にはなりません。
