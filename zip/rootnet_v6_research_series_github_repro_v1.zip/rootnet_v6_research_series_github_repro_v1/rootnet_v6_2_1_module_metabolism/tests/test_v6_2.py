from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from rootnet_v62 import Genome, HyphalNode, ModuleSimulation, Ramet, SimulationConfig
from rootnet_v62.model import canonical_edge


class ModuleMetabolismTests(unittest.TestCase):
    def simulation(self, **changes) -> ModuleSimulation:
        values = dict(ticks=30, width=20, height=10, founder_count=1)
        values.update(changes)
        return ModuleSimulation(SimulationConfig(**values))

    def make_chain(self, simulation: ModuleSimulation, length: int = 3) -> Ramet:
        ramet = simulation.living_ramets()[0]
        for coord in list(ramet.nodes):
            simulation.occupancy.pop(coord, None)
        coords = [(2 + i, 5) for i in range(length)]
        ramet.nodes = {coord: HyphalNode(coord, 0, energy=0.4, water=0.3) for coord in coords}
        ramet.edges = {canonical_edge(coords[i], coords[i + 1]) for i in range(length - 1)}
        ramet.tips = {coords[0], coords[-1]}
        ramet.origin = coords[0]
        for coord in coords:
            simulation.occupancy[coord] = ramet.ramet_id
        return ramet

    def test_transport_conserves_energy(self):
        simulation = self.simulation()
        ramet = self.make_chain(simulation)
        values = [1.0, 0.1, 0.0]
        for node, value in zip(ramet.nodes.values(), values):
            node.energy = value
        before = sum(node.energy for node in ramet.nodes.values())
        moved, error = simulation._transport_field(ramet, "energy", 0.5, 0.5)
        self.assertGreater(moved, 0.0)
        self.assertAlmostEqual(sum(node.energy for node in ramet.nodes.values()), before, places=12)
        self.assertAlmostEqual(error, 0.0, places=12)
        self.assertTrue(all(node.energy >= 0.0 for node in ramet.nodes.values()))

    def test_multiple_outflows_are_donor_capped(self):
        simulation = self.simulation()
        ramet = self.make_chain(simulation)
        center = (3, 5)
        ramet.nodes[center].energy = 0.01
        ramet.nodes[(2, 5)].energy = 0.0
        ramet.nodes[(4, 5)].energy = 0.0
        simulation._transport_field(ramet, "energy", 100.0, 1.0)
        self.assertGreaterEqual(ramet.nodes[center].energy, 0.0)
        self.assertAlmostEqual(sum(n.energy for n in ramet.nodes.values()), 0.01, places=12)

    def test_transport_is_edge_order_independent(self):
        left, right = self.simulation(), self.simulation()
        a, b = self.make_chain(left), self.make_chain(right)
        b.edges = set(reversed(sorted(b.edges)))
        for ramet in (a, b):
            ramet.nodes[(2, 5)].energy = 0.8
            ramet.nodes[(3, 5)].energy = 0.2
            ramet.nodes[(4, 5)].energy = 0.0
        left._transport_field(a, "energy", 0.3, 0.4)
        right._transport_field(b, "energy", 0.3, 0.4)
        self.assertEqual([a.nodes[c].energy for c in sorted(a.nodes)], [b.nodes[c].energy for c in sorted(b.nodes)])

    def test_middle_necrosis_fragments_but_does_not_kill_both_sides(self):
        simulation = self.simulation()
        ramet = self.make_chain(simulation)
        ramet.nodes[(3, 5)].vitality = 0.0
        dead, fragments, died = simulation._prune_necrotic(ramet)
        self.assertEqual(dead, [(3, 5)])
        self.assertFalse(died)
        self.assertEqual(len(fragments), 1)
        living = simulation.living_ramets()
        self.assertEqual(len(living), 2)
        self.assertEqual({r.genet_id for r in living}, {ramet.genet_id})
        self.assertEqual(sorted(len(r.nodes) for r in living), [1, 1])

    def test_small_disconnected_fragment_is_not_forced_to_die(self):
        simulation = self.simulation()
        ramet = self.make_chain(simulation, 2)
        ramet.edges.clear()
        fragments = simulation._split_if_disconnected(ramet)
        self.assertEqual(len(fragments), 1)
        self.assertTrue(all(r.alive for r in simulation.living_ramets()))

    def test_ramet_dies_only_when_last_module_necroses(self):
        simulation = self.simulation()
        ramet = simulation.living_ramets()[0]
        only = next(iter(ramet.nodes.values()))
        only.vitality = 0.0
        _, _, died = simulation._prune_necrotic(ramet)
        self.assertTrue(died)
        self.assertFalse(ramet.alive)
        self.assertEqual(ramet.end_reason, "all_modules_necrotic")

    def test_detritus_delays_reuse_then_releases(self):
        simulation = self.simulation(detritus_decay=0.11, detritus_growth_threshold=0.20)
        ramet = simulation.living_ramets()[0]
        coord = ramet.origin
        ramet.nodes[coord].vitality = 0.0
        simulation._prune_necrotic(ramet)
        self.assertEqual(simulation.detritus[coord[1]][coord[0]], 1.0)
        for _ in range(7): simulation._replenish_and_decay()
        self.assertGreaterEqual(simulation.detritus[coord[1]][coord[0]], 0.20)
        simulation._replenish_and_decay()
        self.assertLess(simulation.detritus[coord[1]][coord[0]], 0.20)

    def test_recycling_never_exceeds_local_capacity(self):
        simulation = self.simulation(recycling_efficiency=1.0)
        ramet = simulation.living_ramets()[0]
        x, y = ramet.origin
        simulation.substrate[y][x] = simulation.substrate_capacity[y][x]
        ramet.nodes[(x, y)].vitality = 0.0
        simulation._prune_necrotic(ramet)
        self.assertLessEqual(simulation.substrate[y][x], simulation.substrate_capacity[y][x])
        self.assertEqual(simulation.necrosis_records[-1]["recycled_substrate"], 0.0)

    def test_adjacency_alone_is_not_an_edge(self):
        simulation = self.simulation()
        ramet = self.make_chain(simulation, 2)
        ramet.edges.clear()
        self.assertNotIn(canonical_edge((2, 5), (3, 5)), ramet.edges)
        self.assertEqual(len(simulation._connected_components(ramet)), 2)

    def test_same_genet_merge_preserves_genet_identity(self):
        simulation = self.simulation()
        original = simulation.living_ramets()[0]
        fragment = Ramet(
            simulation._new_ramet_id(), original.genet_id, 1, (original.origin[0] + 1, original.origin[1]),
            parent_ramet_id=original.ramet_id, created_by="fragmentation",
        )
        simulation.ramets[fragment.ramet_id] = fragment
        simulation.occupancy[fragment.origin] = fragment.ramet_id
        retained = simulation._merge_ramets(original, fragment, (original.origin, fragment.origin))
        self.assertEqual(simulation.ramets[retained].genet_id, original.genet_id)
        self.assertFalse(fragment.alive)
        self.assertEqual(fragment.end_reason, "same_genet_anastomosis")

    def test_different_genets_form_nonself_boundary(self):
        simulation = self.simulation(founder_count=2)
        left, right = simulation.living_ramets()
        for ramet in (left, right):
            for coord in list(ramet.nodes): simulation.occupancy.pop(coord, None)
        left.origin, right.origin = (5, 5), (6, 5)
        left.nodes = {(5, 5): HyphalNode((5, 5), 0)}
        right.nodes = {(6, 5): HyphalNode((6, 5), 0)}
        left.tips, right.tips = {(5, 5)}, {(6, 5)}
        simulation.occupancy[(5, 5)] = left.ramet_id
        simulation.occupancy[(6, 5)] = right.ramet_id
        fused, blocked = simulation._same_genet_fusions()
        self.assertEqual(fused, [])
        self.assertEqual(blocked, 1)
        self.assertTrue(left.alive and right.alive)

    def test_spore_release_does_not_remove_parent(self):
        simulation = self.simulation()
        ramet = simulation.living_ramets()[0]
        next(iter(ramet.nodes.values())).energy = 1.0
        spore = simulation.release_spore(ramet, (0, 0), force=True)
        self.assertIsNotNone(spore)
        self.assertTrue(ramet.alive)
        self.assertIn(ramet.origin, ramet.nodes)

    def test_failed_spore_is_not_ramet_death(self):
        simulation = self.simulation(spore_viability_ticks=1)
        ramet = simulation.living_ramets()[0]
        next(iter(ramet.nodes.values())).energy = 1.0
        spore = simulation.release_spore(ramet, ramet.origin, force=True)
        simulation.tick = spore.expires_tick + 1
        _, failed = simulation._germinate_spores()
        self.assertEqual(failed, [spore.spore_id])
        self.assertFalse(any(r["event"] == "died" for r in simulation.ramet_records))

    def test_genome_is_immutable_during_lifetime(self):
        simulation = self.simulation(ticks=80)
        original = {gid: genet.genome for gid, genet in simulation.genets.items()}
        simulation.run()
        for genet_id, genome in original.items(): self.assertEqual(simulation.genets[genet_id].genome, genome)

    def test_no_age_timer_death(self):
        simulation = self.simulation(ticks=50)
        ramet = simulation.living_ramets()[0]
        node = next(iter(ramet.nodes.values()))
        node.age = 1_000_000
        node.energy = 1.0
        node.water = 1.0
        simulation.step()
        self.assertTrue(ramet.alive)

    def test_exact_seed_replay(self):
        left = self.simulation(master_seed=92, ticks=120)
        right = self.simulation(master_seed=92, ticks=120)
        left.run(); right.run()
        self.assertEqual(left.state_digest(), right.state_digest())

    def test_different_seed_changes_state(self):
        left = self.simulation(master_seed=92, ticks=80)
        right = self.simulation(master_seed=93, ticks=80)
        left.run(); right.run()
        self.assertNotEqual(left.state_digest(), right.state_digest())

    def test_outputs_separate_event_classes(self):
        simulation = self.simulation(ticks=5)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            simulation.run(output)
            expected = {"config.json", "summary.json", "ticks.jsonl", "genets.jsonl", "ramets.jsonl", "necrosis.jsonl", "spores.jsonl"}
            self.assertEqual({p.name for p in output.iterdir()}, expected)
            json.loads((output / "summary.json").read_text(encoding="utf-8"))

    def test_viewer_does_not_change_state(self):
        import watch
        simulation = self.simulation(ticks=1)
        before = simulation.state_digest()
        with contextlib.redirect_stdout(io.StringIO()):
            watch.render(simulation, watch.initial_record(simulation), False)
        self.assertEqual(simulation.state_digest(), before)

    def test_no_adaptive_conductance_or_cambrian_switch(self):
        text = json.dumps(self.simulation().config.to_dict()).lower()
        self.assertNotIn("adaptive", text)
        self.assertNotIn("cambrian", text)
        self.assertNotIn("lifespan", text)


if __name__ == "__main__":
    unittest.main()
