from __future__ import annotations

import unittest

from experiment_v6_3 import (
    _holm_adjust,
    _sign_test,
    compare_to_none,
    derive_evaluation_seeds,
)


class TransportExperimentTests(unittest.TestCase):
    def test_evaluation_seeds_are_deterministic_unique_and_exclude_development_seed(self):
        first = derive_evaluation_seeds()
        self.assertEqual(first, derive_evaluation_seeds())
        self.assertEqual(len(first), 30)
        self.assertEqual(len(set(first)), 30)
        self.assertNotIn(620, first)

    def test_exact_sign_test(self):
        self.assertEqual(_sign_test([1.0, 2.0, 3.0]), (3, 0, 0, 0.25))
        self.assertEqual(_sign_test([1.0, -1.0, 0.0]), (1, 1, 1, 1.0))

    def test_holm_adjustment_is_monotone_in_sorted_order(self):
        adjusted = _holm_adjust({"a": 0.01, "b": 0.03, "c": 0.04})
        self.assertEqual(adjusted, {"a": 0.03, "b": 0.06, "c": 0.06})

    def test_comparison_uses_paired_seeds(self):
        def run(seed, mode, shift):
            return {
                "seed": seed,
                "transport_mode": mode,
                "mean_living_modules": 10.0 + shift,
                "ever_occupied_cells": 20.0 + shift,
                "growth_tick_fraction": 0.2 + shift / 100.0,
                "longest_growth_gap": 30.0 - shift,
                "ecosystem_extinct": False,
                "necrosis_per_100_extensions": 5.0,
            }

        runs = {
            "none": [run(seed, "none", 0.0) for seed in range(12)],
            "equalize": [run(seed, "equalize", 2.0) for seed in reversed(range(12))],
            "demand": [],
        }
        comparison = compare_to_none("equalize", runs)
        self.assertEqual(comparison["classification"], "SUPPORTED")
        self.assertEqual(
            comparison["primary_endpoints"]["mean_living_modules"]["favorable_replicates"],
            12,
        )

    def test_comparison_rejects_unpaired_seed_sets(self):
        minimal = {
            "mean_living_modules": 1.0,
            "ever_occupied_cells": 1,
            "growth_tick_fraction": 1.0,
            "longest_growth_gap": 0,
            "ecosystem_extinct": False,
            "necrosis_per_100_extensions": 0.0,
        }
        runs = {
            "none": [{"seed": 1, **minimal}],
            "equalize": [{"seed": 2, **minimal}],
            "demand": [],
        }
        with self.assertRaises(AssertionError):
            compare_to_none("equalize", runs)


if __name__ == "__main__":
    unittest.main()
