"""Tests for RootNet v6.0."""
