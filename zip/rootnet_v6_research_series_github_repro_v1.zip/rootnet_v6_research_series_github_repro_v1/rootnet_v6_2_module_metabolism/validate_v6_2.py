from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_v62 import ModuleSimulation, SimulationConfig


def run_validation() -> dict[str, object]:
    config = SimulationConfig(master_seed=620, ticks=360)
    first = ModuleSimulation(config)
    summary = first.run()
    replay = ModuleSimulation(config)
    replay.run()
    fragment_records = [
        record for record in first.ramet_records
        if record.get("event") == "created" and record.get("created_by") == "fragmentation"
    ]
    germinations = [record for record in first.spore_records if record.get("event") == "germinated"]
    necrosis_ticks = {record["tick"] for record in first.necrosis_records}
    partial_survival = any(
        record["tick"] in necrosis_ticks and record["living_ramets"] > 0
        for record in first.tick_records
    )
    checks = {
        "exact_seed_replay": first.state_digest() == replay.state_digest(),
        "local_transport_energy_conserved": summary["max_abs_energy_transport_error"] < 1e-12,
        "local_transport_water_conserved": summary["max_abs_water_transport_error"] < 1e-12,
        "partial_necrosis_observed_without_ecosystem_death": len(first.necrosis_records) > 0 and partial_survival,
        "fragmentation_creates_same_genet_ramets": bool(fragment_records) and all(
            first.ramets[r["ramet_id"]].genet_id == first.ramets[r["parent_ramet_id"]].genet_id
            for r in fragment_records
        ),
        "small_fragments_not_automatically_deleted": any(
            record["living_ramets"] > record["living_genets"]
            for record in first.tick_records
        ),
        "ramet_death_separate_from_module_necrosis": (
            summary["total_necrotic_modules"] > summary["total_actual_ramet_deaths"]
        ),
        "offspring_establishes_while_parent_genet_lives": any(r["parent_genet_alive"] for r in germinations),
        "no_age_timer_extinction": summary["final_metrics"]["oldest_module_age"] == 360,
        "ecosystem_remains_living": not summary["ecosystem_extinct"],
    }
    if not all(checks.values()):
        raise AssertionError([name for name, passed in checks.items() if not passed])
    return {
        "schema": "rootnet-v6.2-validation-v1",
        "status": "PASS",
        "scope": "single deterministic mechanism-validation run; not a replicated ecological or evolutionary result",
        "checks": checks,
        "state_sha256": first.state_digest(),
        "observed_tick_360": {
            "living_genets": summary["final_metrics"]["living_genets"],
            "living_ramets": summary["final_metrics"]["living_ramets"],
            "living_modules": summary["final_metrics"]["total_modules"],
            "genets_ever_established": summary["genets_ever_established"],
            "ramets_ever_created": summary["ramets_ever_created"],
            "total_necrotic_modules": summary["total_necrotic_modules"],
            "total_actual_ramet_deaths": summary["total_actual_ramet_deaths"],
            "total_genet_extinctions": summary["total_genet_extinctions"],
            "fragment_ramets_created": len(fragment_records),
            "successful_spore_germinations": len(germinations),
            "oldest_module_age": summary["final_metrics"]["oldest_module_age"],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("validation_v6_2.json"))
    options = parser.parse_args()
    result = run_validation()
    options.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
