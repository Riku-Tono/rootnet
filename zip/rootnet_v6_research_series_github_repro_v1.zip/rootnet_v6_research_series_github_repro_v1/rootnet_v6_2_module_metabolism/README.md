# RootNet v6.2 — Local Module Metabolism

v6.2は、菌糸体を一つの共通財布として扱わず、各菌糸モジュールが局所的なenergy・water・vitalityを持つ人工生命モデルです。v6.0とv6.1は変更していません。

## VS Codeで見る

このフォルダーを開き、ターミナルで実行します。

```powershell
python watch.py
```

短く速く見る場合:

```powershell
python watch.py --ticks 360 --delay 0.04
```

`!`は衰弱、`×`は壊死直前、`▓▒░`は壊死後の残渣です。残渣は徐々に薄くなり、閾値を下回ると再び成長可能になります。

記録を保存する場合:

```powershell
python main.py --ticks 360 --seed 620 --output run_output
```

検証:

```powershell
python -m unittest discover -s tests -v
python validate_v6_2.py
python verify_package.py
```

Python 3.10以降の標準ライブラリだけを使用します。

## 生命単位

- **module**: 局所的なenergy・water・vitalityを持つ菌糸節。
- **ramet**: 現在エッジで接続されている生理的個体。切断により複数へ分かれ得ます。
- **genet**: 遺伝的個体。切断された複数rametが同じgenetに属し得ます。
- **lineage**: 共通創始系統。胞子で新しいgenetが生じても継承されます。

一部のmoduleが壊死してもramet全体は死亡しません。全moduleを失ったときだけramet死亡です。同じgenetの別rametは接触時に再融合できます。別genetとの接触はv6.2では非自己境界となり、融合しません。

## Gemini案から採用したもの

局所資源、段階的な健全度低下、部分壊死、バイオマスの限定的再循環、残渣による遅延再解放、切断後の連結成分検出を採用しました。

一方、`P = R + S - D`、受け手資源での流量クランプ、小断片の強制削除、最適輸送の保証、連続座標は採用していません。輸送は固定コンダクタンスの局所勾配近似で、全送り手の流出をまとめて制限した後に同時反映します。適応コンダクタンスはv6.3の比較対象です。

研究上の詳細は `MODEL_SPEC.md` と `RESEARCH_BOUNDARIES.md` を参照してください。
