from __future__ import annotations

import math
from collections.abc import Mapping

from .model import Edge


DEFAULT_TOLERANCE = 1e-12


def _validated_edges(values: Mapping[Edge, float]) -> list[Edge]:
    edges = sorted(values)
    for edge in edges:
        value = float(values[edge])
        if not math.isfinite(value):
            raise ValueError(f"non-finite conductance candidate for {edge}: {value}")
    return edges


def validate_budget_feasibility(
    edge_count: int,
    target_sum: float,
    lower: float,
    upper: float,
    *,
    tolerance: float = DEFAULT_TOLERANCE,
) -> None:
    edge_count = int(edge_count)
    target_sum = float(target_sum)
    lower = float(lower)
    upper = float(upper)
    if edge_count < 0:
        raise ValueError("edge_count must be non-negative")
    if not all(math.isfinite(value) for value in (target_sum, lower, upper)):
        raise ValueError("budget and bounds must be finite")
    if lower < 0.0 or upper < lower:
        raise ValueError("conductance bounds must satisfy 0 <= lower <= upper")
    if edge_count == 0:
        if abs(target_sum) > tolerance:
            raise ValueError("a zero-edge component must have zero conductance budget")
        return
    minimum = edge_count * lower
    maximum = edge_count * upper
    if target_sum < minimum - tolerance or target_sum > maximum + tolerance:
        raise ValueError(
            "infeasible conductance budget: "
            f"{minimum} <= {target_sum} <= {maximum} is required"
        )


def project_bounded_sum(
    candidates: Mapping[Edge, float],
    target_sum: float,
    lower: float,
    upper: float,
    *,
    tolerance: float = DEFAULT_TOLERANCE,
) -> dict[Edge, float]:
    """Euclidean projection onto a box with a fixed-sum constraint.

    The solution has the form ``clip(candidate - lambda, lower, upper)``.
    Bisection and residual distribution both use canonical edge order so the
    result is deterministic and independent of mapping insertion order.
    """

    edges = _validated_edges(candidates)
    validate_budget_feasibility(
        len(edges), target_sum, lower, upper, tolerance=tolerance
    )
    if not edges:
        return {}

    values = [float(candidates[edge]) for edge in edges]
    low_lambda = min(value - upper for value in values)
    high_lambda = max(value - lower for value in values)

    def projected_sum(lagrange: float) -> float:
        return sum(max(lower, min(upper, value - lagrange)) for value in values)

    for _ in range(128):
        midpoint = (low_lambda + high_lambda) / 2.0
        if projected_sum(midpoint) > target_sum:
            low_lambda = midpoint
        else:
            high_lambda = midpoint

    lagrange = (low_lambda + high_lambda) / 2.0
    result = {
        edge: max(lower, min(upper, value - lagrange))
        for edge, value in zip(edges, values)
    }

    residual = float(target_sum) - sum(result.values())
    if abs(residual) > tolerance:
        if residual > 0.0:
            adjustable = [edge for edge in edges if result[edge] < upper]
            for edge in adjustable:
                addition = min(residual, upper - result[edge])
                result[edge] += addition
                residual -= addition
                if residual <= tolerance:
                    break
        else:
            adjustable = [edge for edge in edges if result[edge] > lower]
            for edge in adjustable:
                subtraction = min(-residual, result[edge] - lower)
                result[edge] -= subtraction
                residual += subtraction
                if residual >= -tolerance:
                    break

    if abs(sum(result.values()) - target_sum) > tolerance * max(1, len(edges)):
        raise ArithmeticError("bounded-sum projection did not reach its target")
    if any(value < lower - tolerance or value > upper + tolerance for value in result.values()):
        raise ArithmeticError("bounded-sum projection violated its bounds")
    return result


def normalized_flux_activity(
    edges: set[Edge],
    resource_fluxes: Mapping[str, Mapping[Edge, float]],
    *,
    epsilon: float,
) -> dict[Edge, float]:
    ordered = sorted(edges)
    if not ordered:
        return {}
    epsilon = max(0.0, float(epsilon))
    active_resources: list[tuple[Mapping[Edge, float], float]] = []
    for resource in sorted(resource_fluxes):
        fluxes = resource_fluxes[resource]
        total = sum(abs(float(fluxes.get(edge, 0.0))) for edge in ordered)
        if total > epsilon:
            active_resources.append((fluxes, total))
    if not active_resources:
        uniform = 1.0 / len(ordered)
        return {edge: uniform for edge in ordered}
    activity = {
        edge: sum(abs(float(fluxes.get(edge, 0.0))) / total for fluxes, total in active_resources)
        / len(active_resources)
        for edge in ordered
    }
    total_activity = sum(activity.values())
    if not math.isclose(total_activity, 1.0, rel_tol=0.0, abs_tol=1e-12):
        activity = {edge: value / total_activity for edge, value in activity.items()}
    return activity


def update_edge_weights(
    current: Mapping[Edge, float],
    activity: Mapping[Edge, float],
    *,
    alpha: float,
    lower: float,
    upper: float,
    tolerance: float = DEFAULT_TOLERANCE,
) -> dict[Edge, float]:
    edges = _validated_edges(current)
    if set(edges) != set(activity):
        raise ValueError("current conductance and activity must cover the same edges")
    alpha = float(alpha)
    if not math.isfinite(alpha) or not 0.0 <= alpha <= 1.0:
        raise ValueError("alpha must satisfy 0 <= alpha <= 1")
    edge_count = len(edges)
    validate_budget_feasibility(edge_count, float(edge_count), lower, upper)
    if not edges:
        return {}
    activity_sum = sum(float(activity[edge]) for edge in edges)
    if any(not math.isfinite(float(activity[edge])) or float(activity[edge]) < 0.0 for edge in edges):
        raise ValueError("activity values must be finite and non-negative")
    if not math.isclose(activity_sum, 1.0, rel_tol=0.0, abs_tol=tolerance):
        raise ValueError("activity must sum to one")
    candidates = {
        edge: (1.0 - alpha) * float(current[edge])
        + alpha * edge_count * float(activity[edge])
        for edge in edges
    }
    return project_bounded_sum(
        candidates,
        float(edge_count),
        lower,
        upper,
        tolerance=tolerance,
    )


def audit_edge_weights(
    weights: Mapping[Edge, float],
    *,
    lower: float,
    upper: float,
    tolerance: float = DEFAULT_TOLERANCE,
) -> dict[str, float | int]:
    edges = _validated_edges(weights)
    if not edges:
        return {
            "edge_count": 0,
            "budget_target": 0.0,
            "budget_actual": 0.0,
            "budget_error": 0.0,
            "weight_min": 0.0,
            "weight_max": 0.0,
            "weight_mean": 0.0,
            "weight_variance": 0.0,
            "at_lower_bound": 0,
            "at_upper_bound": 0,
        }
    values = [float(weights[edge]) for edge in edges]
    target = float(len(values))
    actual = sum(values)
    if abs(actual - target) > tolerance * max(1, len(values)):
        raise AssertionError(f"conductance budget error: {actual - target}")
    if any(value < lower - tolerance or value > upper + tolerance for value in values):
        raise AssertionError("conductance weight outside configured bounds")
    mean = actual / len(values)
    variance = sum((value - mean) ** 2 for value in values) / len(values)
    return {
        "edge_count": len(values),
        "budget_target": target,
        "budget_actual": actual,
        "budget_error": actual - target,
        "weight_min": min(values),
        "weight_max": max(values),
        "weight_mean": mean,
        "weight_variance": variance,
        "at_lower_bound": sum(abs(value - lower) <= tolerance for value in values),
        "at_upper_bound": sum(abs(value - upper) <= tolerance for value in values),
    }
