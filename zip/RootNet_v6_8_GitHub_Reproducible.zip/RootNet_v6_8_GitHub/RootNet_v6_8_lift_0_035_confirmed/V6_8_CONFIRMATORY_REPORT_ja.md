# RootNet v6.8 `+0.035` confirmatory評価報告

## 最終判定

`V6_8_LIFT_0_035_CONFIRMED`

`water_capacity_lift=0.035`、採否基準、critical code、protocolを先に封印し、
その後に完全未使用30 seedsを生成した。30 seeds × 2水場 × 2輸送の120 runsは
全件完了し、事前固定した8基準をすべて通過した。

| endpoint | v6.6 control | v6.8 +0.035 |
|---|---:|---:|
| ecosystem extinction | 50/60 (83.3%) | 12/60 (20.0%) |
| median mean living modules | 8.96 | 12.80 |
| median mean hyphal length | 7.40 | 10.71 |
| median mean tips | 3.65 | 5.03 |
| median mean branch modules | 0.95 | 1.68 |
| pooled cumulative necrosis | 0.978 | 0.822 |

輸送別の候補全滅率はfixed 7/30＝23.3%、adaptive 5/30＝16.7%。どちらも
controlの25/30＝83.3%より低く、方向反転はなかった。

「フサフサ」のratio of mediansは、菌糸長1.447、tip 1.380、branch 1.768。
閾値1.25 / 1.25 / 1.20をすべて上回った。paired improvementは、

- fixed: 菌糸長30/30、tip 28/30、branch 28/30
- adaptive: 菌糸長30/30、tip 29/30、branch 27/30

で、各70%基準を通過した。最大機械誤差は`1.78e-15`である。

この結果は指定人工系における固定criteriaの確認であり、現実の菌類に適した水分量、
死亡率、形態を示すものではない。
