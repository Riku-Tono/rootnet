from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from lineage_view import write_lineage_tree
from models import CambrianAbilities
from network import RootNet
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV56Tests(unittest.TestCase):
    def test_network_metrics_measure_function_not_edge_count(self) -> None:
        network = RootNet()
        for node in ("A", "B", "C", "D"):
            network.add_node(node)
        network.connect("A", "B", 1.0)
        network.connect("B", "C", 1.0)

        metrics = network.metrics({"A", "B", "C", "D"})
        self.assertAlmostEqual(0.75, metrics["largest_component_ratio"])
        self.assertAlmostEqual(0.25, metrics["isolate_rate"])
        self.assertAlmostEqual(4.0 / 3.0, metrics["average_path_length"])
        self.assertAlmostEqual(0.0, metrics["clustering_coefficient"])
        self.assertAlmostEqual(0.5, metrics["reachability"])

    def test_diversity_combines_entropy_and_pairwise_distance(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        metrics = ecosystem.diversity_metrics()
        self.assertGreater(metrics["category_entropy"], 0.0)
        self.assertGreater(metrics["mean_pairwise_distance"], 0.0)
        self.assertAlmostEqual(
            metrics["composite"],
            0.5 * metrics["category_entropy"]
            + 0.5 * metrics["mean_pairwise_distance"],
        )

    def test_latent_abilities_are_weak_before_gradual_expression(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        plant = ecosystem.plants["memory-001"]
        self.assertTrue(all(
            0.0 < expressed < latent
            for latent, expressed in zip(
                plant.abilities.to_dict().values(),
                plant.expressed_abilities.to_dict().values(),
            )
        ))

        previous = None
        while not ecosystem.cambrian.active:
            previous = {
                plant_id: plant.expressed_abilities.to_dict()
                for plant_id, plant in ecosystem.plants.items()
            }
            ecosystem.step()
        self.assertIsNotNone(previous)
        start_day = ecosystem.cambrian.started_day
        self.assertIsNotNone(start_day)
        largest_start_change = max(
            abs(value - previous[plant_id][name])
            for plant_id, plant in ecosystem.plants.items()
            if plant_id in previous
            for name, value in plant.expressed_abilities.to_dict().items()
        )
        self.assertLess(largest_start_change, 0.03)

    def test_resource_transfer_never_exceeds_remaining_resource(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=9)
        actor = FusaPlant("寄生役", plant_id="actor", rng_seed=1)
        host = FusaPlant("宿主", plant_id="host", rng_seed=2)
        actor.expressed_abilities = CambrianAbilities(parasitism=1.0)
        host.expressed_abilities = CambrianAbilities()
        actor.condition.energy = 0.0
        host.condition.energy = 0.001
        ecosystem.add_plant(actor)
        ecosystem.add_plant(host)
        ecosystem.connect_plants(ecosystem.rootnet, "actor", "host", 1.0)
        ecosystem.cambrian.active = True

        for _ in range(1000):
            if ecosystem._cambrian_interactions():
                break
        self.assertEqual(0.0, host.condition.energy)
        self.assertLessEqual(actor.condition.energy, 0.00075)

    def test_movement_records_separate_ecological_modes(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(320):
            ecosystem.step()
        modes = {item.get("type") for item in ecosystem.movement_history}
        self.assertIn("seed", modes)
        self.assertIn("spore", modes)
        self.assertIn("hypha", modes)
        self.assertIn("walk", modes)

    def test_save_resume_matches_continuous_run(self) -> None:
        continuous = FusaEcosystem.demo(123)
        for _ in range(180):
            continuous.step()

        split = FusaEcosystem.demo(123)
        for _ in range(90):
            split.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet_v5_6.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 123)
            for _ in range(90):
                resumed.step()

        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_lineage_tree_uses_v56_and_expression_data(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(140):
            ecosystem.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "tree.html"
            write_lineage_tree(ecosystem, output)
            html = output.read_text(encoding="utf-8")
        self.assertIn("RootNet v5.6 フサ系統樹", html)
        self.assertIn("expressed_abilities", html)
        self.assertIn('id="chirality"', html)


if __name__ == "__main__":
    unittest.main()
