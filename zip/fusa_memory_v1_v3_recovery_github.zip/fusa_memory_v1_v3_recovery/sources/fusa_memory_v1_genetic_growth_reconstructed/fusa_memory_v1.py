import random
import time
from dataclasses import dataclass


@dataclass
class FusaGene:
    """フサフサ遺伝子"""

    growth_speed: float
    dew_affinity: float
    wind_resistance: float
    sunlight_love: float
    patience: float

    @classmethod
    def random_mutation(cls) -> "FusaGene":
        """突然変異によって新しいフサ遺伝子を生成する。"""
        return cls(
            growth_speed=max(0.2, min(1.8, random.gauss(1.0, 0.25))),
            dew_affinity=random.uniform(0.6, 1.4),
            wind_resistance=random.uniform(0.7, 1.3),
            sunlight_love=random.uniform(0.8, 1.6),
            patience=random.uniform(0.9, 1.5),
        )

    def express(self, season: str) -> float:
        """季節に応じた遺伝子の発現量を返す。"""
        if season == "🌱 芽吹き":
            return self.growth_speed * self.dew_affinity * 1.2

        if season == "🌿 育ち":
            return self.growth_speed * self.sunlight_love * 1.1

        if season == "🍀 実り":
            return self.growth_speed * self.wind_resistance * 0.9

        # 🍂 休み
        return self.growth_speed * self.patience * 0.6


class FusaPlant:
    """王立フサ王国に生きる一株のフサ植物。"""

    DAYS_PER_SEASON = 5
    MUTATION_PROBABILITY = 0.025

    def __init__(self, name: str = "王国民No.42"):
        self.name = name
        self.genes = [FusaGene.random_mutation() for _ in range(3)]
        self.fusa_level = 5.0
        self.day = 0
        self.season_index = 0
        self.seasons = ["🌱 芽吹き", "🌿 育ち", "🍀 実り", "🍂 休み"]

    @property
    def current_season(self) -> str:
        return self.seasons[self.season_index]

    def daily_growth(self) -> None:
        """一日分のフサリフサリを進行させる。"""
        self.day += 1

        # 3つの遺伝子が、その日の季節に応じて発現する。
        expressed_fusa = sum(
            gene.express(self.current_season)
            for gene in self.genes
        )

        # 風、朝露、王国民の足音などによる環境のゆらぎ。
        fluctuation = random.gauss(0, 0.3)

        daily_fusa = max(0.1, expressed_fusa + fluctuation)
        self.fusa_level += daily_fusa

        mutation_message = ""

        # 2.5%の確率で、新しいフサ遺伝子が誕生する。
        if random.random() < self.MUTATION_PROBABILITY:
            replaced_index = random.randrange(len(self.genes))
            self.genes[replaced_index] = FusaGene.random_mutation()
            mutation_message = " 🧬 突然変異！ 新たなフサリフサリが誕生"

        print(
            f"{self.day:02d}日目 | "
            f"{self.current_season} | "
            f"{self.name} | "
            f"+{daily_fusa:.2f}フサ | "
            f"総フサ度 {self.fusa_level:.2f}"
            f"{mutation_message}"
        )

        # 一定日数ごとに季節が移る。
        if self.day % self.DAYS_PER_SEASON == 0:
            self.season_index = (self.season_index + 1) % len(self.seasons)
            print(f"　🍃 季節が「{self.current_season}」へ移りました。")


def main() -> None:
    plant = FusaPlant("公式フサリスト・フスフス")

    print("🌿 王立フサ王国 遺伝子育成記録")
    print("─" * 48)

    for _ in range(20):
        plant.daily_growth()

        if plant.fusa_level >= 100:
            print("🍀 今日のフサリフサリ、素晴らしいです！")

        time.sleep(0.2)

    print("\n" + "🌿" * 20)
    print("王国は今日も、遺伝子の積み重ねで")
    print("ほんの少しフサフサになりました。")
    print("トストス。🌿")


if __name__ == "__main__":
    main()
