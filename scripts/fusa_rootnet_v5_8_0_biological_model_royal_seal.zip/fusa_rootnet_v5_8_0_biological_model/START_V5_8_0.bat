@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 main.py --days 10 --seed 42
) else (
  python main.py --days 10 --seed 42
)

echo.
echo RootNet v5.8.0 Biological Model です。
echo fusa_lineage_tree.html で生理資源と系統を確認できます。
echo もう一度実行すると保存した続きから10日進みます。
pause
