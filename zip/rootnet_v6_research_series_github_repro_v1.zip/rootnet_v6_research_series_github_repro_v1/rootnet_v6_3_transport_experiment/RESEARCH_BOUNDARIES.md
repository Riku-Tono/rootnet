# Research boundaries

## Supported by this experiment

- All three conditions were compared with identical seeds and parameters except transport mode.
- Both fixed-conductance transport rules increased persistent module abundance and spatial exploration relative to no transport under the tested artificial environment.
- Demand transport improved all four preregistered primary endpoints relative to no transport under the preregistered analysis.
- Transport balance errors remained at floating-point rounding scale.

## Not supported

- The experiment does not show that a hyphal graph is necessary for survival. The no-transport condition retained graph structure and all 30 no-transport ecosystems avoided total extinction.
- It does not show that demand transport is universally better than equalization. Their direct comparison was not a preregistered primary contrast and was mixed by endpoint.
- The target-demand formula is a deliberately minimal artificial mechanism, not a measured physiological law of fungi.
- No adaptive conductance, vascular remodeling, seasonality, symbiosis, continuous geometry, or real fungal calibration is included.
- The result is not a reconstruction of fungal evolution, proof of transport optimality, or evidence that real fungi obey these parameter values.

## Emergence boundary

Growth locations, topology, resource histories, necrosis, fragmentation, germination, and lineage outcomes are generated from local state, environment, inheritance, and keyed stochastic events. The model author still supplies the fungal-like primitives: tips, edges, extension, spores, and anastomosis. The viewer is read-only.

## Next discriminating experiment

To test whether transport is required for survival rather than merely beneficial for growth, introduce a new preregistered environmental-stress experiment without retuning the organism: lower local resource continuity or impose temporary patch loss, then compare extinction and recovery across the same transport modes. That would be a new protocol and new evaluation seeds.
