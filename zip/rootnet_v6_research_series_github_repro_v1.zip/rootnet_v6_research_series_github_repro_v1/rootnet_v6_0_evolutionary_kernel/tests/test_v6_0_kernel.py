from __future__ import annotations

import dataclasses
import json
import tempfile
import unittest
from pathlib import Path

from rootnet_evo import EvolutionSimulation, Genome, Individual, Phenotype, SimulationConfig
from rootnet_evo.metrics import population_metrics
from rootnet_evo.simulation import COMMON_ANCESTOR_ID


class RootNetV60KernelTests(unittest.TestCase):
    def test_acquisition_investment_has_a_hard_budget(self) -> None:
        phenotype = Phenotype.from_genome(Genome(
            light_investment=1.0,
            substrate_investment=1.0,
        ))
        self.assertAlmostEqual(
            1.0,
            phenotype.light_capture + phenotype.substrate_absorption,
        )

    def test_abilities_have_explicit_maintenance_costs(self) -> None:
        low = Phenotype.from_genome(Genome(
            light_investment=0.0,
            substrate_investment=0.0,
            desiccation_tolerance=0.0,
            resource_sharing=0.0,
            dispersal=0.0,
        ))
        high = Phenotype.from_genome(Genome(
            light_investment=1.0,
            substrate_investment=1.0,
            desiccation_tolerance=1.0,
            resource_sharing=1.0,
            dispersal=1.0,
        ))
        self.assertGreater(high.maintenance_cost, low.maintenance_cost)

    def test_environmental_evaluation_does_not_edit_parent_genomes(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(generations=1))
        before = {
            individual.organism_id: individual.genome
            for individual in simulation.population
        }
        simulation.step()
        after = {
            record["organism_id"]: Genome.from_dict(record["genome"])
            for record in simulation.ancestry_records[:simulation.config.founder_count]
        }
        self.assertEqual(before, after)

    def test_mutation_draw_is_independent_of_habitat_preset(self) -> None:
        homogeneous = EvolutionSimulation(SimulationConfig(habitat_preset="homogeneous"))
        heterogeneous = EvolutionSimulation(SimulationConfig(habitat_preset="heterogeneous"))
        parent_a = homogeneous.population[0]
        parent_b = heterogeneous.population[0]
        genome_a, loci_a = homogeneous._mutate(parent_a, "fixed-birth")
        genome_b, loci_b = heterogeneous._mutate(parent_b, "fixed-birth")
        self.assertEqual(genome_a, genome_b)
        self.assertEqual(loci_a, loci_b)

    def test_zero_mutation_preserves_genome_exactly(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(mutation_probability=0.0))
        parent = simulation.population[0]
        child, mutated = simulation._mutate(parent, "no-mutation")
        self.assertEqual(parent.genome, child)
        self.assertEqual([], mutated)

    def test_local_transport_conserves_total_energy(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(founder_count=2))
        left, right = simulation.population[:2]
        sharing_parent = dataclasses.replace(
            left,
            genome=Genome(resource_sharing=1.0),
        )
        energies = {
            sharing_parent.organism_id: 1.10,
            right.organism_id: 0.20,
        }
        transferred, error = simulation._redistribute_energy(
            [sharing_parent, right],
            energies,
        )
        self.assertGreater(transferred, 0.0)
        self.assertLess(abs(error), 1e-12)

    def test_founders_are_clonal_children_of_one_common_ancestor(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(founder_count=12))
        self.assertEqual(
            {COMMON_ANCESTOR_ID},
            {individual.parent_id for individual in simulation.population},
        )
        self.assertEqual(
            {simulation.config.founder_genome},
            {individual.genome for individual in simulation.population},
        )

    def test_individual_state_has_no_predetermined_biological_type(self) -> None:
        field_names = {field.name for field in dataclasses.fields(Individual)}
        self.assertTrue({"organism_id", "parent_id", "genome", "patch_id"} <= field_names)
        self.assertTrue({"lineage", "functional_group", "species", "ecotype"}.isdisjoint(field_names))

    def test_between_patch_divergence_is_measured_without_feedback(self) -> None:
        first = Individual(
            "left", COMMON_ANCESTOR_ID, "left", 0, "patch-0",
            Genome(light_investment=0.9, substrate_investment=0.1),
        )
        second = Individual(
            "right", COMMON_ANCESTOR_ID, "right", 0, "patch-2",
            Genome(light_investment=0.1, substrate_investment=0.9),
        )
        metrics = population_metrics([first, second])
        self.assertGreater(metrics["between_patch_disparity"], 0.0)
        self.assertEqual({"patch-0", "patch-2"}, set(metrics["patch_trait_means"]))

    def test_same_seed_repeats_exact_state(self) -> None:
        config = SimulationConfig(generations=25, founder_count=20, capacity_per_patch=35)
        first = EvolutionSimulation(config)
        second = EvolutionSimulation(config)
        self.assertEqual(first.run(), second.run())
        self.assertEqual(first.state_digest(), second.state_digest())

    def test_density_regulation_enforces_each_patch_capacity(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(
            generations=18,
            founder_count=20,
            capacity_per_patch=15,
        ))
        simulation.run()
        counts = simulation.generation_records[-1]["patch_counts"]
        self.assertTrue(all(count <= 15 for count in counts.values()))

    def test_ancestry_parent_references_precede_children(self) -> None:
        simulation = EvolutionSimulation(SimulationConfig(generations=12, founder_count=16))
        simulation.run()
        known = {COMMON_ANCESTOR_ID}
        for record in simulation.ancestry_records:
            self.assertIn(record["parent_id"], known)
            known.add(record["organism_id"])

    def test_outputs_are_machine_readable_and_claim_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            simulation = EvolutionSimulation(SimulationConfig(generations=6, founder_count=12))
            summary = simulation.run(directory)
            output = Path(directory)
            self.assertEqual(
                {"ancestry.jsonl", "config.json", "generations.jsonl", "summary.json"},
                {path.name for path in output.iterdir()},
            )
            loaded = json.loads((output / "summary.json").read_text(encoding="utf-8"))
            self.assertEqual(summary, loaded)
            self.assertIn("not a reconstruction", loaded["claim_boundary"])

    def test_engine_contains_no_cambrian_trigger(self) -> None:
        package = Path(__file__).resolve().parents[1] / "rootnet_evo"
        source = "\n".join(
            path.read_text(encoding="utf-8")
            for path in sorted(package.glob("*.py"))
        ).lower()
        self.assertNotIn("cambrian", source)


if __name__ == "__main__":
    unittest.main()
