from __future__ import annotations

import unittest

from ecosystem import FusaEcosystem
from models import MarineState, SolarState, Weather
from simulation import FusaPlant


class RootNetV571Tests(unittest.TestCase):
    def environmental_event(
        self,
        *,
        lineage: str = "memory",
        weather: Weather,
        marine: MarineState,
    ):
        ecosystem = FusaEcosystem(rng_seed=571)
        ecosystem.day = 1
        ecosystem.marine_state = marine
        plant = FusaPlant(
            "環境検査株",
            plant_id="environment-plant",
            lineage=lineage,
            rng_seed=572,
        )
        ecosystem.add_plant(plant)
        report = plant.daily_growth(
            weather=weather,
            solar=SolarState(
                condition="検査光",
                day_length=12.0,
                irradiance=weather.sunlight,
                quantum_harvest=1.0,
            ),
            marine=marine,
            population_pressure=0.0,
            cambrian_active=False,
        )
        return ecosystem, plant, report, ecosystem._environment_life_events([report])

    def test_shade_journal_uses_actual_condition_and_memory_deltas(self) -> None:
        ecosystem, _, report, events = self.environmental_event(
            weather=Weather(temperature=0.5, sunlight=0.05, rainfall=0.5, wind_speed=0.1),
            marine=MarineState(tide_level=0.5, salinity=0.7),
        )
        event = next(item for item in events if item.action == "environment_shade")
        self.assertEqual(report.condition_before.energy, event.state_before["energy"])
        self.assertEqual(report.condition_after.energy, event.state_after["energy"])
        self.assertAlmostEqual(
            report.memory_after.shade - report.memory_before.shade,
            event.memory_changes["shade"],
        )
        self.assertIn("一日の実変化", event.narrative)
        self.assertGreaterEqual(event.importance, ecosystem.JOURNAL_IMPORTANCE_THRESHOLD)

    def test_cold_and_salinity_are_environment_journal_candidates(self) -> None:
        _, _, _, cold_events = self.environmental_event(
            weather=Weather(temperature=0.0, sunlight=0.7, rainfall=0.5, wind_speed=0.1),
            marine=MarineState(tide_level=0.5, salinity=0.7),
        )
        self.assertIn("environment_cold", {event.action for event in cold_events})

        _, _, _, salt_events = self.environmental_event(
            lineage="sea",
            weather=Weather(temperature=0.5, sunlight=0.7, rainfall=0.5, wind_speed=0.1),
            marine=MarineState(tide_level=0.5, salinity=0.1),
        )
        self.assertIn("environment_salinity", {event.action for event in salt_events})

    def test_low_tide_records_failed_immersion_with_actual_delta(self) -> None:
        _, _, report, events = self.environmental_event(
            lineage="coastal",
            weather=Weather(temperature=0.5, sunlight=0.7, rainfall=0.5, wind_speed=0.1),
            marine=MarineState(tide_level=0.1, salinity=0.52),
        )
        event = next(
            item for item in events if item.action == "environment_missed_tide"
        )
        self.assertEqual("failure", event.outcome)
        self.assertEqual(report.condition_before.hydration, event.state_before["hydration"])
        self.assertEqual(report.condition_after.hydration, event.state_after["hydration"])
        self.assertIn("潮が十分に届きませんでした", event.narrative)

    def test_toxic_mutation_journal_matches_actual_biohazard_change(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=573)
        ecosystem.day = 12
        source = FusaPlant("変異株", plant_id="source", rng_seed=574)
        neighbor = FusaPlant("隣接株", plant_id="neighbor", rng_seed=575)
        ecosystem.add_plant(source)
        ecosystem.add_plant(neighbor)
        ecosystem.connect_plants(ecosystem.rootnet, "source", "neighbor", 0.9)
        before = {
            plant.plant_id: ecosystem._life_state_snapshot(plant)
            for plant in ecosystem.living_plants()
        }
        outbreak_id = ecosystem.introduce_toxic_mutation("source", 0.80)
        result = ecosystem._biosecurity_cycle(allow_new_mutations=False)
        result["new_outbreaks"] = [outbreak_id]
        events = ecosystem._biosecurity_life_events(before, result)

        event = next(
            item for item in events if item.action == "biosecurity_toxic_mutation"
        )
        self.assertEqual(before["source"]["biohazard_load"], event.state_before["biohazard_load"])
        self.assertEqual(source.biohazard_load, event.state_after["biohazard_load"])
        self.assertIn(f"{source.biohazard_load:.3f}", event.narrative)
        self.assertTrue(result["severed"])

    def test_failed_biosecurity_exposure_records_actual_load_delta(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=577)
        ecosystem.day = 20
        source = FusaPlant("危険株", plant_id="source", rng_seed=578)
        target = FusaPlant("防疫株", plant_id="target", rng_seed=579)
        source.biohazard_load = 0.70
        source.biohazard_origin = "outbreak-test"
        target.biosecurity_resistance = 0.0
        ecosystem.add_plant(source)
        ecosystem.add_plant(target)
        ecosystem.connect_plants(ecosystem.rootnet, "source", "target", 1.0)
        before = {
            plant.plant_id: ecosystem._life_state_snapshot(plant)
            for plant in ecosystem.living_plants()
        }
        result = ecosystem._biosecurity_cycle(allow_new_mutations=False)
        events = ecosystem._biosecurity_life_events(before, result)

        event = next(
            item for item in events
            if item.plant_id == "target" and item.action == "biosecurity_exposure"
        )
        actual_delta = target.biohazard_load - before["target"]["biohazard_load"]
        recorded_delta = (
            event.state_after["biohazard_load"]
            - event.state_before["biohazard_load"]
        )
        self.assertAlmostEqual(actual_delta, recorded_delta)
        self.assertGreater(actual_delta, 0.0)
        self.assertIn(f"{target.biohazard_load:.3f}", event.narrative)

    def test_environment_and_action_events_share_one_daily_limit(self) -> None:
        ecosystem = FusaEcosystem.demo(576)
        maximum = 0
        environment_seen = False
        for _ in range(120):
            events = ecosystem.step().life_events
            maximum = max(maximum, len(events))
            environment_seen = environment_seen or any(
                event.action.startswith("environment_") for event in events
            )
        self.assertTrue(environment_seen)
        self.assertLessEqual(maximum, ecosystem.MAX_JOURNAL_EVENTS_PER_DAY)


if __name__ == "__main__":
    unittest.main()
