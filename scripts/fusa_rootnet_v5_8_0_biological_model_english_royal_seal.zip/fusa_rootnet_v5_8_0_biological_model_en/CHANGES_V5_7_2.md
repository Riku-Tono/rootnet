# Royal Lawn Management Bureau RootNet v5.7.2 Official Record

## Separated random-number streams

- Added four streams: `world`, `individual`, `mutation`, and `action`
- Derived stable 64-bit stream seeds from the master seed using SHA-256
- Derived per-organism stream seeds without consuming the ecosystem streams
- Prevented differences in organism seeds or action randomness from shifting the external weather sequence
- Added `--world-seed`, `--individual-seed`, `--mutation-seed`, and `--action-seed`

## Persistence

- Schema v11
- Stored all four stream seeds and states for the ecosystem and every organism
- Added deterministic migration from the single random-number state in schema v10
- Stored streams take precedence over command-line seeds when resuming

## Minor fixes

- Added compatibility for a v5.7.1 mismatch where journal code expected `left/right` but reconnection records used `from/to`
- Left the original v5.7.1 ZIP unchanged

## Tests

- 5 separated-stream tests for v5.7.2
- 23 regression tests covering v5.7.1 through v5.6.1
- 28 tests passed in total
- A continuous 320-day run exactly matched a run saved after 137 days and resumed for 183 days
- Every random-number state for the ecosystem and all organisms matched exactly
- External weather matched exactly in a 120-day comparison using cooperation values of 0.10 and 0.90
