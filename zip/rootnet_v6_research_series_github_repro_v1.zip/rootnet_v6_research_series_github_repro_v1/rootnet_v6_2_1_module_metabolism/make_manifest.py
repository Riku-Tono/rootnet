from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.txt"


def included_files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file() and path != MANIFEST
        and "__pycache__" not in path.parts and path.suffix != ".pyc"
        and path.name != "rootnet_v6_2_1_module_metabolism.zip"
    )


def main() -> None:
    lines = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()} *{path.relative_to(ROOT).as_posix()}"
        for path in included_files()
    ]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"Wrote {len(lines)} entries to {MANIFEST.name}")


if __name__ == "__main__": main()
