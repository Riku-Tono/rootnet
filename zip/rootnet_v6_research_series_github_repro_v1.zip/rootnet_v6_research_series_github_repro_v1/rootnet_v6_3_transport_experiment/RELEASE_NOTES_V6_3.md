# RootNet v6.3 release notes

- Added `none`, `equalize`, and `demand` transport modes in a separate package derived from v6.2.1.
- Added source–sink targets based on two ticks of maintenance plus one extension cost for tips.
- Preserved simultaneous, donor-capped, mass-conserving edge updates.
- Added transfer-to-tip and cumulative explored-cell diagnostics.
- Added a preregistered 30-seed paired evaluation with exact sign tests and Holm correction.
- Added 29 unit tests and a deterministic mechanical validation suite.
- Kept v6.0, v6.1, v6.2, and v6.2.1 unchanged.
