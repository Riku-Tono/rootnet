# v6.2.0 release notes

- Preserved v6.0 and v6.1 as immutable prior model series.
- Replaced the colony-wide energy wallet with local energy, water, vitality, and starvation state per hyphal module.
- Added simultaneous, donor-capped, fixed-conductance transfer with explicit conservation diagnostics.
- Added gradual weakening, module-level necrosis, limited recycling, visible detritus, and delayed spatial reuse.
- Added genet/ramet/lineage identity so disconnected pieces can survive as physiological fragments without becoming unrelated organisms.
- Removed automatic edge creation from mere adjacency; extra loops now require an explicit anastomosis event.
- Added same-genet re-anastomosis and a distinct non-self contact boundary.
- Kept module necrosis, ramet death, genet extinction, and spore establishment failure as four different event classes.
- Added a UTF-8 terminal viewer showing vitality, pruning, fragments, and residue decay.
- Deliberately deferred adaptive conductance and continuous coordinates.
