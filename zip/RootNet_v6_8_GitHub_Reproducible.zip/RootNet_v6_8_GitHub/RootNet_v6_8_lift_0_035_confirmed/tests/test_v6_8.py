from __future__ import annotations

import hashlib
import json
import math
import unittest

from confirmatory_v6_8 import (
    CONDITIONS,
    CRITERIA_FILE,
    SEED_COUNT,
    SEED_FILE,
    derive_seeds,
    evaluate_acceptance,
    locked_confirmatory_seeds,
    prior_seeds,
    run_one,
)
from rootnet_v68 import (
    ModuleSimulation,
    SimulationConfig,
    V68_WATER_CAPACITY_LIFT,
    WATER_FIELD_PROFILES,
)
from rootnet_v68.field import bilinear_weights, deposit, withdraw
from rootnet_v68.geometry import SpatialIndex, rotate_point, segments_cross
from seal_evaluation_critical import SEAL_FILE, verify_critical_seal


V66_CORE_REGRESSION_SHA256 = (
    "6aa2f371ac225ef7a69fd724705d51d1c0a004ad06945129b3a25624cc4e419f"
)
ADDED_TICK_DIAGNOSTICS = {
    "maintenance_module_ticks",
    "maintenance_energy_required",
    "maintenance_energy_paid",
    "maintenance_water_required",
    "maintenance_water_paid",
    "energy_limited_module_ticks",
    "water_limited_module_ticks",
    "necrosis_grace_module_ticks",
    "vitality_decay_module_ticks",
    "active_patch_edge_distance",
    "active_patch_module_count",
}


def projected_v66_digest(simulation: ModuleSimulation) -> str:
    payload = {
        "tick": simulation.tick,
        "genets": [simulation.genets[key].to_dict() for key in sorted(simulation.genets)],
        "ramets": [simulation.ramets[key].to_dict() for key in sorted(simulation.ramets)],
        "spores": [spore.to_dict() for spore in simulation.spores],
        "substrate": simulation.substrate,
        "water": simulation.water,
        "detritus": simulation.detritus,
        "ticks": [
            {key: value for key, value in record.items() if key not in ADDED_TICK_DIAGNOSTICS}
            for record in simulation.tick_records
        ],
        "genet_records": simulation.genet_records,
        "ramet_records": simulation.ramet_records,
        "necrosis": simulation.necrosis_records,
        "spore_records": simulation.spore_records,
        "environment_records": simulation.environment_records,
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


class GeometryTests(unittest.TestCase):
    def test_rotation_round_trip(self):
        point, center = (7.25, 4.5), (10.0, 10.0)
        angle = math.radians(22.5)
        restored = rotate_point(rotate_point(point, center, angle), center, -angle)
        self.assertAlmostEqual(restored[0], point[0], places=12)
        self.assertAlmostEqual(restored[1], point[1], places=12)

    def test_segment_crossing_excludes_shared_endpoints(self):
        self.assertTrue(segments_cross((0, 0), (2, 2), (0, 2), (2, 0)))
        self.assertFalse(segments_cross((0, 0), (1, 0), (1, 0), (1, 1)))

    def test_spatial_index_uses_stable_ids(self):
        index = SpatialIndex(1.0)
        index.insert("node-a", (1.0000001, 2.0), "ramet-a")
        index.insert("node-b", (1.4, 2.0), "ramet-b")
        self.assertEqual(index.query((1.2, 2.0), 0.25), ["node-a", "node-b"])

    def test_bilinear_field_operations_conserve_mass(self):
        self.assertAlmostEqual(sum(w for _, _, w in bilinear_weights((2.25, 3.75), 8, 8)), 1.0)
        grid = [[1.0] * 6 for _ in range(6)]
        before = sum(map(sum, grid))
        taken = withdraw(grid, (2.25, 3.75), 0.4)
        self.assertAlmostEqual(before - sum(map(sum, grid)), taken, places=14)
        empty = [[0.0] * 4 for _ in range(4)]
        self.assertAlmostEqual(deposit(empty, (1.5, 1.5), 2.0, 0.3), 1.2, places=15)


class CandidateMechanismTests(unittest.TestCase):
    def config(self, **updates):
        values = dict(ticks=30, width=24, height=24, founder_count=2, master_seed=680)
        values.update(updates)
        return SimulationConfig(**values)

    def test_candidate_lift_is_fixed_at_0_035(self):
        self.assertEqual(V68_WATER_CAPACITY_LIFT, 0.035)
        self.assertEqual(SimulationConfig().water_field_profile, "v68-radial-lift-0.035")

    def test_profiles_are_explicit(self):
        self.assertEqual(
            WATER_FIELD_PROFILES,
            ("v68-radial-lift-0.035", "v66-radial", "v65-depth-stretched"),
        )

    def test_candidate_is_exact_clamped_lift_and_substrate_is_unchanged(self):
        control = ModuleSimulation(self.config(ticks=0, water_field_profile="v66-radial"))
        candidate = ModuleSimulation(
            self.config(ticks=0, water_field_profile="v68-radial-lift-0.035")
        )
        self.assertEqual(control.substrate, candidate.substrate)
        for y, row in enumerate(control.water_capacity):
            for x, value in enumerate(row):
                self.assertEqual(candidate.water_capacity[y][x], min(1.0, value + 0.035))

    def test_exact_replay(self):
        config = self.config(water_field_profile="v68-radial-lift-0.035")
        left, right = ModuleSimulation(config), ModuleSimulation(config)
        left.run(); right.run()
        self.assertEqual(left.state_digest(), right.state_digest())

    def test_control_preserves_v66_core_digest(self):
        simulation = ModuleSimulation(
            SimulationConfig(
                master_seed=660, ticks=40, width=24, height=24, founder_count=2,
                transport_mode="fixed-equalize", rotation_angle_degrees=0.0,
                environment_profile="persistent-patch", environment_move_start_tick=10,
                environment_move_end_tick=30, environment_relocation_tick=20,
                environment_damage_tick=20, water_field_profile="v66-radial",
                necrosis_grace_ticks=0,
            )
        )
        simulation.run()
        self.assertEqual(projected_v66_digest(simulation), V66_CORE_REGRESSION_SHA256)

    def test_transport_errors_within_tolerance(self):
        simulation = ModuleSimulation(self.config(water_field_profile="v68-radial-lift-0.035"))
        summary = simulation.run()
        self.assertLessEqual(summary["max_abs_energy_transport_error"], 1e-12)
        self.assertLessEqual(summary["max_abs_water_transport_error"], 1e-12)
        self.assertLessEqual(summary["max_abs_conductance_budget_error"], 1e-12)


class ConfirmatoryContractTests(unittest.TestCase):
    def test_conditions_are_fixed(self):
        self.assertEqual(
            CONDITIONS,
            {
                "control_v66_radial": "v66-radial",
                "candidate_v68_lift_0_035": "v68-radial-lift-0.035",
            },
        )

    def test_criteria_are_fixed(self):
        criteria = json.loads(CRITERIA_FILE.read_text(encoding="utf-8"))
        self.assertEqual(criteria["candidate_water_capacity_lift"], 0.035)
        self.assertEqual(criteria["candidate_extinction_rate_min_inclusive"], 0.10)
        self.assertEqual(criteria["candidate_extinction_rate_max_inclusive"], 0.50)
        self.assertEqual(
            criteria["minimum_ratio_of_medians"],
            {
                "mean_total_hyphal_length": 1.25,
                "mean_tips": 1.25,
                "mean_branch_modules": 1.20,
            },
        )

    def test_confirmatory_seed_derivation_is_unique_and_unused(self):
        seeds = derive_seeds()
        self.assertEqual(len(seeds), SEED_COUNT)
        self.assertEqual(len(seeds), len(set(seeds)))
        self.assertFalse(set(seeds) & prior_seeds())

    def test_locked_seeds_match_when_present(self):
        if SEED_FILE.exists():
            self.assertEqual(locked_confirmatory_seeds(), derive_seeds())

    def test_critical_seal_matches_when_present(self):
        if SEAL_FILE.exists():
            self.assertTrue(verify_critical_seal())

    def test_run_record_contains_separate_endpoints(self):
        run = run_one(derive_seeds()[0], "fixed-equalize", "candidate_v68_lift_0_035")
        required = {
            "ecosystem_extinct", "mean_total_hyphal_length", "mean_tips",
            "mean_branch_modules", "total_necrotic_modules",
            "total_actual_ramet_deaths", "total_genet_extinctions",
            "fragmentation_events", "spore_establishment_failures",
        }
        self.assertTrue(required <= set(run))

    def test_acceptance_logic_requires_all_checks(self):
        criteria = json.loads(CRITERIA_FILE.read_text(encoding="utf-8"))
        self.assertTrue(criteria["all_checks_required"])
        self.assertIn("not reproduced", criteria["failure_rule"].lower())


if __name__ == "__main__":
    unittest.main()
