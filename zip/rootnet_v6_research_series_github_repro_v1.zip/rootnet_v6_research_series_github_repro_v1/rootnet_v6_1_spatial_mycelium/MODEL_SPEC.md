# RootNet v6.1 model specification

## State and time

- Time is a discrete **tick**, not a synchronized biological generation.
- The environment is a bounded 2-D four-neighbor lattice.
- A **colony** is the persistent unit of life. It owns a connected set of hyphal cells, edges, active tips, energy, hydration, age, ancestry, and an immutable genome.
- Multiple colony generations may coexist. There is no global parent-to-offspring replacement step.

## Causal loop

For each tick: resources replenish; viable spores may germinate; living colonies absorb local substrate, water, and light; established fusion links transfer energy; colonies pay size-dependent maintenance; depleted colonies die; surviving tips may extend; mature colonies may release spores; touching colonies may establish fusion links.

The order is fixed and recorded. An offspring genome is produced only on spore release by inheritance plus environment-independent mutation. A colony's genome never changes during its life.

## Space and morphology

A new hyphal cell may occupy only an empty orthogonal neighbor of an existing tip. It cannot overlap another colony or leave the grid. Branching retains the old tip; otherwise that tip becomes inactive. Additional adjacent segments form within-colony cycles. Contact between distinct colonies can create a fusion link, but colonies and ancestry remain distinct.

## Birth, persistence, and death

- Reproduction means paying a cost and releasing a spore. It does **not** remove the parent.
- Germination creates a new one-cell colony with a parent ID and founder-branch ID.
- A blocked or expired spore is an establishment failure, not an individual colony death.
- Actual colony death occurs only when energy or hydration reaches zero after maintenance.
- There is no fixed lifespan or aging mortality in v6.1.

## Heritable traits and trade-offs

The eight bounded loci control extension, branching, light investment, substrate investment, desiccation tolerance, resource sharing, fusion tendency, and spore dispersal. Light plus substrate investment is normalized to a common acquisition budget when it exceeds one. Extension, branching, tolerance, sharing, fusion, and dispersal all carry explicit energetic costs.

## Randomness and replay

Independent deterministic streams are derived from the master seed for environment, survival, growth, mutation, spore behavior, and fusion. Event draws are keyed by tick and entity ID. Equal configuration and seed must reproduce the exact state digest.

## Output semantics

- `ticks.jsonl`: per-tick state summaries and fluxes.
- `ancestry.jsonl`: established colonies only.
- `deaths.jsonl`: actual colony deaths only.
- `spores.jsonl`: release, germination, and establishment-failure events.

The terminal viewer reads live state but does not alter any model variable.
