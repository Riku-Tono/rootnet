from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_mycelium import MyceliumSimulation, SimulationConfig


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="RootNet v6.1 spatial, overlapping-generation mycelium model"
    )
    parser.add_argument("--ticks", type=int, default=80)
    parser.add_argument("--seed", type=int, default=610)
    parser.add_argument("--width", type=int, default=36)
    parser.add_argument("--height", type=int, default=16)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path("run_output"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = SimulationConfig(
        master_seed=args.seed,
        ticks=args.ticks,
        width=args.width,
        height=args.height,
        founder_count=args.founders,
    )
    simulation = MyceliumSimulation(config)
    summary = simulation.run(args.output)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nSaved machine-readable records to: {args.output.resolve()}")


if __name__ == "__main__":
    main()
