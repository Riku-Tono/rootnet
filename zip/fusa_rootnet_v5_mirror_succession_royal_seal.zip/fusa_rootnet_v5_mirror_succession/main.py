from __future__ import annotations

import argparse
import sys
from pathlib import Path

from persistence import load_ecosystem, save_ecosystem_atomic


def configure_utf8_output() -> None:
    """Windowsのcp932端末でも絵文字と日本語を安全に出力する。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8", errors="replace")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="RootNet v5――鏡界と継承編")
    parser.add_argument("--days", type=int, default=12)
    parser.add_argument("--save", type=Path, default=Path("fusa_rootnet_v5.json"))
    parser.add_argument("--seed", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    configure_utf8_output()
    args = parse_args()
    eco = load_ecosystem(args.save, args.seed)
    days = max(1, min(args.days, 3650))
    print("🌿🪞👑 RootNet v5――鏡界と継承編")
    print(
        f"群落: {eco.name} / 生存株数: {len(eco.living_plants())} "
        f"/ 歴代株数: {len(eco.plants)} / 第{eco.day}日から再開"
    )
    print("─" * 76)
    for _ in range(days):
        report = eco.step(); w = report.weather
        solar, sea = report.solar, report.marine
        print(
            f"第{report.day}日 | {solar.condition} 日長{solar.day_length:.1f}h "
            f"光{w.sunlight:.2f} 気温{w.temperature:.2f} 雨{w.rainfall:.2f}"
        )
        print(
            f"  {sea.moon_phase} 潮{sea.tide_level:.2f} 波{sea.wave_strength:.2f} "
            f"海温{sea.sea_temperature:.2f} 塩分{sea.salinity:.2f} 海栄養{sea.nutrients:.2f}"
        )
        for signal in report.signals:
            print(f"  ⚡ {signal.message}（{signal.signal_type} / 強度{signal.strength:.2f}）")
        for signal in report.marine_signals:
            print(f"  🌊 {signal.message}（海底RootNet / 強度{signal.strength:.2f}）")
        print(
            f"  💧浄水 +{report.water_cleaned:.3f}  🔥太陽・落葉燃料 +{report.fuel_collected:.3f} "
            f"🪸共生藻光合成 +{report.coral_energy:.3f}"
        )
        if report.stored_seed_ids:
            print(f"  🫘 本物の種子庫へ{len(report.stored_seed_ids)}粒を保存")
        if report.wave_moved_seed_ids:
            print(f"  🌊 波が種を{len(report.wave_moved_seed_ids)}粒、潮間帯へ運びました")
        for plant_id in report.new_plant_ids:
            plant = eco.plants[plant_id]
            handedness = "鏡像D型" if plant.chirality == "D" else "通常L型"
            traits = "・".join(plant.traits.active_names()) or "穏やかな基本形質"
            print(
                f"  🌱 新株「{plant.name}」誕生 "
                f"（第{plant.generation}世代 / {handedness} / {traits}）"
            )
        for plant_id, reason in report.deaths:
            plant = eco.plants[plant_id]
            print(f"  🍂 {plant.name}が{reason}（享年{plant.age}日）")
        if report.soil_returned > 0:
            print(f"  ♻️ 枯株から土へ栄養 +{report.soil_returned:.4f}")
        state = eco.infrastructure
        print(
            f"  基盤 | 水質{state.water_quality:.2f} 貯水{state.water_reserve:.2f} "
            f"土{state.soil_nutrients:.2f} 燃料{state.amber_fuel:.1f} "
            f"種子庫{state.seed_bank} 生存株{len(eco.living_plants())}"
        )
        print(
            f"  🏞️ 環境収容力{report.carrying_capacity} "
            f"人口圧{report.population_pressure:.2f}"
        )
        if report.elder_successor_id:
            successor = eco.plants[report.elder_successor_id]
            print(f"  👑 新長老「{successor.name}」をRootNet評議会が選出")
    save_ecosystem_atomic(eco, args.save)
    print("─" * 76)
    print(f"💾 保存完了: {args.save}")
    print("鏡の向こうにも生命あり。長老は倒れても、記憶と役目は次代へ。")
    print("パフウリ・トフトフ。🌿🪞👑")


if __name__ == "__main__":
    main()
