from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_v62 import ModuleSimulation, SimulationConfig


def main() -> None:
    parser = argparse.ArgumentParser(description="RootNet v6.2 local-module metabolism kernel")
    parser.add_argument("--ticks", type=int, default=360)
    parser.add_argument("--seed", type=int, default=620)
    parser.add_argument("--width", type=int, default=42)
    parser.add_argument("--height", type=int, default=18)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path("run_output"))
    args = parser.parse_args()
    simulation = ModuleSimulation(SimulationConfig(
        master_seed=args.seed,
        ticks=args.ticks,
        width=args.width,
        height=args.height,
        founder_count=args.founders,
    ))
    summary = simulation.run(args.output)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nSaved records to: {args.output.resolve()}")


if __name__ == "__main__":
    main()
