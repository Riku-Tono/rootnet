from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


@dataclass
class FusaGene:
    growth_speed: float
    dew_affinity: float
    wind_resistance: float
    sunlight_love: float
    patience: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaGene":
        gene = cls(**data)
        gene.normalize()
        return gene

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def normalize(self) -> None:
        self.growth_speed = clamp(self.growth_speed, 0.4, 1.8)
        self.dew_affinity = clamp(self.dew_affinity, 0.3, 1.8)
        self.wind_resistance = clamp(self.wind_resistance, 0.4, 1.8)
        self.sunlight_love = clamp(self.sunlight_love, 0.5, 2.0)
        self.patience = clamp(self.patience, 0.6, 2.0)


@dataclass
class PlantCondition:
    health: float = 1.0
    hydration: float = 1.0
    energy: float = 1.0
    damage: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PlantCondition":
        condition = cls(
            health=float(data.get("health", 1.0)),
            hydration=float(data.get("hydration", 1.0)),
            energy=float(data.get("energy", 1.0)),
            damage=float(data.get("damage", 0.0)),
        )
        condition.normalize()
        return condition

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def normalize(self) -> None:
        self.health = clamp(self.health, 0.0, 1.0)
        self.hydration = clamp(self.hydration, 0.0, 1.0)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.damage = clamp(self.damage, 0.0, 1.0)


@dataclass
class EnvironmentalMemory:
    drought: float = 0.0
    strong_wind: float = 0.0
    shade: float = 0.0
    heat: float = 0.0
    cold: float = 0.0
    touch: float = 0.0
    salinity: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EnvironmentalMemory":
        memory = cls(
            drought=float(data.get("drought", 0.0)),
            strong_wind=float(data.get("strong_wind", 0.0)),
            shade=float(data.get("shade", 0.0)),
            heat=float(data.get("heat", 0.0)),
            cold=float(data.get("cold", 0.0)),
            touch=float(data.get("touch", 0.0)),
            salinity=float(data.get("salinity", 0.0)),
        )
        memory.normalize()
        return memory

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def learn(self, stress_type: str, intensity: float) -> None:
        if not hasattr(self, stress_type):
            raise ValueError(f"未知のストレス種別です: {stress_type}")
        current = float(getattr(self, stress_type))
        setattr(self, stress_type, clamp(current + intensity * 0.08, 0.0, 1.0))

    def get(self, stress_type: str) -> float:
        if not hasattr(self, stress_type):
            raise ValueError(f"未知のストレス種別です: {stress_type}")
        return float(getattr(self, stress_type))

    def primed_copy(self, ratio: float = 0.15) -> "EnvironmentalMemory":
        return EnvironmentalMemory(
            drought=self.drought * ratio,
            strong_wind=self.strong_wind * ratio,
            shade=self.shade * ratio,
            heat=self.heat * ratio,
            cold=self.cold * ratio,
            touch=self.touch * ratio,
            salinity=self.salinity * ratio,
        )

    def normalize(self) -> None:
        self.drought = clamp(self.drought, 0.0, 1.0)
        self.strong_wind = clamp(self.strong_wind, 0.0, 1.0)
        self.shade = clamp(self.shade, 0.0, 1.0)
        self.heat = clamp(self.heat, 0.0, 1.0)
        self.cold = clamp(self.cold, 0.0, 1.0)
        self.touch = clamp(self.touch, 0.0, 1.0)
        self.salinity = clamp(self.salinity, 0.0, 1.0)


@dataclass
class Weather:
    temperature: float
    sunlight: float
    rainfall: float
    wind_speed: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Weather":
        return cls(**data)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class StressRecord:
    day: int
    stress_type: str
    display_name: str
    intensity: float
    effective_intensity: float
    mitigation: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StressRecord":
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FusaSeed:
    name: str
    parent_name: str
    generation: int
    genes: list[FusaGene]
    memory: EnvironmentalMemory
    born_day: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaSeed":
        return cls(
            name=str(data["name"]),
            parent_name=str(data["parent_name"]),
            generation=int(data["generation"]),
            genes=[FusaGene.from_dict(item) for item in data["genes"]],
            memory=EnvironmentalMemory.from_dict(data.get("memory", {})),
            born_day=int(data["born_day"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "parent_name": self.parent_name,
            "generation": self.generation,
            "genes": [gene.to_dict() for gene in self.genes],
            "memory": self.memory.to_dict(),
            "born_day": self.born_day,
        }


@dataclass
class FusaTraits:
    mobility: float = 0.15
    armor: float = 0.20
    deep_rooting: float = 0.30
    symbiosis: float = 0.35
    thermal_regulation: float = 0.20
    signal_bridge: float = 0.10

    def normalize(self) -> None:
        self.mobility = clamp(self.mobility, 0.0, 1.0)
        self.armor = clamp(self.armor, 0.0, 1.0)
        self.deep_rooting = clamp(self.deep_rooting, 0.0, 1.0)
        self.symbiosis = clamp(self.symbiosis, 0.0, 1.0)
        self.thermal_regulation = clamp(self.thermal_regulation, 0.0, 1.0)
        self.signal_bridge = clamp(self.signal_bridge, 0.0, 1.0)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaTraits":
        value = cls(
            mobility=float(data.get("mobility", 0.15)),
            armor=float(data.get("armor", 0.20)),
            deep_rooting=float(data.get("deep_rooting", 0.30)),
            symbiosis=float(data.get("symbiosis", 0.35)),
            thermal_regulation=float(data.get("thermal_regulation", 0.20)),
            signal_bridge=float(data.get("signal_bridge", 0.10)),
        )
        value.normalize()
        return value

    def active_names(self, threshold: float = 0.58) -> list[str]:
        labels = {
            "mobility": "歩行性",
            "armor": "防御殻",
            "deep_rooting": "深根",
            "symbiosis": "共生力",
            "thermal_regulation": "温度調整",
            "signal_bridge": "鏡界通信",
        }
        return [
            labels[name]
            for name, value in self.to_dict().items()
            if value >= threshold
        ]


@dataclass
class CambrianAbilities:
    mobility: float = 0.0
    armor: float = 0.0
    parasitism: float = 0.0
    predation: float = 0.0
    bioluminescence: float = 0.0
    deep_rooting: float = 0.0
    false_signal: float = 0.0
    mirror_bridge: float = 0.0

    def normalize(self) -> None:
        for name in self.to_dict():
            setattr(self, name, clamp(float(getattr(self, name)), 0.0, 1.0))

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CambrianAbilities":
        value = cls(
            mobility=float(data.get("mobility", 0.0)),
            armor=float(data.get("armor", 0.0)),
            parasitism=float(data.get("parasitism", 0.0)),
            predation=float(data.get("predation", 0.0)),
            bioluminescence=float(data.get("bioluminescence", 0.0)),
            deep_rooting=float(data.get("deep_rooting", 0.0)),
            false_signal=float(data.get("false_signal", 0.0)),
            mirror_bridge=float(data.get("mirror_bridge", 0.0)),
        )
        value.normalize()
        return value

    def active_names(self, threshold: float = 0.58) -> list[str]:
        labels = {
            "mobility": "移動能力",
            "armor": "装甲",
            "parasitism": "寄生",
            "predation": "捕食",
            "bioluminescence": "発光",
            "deep_rooting": "深根",
            "false_signal": "偽信号",
            "mirror_bridge": "鏡像橋渡し",
        }
        return [
            labels[name]
            for name, value in self.to_dict().items()
            if value >= threshold
        ]


@dataclass
class CambrianState:
    active: bool = False
    started_day: int | None = None
    unlocked_abilities: list[str] = None  # type: ignore[assignment]
    last_audit: dict[str, Any] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.unlocked_abilities is None:
            self.unlocked_abilities = []
        if self.last_audit is None:
            self.last_audit = {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "active": self.active,
            "started_day": self.started_day,
            "unlocked_abilities": list(self.unlocked_abilities),
            "last_audit": dict(self.last_audit),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CambrianState":
        return cls(
            active=bool(data.get("active", False)),
            started_day=(
                int(data["started_day"])
                if data.get("started_day") is not None
                else None
            ),
            unlocked_abilities=[
                str(value) for value in data.get("unlocked_abilities", [])
            ],
            last_audit=dict(data.get("last_audit", {})),
        )


@dataclass
class StoredSeed:
    seed_id: str
    seed: FusaSeed
    parent_id: str
    lineage: str
    district: str
    stored_day: int
    location: str = "seed_bank"
    chirality: str = "L"
    traits: FusaTraits | None = None
    abilities: CambrianAbilities | None = None

    def __post_init__(self) -> None:
        if self.traits is None:
            self.traits = FusaTraits()
        if self.abilities is None:
            self.abilities = CambrianAbilities()
        self.chirality = "D" if self.chirality == "D" else "L"
        self.traits.normalize()
        self.abilities.normalize()

    def to_dict(self) -> dict[str, Any]:
        return {
            "seed_id": self.seed_id,
            "seed": self.seed.to_dict(),
            "parent_id": self.parent_id,
            "lineage": self.lineage,
            "district": self.district,
            "stored_day": self.stored_day,
            "location": self.location,
            "chirality": self.chirality,
            "traits": self.traits.to_dict(),
            "abilities": self.abilities.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StoredSeed":
        return cls(
            seed_id=str(data["seed_id"]),
            seed=FusaSeed.from_dict(data["seed"]),
            parent_id=str(data["parent_id"]),
            lineage=str(data.get("lineage", "memory")),
            district=str(data.get("district", "中央庭園")),
            stored_day=int(data.get("stored_day", 0)),
            location=str(data.get("location", "seed_bank")),
            chirality=str(data.get("chirality", "L")),
            traits=FusaTraits.from_dict(data.get("traits", {})),
            abilities=CambrianAbilities.from_dict(data.get("abilities", {})),
        )


@dataclass
class SolarState:
    condition: str = "☀️ 晴天"
    day_length: float = 12.0
    irradiance: float = 0.8
    sunset_glow: float = 0.3
    quantum_harvest: float = 0.8

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SolarState":
        return cls(
            condition=str(data.get("condition", "☀️ 晴天")),
            day_length=float(data.get("day_length", 12.0)),
            irradiance=float(data.get("irradiance", 0.8)),
            sunset_glow=float(data.get("sunset_glow", 0.3)),
            quantum_harvest=float(data.get("quantum_harvest", 0.8)),
        )


@dataclass
class MarineState:
    moon_phase: str = "🌑 新月"
    moon_fraction: float = 0.0
    tide_level: float = 0.5
    sea_temperature: float = 0.55
    salinity: float = 0.70
    nutrients: float = 0.55
    wave_strength: float = 0.35

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MarineState":
        return cls(
            moon_phase=str(data.get("moon_phase", "🌑 新月")),
            moon_fraction=float(data.get("moon_fraction", 0.0)),
            tide_level=float(data.get("tide_level", 0.5)),
            sea_temperature=float(data.get("sea_temperature", 0.55)),
            salinity=float(data.get("salinity", 0.70)),
            nutrients=float(data.get("nutrients", 0.55)),
            wave_strength=float(data.get("wave_strength", 0.35)),
        )


@dataclass
class SensoryState:
    warmth: float = 0.5
    cold: float = 0.5
    touch: float = 0.0

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SensoryState":
        return cls(
            warmth=float(data.get("warmth", 0.5)),
            cold=float(data.get("cold", 0.5)),
            touch=float(data.get("touch", 0.0)),
        )


@dataclass
class CoralColony:
    colony_id: str
    name: str
    district: str
    health: float = 0.85
    symbiotic_algae: float = 0.80
    stored_energy: float = 0.35
    touch_response: float = 0.0
    alive: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CoralColony":
        return cls(
            colony_id=str(data["colony_id"]),
            name=str(data["name"]),
            district=str(data.get("district", "珊瑚礁")),
            health=float(data.get("health", 0.85)),
            symbiotic_algae=float(data.get("symbiotic_algae", 0.80)),
            stored_energy=float(data.get("stored_energy", 0.35)),
            touch_response=float(data.get("touch_response", 0.0)),
            alive=bool(data.get("alive", True)),
        )


@dataclass
class InfrastructureState:
    water_quality: float = 0.45
    water_reserve: float = 0.65
    amber_fuel: float = 0.0
    pest_pressure: float = 0.25
    pollination: float = 0.35
    seed_bank: int = 0
    soil_nutrients: float = 0.40

    def normalize(self) -> None:
        self.water_quality = clamp(self.water_quality, 0.0, 1.0)
        self.water_reserve = clamp(self.water_reserve, 0.0, 1.0)
        self.amber_fuel = clamp(self.amber_fuel, 0.0, 1000.0)
        self.pest_pressure = clamp(self.pest_pressure, 0.0, 1.0)
        self.pollination = clamp(self.pollination, 0.0, 1.0)
        self.seed_bank = max(0, int(self.seed_bank))
        self.soil_nutrients = clamp(self.soil_nutrients, 0.0, 1.0)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InfrastructureState":
        value = cls(
            water_quality=float(data.get("water_quality", 0.45)),
            water_reserve=float(data.get("water_reserve", 0.65)),
            amber_fuel=float(data.get("amber_fuel", 0.0)),
            pest_pressure=float(data.get("pest_pressure", 0.25)),
            pollination=float(data.get("pollination", 0.35)),
            seed_bank=int(data.get("seed_bank", 0)),
            soil_nutrients=float(data.get("soil_nutrients", 0.40)),
        )
        value.normalize()
        return value
