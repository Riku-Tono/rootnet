# Research boundaries and frozen scope

## Primary question

Can heritable variation, ecological trade-offs, and spatial environmental
heterogeneity alone generate persistent ecological diversification from a
common ancestral population?

## What the kernel can establish

After a separately specified replicated experiment, the kernel may support
claims about differences between its own configured artificial worlds, such as
trait distributions, patch occupation, ancestral branch persistence,
phenotypic disparity, or analysis-only strategy frequencies.

## What it cannot establish

- that fungi, algae, lichens, or mycorrhizae evolved by the same path;
- that a measured trait cluster is a biological species;
- that a numerical parameter corresponds to a real gene or measured rate;
- that a rapid disparity increase is a historical Cambrian event;
- that spatial heterogeneity is a universal cause of diversification;
- that resource sharing evolved in nature;
- that an observed single-seed trajectory is reproducible population evidence.

## Anti-circularity rules

1. Diversity metrics do not alter mutation rates or unlock abilities.
2. Analysis-only labels do not alter dynamics.
3. Habitat values do not modify inherited traits within an organism.
4. The same genotype-to-phenotype function is used in every habitat.
5. Null, convergence, extinction, and no-diversification outcomes are valid.
6. New mechanisms require a new version and a new protocol; they are not added
   after inspecting a fixed experiment's outcome.

## Full experiment status

No replicated full experiment is included in the v6.0 release. Before such a
run, benchmark runtime, set the fixed number of seeds and generations, define
the primary outcome and stopping rules, and receive explicit approval.

An appropriate first comparison would pair identical master seeds under the
homogeneous and heterogeneous presets. That design is only a proposal here,
not an executed or sealed experiment.
