# Provenance

This GitHub bundle was assembled on 2026-08-18 from five previously sealed RootNet ZIP packages. Each ZIP was extracted into its own directory without changing the versioned model files.

## Sealed source archives

```text
afb98a219e59e734b2ea69b1dec826293de69781696503ee0f423d9be505ab03  rootnet_v6_0_evolutionary_kernel.zip
75d57ae4c3878616e244e0c50d61e7a5258fcbfa6068243116e2c04622aba127  rootnet_v6_1_spatial_mycelium.zip
b27f7577eec3537ff5ecb09854d978ba4131dffcae774aa7ae8ac86f874997ea  rootnet_v6_2_module_metabolism.zip
2f84ad8531f42aef43fc8bfa6ce2e2d29e4b872d44f40fdf3ffd4000a5e87047  rootnet_v6_2_1_module_metabolism.zip
3e4e0dc7b666dd4069e52d4d9aa2712419fb49021a6e97f4cc00f2667526aee3  rootnet_v6_3_transport_experiment.zip
```

The source ZIP files themselves are not duplicated inside this bundle. Their extracted, internally manifested contents are included instead.

## Repository-level additions

- `README.md`: unified v5.8.0-to-v6.3 orientation and reproduction guide;
- `PROVENANCE.md`: this source record;
- `MANIFEST_SHA256.txt`: SHA-256 for every committed bundle file except the manifest itself;
- `make_manifest.py`: deterministic manifest generator;
- `verify_all.py`: outer-manifest verification plus each version's own tests and sealed validation reproduction;
- `build_release.py`: deterministic outer-ZIP builder;
- `.gitattributes` and `.gitignore`: stable Git text handling and exclusion of generated files;
- `.github/workflows/verify.yml`: Windows GitHub Actions verification.

The repository-level additions do not alter simulation dynamics. Each version retains its own `README.md`, `MODEL_SPEC.md`, `RESEARCH_BOUNDARIES.md`, release notes, tests, validation record, and internal manifest.

## Reproducibility boundary

`python verify_all.py` verifies all internal manifests, unit tests, and deterministic mechanism-validation records. `python verify_all.py --full-evaluation` additionally reruns the v6.3 preregistered 30-seed evaluation and requires exact equality with `evaluation_v6_3.json` after removing the machine-dependent elapsed-time field.

The project uses only the Python standard library. The packages specify their own supported Python ranges; Python 3.11 or newer is recommended for the combined bundle.
