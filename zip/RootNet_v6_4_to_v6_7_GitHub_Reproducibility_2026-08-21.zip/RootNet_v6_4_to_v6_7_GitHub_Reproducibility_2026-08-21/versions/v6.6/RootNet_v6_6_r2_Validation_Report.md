# RootNet v6.6 r2 validation report

## Verdict

`PASS` — unit, deterministic mechanism, development-seed audit, manifest, and
sealed-validation reproduction only. Confirmatory evaluation is `SEALED_NOT_RUN`.
No evaluation-seed simulation was started.

## r2 provenance correction

- The package now contains
  `confirmatory_geometry_development_audit_v6_6_r2.json`.
- It records exactly 20 runs: development seeds 660–661, 360 ticks, 42×42,
  3 founders, two transport modes, and five angles.
- `cumulative_active_patch_uptake` is exactly zero in 20/20 runs.
- The audit and sealed validation both record `SEALED_NOT_RUN` and zero
  evaluation-seed runs.
- r2 makes no model, statistical, geometry, ecological, endpoint, or evaluation
  seed change relative to r1.

## Verification

- 25 unit tests: PASS;
- 22 machine-readable validation checks: PASS;
- confirmatory-geometry audit provenance and 20/20 zero result: PASS;
- manifest verification: PASS;
- sealed validation reproduction: PASS;
- clean ZIP re-extraction verification: PASS.

Mechanism coverage includes continuous geometry, arbitrary rotation, segment
crossing, spatial indexing, bilinear coupling, conservative field accounting,
Euclidean edge length, length-dependent conductance, energy/water conservation,
adaptive conductance budget, exact replay, event-keyed candidate RNG, zero-safe
equivalence, 0°/90° invariant checks, and requested-horizon extinction records.

The 20-run seeds 660–661 development audit is diagnostic mechanism evidence only,
not confirmatory evidence. Assay geometry and ecological parameters were not tuned.
The ordinary 120-tick/32×32 development audit remains a separate diagnostic stage.
