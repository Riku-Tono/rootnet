from __future__ import annotations

import math
import statistics
from collections import Counter

from .model import Genet, Ramet, TRAIT_NAMES


def _mean(values) -> float:
    values = list(values)
    return statistics.fmean(values) if values else 0.0


def network_metrics(
    ramets: list[Ramet],
    genets: dict[str, Genet],
    detritus: list[list[float]],
) -> dict[str, object]:
    living = [ramet for ramet in ramets if ramet.alive and ramet.nodes]
    living_genet_ids = {ramet.genet_id for ramet in living}
    nodes = [node for ramet in living for node in ramet.nodes.values()]
    edge_count = sum(len(ramet.edges) for ramet in living)
    degree_counts: Counter[tuple[str, tuple[int, int]]] = Counter()
    for ramet in living:
        for left, right in ramet.edges:
            degree_counts[(ramet.ramet_id, left)] += 1
            degree_counts[(ramet.ramet_id, right)] += 1
    trait_means = {
        name: _mean(getattr(genets[genet_id].genome, name) for genet_id in living_genet_ids)
        for name in TRAIT_NAMES
    }
    trait_variances = {
        name: _mean(
            (getattr(genets[genet_id].genome, name) - trait_means[name]) ** 2
            for genet_id in living_genet_ids
        )
        for name in TRAIT_NAMES
    }
    return {
        "living_genets": len(living_genet_ids),
        "living_ramets": len(living),
        "total_modules": len(nodes),
        "total_edges": edge_count,
        "total_tips": sum(len(ramet.tips) for ramet in living),
        "branch_modules": sum(degree >= 3 for degree in degree_counts.values()),
        "cycle_rank": sum(max(0, len(r.edges) - len(r.nodes) + 1) for r in living),
        "weakened_modules": sum(node.vitality < 0.55 for node in nodes),
        "critical_modules": sum(node.vitality < 0.25 for node in nodes),
        "mean_vitality": round(_mean(node.vitality for node in nodes), 9),
        "mean_local_energy": round(_mean(node.energy for node in nodes), 9),
        "mean_local_water": round(_mean(node.water for node in nodes), 9),
        "oldest_module_age": max((node.age for node in nodes), default=0),
        "detritus_cells": sum(value > 0.0 for row in detritus for value in row),
        "blocked_detritus_cells": sum(value >= 0.20 for row in detritus for value in row),
        "extant_lineages": len({genets[g].lineage_id for g in living_genet_ids}),
        "trait_means": {name: round(value, 9) for name, value in trait_means.items()},
        "trait_variances": {name: round(value, 9) for name, value in trait_variances.items()},
        "phenotypic_disparity": round(math.sqrt(_mean(trait_variances.values())), 9),
    }
