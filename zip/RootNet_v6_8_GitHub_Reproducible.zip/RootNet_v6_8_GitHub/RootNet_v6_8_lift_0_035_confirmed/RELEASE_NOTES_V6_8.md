# RootNet v6.8 release notes

- Fixed `water_capacity_lift = 0.035`; no post-result retuning.
- Sealed protocol, criteria, tests, model, and evaluation code before seed generation.
- Generated 30 completely unused confirmatory seeds after the critical-file seal.
- Completed 120/120 paired confirmatory runs.
- Confirmed candidate with 12/60 whole-ecosystem extinctions versus 50/60 control.
- Passed all predeclared extinction, necrosis, mechanical, transport-direction,
  hyphal-length, tip, branch, and paired-improvement criteria.
- Preserved separate necrosis, ramet-death, genet-extinction, fragmentation,
  environmental-damage, and establishment-failure accounting.
- Retained the read-only edge-drawing terminal observer.
