# RootNet v6.4–v6.7 Reproducibility Bundle

This archive is a clean GitHub-oriented bundle of the final RootNet v6.4–v6.7 package revisions and their companion evidence. It excludes development worktrees, superseded package revisions, Python bytecode, temporary extraction directories, and conversation logs.

日本語要約：各`versions/`フォルダに最終パッケージ、固定protocol・seed、検証記録、公開済み結果を収録しています。最初にパッケージZIPのSHA-256を確認し、展開後に`python verify_package.py`を実行してください。OS差により動的stateのbyte-level digestだけが変わる場合があるため、artifact integrityと数値再現は分けて判断してください。

## Bundle contents

| Directory | Final package | Evidence status |
|---|---|---|
| `versions/v6.4/` | `RootNet_v6_4_simple_adaptive_conductance_r2.zip` | 30 paired seeds × 3 conditions = 90 runs; both primary comparisons `NO_CLEAR_DIFFERENCE` |
| `versions/v6.5/` | `RootNet_v6_5_dynamic_environment_r2.zip` | 30 paired seeds × 8 conditions = 240 runs; all eight comparisons `NO_CLEAR_DIFFERENCE`; retain `COMPLETED_WITH_PROTOCOL_DEVIATION` |
| `versions/v6.6/` | `RootNet_v6_6_r2_continuous_coordinates.zip` | 30 seeds × 2 transport modes × 5 angles = 300 records; 24/24 primary rotation comparisons equivalent within ±5%; 274/300 early extinctions |
| `versions/v6.7/` | `RootNet_v6_7_Causal_Separation_SEALED_2026-08-21.zip` | 160-run development assay; `WATER_FIELD_DOMINANT` in the sealed reference runtime; no confirmatory v6.7 evaluation |

`README.md` describes the complete v5.8.0–v6.7 research series and the allowed claim boundaries. `SHA256SUMS.txt` covers every other file in this bundle. `VERIFICATION_REPORT.md` records the clean-extraction checks performed while building this archive.

## Requirements

- Python from the standard library only; no third-party Python packages are required by these four packages.
- Use the exact runtime declared inside a package when byte-exact sealed replay is required.
- The bundle-build verification environment was Windows 11 x86-64 with CPython 3.14.5.

Other platforms may execute the model but can produce a different byte-level dynamic-state digest because of floating-point and math-library differences. This does not by itself indicate artifact corruption. It is also not automatically harmless: compare discrete topology, IDs, events, and counts exactly, and compare continuous values with prespecified tolerances.

## 1. Verify bundle integrity

From the extracted bundle root in PowerShell:

```powershell
Get-Content .\SHA256SUMS.txt | ForEach-Object {
    if ($_ -match '^([0-9A-F]{64})  (.+)$') {
        $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Matches[2]).Hash
        if ($actual -ne $Matches[1]) { throw "SHA-256 mismatch: $($Matches[2])" }
    }
}
```

The companion `*_SHA256.txt` files record the original hashes published with individual packages or results. The top-level `SHA256SUMS.txt` independently covers the assembled GitHub bundle.

## 2. Verify an individual package

Extract the selected package ZIP into a new directory, enter the directory containing `verify_package.py`, and run:

```powershell
python verify_package.py
```

Expected clean-extraction results in the bundle-build reference environment:

| Version | Tests | Manifest | Sealed validation |
|---|---:|---|---|
| v6.4 r2 | 42/42 | PASS | PASS |
| v6.5 r2 | 52/52 | PASS | PASS |
| v6.6 r2 | 25/25 | PASS | PASS |
| v6.7 | 17/17 | PASS | PASS |

For v6.7, first extract the outer sealed ZIP and then extract the inner `RootNet_v6_7_causal_separation.zip`.

## 3. Reproduce the recorded assays

Run these commands only inside a clean extraction of the matching final package. They can take several minutes.

### v6.4 r2

```powershell
python experiment_v6_4.py --stage evaluation --output reproduced_evaluation_v6_4.json
```

Compare with `versions/v6.4/RootNet_v6_4_Simple_r2_Evaluation.json`. The package README says the evaluation was not yet run because the package was sealed before the evaluation; the companion result in this bundle is the subsequently completed evaluation and the package itself remains unchanged.

### v6.5 r2

```powershell
python experiment_v6_5.py --stage evaluation --output reproduced_evaluation_v6_5.json
```

Compare with `versions/v6.5/RootNet_v6_5_r2_Evaluation.json`. Preserve the published `COMPLETED_WITH_PROTOCOL_DEVIATION` status: 13 early-extinction trajectories were not zero-padded through tick 360 in the original primary calculation. The published post hoc zero-padded sensitivity analysis did not change any of the eight qualitative classifications.

### v6.6 r2

```powershell
python experiment_v6_6.py --stage evaluation --output reproduced_evaluation_v6_6.json
```

Compare with `versions/v6.6/RootNet_v6_6_r2_Confirmatory_Evaluation.json`. The sealed package README predates the authorized evaluation and therefore says `SEALED_NOT_RUN`; the companion result is the subsequently completed 300-record evaluation. Rotation equivalence is an engineering result and must not be presented as ecological health.

### v6.7

```powershell
python experiment_v6_7.py --output reproduced_development_v6_7.json
```

Compare with `RootNet_v6_7_Causal_Separation_Result.json` inside the extracted outer sealed archive. This is a development cause-separation assay, not a confirmatory evaluation. Report the current qualification as:

> `WATER_FIELD_DOMINANT — sealed reference-runtime result; cross-platform portability audit pending`

## Claim boundaries

- A matching artifact hash establishes file identity, not biological validity.
- A package verifier PASS establishes the package's stated mechanical checks, not ecological health.
- v6.4 and v6.5 found no clear difference; they did not prove universal equivalence or uselessness of adaptive conductance.
- v6.6 passed its rotation audit but exposed severe ecological collapse.
- v6.7 diagnosed the tested water field as dominant but did not select or validate a final repaired water field.
- None of these artificial systems is calibrated to predict a real fungal species or ecosystem.

## GitHub note

No software license is added by this bundle. Repository owners should add an explicit license only after choosing the intended reuse terms. Until then, publication on GitHub alone should not be interpreted as granting a particular open-source license.
