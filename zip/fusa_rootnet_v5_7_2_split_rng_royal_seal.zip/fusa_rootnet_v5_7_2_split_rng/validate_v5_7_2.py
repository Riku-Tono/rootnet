from __future__ import annotations

import argparse
import json
import tempfile
import time
from pathlib import Path

from ecosystem import FusaEcosystem
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic


def external_weather(report) -> dict:
    return {
        "day": report.day,
        "solar": report.solar.to_dict(),
        "weather": report.weather.to_dict(),
        "moon_phase": report.marine.moon_phase,
        "tide_level": report.marine.tide_level,
        "wave_strength": report.marine.wave_strength,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("validation_v5_7_2.json"))
    args = parser.parse_args()
    started = time.perf_counter()

    continuous = FusaEcosystem.demo(rng_seed=20260801)
    split = FusaEcosystem.demo(rng_seed=20260801)
    for _ in range(320):
        continuous.step()
    for _ in range(137):
        split.step()

    with tempfile.TemporaryDirectory() as folder:
        save_path = Path(folder) / "day137.json"
        save_ecosystem_atomic(split, save_path)
        resumed = load_ecosystem(
            save_path,
            rng_seed=999,
            world_seed=998,
            individual_seed=997,
            mutation_seed=996,
            action_seed=995,
        )
        for _ in range(183):
            resumed.step()

    continuous_data = ecosystem_to_dict(continuous)
    resumed_data = ecosystem_to_dict(resumed)

    low = FusaEcosystem.demo(rng_seed=29)
    high = FusaEcosystem.demo(rng_seed=29)
    low.plants["memory-001"].temperament.cooperation = 0.10
    high.plants["memory-001"].temperament.cooperation = 0.90
    low_weather = []
    high_weather = []
    for _ in range(120):
        low_weather.append(external_weather(low.step()))
        high_weather.append(external_weather(high.step()))

    report = {
        "version": "5.7.2",
        "schema_version": continuous_data["schema_version"],
        "continuous_vs_save_resume": {
            "master_seed": 20260801,
            "total_days": 320,
            "save_day": 137,
            "resume_days": 183,
            "exact_ecosystem_dict_match": continuous_data == resumed_data,
            "ecosystem_rng_seeds_match": continuous.rng_seeds == resumed.rng_seeds,
            "ecosystem_rng_states_match": continuous_data["rng_states"] == resumed_data["rng_states"],
            "all_plant_rng_states_match": all(
                left["rng_states"] == right["rng_states"]
                for left, right in zip(continuous_data["plants"], resumed_data["plants"])
            ),
            "final_day": resumed.day,
            "final_living": len(resumed.living_plants()),
            "total_plants": len(resumed.plants),
        },
        "temperament_intervention_weather_control": {
            "master_seed": 29,
            "days": 120,
            "plant_id": "memory-001",
            "low_cooperation": 0.10,
            "high_cooperation": 0.90,
            "external_weather_exact_match": low_weather == high_weather,
            "low_action_counts": low.life_action_counts,
            "high_action_counts": high.life_action_counts,
        },
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }
    report["pass"] = all((
        report["continuous_vs_save_resume"]["exact_ecosystem_dict_match"],
        report["continuous_vs_save_resume"]["ecosystem_rng_seeds_match"],
        report["continuous_vs_save_resume"]["ecosystem_rng_states_match"],
        report["continuous_vs_save_resume"]["all_plant_rng_states_match"],
        report["temperament_intervention_weather_control"]["external_weather_exact_match"],
    ))
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
