# RootNet v5.8.0 Biological Model Specification

## Scope and limitations

The model represents fungi, algae, and symbiotic organisms combining functions of both. Because it has not been calibrated with measured data, it must not be used to predict the population sizes or mortality rates of real species. It is an artificial ecosystem for studying resource allocation, fragmentation, containment, and community transitions produced by the specified rules.

## State variables

Each organism has internal pools ranging from 0.0 to 1.5.

- `carbon`: carbon and chemical energy used for maintenance metabolism and growth
- `water`: hydration state
- `nitrogen`: nitrogen required for growth

Consecutive deficit days are also stored for each resource. On a day with adequate supply, the corresponding count recovers by one day.

## Physiological traits

- `photosynthetic_efficiency`: efficiency of obtaining carbon from light
- `substrate_uptake`: efficiency of obtaining carbon from organic substrate
- `nitrogen_uptake`: uptake of soil nitrogen
- `water_uptake`: uptake from rain and stored water
- `maintenance_rate`: daily carbon maintenance cost
- `resource_sharing`: tendency to provide resources to connected organisms
- `fusion_compatibility`: transport compatibility with a connected organism
- `desiccation_tolerance`: tolerance that reduces water-maintenance cost

These traits are derived deterministically from genes and morphological traits inherited from earlier versions. In offspring, they change through inherited and mutated genes. They are not personality traits.

## Daily calculation order

1. Acquire external resources from light, substrate, rain, stored water, and soil
2. Transport resources across connected RootNet and seafloor-RootNet edges
3. Consume carbon, water, and nitrogen for maintenance
4. Update deficit-day counters and tissue damage
5. Use remaining resources for growth
6. Update environmental stress, biosecurity, reproduction, fragmentation, and reconnection

Fungi have a photosynthetic efficiency of zero. Carbon input for algae depends on light. Symbiotic organisms use both light-derived and substrate-derived carbon.

## RootNet resource transport

When the resource difference between two connected organisms exceeds 0.10, the resource is transported from the higher side to the lower side. The amount is approximately proportional to:

~~~text
(resource difference - 0.10)
x conductivity
x donor resource_sharing
x the lower fusion_compatibility of the two organisms
~~~

The donor retains a minimum reserve of 0.18. Transport has no external loss and conserves the total amount across all organisms.

## Mass-balance audit

The following is recorded for every resource on every day:

~~~text
starting amount + external input - capacity overflow - maintenance consumption - growth consumption - ending amount
~~~

This value is stored as `mass_balance_error`. The test tolerance is an absolute value below `1e-10`.

## Deficits and death

When a shortfall exceeds 10% of the required amount, the corresponding deficit-day count increases. Starting on day 4, damage accumulates according to the duration of the deficit. An organism dies from carbon deficit, water deficit, or nitrogen deficit when a deficit has continued for at least 18 days and vitality has fallen to 0.18 or below.
