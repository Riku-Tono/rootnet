from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ecosystem import FusaEcosystem
from models import EnvironmentalMemory, FusaGene, InfrastructureState, PlantCondition, StressRecord, FusaSeed
from network import RootNet
from simulation import FusaPlant

SCHEMA_VERSION = 4


def _as_random_state(value: Any) -> Any:
    """JSONのlistをrandom.setstate()が要求するtupleへ戻す。"""
    if isinstance(value, list):
        return tuple(_as_random_state(item) for item in value)
    return value


def plant_to_dict(plant: FusaPlant) -> dict[str, Any]:
    return {
        "name": plant.name, "plant_id": plant.plant_id, "lineage": plant.lineage,
        "district": plant.district, "elder": plant.elder, "generation": plant.generation,
        "alive": plant.alive, "death_day": plant.death_day, "death_reason": plant.death_reason,
        "age": plant.age, "day": plant.day, "fusa_level": plant.fusa_level,
        "genes": [g.to_dict() for g in plant.genes], "condition": plant.condition.to_dict(),
        "environmental_memory": plant.memory.to_dict(), "weather_history": plant.weather_history,
        "stress_history": [s.to_dict() for s in plant.stress_history],
        "offspring": [seed.to_dict() for seed in plant.offspring],
        "last_reproduction_day": plant.last_reproduction_day,
        "rng_state": plant._rng.getstate(),
    }


def ecosystem_to_dict(eco: FusaEcosystem) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION, "name": eco.name, "day": eco.day,
        "plants": [plant_to_dict(p) for p in eco.plants.values()],
        "rootnet": eco.rootnet.to_dict(), "infrastructure": eco.infrastructure.to_dict(),
        "event_history": eco.event_history,
        "next_plant_serial": eco.next_plant_serial,
        "rng_state": eco._rng.getstate(),
    }


def save_ecosystem_atomic(eco: FusaEcosystem, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(ecosystem_to_dict(eco), f, ensure_ascii=False, indent=2)
        f.flush()
    temp.replace(path)


def load_ecosystem(path: Path, rng_seed: int | None = None) -> FusaEcosystem:
    if not path.exists():
        return FusaEcosystem.demo(rng_seed)
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if int(data.get("schema_version", 0)) < 4:
        return FusaEcosystem.demo(rng_seed)
    eco = FusaEcosystem(str(data.get("name", "王立フサ生態基盤")), rng_seed)
    eco.day = int(data.get("day", 0))
    for index, item in enumerate(data.get("plants", [])):
        plant = FusaPlant(
            name=str(item["name"]), generation=int(item.get("generation", 1)),
            genes=[FusaGene.from_dict(g) for g in item.get("genes", [])],
            memory=EnvironmentalMemory.from_dict(item.get("environmental_memory", {})),
            rng_seed=None if rng_seed is None else rng_seed + index,
            plant_id=str(item.get("plant_id", item["name"])),
            lineage=str(item.get("lineage", "memory")), district=str(item.get("district", "中央庭園")),
            elder=bool(item.get("elder", False)),
        )
        plant.alive = bool(item.get("alive", True))
        plant.death_day = (
            int(item["death_day"]) if item.get("death_day") is not None else None
        )
        plant.death_reason = (
            str(item["death_reason"]) if item.get("death_reason") is not None else None
        )
        plant.age = int(item.get("age", 0)); plant.day = int(item.get("day", eco.day))
        plant.fusa_level = float(item.get("fusa_level", 5.0))
        plant.condition = PlantCondition.from_dict(item.get("condition", {}))
        plant.weather_history = list(item.get("weather_history", []))
        plant.stress_history = [StressRecord.from_dict(x) for x in item.get("stress_history", [])]
        plant.offspring = [FusaSeed.from_dict(x) for x in item.get("offspring", [])]
        plant.last_reproduction_day = int(item.get("last_reproduction_day", -10_000))
        if item.get("rng_state") is not None:
            plant._rng.setstate(_as_random_state(item["rng_state"]))
        eco.add_plant(plant)
    eco.rootnet = RootNet.from_dict(data.get("rootnet", {}))
    eco.infrastructure = InfrastructureState.from_dict(data.get("infrastructure", {}))
    eco.event_history = list(data.get("event_history", []))
    eco.next_plant_serial = int(data.get("next_plant_serial", 1))
    if data.get("rng_state") is not None:
        eco._rng.setstate(_as_random_state(data["rng_state"]))
    return eco
