# RootNet v6.8 `+0.035` confirmatory protocol

## Status before seed generation

`LOCKED_BEFORE_CONFIRMATORY_SEEDS`

The candidate is fixed at `water_capacity_lift = 0.035`. Results may not be
used to move it to `0.033`, `0.037`, or any other value in this evaluation.

## Design

- seed namespace: `rootnet-v6.8-lift-0.035-confirmatory-v1`
- 30 completely unused seeds, derived and locked only after the critical-file seal
- 360 ticks, 42×42 circular arena, three founders, rotation 0°
- two water conditions: `v66-radial` control and `v68-radial-lift-0.035` candidate
- two transport modes: `fixed-equalize` and `adaptive-equalize`
- immediate necrosis (`necrosis_grace_ticks=0`)
- 30 × 2 × 2 = 120 runs

Each seed/transport pair is evaluated under both water conditions. All results,
including failures and zero tails, are retained.

## Acceptance rule

Every rule in `EVALUATION_ACCEPTANCE_CRITERIA.json` must pass:

1. Candidate pooled whole-ecosystem extinction is 10–50%, inclusive.
2. Candidate reduces pooled extinction by at least 25 percentage points versus control.
3. Candidate extinction does not exceed control in either transport mode.
4. Candidate pooled cumulative necrosis remains 10–90%, inclusive.
5. Energy, water, and conductance-budget errors remain at most `1e-12`.
6. Candidate/control ratio of medians is at least 1.25 for mean total hyphal
   length, 1.25 for mean tips, and 1.20 for mean branch modules.
7. Within each transport mode, at least 70% of the 30 paired runs improve each
   of those three fluffiness endpoints.
8. Module necrosis, ramet death, genet extinction, fragmentation, and spore
   establishment failure remain separately recorded.

The verdict is `V6_8_LIFT_0_035_CONFIRMED` only if all checks pass. Otherwise it
is `V6_8_LIFT_0_035_NOT_REPRODUCED`, and this candidate is closed without
changing the lift, thresholds, or seeds.

This is an artificial-system engineering/ecology evaluation, not biological
calibration to a real fungus.
