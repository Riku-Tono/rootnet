"""RootNet v6.2 local-module metabolism and partial-necrosis kernel."""

from .model import Genet, Genome, HyphalNode, Phenotype, Ramet, Spore, TRAIT_NAMES
from .simulation import ModuleSimulation, SimulationConfig

__all__ = [
    "Genet",
    "Genome",
    "HyphalNode",
    "ModuleSimulation",
    "Phenotype",
    "Ramet",
    "SimulationConfig",
    "Spore",
    "TRAIT_NAMES",
]

__version__ = "6.2.0"
