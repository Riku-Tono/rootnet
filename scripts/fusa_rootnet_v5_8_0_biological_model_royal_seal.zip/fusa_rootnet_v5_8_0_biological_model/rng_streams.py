from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any


STREAM_NAMES = ("world", "individual", "mutation", "action")
_MASK_64 = (1 << 64) - 1


def derive_seed(base_seed: int, label: str) -> int:
    """同じ基底seedとラベルから、安定した独立64-bit seedを作る。"""
    payload = f"RootNet-v5.7.2|{int(base_seed) & _MASK_64}|{label}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def resolve_seed_bundle(
    master_seed: int | None,
    *,
    world_seed: int | None = None,
    individual_seed: int | None = None,
    mutation_seed: int | None = None,
    action_seed: int | None = None,
) -> dict[str, int]:
    """明示seedを優先し、残りをmasterから決定的に派生する。"""
    explicit = {
        "world": world_seed,
        "individual": individual_seed,
        "mutation": mutation_seed,
        "action": action_seed,
    }
    resolved: dict[str, int] = {}
    for name in STREAM_NAMES:
        value = explicit[name]
        if value is not None:
            resolved[name] = int(value) & _MASK_64
        elif master_seed is not None:
            resolved[name] = derive_seed(master_seed, name)
        else:
            resolved[name] = secrets.randbits(64)
    return resolved


def spawn_seed(stream_seed: int, subject_id: str) -> int:
    """群落系列を消費せず、個体ID専用のseedを派生する。"""
    return derive_seed(stream_seed, f"plant:{subject_id}")


def seed_from_legacy_state(state: Any, stream_name: str) -> int:
    """旧単一乱数状態から、移行用の独立seedを再現可能に作る。"""
    payload = json.dumps(state, ensure_ascii=True, separators=(",", ":"))
    digest = hashlib.sha256(
        f"RootNet-v5.7.2-migration|{stream_name}|{payload}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big")
