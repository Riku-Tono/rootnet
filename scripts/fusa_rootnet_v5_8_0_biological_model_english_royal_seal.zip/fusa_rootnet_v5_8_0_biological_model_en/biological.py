from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable


RESOURCE_NAMES = ("carbon", "water", "nitrogen")
FUNCTIONAL_GROUPS = ("fungus", "alga", "symbiotic")


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


@dataclass
class BiologicalTraits:
    """Heritable physiological parameters, not personality descriptors."""

    functional_group: str = "symbiotic"
    photosynthetic_efficiency: float = 0.45
    substrate_uptake: float = 0.45
    nitrogen_uptake: float = 0.50
    water_uptake: float = 0.50
    maintenance_rate: float = 0.030
    resource_sharing: float = 0.50
    fusion_compatibility: float = 0.65
    desiccation_tolerance: float = 0.50

    def normalize(self) -> None:
        if self.functional_group not in FUNCTIONAL_GROUPS:
            self.functional_group = "symbiotic"
        for name in (
            "photosynthetic_efficiency",
            "substrate_uptake",
            "nitrogen_uptake",
            "water_uptake",
            "resource_sharing",
            "fusion_compatibility",
            "desiccation_tolerance",
        ):
            setattr(self, name, _clamp(float(getattr(self, name))))
        self.maintenance_rate = _clamp(float(self.maintenance_rate), 0.008, 0.080)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BiologicalTraits":
        value = cls(
            functional_group=str(data.get("functional_group", "symbiotic")),
            photosynthetic_efficiency=float(data.get("photosynthetic_efficiency", 0.45)),
            substrate_uptake=float(data.get("substrate_uptake", 0.45)),
            nitrogen_uptake=float(data.get("nitrogen_uptake", 0.50)),
            water_uptake=float(data.get("water_uptake", 0.50)),
            maintenance_rate=float(data.get("maintenance_rate", 0.030)),
            resource_sharing=float(data.get("resource_sharing", 0.50)),
            fusion_compatibility=float(data.get("fusion_compatibility", 0.65)),
            desiccation_tolerance=float(data.get("desiccation_tolerance", 0.50)),
        )
        value.normalize()
        return value

    @classmethod
    def derive(cls, lineage: str, genes: Iterable[Any], legacy_traits: Any) -> "BiologicalTraits":
        genes = list(genes)
        sunlight = sum(g.sunlight_love for g in genes) / max(1, len(genes))
        dew = sum(g.dew_affinity for g in genes) / max(1, len(genes))
        patience = sum(g.patience for g in genes) / max(1, len(genes))
        group = {
            "elder": "fungus",
            "amber": "fungus",
            "aqua": "alga",
            "sea": "alga",
            "memory": "symbiotic",
            "coastal": "symbiotic",
        }.get(lineage, "symbiotic")
        photo_scale = {"fungus": 0.0, "alga": 0.78, "symbiotic": 0.48}[group]
        substrate_scale = {"fungus": 0.82, "alga": 0.12, "symbiotic": 0.52}[group]
        value = cls(
            functional_group=group,
            photosynthetic_efficiency=photo_scale * sunlight / 1.5,
            substrate_uptake=substrate_scale * (0.65 + legacy_traits.deep_rooting * 0.35),
            nitrogen_uptake=0.30 + legacy_traits.deep_rooting * 0.45,
            water_uptake=0.30 + dew / 1.5 * 0.45,
            maintenance_rate=0.022 + max(0.0, 1.3 - patience) * 0.012,
            resource_sharing=0.18 + legacy_traits.symbiosis * 0.67,
            fusion_compatibility=0.24 + legacy_traits.signal_bridge * 0.30 + legacy_traits.symbiosis * 0.38,
            desiccation_tolerance=0.24 + legacy_traits.deep_rooting * 0.38 + legacy_traits.thermal_regulation * 0.28,
        )
        value.normalize()
        return value


@dataclass
class ResourceState:
    carbon: float = 0.72
    water: float = 0.72
    nitrogen: float = 0.58
    carbon_deficit_days: int = 0
    water_deficit_days: int = 0
    nitrogen_deficit_days: int = 0
    cumulative_carbon_input: float = 0.0
    cumulative_water_input: float = 0.0
    cumulative_nitrogen_input: float = 0.0
    cumulative_maintenance: float = 0.0
    cumulative_export: float = 0.0
    cumulative_import: float = 0.0

    def normalize(self) -> None:
        for name in RESOURCE_NAMES:
            setattr(self, name, _clamp(float(getattr(self, name)), 0.0, 1.5))
        for name in ("carbon_deficit_days", "water_deficit_days", "nitrogen_deficit_days"):
            setattr(self, name, max(0, int(getattr(self, name))))
        for name in (
            "cumulative_carbon_input",
            "cumulative_water_input",
            "cumulative_nitrogen_input",
            "cumulative_maintenance",
            "cumulative_export",
            "cumulative_import",
        ):
            setattr(self, name, max(0.0, float(getattr(self, name))))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ResourceState":
        value = cls(**{
            name: data.get(name, field.default)
            for name, field in cls.__dataclass_fields__.items()
        })
        value.normalize()
        return value


@dataclass
class BiologicalFlux:
    plant_id: str
    functional_group: str
    carbon_input: float = 0.0
    water_input: float = 0.0
    nitrogen_input: float = 0.0
    carbon_maintenance: float = 0.0
    water_maintenance: float = 0.0
    nitrogen_maintenance: float = 0.0
    carbon_import: float = 0.0
    carbon_export: float = 0.0
    water_import: float = 0.0
    water_export: float = 0.0
    nitrogen_import: float = 0.0
    nitrogen_export: float = 0.0
    overflow: float = 0.0
    deficiency_damage: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def deficit_reason(state: ResourceState) -> str | None:
    streaks = {
        "carbon deficit": state.carbon_deficit_days,
        "water deficit": state.water_deficit_days,
        "nitrogen deficit": state.nitrogen_deficit_days,
    }
    reason, days = max(streaks.items(), key=lambda item: item[1])
    return reason if days >= 18 else None

