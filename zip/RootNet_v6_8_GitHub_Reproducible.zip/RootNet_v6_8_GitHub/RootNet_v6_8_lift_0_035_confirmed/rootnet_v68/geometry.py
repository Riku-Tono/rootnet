from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable

from .model import NodeId, Point


def rotate_point(point: Point, center: Point, angle_radians: float) -> Point:
    x, y = point
    cx, cy = center
    cosine, sine = math.cos(angle_radians), math.sin(angle_radians)
    dx, dy = x - cx, y - cy
    return (cx + cosine * dx - sine * dy, cy + sine * dx + cosine * dy)


def point_at(origin: Point, heading: float, distance: float) -> Point:
    return (origin[0] + math.cos(heading) * distance,
            origin[1] + math.sin(heading) * distance)


def _orientation(a: Point, b: Point, c: Point) -> float:
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def segments_cross(a: Point, b: Point, c: Point, d: Point, *, epsilon: float = 1e-12) -> bool:
    """Return True only for a proper interior intersection."""

    if any(math.dist(left, right) <= epsilon for left in (a, b) for right in (c, d)):
        return False
    return (_orientation(a, b, c) * _orientation(a, b, d) < -epsilon
            and _orientation(c, d, a) * _orientation(c, d, b) < -epsilon)


class SpatialIndex:
    """Deterministic uniform-grid index for continuous node positions."""

    def __init__(self, cell_size: float) -> None:
        if cell_size <= 0.0:
            raise ValueError("cell_size must be positive")
        self.cell_size = float(cell_size)
        self._buckets: dict[tuple[int, int], set[NodeId]] = defaultdict(set)
        self._positions: dict[NodeId, Point] = {}
        self._owners: dict[NodeId, str] = {}

    def _bucket(self, point: Point) -> tuple[int, int]:
        return (math.floor(point[0] / self.cell_size),
                math.floor(point[1] / self.cell_size))

    def insert(self, node_id: NodeId, point: Point, owner: str) -> None:
        if node_id in self._positions:
            raise ValueError(f"duplicate spatial node: {node_id}")
        self._positions[node_id], self._owners[node_id] = point, owner
        self._buckets[self._bucket(point)].add(node_id)

    def remove(self, node_id: NodeId) -> None:
        point = self._positions.pop(node_id, None)
        self._owners.pop(node_id, None)
        if point is None:
            return
        bucket = self._bucket(point)
        self._buckets[bucket].discard(node_id)
        if not self._buckets[bucket]:
            self._buckets.pop(bucket, None)

    def set_owner(self, node_id: NodeId, owner: str) -> None:
        if node_id not in self._positions:
            raise KeyError(node_id)
        self._owners[node_id] = owner

    def owner(self, node_id: NodeId) -> str:
        return self._owners[node_id]

    def position(self, node_id: NodeId) -> Point:
        return self._positions[node_id]

    def query(self, point: Point, radius: float, *, exclude: Iterable[NodeId] = ()) -> list[NodeId]:
        excluded = set(exclude)
        reach = math.ceil(radius / self.cell_size)
        bx, by = self._bucket(point)
        candidates: list[NodeId] = []
        for y in range(by - reach, by + reach + 1):
            for x in range(bx - reach, bx + reach + 1):
                candidates.extend(self._buckets.get((x, y), ()))
        return sorted(node_id for node_id in candidates
                      if node_id not in excluded
                      and math.dist(point, self._positions[node_id]) <= radius)

    def __len__(self) -> int:
        return len(self._positions)
