# v6.1.0 release notes

- Replaced non-overlapping whole-population generations with persistent, overlapping colony lifetimes.
- Made each organism an explicit spatial mycelium with cells, edges, tips, branching, and local growth.
- Added local substrate, water, light, maintenance, and resource depletion/recovery.
- Added costly spore release without removing the parent; successful offspring and parents can coexist.
- Separated actual colony death from spore establishment failure in both metrics and files.
- Added ancestry, mutation at reproduction, contact-mediated fusion, and conservative resource sharing.
- Added an animated, colored, emoji-labelled VS Code terminal viewer.
- Kept v6.0 unchanged and removed any need for predefined species or programmed radiation events.
