from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from biological import BiologicalTraits, ResourceState
from ecosystem import FusaEcosystem
from models import (
    CoralColony,
    CambrianAbilities,
    CambrianState,
    EnvironmentalMemory,
    FusaGene,
    FusaSeed,
    FusaTraits,
    InfrastructureState,
    LifeEvent,
    LifeNeeds,
    MarineState,
    PlantCondition,
    RelationshipState,
    SensoryState,
    SolarState,
    StoredSeed,
    StressRecord,
    Temperament,
)
from network import RootNet
from rng_streams import STREAM_NAMES, resolve_seed_bundle, seed_from_legacy_state
from simulation import FusaPlant

SCHEMA_VERSION = 12


def _as_random_state(value: Any) -> Any:
    """Convert JSON lists back to the tuples required by random.setstate()."""
    if isinstance(value, list):
        return tuple(_as_random_state(item) for item in value)
    return value


def _rng_states(value: FusaEcosystem | FusaPlant) -> dict[str, Any]:
    return {
        "world": value._world_rng.getstate(),
        "individual": value._individual_rng.getstate(),
        "mutation": value._mutation_rng.getstate(),
        "action": value._action_rng.getstate(),
    }


def _saved_seed_bundle(data: dict[str, Any], fallback: dict[str, int]) -> dict[str, int]:
    saved = data.get("rng_seeds")
    if isinstance(saved, dict) and all(name in saved for name in STREAM_NAMES):
        return {name: int(saved[name]) for name in STREAM_NAMES}
    legacy_state = data.get("rng_state")
    if legacy_state is not None:
        return {
            name: seed_from_legacy_state(legacy_state, name)
            for name in STREAM_NAMES
        }
    return dict(fallback)


def _restore_rng_states(value: FusaEcosystem | FusaPlant, data: dict[str, Any]) -> None:
    states = data.get("rng_states")
    if not isinstance(states, dict):
        return
    for name in STREAM_NAMES:
        state = states.get(name)
        if state is not None:
            getattr(value, f"_{name}_rng").setstate(_as_random_state(state))


def plant_to_dict(plant: FusaPlant) -> dict[str, Any]:
    return {
        "name": plant.name, "plant_id": plant.plant_id, "lineage": plant.lineage,
        "district": plant.district, "elder": plant.elder, "generation": plant.generation,
        "parent_id": plant.parent_id, "ancestor_id": plant.ancestor_id,
        "birth_day": plant.birth_day, "child_ids": plant.child_ids,
        "chirality": plant.chirality, "traits": plant.traits.to_dict(),
        "abilities": plant.abilities.to_dict(),
        "expressed_abilities": plant.expressed_abilities.to_dict(),
        "biohazard_load": plant.biohazard_load,
        "biohazard_origin": plant.biohazard_origin,
        "toxin_potential": plant.toxin_potential,
        "biosecurity_resistance": plant.biosecurity_resistance,
        "quarantine_until": plant.quarantine_until,
        "biological_traits": plant.biological_traits.to_dict(),
        "resources": plant.resources.to_dict(),
        "needs": plant.needs.to_dict(),
        "temperament": plant.temperament.to_dict(),
        "relationships": {
            plant_id: relation.to_dict()
            for plant_id, relation in plant.relationships.items()
        },
        "decision_memory": plant.decision_memory,
        "last_life_action": plant.last_life_action,
        "alive": plant.alive, "death_day": plant.death_day, "death_reason": plant.death_reason,
        "corpse_stage": plant.corpse_stage,
        "decomposition_progress": plant.decomposition_progress,
        "soil_returned": plant.soil_returned,
        "last_senses": plant.last_senses.to_dict(),
        "age": plant.age, "day": plant.day, "fusa_level": plant.fusa_level,
        "genes": [g.to_dict() for g in plant.genes], "condition": plant.condition.to_dict(),
        "environmental_memory": plant.memory.to_dict(), "weather_history": plant.weather_history,
        "stress_history": [s.to_dict() for s in plant.stress_history],
        "offspring": [seed.to_dict() for seed in plant.offspring],
        "last_reproduction_day": plant.last_reproduction_day,
        "rng_seeds": dict(plant.rng_seeds),
        "rng_states": _rng_states(plant),
        "rng_state": plant._action_rng.getstate(),
    }


def ecosystem_to_dict(eco: FusaEcosystem) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION, "name": eco.name, "day": eco.day,
        "plants": [plant_to_dict(p) for p in eco.plants.values()],
        "rootnet": eco.rootnet.to_dict(),
        "undersea_rootnet": eco.undersea_rootnet.to_dict(),
        "infrastructure": eco.infrastructure.to_dict(),
        "solar_state": eco.solar_state.to_dict(),
        "marine_state": eco.marine_state.to_dict(),
        "corals": [coral.to_dict() for coral in eco.corals.values()],
        "seed_inventory": [packet.to_dict() for packet in eco.seed_inventory],
        "lineage_tree": eco.lineage_tree_data(),
        "event_history": eco.event_history,
        "next_plant_serial": eco.next_plant_serial,
        "next_seed_serial": eco.next_seed_serial,
        "capacity_history": eco.capacity_history,
        "water_quality_history": eco.water_quality_history,
        "movement_history": eco.movement_history,
        "severed_links": eco.severed_links,
        "outbreak_history": eco.outbreak_history,
        "biosecurity_history": eco.biosecurity_history,
        "biological_history": eco.biological_history,
        "life_journal": [event.to_dict() for event in eco.life_journal],
        "life_action_counts": eco.life_action_counts,
        "cambrian": eco.cambrian.to_dict(),
        "rng_seeds": dict(eco.rng_seeds),
        "rng_states": _rng_states(eco),
        "rng_state": eco._action_rng.getstate(),
    }


def save_ecosystem_atomic(eco: FusaEcosystem, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(ecosystem_to_dict(eco), f, ensure_ascii=False, indent=2)
        f.flush()
    temp.replace(path)


def load_ecosystem(
    path: Path,
    rng_seed: int | None = None,
    *,
    world_seed: int | None = None,
    individual_seed: int | None = None,
    mutation_seed: int | None = None,
    action_seed: int | None = None,
) -> FusaEcosystem:
    if not path.exists():
        return FusaEcosystem.demo(
            rng_seed,
            world_seed=world_seed,
            individual_seed=individual_seed,
            mutation_seed=mutation_seed,
            action_seed=action_seed,
        )
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    loaded_schema = int(data.get("schema_version", 0))
    if loaded_schema < 4:
        return FusaEcosystem.demo(
            rng_seed,
            world_seed=world_seed,
            individual_seed=individual_seed,
            mutation_seed=mutation_seed,
            action_seed=action_seed,
        )
    fallback_seeds = resolve_seed_bundle(
        rng_seed,
        world_seed=world_seed,
        individual_seed=individual_seed,
        mutation_seed=mutation_seed,
        action_seed=action_seed,
    )
    ecosystem_seeds = _saved_seed_bundle(data, fallback_seeds)
    eco = FusaEcosystem(
        str(data.get("name", "RootNet Biological Community")),
        world_seed=ecosystem_seeds["world"],
        individual_seed=ecosystem_seeds["individual"],
        mutation_seed=ecosystem_seeds["mutation"],
        action_seed=ecosystem_seeds["action"],
    )
    eco.day = int(data.get("day", 0))
    for item in data.get("plants", []):
        plant_id = str(item.get("plant_id", item["name"]))
        plant_seeds = _saved_seed_bundle(item, eco.plant_stream_seeds(plant_id))
        plant = FusaPlant(
            name=str(item["name"]), generation=int(item.get("generation", 1)),
            genes=[FusaGene.from_dict(g) for g in item.get("genes", [])],
            memory=EnvironmentalMemory.from_dict(item.get("environmental_memory", {})),
            plant_id=plant_id,
            lineage=str(item.get("lineage", "memory")), district=str(item.get("district", "Central Garden")),
            elder=bool(item.get("elder", False)),
            parent_id=(
                str(item["parent_id"]) if item.get("parent_id") is not None else None
            ),
            ancestor_id=str(item.get("ancestor_id", item.get("plant_id", item["name"]))),
            birth_day=int(item.get("birth_day", 0)),
            chirality=str(item.get("chirality", "L")),
            traits=FusaTraits.from_dict(item.get("traits", {})),
            abilities=(
                CambrianAbilities.from_dict(item.get("abilities", {}))
                if "abilities" in item
                else None
            ),
            expressed_abilities=(
                CambrianAbilities.from_dict(item.get("expressed_abilities", {}))
                if "expressed_abilities" in item
                else None
            ),
            biological_traits=(
                BiologicalTraits.from_dict(item["biological_traits"])
                if "biological_traits" in item
                else None
            ),
            resources=(
                ResourceState.from_dict(item["resources"])
                if "resources" in item
                else None
            ),
            world_seed=plant_seeds["world"],
            individual_seed=plant_seeds["individual"],
            mutation_seed=plant_seeds["mutation"],
            action_seed=plant_seeds["action"],
        )
        plant.child_ids = [str(value) for value in item.get("child_ids", [])]
        plant.alive = bool(item.get("alive", True))
        plant.death_day = (
            int(item["death_day"]) if item.get("death_day") is not None else None
        )
        plant.death_reason = (
            str(item["death_reason"]) if item.get("death_reason") is not None else None
        )
        plant.corpse_stage = str(
            item.get("corpse_stage", "alive" if plant.alive else "dead organism")
        )
        plant.decomposition_progress = float(item.get("decomposition_progress", 0.0))
        plant.soil_returned = float(item.get("soil_returned", 0.0))
        plant.last_senses = SensoryState.from_dict(item.get("last_senses", {}))
        plant.age = int(item.get("age", 0)); plant.day = int(item.get("day", eco.day))
        plant.fusa_level = float(item.get("fusa_level", 5.0))
        plant.condition = PlantCondition.from_dict(item.get("condition", {}))
        plant.weather_history = list(item.get("weather_history", []))
        plant.stress_history = [StressRecord.from_dict(x) for x in item.get("stress_history", [])]
        plant.offspring = [FusaSeed.from_dict(x) for x in item.get("offspring", [])]
        plant.last_reproduction_day = int(item.get("last_reproduction_day", -10_000))
        plant.biohazard_load = float(item.get("biohazard_load", 0.0))
        plant.biohazard_origin = (
            str(item["biohazard_origin"])
            if item.get("biohazard_origin") is not None
            else None
        )
        plant.toxin_potential = float(
            item.get("toxin_potential", plant.toxin_potential)
        )
        plant.biosecurity_resistance = float(
            item.get("biosecurity_resistance", plant.biosecurity_resistance)
        )
        plant.quarantine_until = int(item.get("quarantine_until", 0))
        plant.needs = LifeNeeds.from_dict(item.get("needs", {}))
        plant.temperament = Temperament.from_dict(item.get("temperament", {}))
        plant.relationships = {
            str(plant_id): RelationshipState.from_dict(relation)
            for plant_id, relation in item.get("relationships", {}).items()
        }
        plant.decision_memory = {
            str(action): {
                str(key): value
                for key, value in record.items()
            }
            for action, record in item.get("decision_memory", {}).items()
        }
        plant.last_life_action = (
            str(item["last_life_action"])
            if item.get("last_life_action") is not None
            else None
        )
        _restore_rng_states(plant, item)
        eco.add_plant(plant)
    eco.rootnet = RootNet.from_dict(data.get("rootnet", {}))
    eco.undersea_rootnet = RootNet.from_dict(data.get("undersea_rootnet", {}))
    eco.infrastructure = InfrastructureState.from_dict(data.get("infrastructure", {}))
    eco.solar_state = SolarState.from_dict(data.get("solar_state", {}))
    eco.marine_state = MarineState.from_dict(data.get("marine_state", {}))
    eco.corals = {
        coral.colony_id: coral
        for coral in [
            CoralColony.from_dict(item)
            for item in data.get("corals", [])
        ]
    }
    eco.seed_inventory = [
        StoredSeed.from_dict(item)
        for item in data.get("seed_inventory", [])
    ]
    eco.event_history = list(data.get("event_history", []))
    eco.next_plant_serial = int(data.get("next_plant_serial", 1))
    eco.next_seed_serial = int(data.get("next_seed_serial", 1))
    eco.capacity_history = [
        int(value) for value in data.get("capacity_history", [])
    ]
    eco.water_quality_history = [
        float(value) for value in data.get("water_quality_history", [])
    ]
    eco.movement_history = [
        dict(value) for value in data.get("movement_history", [])
    ]
    eco.severed_links = [
        dict(value) for value in data.get("severed_links", [])
    ]
    eco.outbreak_history = [
        dict(value) for value in data.get("outbreak_history", [])
    ]
    eco.biosecurity_history = [
        dict(value) for value in data.get("biosecurity_history", [])
    ]
    eco.biological_history = [
        dict(value) for value in data.get("biological_history", [])
    ]
    eco.life_journal = [
        LifeEvent.from_dict(value) for value in data.get("life_journal", [])
    ]
    eco.life_action_counts = {
        str(action): int(count)
        for action, count in data.get("life_action_counts", {}).items()
    }
    eco.cambrian = CambrianState.from_dict(data.get("cambrian", {}))
    _restore_rng_states(eco, data)
    if loaded_schema < 5:
        _migrate_v4_to_v4_1(eco)
    if loaded_schema < 6:
        _migrate_v4_1_to_v5(eco)
    if loaded_schema < 7:
        _migrate_v5_to_v5_5(eco)
    if loaded_schema < 8:
        _migrate_v5_5_to_v5_6(eco)
    return eco


def _migrate_v4_to_v4_1(eco: FusaEcosystem) -> None:
    """Add a coast, sea Fusa, and coral reef once to a legacy v4 community."""
    additions = [
        ("coast-001", "Nagifusa, Listener to the Tide", "coastal", "Coral Coast"),
        ("sea-001", "Mio, Fusa of the Blue Sea", "sea", "Shallow-Sea Garden"),
    ]
    for plant_id, name, lineage, district in additions:
        if plant_id in eco.plants:
            continue
        plant = FusaPlant(
            name=name,
            plant_id=plant_id,
            lineage=lineage,
            district=district,
            ancestor_id=plant_id,
            birth_day=eco.day,
            **{
                f"{stream_name}_seed": stream_seed
                for stream_name, stream_seed in eco.plant_stream_seeds(plant_id).items()
            },
        )
        plant.day = eco.day
        plant.age = eco.day
        eco.add_plant(plant)
    if "aqua-002" in eco.plants and "coast-001" in eco.plants:
        eco.connect_plants(eco.rootnet, "aqua-002", "coast-001", 0.66)
    if "coast-001" in eco.plants and "sea-001" in eco.plants:
        eco.connect_plants(eco.undersea_rootnet, "coast-001", "sea-001", 0.91)
    if "coral-001" not in eco.corals:
        eco.corals["coral-001"] = CoralColony(
            colony_id="coral-001",
            name="Royal Asahi Coral Colony",
            district="Coral Coast",
        )
    # The legacy seed_bank stores only a count and contains no genetic information, so, 
    # start with a new empty seed bank instead of fabricating physical seeds.
    eco.infrastructure.seed_bank = len(eco.seed_inventory)


def _migrate_v4_1_to_v5(eco: FusaEcosystem) -> None:
    """Add the ancient mirror-image D lineage once to a v4.1 community."""
    if "mirror-001" not in eco.plants:
        mirror = FusaPlant(
            name="Mirror-Realm Fusa",
            plant_id="mirror-001",
            lineage="memory",
            district="Mirror-Tide Cave",
            ancestor_id="mirror-001",
            birth_day=eco.day,
            chirality="D",
            **{
                f"{stream_name}_seed": stream_seed
                for stream_name, stream_seed in eco.plant_stream_seeds("mirror-001").items()
            },
        )
        mirror.day = eco.day
        mirror.age = eco.day
        eco.add_plant(mirror)
    if "elder-001" in eco.plants:
        eco.connect_plants(eco.rootnet, "elder-001", "mirror-001", 0.70)


def _migrate_v5_to_v5_5(eco: FusaEcosystem) -> None:
    """Prepare locked ability slots from v5 traits."""
    for packet in eco.seed_inventory:
        if packet.abilities is None or not any(packet.abilities.to_dict().values()):
            parent = eco.plants.get(packet.parent_id)
            packet.abilities = (
                CambrianAbilities.from_dict(parent.abilities.to_dict())
                if parent is not None
                else CambrianAbilities()
            )
    eco.cambrian = CambrianState()


def _migrate_v5_5_to_v5_6(eco: FusaEcosystem) -> None:
    """Carry v5.5 ability values forward as latent abilities and separate their expression values."""
    ratio = 0.75 if eco.cambrian.active else 0.10
    for plant in eco.plants.values():
        plant.expressed_abilities = CambrianAbilities.from_dict({
            name: value * ratio
            for name, value in plant.abilities.to_dict().items()
        })

