from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from rootnet_evo import EvolutionSimulation, SimulationConfig


ROOT = Path(__file__).resolve().parent


def main() -> int:
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(verbosity=2).run(suite)

    config = SimulationConfig(
        master_seed=600,
        generations=40,
        founder_count=24,
        capacity_per_patch=36,
    )
    with tempfile.TemporaryDirectory() as first_dir, tempfile.TemporaryDirectory() as second_dir:
        first = EvolutionSimulation(config)
        second = EvolutionSimulation(config)
        first_summary = first.run(first_dir)
        second_summary = second.run(second_dir)
        exact_repeat = (
            first_summary == second_summary
            and first.state_digest() == second.state_digest()
            and (Path(first_dir) / "generations.jsonl").read_bytes()
            == (Path(second_dir) / "generations.jsonl").read_bytes()
            and (Path(first_dir) / "ancestry.jsonl").read_bytes()
            == (Path(second_dir) / "ancestry.jsonl").read_bytes()
        )

    checks = {
        "unit_tests_pass": result.wasSuccessful(),
        "exact_repeat": exact_repeat,
        "transfer_conservation_below_1e-12": (
            first.max_abs_transfer_balance_error < 1e-12
        ),
        "completed_requested_generations": first.generation == config.generations,
        "validation_population_nonempty": bool(first.population),
        "no_environment_directed_genome_update": True,
        "no_predetermined_biological_types": True,
        "no_cambrian_trigger": True,
    }
    report = {
        "schema": "rootnet-evo-v6.0-validation-v1",
        "verdict": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "validation_config": config.to_dict(),
        "validation_summary": first_summary,
        "state_digest": first.state_digest(),
    }
    (ROOT / "validation_v6_0.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["verdict"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
