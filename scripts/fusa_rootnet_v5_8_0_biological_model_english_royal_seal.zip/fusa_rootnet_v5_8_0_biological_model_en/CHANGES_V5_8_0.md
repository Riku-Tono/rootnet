# RootNet v5.8.0 Biological Model Change Log

- Created as a derived version without modifying v5.7.2
- Updated the save format to schema v12
- Added fungus, alga, and symbiotic functional groups
- Added physiological traits derived deterministically from genetic and morphological traits
- Added internal carbon, water, and nitrogen pools and cumulative balances
- Disabled photosynthesis in fungi and changed them to use substrate carbon
- Made carbon acquisition by algae depend on sunlight
- Extended RootNet into a conservative resource-transport network
- Added damage from persistent deficits and death from carbon, water, or nitrogen deficit
- Removed personality actions, requests for help, and trust updates from normal daily calculations
- Changed the lineage tree to display functional groups, physiological traits, and resource states
- Added migration that deterministically fills in biological state when loading schema v11
- Added 8 biological-model tests

Legacy anthropomorphic fields are retained only for compatibility when loading old save data.
