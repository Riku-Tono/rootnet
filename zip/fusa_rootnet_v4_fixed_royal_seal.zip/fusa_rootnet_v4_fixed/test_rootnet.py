from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV4Tests(unittest.TestCase):
    def test_three_initial_genes_are_distinct(self) -> None:
        plant = FusaPlant(rng_seed=42)
        variants = {tuple(gene.to_dict().values()) for gene in plant.genes}
        self.assertEqual(3, len(variants))

    def test_save_resume_matches_continuous_run(self) -> None:
        continuous = FusaEcosystem.demo(2718)
        for _ in range(30):
            continuous.step()

        split = FusaEcosystem.demo(2718)
        for _ in range(15):
            split.step()

        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 2718)
            for _ in range(15):
                resumed.step()

        self.assertEqual(
            ecosystem_to_dict(continuous),
            ecosystem_to_dict(resumed),
        )

    def test_seed_germinates_as_next_generation(self) -> None:
        ecosystem = FusaEcosystem.demo(2718)
        for _ in range(30):
            ecosystem.step()
        children = [
            plant for plant in ecosystem.plants.values()
            if plant.generation > 1
        ]
        self.assertGreaterEqual(len(children), 1)
        self.assertTrue(all(len(child.genes) == 3 for child in children))

    def test_old_plant_dies_and_leaves_rootnet(self) -> None:
        ecosystem = FusaEcosystem.demo(7)
        plant = ecosystem.plants["memory-001"]
        plant.age = plant.natural_lifespan() - 1

        report = ecosystem.step()

        self.assertFalse(plant.alive)
        self.assertEqual("寿命を全うした", plant.death_reason)
        self.assertNotIn(plant.plant_id, ecosystem.rootnet.links)
        self.assertIn(
            (plant.plant_id, "寿命を全うした"),
            report.deaths,
        )


if __name__ == "__main__":
    unittest.main()
