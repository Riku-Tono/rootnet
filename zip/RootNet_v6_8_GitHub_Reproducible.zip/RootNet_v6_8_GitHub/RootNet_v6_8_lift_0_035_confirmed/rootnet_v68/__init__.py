"""RootNet v6.8 single-candidate water-field repair assay."""

from .environment import ENVIRONMENT_PROFILES, EXPERIMENT_ENVIRONMENTS
from .model import Genet, Genome, HyphalNode, Phenotype, Ramet, Spore, TRAIT_NAMES
from .simulation import (
    EXPERIMENT_TRANSPORT_MODES,
    ModuleSimulation,
    ROTATION_ANGLES_DEGREES,
    SimulationConfig,
    TRANSPORT_MODES,
    V68_WATER_CAPACITY_LIFT,
    WATER_FIELD_PROFILES,
)

__all__ = [
    "Genet",
    "Genome",
    "HyphalNode",
    "ModuleSimulation",
    "Phenotype",
    "Ramet",
    "SimulationConfig",
    "Spore",
    "TRAIT_NAMES",
    "TRANSPORT_MODES",
    "EXPERIMENT_TRANSPORT_MODES",
    "ENVIRONMENT_PROFILES",
    "EXPERIMENT_ENVIRONMENTS",
    "ROTATION_ANGLES_DEGREES",
    "WATER_FIELD_PROFILES",
    "V68_WATER_CAPACITY_LIFT",
]

__version__ = "6.8.0"
