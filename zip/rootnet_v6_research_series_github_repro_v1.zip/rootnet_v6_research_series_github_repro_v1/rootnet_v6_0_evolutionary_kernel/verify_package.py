from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.txt"


def actual_files() -> set[str]:
    return {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file()
        and path != MANIFEST
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
        and "smoke_output" not in path.parts
        and "run_output" not in path.parts
    }


def verify_manifest() -> list[str]:
    failures: list[str] = []
    if not MANIFEST.exists():
        return ["MANIFEST_SHA256.txt is missing"]
    expected: dict[str, str] = {}
    for line_number, line in enumerate(MANIFEST.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            digest, relative = line.split("  ", 1)
        except ValueError:
            failures.append(f"invalid manifest line {line_number}")
            continue
        expected[relative] = digest

    actual = actual_files()
    if set(expected) != actual:
        missing = sorted(set(expected) - actual)
        extra = sorted(actual - set(expected))
        if missing:
            failures.append(f"missing files: {missing}")
        if extra:
            failures.append(f"unmanifested files: {extra}")

    for relative, expected_digest in sorted(expected.items()):
        path = ROOT / Path(relative)
        if not path.exists():
            continue
        actual_digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual_digest != expected_digest:
            failures.append(f"hash mismatch: {relative}")
    return failures


def run_checked(command: list[str]) -> None:
    completed = subprocess.run(command, cwd=ROOT, check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"command failed ({completed.returncode}): {' '.join(command)}")


def main() -> int:
    failures = verify_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("PACKAGE VERIFICATION: FAIL")
        return 1

    try:
        run_checked([sys.executable, "-m", "unittest", "discover", "-v"])
        run_checked([sys.executable, "validate_v6_0.py"])
    except RuntimeError as error:
        print(f"FAIL: {error}")
        print("PACKAGE VERIFICATION: FAIL")
        return 1

    validation = json.loads((ROOT / "validation_v6_0.json").read_text(encoding="utf-8"))
    if validation.get("verdict") != "PASS":
        print("FAIL: validation_v6_0.json verdict is not PASS")
        print("PACKAGE VERIFICATION: FAIL")
        return 1

    failures = verify_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("PACKAGE VERIFICATION: FAIL")
        return 1

    print("PACKAGE VERIFICATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
