from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from persistence import SCHEMA_VERSION, ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic


class RootNetV572SplitRngTests(unittest.TestCase):
    def test_master_seed_derives_four_distinct_reproducible_streams(self) -> None:
        left = FusaEcosystem.demo(rng_seed=42)
        right = FusaEcosystem.demo(rng_seed=42)

        self.assertEqual(left.rng_seeds, right.rng_seeds)
        self.assertEqual(4, len(set(left.rng_seeds.values())))
        self.assertEqual(
            left.plants["memory-001"].rng_seeds,
            right.plants["memory-001"].rng_seeds,
        )
        self.assertEqual(4, len(set(left.plants["memory-001"].rng_seeds.values())))

    def test_individual_seed_changes_temperament_without_changing_weather(self) -> None:
        common = dict(world_seed=101, mutation_seed=303, action_seed=404)
        left = FusaEcosystem.demo(individual_seed=202, **common)
        right = FusaEcosystem.demo(individual_seed=999, **common)

        left_temperaments = [plant.temperament.to_dict() for plant in left.living_plants()]
        right_temperaments = [plant.temperament.to_dict() for plant in right.living_plants()]
        self.assertNotEqual(left_temperaments, right_temperaments)

        left_weather = []
        right_weather = []
        for _ in range(80):
            left_report = left.step()
            right_report = right.step()
            left_weather.append((
                left_report.solar.to_dict(),
                left_report.weather.to_dict(),
                left_report.marine.moon_phase,
                left_report.marine.tide_level,
                left_report.marine.wave_strength,
            ))
            right_weather.append((
                right_report.solar.to_dict(),
                right_report.weather.to_dict(),
                right_report.marine.moon_phase,
                right_report.marine.tide_level,
                right_report.marine.wave_strength,
            ))
        self.assertEqual(left_weather, right_weather)

    def test_action_draws_do_not_advance_world_or_mutation_streams(self) -> None:
        left = FusaEcosystem.demo(rng_seed=572)
        right = FusaEcosystem.demo(rng_seed=572)
        world_before = right._world_rng.getstate()
        mutation_before = right._mutation_rng.getstate()

        for _ in range(500):
            right._action_rng.random()

        self.assertEqual(world_before, right._world_rng.getstate())
        self.assertEqual(mutation_before, right._mutation_rng.getstate())
        self.assertNotEqual(left._action_rng.getstate(), right._action_rng.getstate())

        left_report = left.step()
        right_report = right.step()
        self.assertEqual(left_report.solar.to_dict(), right_report.solar.to_dict())
        self.assertEqual(left_report.weather.to_dict(), right_report.weather.to_dict())

    def test_all_stream_states_survive_save_resume_exactly(self) -> None:
        continuous = FusaEcosystem.demo(rng_seed=777)
        split = FusaEcosystem.demo(rng_seed=777)

        for _ in range(53):
            continuous.step()
        for _ in range(21):
            split.step()

        with tempfile.TemporaryDirectory() as folder:
            save_path = Path(folder) / "split_rng.json"
            save_ecosystem_atomic(split, save_path)
            saved = json.loads(save_path.read_text(encoding="utf-8"))
            self.assertEqual(SCHEMA_VERSION, saved["schema_version"])
            self.assertEqual(set(("world", "individual", "mutation", "action")), set(saved["rng_states"]))
            self.assertEqual(set(("world", "individual", "mutation", "action")), set(saved["plants"][0]["rng_states"]))
            resumed = load_ecosystem(save_path, rng_seed=999999)

        for _ in range(32):
            resumed.step()

        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_schema10_single_rng_migrates_deterministically(self) -> None:
        source = FusaEcosystem.demo(rng_seed=10)
        for _ in range(12):
            source.step()
        legacy = ecosystem_to_dict(source)
        legacy["schema_version"] = 10
        legacy.pop("rng_seeds", None)
        legacy.pop("rng_states", None)
        for plant in legacy["plants"]:
            plant.pop("rng_seeds", None)
            plant.pop("rng_states", None)

        with tempfile.TemporaryDirectory() as folder:
            save_path = Path(folder) / "schema10.json"
            save_path.write_text(json.dumps(legacy, ensure_ascii=False), encoding="utf-8")
            first = load_ecosystem(save_path, rng_seed=111)
            second = load_ecosystem(save_path, rng_seed=222)

        self.assertEqual(first.rng_seeds, second.rng_seeds)
        self.assertEqual(4, len(set(first.rng_seeds.values())))
        self.assertEqual(
            first.plants["memory-001"].rng_seeds,
            second.plants["memory-001"].rng_seeds,
        )
        for _ in range(20):
            first.step()
            second.step()
        self.assertEqual(ecosystem_to_dict(first), ecosystem_to_dict(second))


if __name__ == "__main__":
    unittest.main()

