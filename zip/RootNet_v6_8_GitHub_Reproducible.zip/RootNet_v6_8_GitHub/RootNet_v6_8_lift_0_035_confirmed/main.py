from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_v68 import (
    ENVIRONMENT_PROFILES,
    ModuleSimulation,
    SimulationConfig,
    TRANSPORT_MODES,
    WATER_FIELD_PROFILES,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="RootNet v6.8 water-field repair simulation")
    parser.add_argument("--ticks", type=int, default=360)
    parser.add_argument("--seed", type=int, default=680)
    parser.add_argument("--width", type=int, default=42)
    parser.add_argument("--height", type=int, default=42)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--transport", choices=TRANSPORT_MODES, default="adaptive-equalize")
    parser.add_argument(
        "--environment",
        choices=ENVIRONMENT_PROFILES,
        default="persistent-patch",
    )
    parser.add_argument("--alpha", type=float, default=0.10)
    parser.add_argument("--weight-min", type=float, default=0.25)
    parser.add_argument("--weight-max", type=float, default=4.0)
    parser.add_argument("--rotation", type=float, default=0.0, help="Assay rotation in degrees")
    parser.add_argument(
        "--water-field",
        choices=WATER_FIELD_PROFILES,
        default="v68-radial-lift-0.035",
    )
    parser.add_argument("--output", type=Path, default=Path("run_output"))
    args = parser.parse_args()
    simulation = ModuleSimulation(SimulationConfig(
        master_seed=args.seed,
        ticks=args.ticks,
        width=args.width,
        height=args.height,
        founder_count=args.founders,
        transport_mode=args.transport,
        environment_profile=args.environment,
        environment_move_start_tick=max(1, args.ticks // 4),
        environment_move_end_tick=max(2, (3 * args.ticks) // 4),
        environment_relocation_tick=max(1, args.ticks // 2),
        environment_damage_tick=max(1, args.ticks // 2),
        conductance_alpha=args.alpha,
        conductance_weight_min=args.weight_min,
        conductance_weight_max=args.weight_max,
        rotation_angle_degrees=args.rotation,
        water_field_profile=args.water_field,
        necrosis_grace_ticks=0,
    ))
    summary = simulation.run(args.output)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nSaved records to: {args.output.resolve()}")


if __name__ == "__main__":
    main()
