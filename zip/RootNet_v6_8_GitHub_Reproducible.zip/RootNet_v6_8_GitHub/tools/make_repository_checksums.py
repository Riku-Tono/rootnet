from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "SHA256SUMS.txt"
EXCLUDED_DIRS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache"}


def main() -> None:
    entries: list[tuple[str, str]] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == OUTPUT:
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append((relative.as_posix(), digest))
    lines = [f"{digest} *{relative}" for relative, digest in sorted(entries)]
    OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"wrote {len(lines)} entries to {OUTPUT}")


if __name__ == "__main__":
    main()

