from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


@dataclass
class FusaGene:
    growth_speed: float
    dew_affinity: float
    wind_resistance: float
    sunlight_love: float
    patience: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaGene":
        gene = cls(**data)
        gene.normalize()
        return gene

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def normalize(self) -> None:
        self.growth_speed = clamp(self.growth_speed, 0.4, 1.8)
        self.dew_affinity = clamp(self.dew_affinity, 0.3, 1.8)
        self.wind_resistance = clamp(self.wind_resistance, 0.4, 1.8)
        self.sunlight_love = clamp(self.sunlight_love, 0.5, 2.0)
        self.patience = clamp(self.patience, 0.6, 2.0)


@dataclass
class PlantCondition:
    health: float = 1.0
    hydration: float = 1.0
    energy: float = 1.0
    damage: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PlantCondition":
        condition = cls(
            health=float(data.get("health", 1.0)),
            hydration=float(data.get("hydration", 1.0)),
            energy=float(data.get("energy", 1.0)),
            damage=float(data.get("damage", 0.0)),
        )
        condition.normalize()
        return condition

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def normalize(self) -> None:
        self.health = clamp(self.health, 0.0, 1.0)
        self.hydration = clamp(self.hydration, 0.0, 1.0)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.damage = clamp(self.damage, 0.0, 1.0)


@dataclass
class EnvironmentalMemory:
    drought: float = 0.0
    strong_wind: float = 0.0
    shade: float = 0.0
    heat: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EnvironmentalMemory":
        memory = cls(
            drought=float(data.get("drought", 0.0)),
            strong_wind=float(data.get("strong_wind", 0.0)),
            shade=float(data.get("shade", 0.0)),
            heat=float(data.get("heat", 0.0)),
        )
        memory.normalize()
        return memory

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def learn(self, stress_type: str, intensity: float) -> None:
        if not hasattr(self, stress_type):
            raise ValueError(f"未知のストレス種別です: {stress_type}")
        current = float(getattr(self, stress_type))
        setattr(self, stress_type, clamp(current + intensity * 0.08, 0.0, 1.0))

    def get(self, stress_type: str) -> float:
        if not hasattr(self, stress_type):
            raise ValueError(f"未知のストレス種別です: {stress_type}")
        return float(getattr(self, stress_type))

    def primed_copy(self, ratio: float = 0.15) -> "EnvironmentalMemory":
        return EnvironmentalMemory(
            drought=self.drought * ratio,
            strong_wind=self.strong_wind * ratio,
            shade=self.shade * ratio,
            heat=self.heat * ratio,
        )

    def normalize(self) -> None:
        self.drought = clamp(self.drought, 0.0, 1.0)
        self.strong_wind = clamp(self.strong_wind, 0.0, 1.0)
        self.shade = clamp(self.shade, 0.0, 1.0)
        self.heat = clamp(self.heat, 0.0, 1.0)


@dataclass
class Weather:
    temperature: float
    sunlight: float
    rainfall: float
    wind_speed: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Weather":
        return cls(**data)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class StressRecord:
    day: int
    stress_type: str
    display_name: str
    intensity: float
    effective_intensity: float
    mitigation: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StressRecord":
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FusaSeed:
    name: str
    parent_name: str
    generation: int
    genes: list[FusaGene]
    memory: EnvironmentalMemory
    born_day: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusaSeed":
        return cls(
            name=str(data["name"]),
            parent_name=str(data["parent_name"]),
            generation=int(data["generation"]),
            genes=[FusaGene.from_dict(item) for item in data["genes"]],
            memory=EnvironmentalMemory.from_dict(data.get("memory", {})),
            born_day=int(data["born_day"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "parent_name": self.parent_name,
            "generation": self.generation,
            "genes": [gene.to_dict() for gene in self.genes],
            "memory": self.memory.to_dict(),
            "born_day": self.born_day,
        }


@dataclass
class InfrastructureState:
    water_quality: float = 0.45
    water_reserve: float = 0.65
    amber_fuel: float = 0.0
    pest_pressure: float = 0.25
    pollination: float = 0.35
    seed_bank: int = 0

    def normalize(self) -> None:
        self.water_quality = clamp(self.water_quality, 0.0, 1.0)
        self.water_reserve = clamp(self.water_reserve, 0.0, 1.0)
        self.amber_fuel = clamp(self.amber_fuel, 0.0, 1000.0)
        self.pest_pressure = clamp(self.pest_pressure, 0.0, 1.0)
        self.pollination = clamp(self.pollination, 0.0, 1.0)
        self.seed_bank = max(0, int(self.seed_bank))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InfrastructureState":
        value = cls(
            water_quality=float(data.get("water_quality", 0.45)),
            water_reserve=float(data.get("water_reserve", 0.65)),
            amber_fuel=float(data.get("amber_fuel", 0.0)),
            pest_pressure=float(data.get("pest_pressure", 0.25)),
            pollination=float(data.get("pollination", 0.35)),
            seed_bank=int(data.get("seed_bank", 0)),
        )
        value.normalize()
        return value
