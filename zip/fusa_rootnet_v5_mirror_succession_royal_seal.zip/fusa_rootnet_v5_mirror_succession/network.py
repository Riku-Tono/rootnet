from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

from models import clamp


@dataclass
class RootSignal:
    day: int
    signal_type: str
    message: str
    strength: float
    origin_id: str
    ttl: int = 4

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RootSignal":
        return cls(**data)


@dataclass
class SignalReceipt:
    plant_id: str
    signal_type: str
    strength: float
    distance: int


class RootNet:
    """命令ではなく、短い環境情報だけを運ぶ地下分散網。"""

    def __init__(self) -> None:
        self.links: dict[str, dict[str, float]] = {}
        self.signal_history: list[RootSignal] = []

    def add_node(self, plant_id: str) -> None:
        self.links.setdefault(plant_id, {})

    def connect(self, left: str, right: str, conductivity: float = 0.85) -> None:
        if left == right:
            return
        self.add_node(left)
        self.add_node(right)
        value = clamp(conductivity, 0.05, 1.0)
        self.links[left][right] = value
        self.links[right][left] = value

    def remove_node(self, plant_id: str) -> None:
        """死亡株を通信網から外す。履歴と個体記録そのものは残す。"""
        for neighbor in list(self.links.get(plant_id, {})):
            self.links.get(neighbor, {}).pop(plant_id, None)
        self.links.pop(plant_id, None)

    def broadcast(self, signal: RootSignal) -> list[SignalReceipt]:
        self.signal_history.append(signal)
        receipts: list[SignalReceipt] = []
        queue = deque([(signal.origin_id, signal.strength, 0)])
        strongest = {signal.origin_id: signal.strength}

        while queue:
            node, strength, distance = queue.popleft()
            receipts.append(SignalReceipt(node, signal.signal_type, strength, distance))
            if distance >= signal.ttl:
                continue
            for neighbor, conductivity in self.links.get(node, {}).items():
                propagated = strength * conductivity * 0.82
                if propagated < 0.05 or propagated <= strongest.get(neighbor, 0.0):
                    continue
                strongest[neighbor] = propagated
                queue.append((neighbor, propagated, distance + 1))
        return receipts

    def to_dict(self) -> dict[str, Any]:
        return {
            "links": self.links,
            "signal_history": [item.to_dict() for item in self.signal_history],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RootNet":
        network = cls()
        network.links = {
            str(node): {str(other): float(value) for other, value in edges.items()}
            for node, edges in data.get("links", {}).items()
        }
        network.signal_history = [
            RootSignal.from_dict(item) for item in data.get("signal_history", [])
        ]
        return network
