# RootNet v6.0 release notes

## New research line

v6.0 is not an in-place upgrade of v5.8. It is a separate minimal evolutionary
kernel. The v5.8 ecological transport baseline remains unchanged.

## Added

- one-common-ancestor clonal initialization;
- five inherited continuous parameters;
- deterministic phenotype derivation and explicit costs;
- habitat-dependent acquisition without habitat-dependent mutation;
- conservative local resource redistribution;
- non-overlapping survival and reproduction;
- Gaussian inherited mutation and adjacent-patch dispersal;
- homogeneous and heterogeneous habitat presets;
- subject-keyed split random streams;
- full ancestry and per-generation machine-readable traces;
- exact-repeat, conservation, causality, capacity, and scope tests.

## Removed from the evolutionary dynamics

- preassigned fungus, alga, symbiont, species, and ecotype state;
- preassigned immutable lineages;
- `Cambrian` threshold and mutation acceleration;
- within-life environment-directed inherited ability change.

## Not yet added

- physical hyphal morphology;
- separate coevolving partners;
- operational speciation;
- recombination or GRNs;
- geological environmental history;
- a replicated evolutionary experiment.
