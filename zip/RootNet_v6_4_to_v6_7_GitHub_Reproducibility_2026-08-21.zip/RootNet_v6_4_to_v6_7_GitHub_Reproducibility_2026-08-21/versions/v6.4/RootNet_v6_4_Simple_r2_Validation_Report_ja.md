# RootNet v6.4 simple validation report

## 結果

`PASS`

42件のテストが通過した。範囲は機械検証と開発seed 640–641だけで、本評価ではない。

## 主な検証

- v6.3 `none` semantic regression: PASS
- v6.3 `equalize` / v6.4 `fixed-equalize` semantic regression: PASS
- 2-round absolute realized flux加算: PASS
- 総コンダクタンス予算・上下限: PASS
- energy・water保存: PASS
- 強化・減衰・非一様化: PASS
- 同一seed完全再実行: PASS
- topology後、次の輸送開始時に射影: PASS
- 主指標が2つだけであること: PASS
- evaluation seed生成規則・一覧hash・重複排除: PASS
- evaluationのseed一覧・tick・寸法・founderロック: PASS

## 開発seed 640、160 tick

- conductance updates: 477
- strengthened edges: 1541
- weakened edges: 1656
- maximum weight variance: 0.613143223699295
- maximum conductance-budget error: `1.77635683940025e-15`
- maximum energy balance error: `8.88178419700125e-16`
- maximum water balance error: `1.11022302462516e-16`

開発seed 2本のエンドポイント差は評価しない。保存済み解析が`NO_CLEAR_DIFFERENCE`でも、標本数2なので生態学的解釈を与えない。

## 回帰方式

raw float JSON SHAは、PythonやOSによる末尾表現差まで含むためportableな契約にしない。v6.3回帰では、v6.4だけの`edge_weights`を除外し、fixtureの全項目を再帰比較する。離散値はexact、floatだけ`abs_tol=1e-9`, `rel_tol=0`とする。raw SHAは同一環境内の決定性診断だけに使う。

r2では`adaptive_seed_640.state_sha256`を封印validationから除外した。adaptiveの同一環境内決定性は、2 runのraw state SHAをその場で比較する`adaptive_exact_replay`により保持する。

## Evaluation封印

30 seedはnamespaceから決定論的に生成し、seed-list SHA-256 `997ed7c7191e7411fbad7ff151851a599c5920bc5e0aea2f04c649bfc825527f`へ固定した。検証時点でevaluation simulationは未実行である。
