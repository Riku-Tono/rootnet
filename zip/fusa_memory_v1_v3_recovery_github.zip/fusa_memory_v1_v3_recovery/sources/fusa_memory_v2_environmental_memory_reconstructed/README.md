# 環境記憶型フサリウム第2版（ログ復元）

環境ストレス、遺伝形質の適応、ストレス履歴のJSON保存、成長グラフを持つ第2版です。

```bash
python -m pip install -r requirements.txt
python fusa_memory_v2.py
```

当時の保存ログに残る完全なコードと、その直後に承認された2か所の小修正を組み合わせて復元しています。原本ZIPではありません。

Windows PowerShellで絵文字を出力できない場合は、先に `$env:PYTHONIOENCODING = "utf-8"` を設定してください。
