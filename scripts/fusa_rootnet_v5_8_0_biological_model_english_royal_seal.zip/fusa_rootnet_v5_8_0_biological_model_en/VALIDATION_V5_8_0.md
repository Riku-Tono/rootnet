# RootNet v5.8.0 Validation Report

Overall verdict: **PASS**

- Automated tests: 36 run, 0 failures or errors
- Continuous 320 days vs. save after 137 days and resume for 183 days: exact match
- Maximum mass-balance error: `7.105e-15`
- Anthropomorphic behavior in normal daily execution: disabled
- Living organisms after 320 days: 24 (28 historical)
- Living functional groups: {'alga': 15, 'fungus': 8, 'symbiotic': 1}
- Causes of death: {'carbon deficit': 4}
- Functional groups of dead organisms: {'alga': 1, 'symbiotic': 3}
- Cumulative network transport: {'carbon': 2.7908834545528562, 'water': 0.9540839406406353, 'nitrogen': 0.6936789462171242}

The 320-day run under normal conditions is a stability check, not a reproduction of real mortality rates. Resource-deficit death was confirmed in a dedicated test with external inputs disabled.
