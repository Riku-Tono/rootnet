# RootNet v6.3 evaluation report

## Outcome

Both transport conditions were classified `SUPPORTED` against no transport by the rule fixed before evaluation. The evaluation used 30 previously unobserved deterministic seeds, paired across the three conditions, for 360 ticks each.

| Endpoint, median across runs | none | equalize | demand |
|---|---:|---:|---:|
| Living module tick-average | 7.50 | 22.50 | 23.01 |
| Distinct cells ever occupied | 12.0 | 38.5 | 54.5 |
| Ticks with extension | 2.22% | 7.22% | 11.94% |
| Longest extension-free interval | 128.0 | 60.0 | 77.5 |
| Total extensions | 10.5 | 34.5 | 50.5 |
| Necrosis per 100 extensions | 40.00 | 25.95 | 20.59 |
| Final living modules | 9.0 | 30.0 | 45.0 |

Medians in this table are descriptive marginal medians. Confirmatory decisions use paired within-seed differences rather than differences between these marginal medians.

## Preregistered paired results against none

### equalize

- Mean living modules: favorable in 30/30 pairs; median paired increase 13.93; Holm-adjusted p = 7e-9.
- Cells ever occupied: favorable in 30/30; median increase 25; adjusted p = 7e-9.
- Growth-tick fraction: favorable in 28/29 non-tied pairs; median increase 4.72 percentage points; adjusted p = 2.24e-7.
- Longest growth gap: favorable in 18/30; median reduction 68.5 ticks; adjusted p = 0.362.
- Safety guard passed; total ecosystem extinction was 0/30 in both conditions.

### demand

- Mean living modules: favorable in 30/30 pairs; median paired increase 15.82; Holm-adjusted p = 7e-9.
- Cells ever occupied: favorable in 28/28 non-tied pairs; median increase 41.5; adjusted p = 2.2e-8.
- Growth-tick fraction: favorable in 28/30; median increase 9.72 percentage points; adjusted p = 1.736e-6.
- Longest growth gap: favorable in 27/30; median reduction 53.5 ticks; adjusted p = 8.43e-6.
- Safety guard passed; total ecosystem extinction was 0/30 in both conditions.

Maximum observed absolute balance error was `3.55e-15` for energy and `4.44e-16` for water.

## Interpretation

The result supports the statement:

> In this RootNet environment, conservative resource translocation over the hyphal network strongly supports sustained growth and spatial exploration.

It does not support the stronger statement that network translocation is necessary for survival, because no whole-ecosystem extinctions occurred even without transport.

Demand versus equalization is secondary and post hoc. Demand explored more cells in 20/30 pairs and had higher growth-tick fraction in 21/29 non-tied pairs, but mean living modules split 14/16 and longest-gap results were mixed. Demand should therefore be described as a different allocation strategy with stronger exploratory activity here, not as a universally superior transport law.

## Audit trail

- Protocol: `V6_3_PREREGISTERED_PROTOCOL.md`
- Evaluation data: `evaluation_v6_3.json`
- Evaluation source SHA-256: `9cb2c26f81823f8a6ac39107b79b8228d934c829e58dc2342bfab65a6b0f3518`
- Mechanical validation: `validation_v6_3.json`
- Evaluation runtime on this machine: 39.47 seconds for 90 runs.
