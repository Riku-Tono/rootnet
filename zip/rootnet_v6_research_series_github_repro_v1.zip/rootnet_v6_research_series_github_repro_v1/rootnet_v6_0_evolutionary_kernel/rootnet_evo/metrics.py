from __future__ import annotations

import math
import statistics
from collections import Counter
from typing import Iterable

from .model import Individual, Phenotype, TRAIT_NAMES


def _mean(values: Iterable[float]) -> float:
    values = list(values)
    return statistics.fmean(values) if values else 0.0


def population_metrics(population: list[Individual]) -> dict[str, object]:
    if not population:
        return {
            "population": 0,
            "patch_counts": {},
            "extant_founder_branches": 0,
            "trait_means": {name: 0.0 for name in TRAIT_NAMES},
            "trait_variances": {name: 0.0 for name in TRAIT_NAMES},
            "phenotypic_disparity": 0.0,
            "within_patch_disparity": 0.0,
            "between_patch_disparity": 0.0,
            "patch_trait_means": {},
            "analysis_only_strategy_counts": {},
        }

    genomes = [individual.genome for individual in population]
    trait_means = {
        name: _mean(getattr(genome, name) for genome in genomes)
        for name in TRAIT_NAMES
    }
    trait_variances = {
        name: _mean(
            (getattr(genome, name) - trait_means[name]) ** 2
            for genome in genomes
        )
        for name in TRAIT_NAMES
    }
    disparity = math.sqrt(_mean(trait_variances.values()))

    patch_populations: dict[str, list[Individual]] = {}
    for patch_id in sorted({individual.patch_id for individual in population}):
        patch_populations[patch_id] = [
            individual for individual in population
            if individual.patch_id == patch_id
        ]
    patch_trait_means = {
        patch_id: {
            name: _mean(getattr(individual.genome, name) for individual in members)
            for name in TRAIT_NAMES
        }
        for patch_id, members in patch_populations.items()
    }
    within_patch_variance = _mean(
        _mean(
            (getattr(individual.genome, name) - patch_trait_means[patch_id][name]) ** 2
            for name in TRAIT_NAMES
        )
        for patch_id, members in patch_populations.items()
        for individual in members
    )
    between_patch_variance = _mean(
        _mean(
            (patch_trait_means[patch_id][name] - trait_means[name]) ** 2
            for patch_id in patch_trait_means
        )
        for name in TRAIT_NAMES
    )

    strategies: Counter[str] = Counter()
    for genome in genomes:
        phenotype = Phenotype.from_genome(genome)
        difference = phenotype.light_capture - phenotype.substrate_absorption
        if difference > 0.15:
            strategies["light_dominant"] += 1
        elif difference < -0.15:
            strategies["substrate_dominant"] += 1
        else:
            strategies["balanced"] += 1

    return {
        "population": len(population),
        "patch_counts": dict(sorted(Counter(
            individual.patch_id for individual in population
        ).items())),
        "extant_founder_branches": len({
            individual.root_lineage_id for individual in population
        }),
        "trait_means": {
            name: round(value, 9) for name, value in trait_means.items()
        },
        "trait_variances": {
            name: round(value, 9) for name, value in trait_variances.items()
        },
        "phenotypic_disparity": round(disparity, 9),
        "within_patch_disparity": round(math.sqrt(within_patch_variance), 9),
        "between_patch_disparity": round(math.sqrt(between_patch_variance), 9),
        "patch_trait_means": {
            patch_id: {
                name: round(value, 9) for name, value in means.items()
            }
            for patch_id, means in patch_trait_means.items()
        },
        "analysis_only_strategy_counts": dict(sorted(strategies.items())),
    }
