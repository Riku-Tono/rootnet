from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from lineage_view import write_lineage_tree
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic


class RootNetV55Tests(unittest.TestCase):
    def test_cambrian_waits_for_all_five_conditions(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        ecosystem.step()
        self.assertFalse(ecosystem.cambrian.active)
        audit = ecosystem.cambrian.last_audit
        self.assertFalse(audit["generation_ready"])
        self.assertFalse(audit["population_ready"])

        for _ in range(179):
            ecosystem.step()
            if ecosystem.cambrian.active:
                break

        self.assertTrue(ecosystem.cambrian.active)
        self.assertIsNotNone(ecosystem.cambrian.started_day)
        self.assertTrue(all([
            ecosystem.cambrian.last_audit["generation_ready"],
            ecosystem.cambrian.last_audit["population_ready"],
            ecosystem.cambrian.last_audit["diversity_ready"],
            ecosystem.cambrian.last_audit["stable_water_ready"],
            ecosystem.cambrian.last_audit["rootnet_ready"],
        ]))

    def test_all_eight_abilities_unlock_and_appear(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(180):
            ecosystem.step()
        expected = {
            "mobility", "armor", "parasitism", "predation",
            "bioluminescence", "deep_rooting", "false_signal", "mirror_bridge",
        }
        self.assertEqual(expected, set(ecosystem.cambrian.unlocked_abilities))
        expressed = {
            name
            for plant in ecosystem.plants.values()
            for name, value in plant.abilities.to_dict().items()
            if value >= 0.58
        }
        self.assertEqual(expected, expressed)

    def test_post_cambrian_world_records_motion_signals_and_interactions(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        reports = [ecosystem.step() for _ in range(180)]
        self.assertTrue(any(report.false_signals for report in reports))
        self.assertTrue(any(report.movements for report in reports))
        self.assertTrue(any(report.interactions for report in reports))
        self.assertGreater(len(ecosystem.movement_history), 0)

    def test_save_resume_matches_continuous_run_across_cambrian_start(self) -> None:
        continuous = FusaEcosystem.demo(123)
        for _ in range(160):
            continuous.step()

        split = FusaEcosystem.demo(123)
        for _ in range(80):
            split.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet_v5_5.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 123)
            for _ in range(80):
                resumed.step()

        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_lineage_tree_html_contains_filters_and_abilities(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(140):
            ecosystem.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "tree.html"
            write_lineage_tree(ecosystem, output)
            html = output.read_text(encoding="utf-8")
        self.assertIn("RootNet v5.5 フサ系統樹", html)
        self.assertIn('id="chirality"', html)
        self.assertIn("active_abilities", html)
        self.assertIn("mirror-001", html)


if __name__ == "__main__":
    unittest.main()
