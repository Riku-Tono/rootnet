from __future__ import annotations

import hashlib
import random


STREAM_NAMES = (
    "environment",
    "growth",
    "mutation",
    "spore",
    "germination",
    "anastomosis",
)


def derive_seed(base_seed: int, label: str) -> int:
    payload = f"RootNet-v6.6|{int(base_seed)}|{label}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def stream_seeds(master_seed: int) -> dict[str, int]:
    return {name: derive_seed(master_seed, name) for name in STREAM_NAMES}


def keyed_rng(stream_seed: int, subject: str) -> random.Random:
    return random.Random(derive_seed(stream_seed, subject))
