# RootNet v6.3 — 地下ネットワーク転流実験

v6.3は、v6.2.1を変更せず別パッケージにした、菌糸ネットワークの資源転流機能に関する対応比較実験です。

## 今回わかったこと

未観測30 seed、各360 tickの事前固定比較では、転流なしに対して平準化型と先端需要型の両方が、事前判定規則で`SUPPORTED`になりました。

- 転流なし: 生存module数のtick平均中央値 7.50、探索済みセル中央値 12、成長tick率中央値 2.22%。
- 平準化型: 22.50、38.5、7.22%。
- 先端需要型: 23.01、54.5、11.94%。
- 生態系全滅は全条件で0/30でした。

したがって、**この環境では転流がなくても生活は継続しましたが、菌糸グラフ上の保存的転流は持続的成長と空間探索を強く支えました**。「地下ネットワークがなければ生存不能」とはまだ言えません。

詳細は`EVALUATION_REPORT_V6_3.md`、生データは`evaluation_v6_3.json`、事前仕様は`V6_3_PREREGISTERED_PROTOCOL.md`です。

## VS Codeのターミナルで見る

このフォルダーをVS Codeで開き、3条件を別々に見られます。

```powershell
python watch.py --transport none
python watch.py --transport equalize
python watch.py --transport demand
```

同じseedを指定すると、初期条件と乱数系列を対応させられます。

```powershell
python watch.py --transport demand --seed 620 --ticks 360 --delay 0.04
```

記録を保存する場合:

```powershell
python main.py --transport demand --seed 620 --ticks 360 --output run_output_demand
```

## 検証

```powershell
python -m unittest discover -s tests -v
python validate_v6_3.py
python verify_package.py
```

封印済み評価を再現する場合:

```powershell
python experiment_v6_3.py --ticks 360 --replicates 30 --output reproduced_evaluation_v6_3.json
```

Python 3.10以降の標準ライブラリだけを使用します。

## 条件

- `none`: energy・waterをモジュール間で移さない。
- `equalize`: v6.2.1と同じ、局所的な量の差を平準化する固定コンダクタンス転流。
- `demand`: 非先端には2 tick分の維持費、先端にはさらに1回の伸長費を目標量として与えるsource–sink転流。

需要型でも資源を生成せず、送り手の目標維持量を輸出しません。複数辺の流出を送り手単位でまとめて制限し、全変更を同時反映します。観察画面は状態を読むだけで、力学には影響しません。
