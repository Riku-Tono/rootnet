from __future__ import annotations

import argparse
import os
import sys
import time
from collections import defaultdict

from rootnet_mycelium import MyceliumSimulation, SimulationConfig
from rootnet_mycelium.model import Coord


RESET = "\033[0m"
DIM = "\033[2m"
BOLD = "\033[1m"
COLORS = ("\033[38;5;114m", "\033[38;5;81m", "\033[38;5;215m", "\033[38;5;183m", "\033[38;5;117m", "\033[38;5;221m")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Watch living mycelia grow in the terminal")
    parser.add_argument("--ticks", type=int, default=100)
    parser.add_argument("--seed", type=int, default=610)
    parser.add_argument("--delay", type=float, default=0.12)
    parser.add_argument("--width", type=int, default=36)
    parser.add_argument("--height", type=int, default=16)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--no-clear", action="store_true", help="print frames instead of animating in place")
    return parser.parse_args()


def glyph(simulation: MyceliumSimulation, coord: Coord, colony_id: str) -> str:
    colony = simulation.colonies[colony_id]
    if coord in colony.tips:
        return "◆"
    if coord == colony.origin:
        return "●"
    connected = {
        neighbor
        for neighbor in simulation.neighbors(coord)
        if tuple(sorted((coord, neighbor))) in colony.edges
    }
    horizontal = any(x != coord[0] for x, _ in connected)
    vertical = any(y != coord[1] for _, y in connected)
    if horizontal and vertical:
        return "┼"
    if vertical:
        return "│"
    return "─"


def render(simulation: MyceliumSimulation, record: dict[str, object], clear: bool) -> None:
    if clear:
        sys.stdout.write("\033[2J\033[H")
    root_ids = sorted({c.root_branch_id for c in simulation.living_colonies()})
    color_for_root = {root_id: COLORS[index % len(COLORS)] for index, root_id in enumerate(root_ids)}
    spore_positions: dict[Coord, int] = defaultdict(int)
    for spore in simulation.spores:
        spore_positions[spore.position] += 1

    print(f"{BOLD}RootNet v6.1  🌊 空間的な菌糸体  tick {simulation.tick:>3}/{simulation.config.ticks}{RESET}")
    print(
        f"🍄 生存コロニー {record['living_colonies']:>3}   "
        f"🌿 菌糸セル {record['total_hyphal_cells']:>3}   "
        f"◆ 先端 {record['total_tips']:>3}   "
        f"⏳ 最長寿命 {record['oldest_colony_age']:>3} tick"
    )
    print(
        f"👪 親子同時生存 {record['parent_child_pairs_alive_together']:>2}   "
        f"🫧 胞子 {record['pending_spores']:>2}   "
        f"🤝 融合 {record['fusion_links']:>2}   "
        f"💀 実死亡 {len(record['actual_colony_deaths']):>2}   "
        f"× 胞子失敗 {len(record['spore_establishment_failures']):>2}"
    )
    print(f"{DIM}☀ 光の強い海面  ┌{'─' * simulation.config.width}┐{RESET}")
    for y in range(simulation.config.height):
        row = []
        for x in range(simulation.config.width):
            coord = (x, y)
            colony_id = simulation.occupancy.get(coord)
            if colony_id is not None:
                colony = simulation.colonies[colony_id]
                row.append(color_for_root[colony.root_branch_id] + glyph(simulation, coord, colony_id) + RESET)
            elif coord in spore_positions:
                row.append("\033[38;5;229m°" + RESET)
            else:
                row.append(DIM + "·" + RESET)
        print(" " * 15 + "│" + "".join(row) + "│")
    print(f"{DIM}🪨 基質の豊かな深部  └{'─' * simulation.config.width}┘{RESET}")

    events = []
    if record["germinated_colonies"]:
        for child_id in record["germinated_colonies"]:
            child = simulation.colonies[child_id]
            parent_alive = simulation.colonies[child.parent_id].alive
            events.append(f"✨ {child_id} が発芽（親 {child.parent_id} は{'生存' if parent_alive else '死亡'}）")
    if record["spores_released"]:
        events.append(f"🫧 胞子放出: {', '.join(record['spores_released'])}")
    if record["new_fusion_links"]:
        events.append(f"🤝 菌糸融合: {len(record['new_fusion_links'])} 組")
    if record["actual_colony_deaths"]:
        events.append(f"💀 実死亡: {', '.join(record['actual_colony_deaths'])}")
    if record["spore_establishment_failures"]:
        events.append(f"× 定着せず: {', '.join(record['spore_establishment_failures'])}")
    print("  " + ("  /  ".join(events) if events else f"{DIM}菌糸体は生存したまま伸長中…{RESET}"))
    print(f"{DIM}凡例: ● 発芽点  ─│┼ 菌糸  ◆ 成長先端  ° 胞子  色=創始系統{RESET}")
    sys.stdout.flush()


def main() -> None:
    args = parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if os.name == "nt":
        os.system("")
    simulation = MyceliumSimulation(SimulationConfig(
        master_seed=args.seed,
        ticks=args.ticks,
        width=args.width,
        height=args.height,
        founder_count=args.founders,
    ))
    first = {
        "living_colonies": len(simulation.living_colonies()),
        "total_hyphal_cells": sum(len(c.cells) for c in simulation.living_colonies()),
        "total_tips": sum(len(c.tips) for c in simulation.living_colonies()),
        "oldest_colony_age": 0,
        "parent_child_pairs_alive_together": 0,
        "pending_spores": 0,
        "fusion_links": 0,
        "actual_colony_deaths": [],
        "spore_establishment_failures": [],
        "germinated_colonies": [],
        "spores_released": [],
        "new_fusion_links": [],
    }
    render(simulation, first, not args.no_clear)
    time.sleep(max(0.0, args.delay))
    while simulation.tick < simulation.config.ticks and (simulation.living_colonies() or simulation.spores):
        record = simulation.step()
        render(simulation, record, not args.no_clear)
        time.sleep(max(0.0, args.delay))
    print(f"\n{BOLD}終了。これは重複世代です。親は死亡条件を満たすまで残ります。{RESET}")


if __name__ == "__main__":
    main()
