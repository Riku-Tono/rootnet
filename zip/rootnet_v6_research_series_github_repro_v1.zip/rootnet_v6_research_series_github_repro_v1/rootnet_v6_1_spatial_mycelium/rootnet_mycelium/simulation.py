from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .metrics import population_metrics
from .model import Colony, Coord, Genome, Spore, TRAIT_NAMES, canonical_edge, clamp
from .rng import keyed_rng, stream_seeds


COMMON_ANCESTOR_ID = "ancestor-000000"


@dataclass(frozen=True)
class SimulationConfig:
    master_seed: int = 610
    ticks: int = 80
    width: int = 36
    height: int = 16
    founder_count: int = 3
    max_cells_per_colony: int = 140
    mutation_probability: float = 0.20
    mutation_sigma: float = 0.032
    substrate_recovery: float = 0.035
    water_recovery: float = 0.08
    spore_viability_ticks: int = 18
    reproduction_min_age: int = 14
    reproduction_min_cells: int = 11
    founder_genome: Genome = field(default_factory=Genome)

    def normalized(self) -> "SimulationConfig":
        width = max(8, int(self.width))
        height = max(6, int(self.height))
        founder_count = max(1, min(int(self.founder_count), width - 2))
        return SimulationConfig(
            master_seed=int(self.master_seed),
            ticks=max(0, int(self.ticks)),
            width=width,
            height=height,
            founder_count=founder_count,
            max_cells_per_colony=max(2, int(self.max_cells_per_colony)),
            mutation_probability=clamp(self.mutation_probability),
            mutation_sigma=max(0.0, float(self.mutation_sigma)),
            substrate_recovery=clamp(self.substrate_recovery),
            water_recovery=clamp(self.water_recovery),
            spore_viability_ticks=max(1, int(self.spore_viability_ticks)),
            reproduction_min_age=max(1, int(self.reproduction_min_age)),
            reproduction_min_cells=max(2, int(self.reproduction_min_cells)),
            founder_genome=self.founder_genome.normalized(),
        )

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self.normalized())
        result["founder_genome"] = self.founder_genome.normalized().to_dict()
        return result


class MyceliumSimulation:
    def __init__(self, config: SimulationConfig) -> None:
        self.config = config.normalized()
        self.stream_seeds = stream_seeds(self.config.master_seed)
        self.tick = 0
        self._next_colony_serial = 1
        self._next_spore_serial = 1
        self.substrate_capacity, self.water_capacity = self._make_resource_capacities()
        self.substrate = [row[:] for row in self.substrate_capacity]
        self.water = [row[:] for row in self.water_capacity]
        self.colonies: dict[str, Colony] = {}
        self.occupancy: dict[Coord, str] = {}
        self.spores: list[Spore] = []
        self.fusion_links: set[tuple[str, str]] = set()
        self.tick_records: list[dict[str, Any]] = []
        self.ancestry_records: list[dict[str, Any]] = []
        self.death_records: list[dict[str, Any]] = []
        self.spore_records: list[dict[str, Any]] = []
        self.max_abs_fusion_balance_error = 0.0
        self._make_founders()

    def _rng(self, stream_name: str, subject: str):
        return keyed_rng(self.stream_seeds[stream_name], subject)

    def _make_resource_capacities(self) -> tuple[list[list[float]], list[list[float]]]:
        substrate: list[list[float]] = []
        water: list[list[float]] = []
        for y in range(self.config.height):
            depth = y / max(1, self.config.height - 1)
            substrate_row = []
            water_row = []
            for x in range(self.config.width):
                patch = 0.07 * math.sin((x + 1) * 0.71) * math.cos((y + 1) * 0.43)
                substrate_row.append(clamp(0.22 + 0.68 * depth + patch))
                water_row.append(clamp(0.34 + 0.54 * depth - patch * 0.35))
            substrate.append(substrate_row)
            water.append(water_row)
        return substrate, water

    def light_at(self, coord: Coord) -> float:
        _, y = coord
        depth = y / max(1, self.config.height - 1)
        return clamp(1.0 - depth * 0.94, 0.04, 1.0)

    def in_bounds(self, coord: Coord) -> bool:
        x, y = coord
        return 0 <= x < self.config.width and 0 <= y < self.config.height

    def neighbors(self, coord: Coord) -> list[Coord]:
        x, y = coord
        return [
            candidate
            for candidate in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
            if self.in_bounds(candidate)
        ]

    def _make_founders(self) -> None:
        y = self.config.height // 2
        for index in range(self.config.founder_count):
            x = round((index + 1) * (self.config.width - 1) / (self.config.founder_count + 1))
            origin = (x, y)
            colony_id = f"colony-{self._next_colony_serial:07d}"
            self._next_colony_serial += 1
            colony = Colony(
                colony_id=colony_id,
                parent_id=COMMON_ANCESTOR_ID,
                root_branch_id=colony_id,
                birth_tick=0,
                genome=self.config.founder_genome,
                origin=origin,
            )
            self.colonies[colony_id] = colony
            self.occupancy[origin] = colony_id
            self.ancestry_records.append(self._ancestry_record(colony, []))

    @staticmethod
    def _ancestry_record(colony: Colony, mutated_loci: list[str]) -> dict[str, Any]:
        return {
            "colony_id": colony.colony_id,
            "parent_id": colony.parent_id,
            "root_branch_id": colony.root_branch_id,
            "birth_tick": colony.birth_tick,
            "origin": list(colony.origin),
            "genome": colony.genome.to_dict(),
            "mutated_loci": mutated_loci,
        }

    def living_colonies(self) -> list[Colony]:
        return sorted(
            (colony for colony in self.colonies.values() if colony.alive),
            key=lambda colony: colony.colony_id,
        )

    def _replenish_resources(self) -> None:
        for y in range(self.config.height):
            for x in range(self.config.width):
                self.substrate[y][x] += (
                    self.substrate_capacity[y][x] - self.substrate[y][x]
                ) * self.config.substrate_recovery
                self.water[y][x] += (
                    self.water_capacity[y][x] - self.water[y][x]
                ) * self.config.water_recovery

    def _absorb(self, colony: Colony) -> dict[str, float]:
        phenotype = colony.phenotype
        substrate_taken = 0.0
        water_taken = 0.0
        light_energy = 0.0
        for x, y in sorted(colony.cells):
            substrate_amount = min(
                self.substrate[y][x],
                0.0085 * phenotype.substrate_absorption,
            )
            water_amount = min(
                self.water[y][x],
                0.011 * (0.35 + 0.65 * phenotype.desiccation_tolerance),
            )
            self.substrate[y][x] -= substrate_amount
            self.water[y][x] -= water_amount
            substrate_taken += substrate_amount
            water_taken += water_amount
            light_energy += 0.0065 * self.light_at((x, y)) * phenotype.light_capture

        chemical_energy = substrate_taken * 2.45
        colony.energy = min(12.0, colony.energy + chemical_energy + light_energy)
        colony.hydration = min(8.0, colony.hydration + water_taken)
        return {
            "substrate_taken": substrate_taken,
            "water_taken": water_taken,
            "chemical_energy": chemical_energy,
            "light_energy": light_energy,
        }

    def _apply_maintenance(self, colony: Colony) -> None:
        phenotype = colony.phenotype
        colony.energy -= (
            phenotype.base_maintenance
            + len(colony.cells) * phenotype.segment_maintenance
        )
        colony.hydration -= (
            0.0035
            + len(colony.cells)
            * 0.00052
            * (1.0 - 0.55 * phenotype.desiccation_tolerance)
        )
        colony.age += 1

    def _kill_if_depleted(self, colony: Colony) -> bool:
        if colony.energy > 0.0 and colony.hydration > 0.0:
            return False
        reason = "energy_depletion" if colony.energy <= 0.0 else "water_depletion"
        colony.alive = False
        colony.death_tick = self.tick
        colony.death_reason = reason
        for x, y in colony.cells:
            if self.occupancy.get((x, y)) == colony.colony_id:
                del self.occupancy[(x, y)]
            self.substrate[y][x] = clamp(self.substrate[y][x] + 0.018)
        self.fusion_links = {
            pair for pair in self.fusion_links if colony.colony_id not in pair
        }
        self.death_records.append({
            "tick": self.tick,
            "colony_id": colony.colony_id,
            "age": colony.age,
            "cells": len(colony.cells),
            "reason": reason,
        })
        return True

    def _growth_score(self, colony: Colony, coord: Coord) -> float:
        x, y = coord
        phenotype = colony.phenotype
        return (
            self.substrate[y][x] * phenotype.substrate_absorption
            + self.light_at(coord) * phenotype.light_capture
            + self.water[y][x] * phenotype.desiccation_tolerance * 0.45
        )

    def _grow(self, colony: Colony) -> int:
        phenotype = colony.phenotype
        if (
            colony.energy <= phenotype.extension_cost + 0.25
            or len(colony.cells) >= self.config.max_cells_per_colony
            or not colony.tips
        ):
            return 0
        rng = self._rng("growth", f"tick:{self.tick}|colony:{colony.colony_id}")
        attempts = 1 + int(rng.random() < phenotype.extension_rate * 0.62)
        grown = 0
        for attempt in range(attempts):
            if colony.energy <= phenotype.extension_cost + 0.25:
                break
            available_tips = sorted(colony.tips)
            if not available_tips:
                break
            tip = available_tips[rng.randrange(len(available_tips))]
            candidates = [
                coord for coord in self.neighbors(tip)
                if coord not in self.occupancy
            ]
            if not candidates:
                colony.tips.discard(tip)
                continue
            scored = [
                (
                    self._growth_score(colony, coord) + rng.uniform(0.0, 0.16),
                    coord,
                )
                for coord in candidates
            ]
            _, new_coord = max(scored, key=lambda item: (item[0], item[1]))
            colony.cells.add(new_coord)
            colony.edges.add(canonical_edge(tip, new_coord))
            self.occupancy[new_coord] = colony.colony_id
            colony.energy -= phenotype.extension_cost
            if rng.random() >= phenotype.branching_rate:
                colony.tips.discard(tip)
            colony.tips.add(new_coord)
            for neighbor in self.neighbors(new_coord):
                if neighbor in colony.cells and neighbor != tip:
                    colony.edges.add(canonical_edge(new_coord, neighbor))
            grown += 1
            if len(colony.cells) >= self.config.max_cells_per_colony:
                break
        return grown

    def _establish_fusions(self) -> list[tuple[str, str]]:
        contacts: set[tuple[str, str]] = set()
        for coord, colony_id in sorted(self.occupancy.items()):
            for neighbor in self.neighbors(coord):
                other_id = self.occupancy.get(neighbor)
                if other_id is None or other_id == colony_id:
                    continue
                contacts.add(tuple(sorted((colony_id, other_id))))

        new_links = []
        for pair in sorted(contacts - self.fusion_links):
            left = self.colonies[pair[0]]
            right = self.colonies[pair[1]]
            compatibility = min(
                left.phenotype.fusion_tendency,
                right.phenotype.fusion_tendency,
            )
            rng = self._rng("fusion", f"tick:{self.tick}|pair:{pair[0]}|{pair[1]}")
            if rng.random() < 0.10 * compatibility:
                self.fusion_links.add(pair)
                new_links.append(pair)
        return new_links

    def _transfer_across_fusions(self) -> tuple[float, float]:
        living_ids = {colony.colony_id for colony in self.living_colonies()}
        before = sum(self.colonies[colony_id].energy for colony_id in living_ids)
        transferred = 0.0
        for left_id, right_id in sorted(self.fusion_links):
            if left_id not in living_ids or right_id not in living_ids:
                continue
            left = self.colonies[left_id]
            right = self.colonies[right_id]
            left_density = left.energy / max(1, len(left.cells))
            right_density = right.energy / max(1, len(right.cells))
            if abs(left_density - right_density) < 0.01:
                continue
            donor, receiver = (left, right) if left_density > right_density else (right, left)
            compatibility = min(
                donor.phenotype.fusion_tendency,
                receiver.phenotype.fusion_tendency,
            )
            amount = min(
                abs(left_density - right_density)
                * donor.phenotype.resource_sharing
                * compatibility
                * 0.08,
                0.08,
                max(0.0, donor.energy - 0.25),
            )
            donor.energy -= amount
            receiver.energy += amount
            transferred += amount
        after = sum(self.colonies[colony_id].energy for colony_id in living_ids)
        error = after - before
        self.max_abs_fusion_balance_error = max(
            self.max_abs_fusion_balance_error,
            abs(error),
        )
        return transferred, error

    def _mutate_genome(self, parent: Colony, subject: str) -> tuple[Genome, list[str]]:
        rng = self._rng("mutation", subject)
        values = parent.genome.to_dict()
        mutated_loci = []
        for trait_name in TRAIT_NAMES:
            if rng.random() < self.config.mutation_probability:
                values[trait_name] += rng.gauss(0.0, self.config.mutation_sigma)
                mutated_loci.append(trait_name)
        return Genome.from_dict(values), mutated_loci

    def release_spore(
        self,
        colony: Colony,
        position: Coord | None = None,
        *,
        force: bool = False,
    ) -> Spore | None:
        phenotype = colony.phenotype
        if not colony.alive or colony.energy <= phenotype.spore_cost + 0.30:
            return None
        if not force and (
            colony.age < self.config.reproduction_min_age
            or len(colony.cells) < self.config.reproduction_min_cells
        ):
            return None
        spore_id = f"spore-{self._next_spore_serial:08d}"
        self._next_spore_serial += 1
        subject = f"tick:{self.tick}|parent:{colony.colony_id}|spore:{spore_id}"
        genome, mutated_loci = self._mutate_genome(colony, subject)
        rng = self._rng("spore", subject)
        if position is None:
            source = sorted(colony.cells)[rng.randrange(len(colony.cells))]
            radius = 1 + int(round(5 * phenotype.spore_dispersal))
            position = (
                max(0, min(self.config.width - 1, source[0] + rng.randint(-radius, radius))),
                max(0, min(self.config.height - 1, source[1] + rng.randint(-radius, radius))),
            )
        spore = Spore(
            spore_id=spore_id,
            parent_id=colony.colony_id,
            root_branch_id=colony.root_branch_id,
            genome=genome,
            position=position,
            released_tick=self.tick,
            expires_tick=self.tick + self.config.spore_viability_ticks,
        )
        colony.energy -= phenotype.spore_cost
        colony.spores_released += 1
        self.spores.append(spore)
        self.spore_records.append({
            "event": "released",
            "tick": self.tick,
            **spore.to_dict(),
            "mutated_loci": mutated_loci,
        })
        return spore

    def _reproduce(self, colony: Colony) -> Spore | None:
        if (
            colony.age < self.config.reproduction_min_age
            or len(colony.cells) < self.config.reproduction_min_cells
        ):
            return None
        rng = self._rng("spore", f"reproduction:{self.tick}|{colony.colony_id}")
        probability = 0.018 + 0.045 * colony.phenotype.spore_dispersal
        if rng.random() >= probability:
            return None
        return self.release_spore(colony)

    def _germinate_spores(self) -> tuple[list[str], list[str]]:
        germinated: list[str] = []
        failed: list[str] = []
        remaining: list[Spore] = []
        for spore in sorted(self.spores, key=lambda item: item.spore_id):
            x, y = spore.position
            if self.tick > spore.expires_tick:
                failed.append(spore.spore_id)
                self.spore_records.append({
                    "event": "establishment_failed",
                    "tick": self.tick,
                    **spore.to_dict(),
                    "reason": "viability_expired",
                })
                continue
            if spore.position in self.occupancy:
                remaining.append(spore)
                continue
            resource_score = (
                self.substrate[y][x]
                + self.water[y][x]
                + self.light_at(spore.position) * 0.35
            ) / 2.35
            rng = self._rng("survival", f"germinate:{self.tick}|{spore.spore_id}")
            if resource_score < 0.28 or rng.random() >= 0.24 + 0.42 * resource_score:
                remaining.append(spore)
                continue

            colony_id = f"colony-{self._next_colony_serial:07d}"
            self._next_colony_serial += 1
            colony = Colony(
                colony_id=colony_id,
                parent_id=spore.parent_id,
                root_branch_id=spore.root_branch_id,
                birth_tick=self.tick,
                genome=spore.genome,
                origin=spore.position,
                energy=1.8,
                hydration=1.25,
            )
            self.colonies[colony_id] = colony
            self.occupancy[spore.position] = colony_id
            release_record = next(
                record for record in reversed(self.spore_records)
                if record.get("event") == "released"
                and record.get("spore_id") == spore.spore_id
            )
            self.ancestry_records.append(
                self._ancestry_record(colony, list(release_record["mutated_loci"]))
            )
            self.spore_records.append({
                "event": "germinated",
                "tick": self.tick,
                **spore.to_dict(),
                "child_colony_id": colony_id,
                "parent_alive_at_germination": bool(
                    self.colonies.get(spore.parent_id)
                    and self.colonies[spore.parent_id].alive
                ),
            })
            germinated.append(colony_id)
        self.spores = remaining
        return germinated, failed

    def step(self) -> dict[str, Any]:
        if not self.living_colonies() and not self.spores:
            raise RuntimeError("the ecosystem has no living colonies or viable spores")
        self.tick += 1
        self._replenish_resources()
        germinated, failed_spores = self._germinate_spores()
        genome_snapshot = {
            colony.colony_id: colony.genome for colony in self.living_colonies()
        }
        substrate_taken = 0.0
        water_taken = 0.0
        energy_acquired = 0.0
        for colony in self.living_colonies():
            flux = self._absorb(colony)
            substrate_taken += flux["substrate_taken"]
            water_taken += flux["water_taken"]
            energy_acquired += flux["chemical_energy"] + flux["light_energy"]

        transferred, transfer_error = self._transfer_across_fusions()
        deaths = []
        grown_cells = 0
        released = []
        for colony in self.living_colonies():
            self._apply_maintenance(colony)
            if self._kill_if_depleted(colony):
                deaths.append(colony.colony_id)
                continue
            grown_cells += self._grow(colony)
            spore = self._reproduce(colony)
            if spore is not None:
                released.append(spore.spore_id)

        new_fusions = self._establish_fusions()
        for colony_id, genome in genome_snapshot.items():
            colony = self.colonies[colony_id]
            if colony.genome != genome:
                raise AssertionError("a living colony genome changed within its lifetime")

        metrics = population_metrics(self.living_colonies(), self.fusion_links)
        record = {
            "tick": self.tick,
            "germinated_colonies": germinated,
            "spores_released": released,
            "spore_establishment_failures": failed_spores,
            "actual_colony_deaths": deaths,
            "grown_hyphal_cells": grown_cells,
            "new_fusion_links": [list(pair) for pair in new_fusions],
            "pending_spores": len(self.spores),
            "substrate_taken": round(substrate_taken, 12),
            "water_taken": round(water_taken, 12),
            "energy_acquired": round(energy_acquired, 12),
            "fusion_resource_transferred": round(transferred, 12),
            "fusion_balance_error": transfer_error,
            **metrics,
        }
        self.tick_records.append(record)
        return record

    def run(self, output_directory: str | Path | None = None) -> dict[str, Any]:
        while self.tick < self.config.ticks and (self.living_colonies() or self.spores):
            self.step()
        final_metrics = population_metrics(self.living_colonies(), self.fusion_links)
        summary = {
            "schema": "rootnet-v6.1-spatial-mycelium-summary-v1",
            "completed_ticks": self.tick,
            "requested_ticks": self.config.ticks,
            "extinct": not bool(self.living_colonies() or self.spores),
            "config": self.config.to_dict(),
            "stream_seeds": self.stream_seeds,
            "final_metrics": final_metrics,
            "total_colonies_ever_established": len(self.ancestry_records),
            "total_actual_colony_deaths": len(self.death_records),
            "pending_spores": len(self.spores),
            "spore_establishment_failures": sum(
                record.get("event") == "establishment_failed"
                for record in self.spore_records
            ),
            "max_abs_fusion_balance_error": self.max_abs_fusion_balance_error,
            "claim_boundary": (
                "Artificial spatial mycelium mechanism output; not a reconstruction "
                "of fungal history, a species claim, or a population estimate."
            ),
        }
        if output_directory is not None:
            self.write_outputs(Path(output_directory), summary)
        return summary

    def write_outputs(self, output_directory: Path, summary: dict[str, Any]) -> None:
        output_directory.mkdir(parents=True, exist_ok=True)
        files = {
            "config.json": self.config.to_dict(),
            "summary.json": summary,
        }
        for filename, payload in files.items():
            (output_directory / filename).write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        for filename, records in (
            ("ticks.jsonl", self.tick_records),
            ("ancestry.jsonl", self.ancestry_records),
            ("deaths.jsonl", self.death_records),
            ("spores.jsonl", self.spore_records),
        ):
            with (output_directory / filename).open("w", encoding="utf-8", newline="\n") as handle:
                for record in records:
                    handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    def state_digest(self) -> str:
        payload = {
            "tick": self.tick,
            "colonies": [
                colony.to_dict() for colony in sorted(
                    self.colonies.values(), key=lambda item: item.colony_id
                )
            ],
            "spores": [spore.to_dict() for spore in self.spores],
            "fusion_links": [list(pair) for pair in sorted(self.fusion_links)],
            "substrate": self.substrate,
            "water": self.water,
            "records": self.tick_records,
            "ancestry": self.ancestry_records,
            "deaths": self.death_records,
            "spore_records": self.spore_records,
        }
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()
