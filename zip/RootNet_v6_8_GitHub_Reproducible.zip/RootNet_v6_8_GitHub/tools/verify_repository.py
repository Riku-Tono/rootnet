from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHECKSUMS = ROOT / "SHA256SUMS.txt"
PACKAGE = ROOT / "RootNet_v6_8_lift_0_035_confirmed"
EXCLUDED_DIRS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache"}


def repository_files() -> dict[str, Path]:
    result: dict[str, Path] = {}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == CHECKSUMS:
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        result[relative.as_posix()] = path
    return result


def verify_checksums() -> tuple[bool, list[str]]:
    expected: dict[str, str] = {}
    for line in CHECKSUMS.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(" *", 1)
        expected[relative] = digest
    current = repository_files()
    details: list[str] = []
    if set(expected) != set(current):
        missing = sorted(set(expected) - set(current))
        extra = sorted(set(current) - set(expected))
        if missing:
            details.append(f"missing files: {missing}")
        if extra:
            details.append(f"untracked files: {extra}")
    for relative in sorted(set(expected) & set(current)):
        actual = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if actual != expected[relative]:
            details.append(f"hash mismatch: {relative}")
    return not details, details


def main() -> None:
    checksums_ok, details = verify_checksums()
    package = subprocess.run(
        [sys.executable, "verify_package.py"],
        cwd=PACKAGE,
        text=True,
        capture_output=True,
        check=False,
    )
    try:
        package_report = json.loads(package.stdout)
    except json.JSONDecodeError:
        package_report = {"raw_stdout": package.stdout.strip()}
    report = {
        "schema": "rootnet-v6.8-github-repository-verification-v1",
        "repository_checksums": "PASS" if checksums_ok else "FAIL",
        "sealed_package_verification": "PASS" if package.returncode == 0 else "FAIL",
        "repository_details": details,
        "package_report": package_report,
    }
    if package.stderr.strip():
        report["package_stderr"] = package.stderr.strip()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not (checksums_ok and package.returncode == 0):
        sys.exit(1)


if __name__ == "__main__":
    main()

