# RootNet v6.0 Evolutionary Kernel

RootNet v6.0 is a new research line, separate from the frozen v5.8 ecological
transport model. It is a deliberately small artificial evolutionary system for
testing whether inherited variation, explicit trade-offs, local interaction,
and spatial environmental heterogeneity can change population trait
distributions across generations.

This package does **not** claim to reconstruct fungal evolution. It contains no
preassigned fungus, alga, symbiont, species, or ecotype state. Those words may
only be used later as bounded interpretations of measured strategies.

## Research question

> Can heritable variation, ecological trade-offs, and spatial environmental
> heterogeneity alone generate persistent ecological diversification from a
> common ancestral population?

v6.0 implements the apparatus needed to ask this question. It does not answer
the question by itself; a separately sealed and approved replicated experiment
is required.

## Causal chain

```text
inherited genome
      |
      v
deterministic phenotype + explicit maintenance costs
      |
      v
local habitat and conservative resource redistribution
      |
      v
survival to reproduction and offspring number
      |
      v
inheritance + random mutation + dispersal
      |
      +-----------------------------> next generation
```

The environment cannot write into a living organism's genome. Environmental
adaptation can therefore appear only through differential survival and
reproduction of inherited variants.

## Included in v6.0

- one conceptual common ancestor represented by a clonal founder population;
- five continuous inherited parameters;
- a deterministic genotype-to-phenotype map;
- acquisition, tolerance, sharing, and dispersal costs;
- three habitat patches, with homogeneous and heterogeneous presets;
- conservative local energy redistribution controlled by the donor's sharing
  trait;
- non-overlapping generations and asexual inheritance;
- random per-locus mutation that does not depend on the environment;
- offspring dispersal between adjacent patches;
- per-patch density regulation;
- complete recruited and unrecruited birth ancestry records;
- trait means, variances, global/within/between-patch disparity, patch occupancy,
  and founder-branch loss;
- split, subject-keyed random streams for environment, demography, mutation,
  dispersal, and density regulation.

## Explicitly excluded

- `Cambrian` triggers or mutation-rate acceleration caused by diversity;
- predetermined biological types or immutable ecological lineages;
- environmental rewriting of inherited traits;
- GRNs, DNA sequences, recombination, mating, and sexual isolation;
- an operational species or speciation claim;
- separately evolving symbiotic partners;
- physical hyphal geometry;
- geological or deep-time environmental history;
- calibration to a real organism or ecosystem.

These are exclusions, not missing hidden mechanisms. They keep the first causal
test identifiable.

## Run

Python 3.11 or newer is recommended. The kernel uses only the standard library.

```powershell
python main.py --generations 20 --seed 600 --output smoke_output
```

The default command requests 120 generations, but it is a single trajectory,
not a research result.

Outputs:

- `config.json`: normalized run configuration;
- `summary.json`: final bounded summary and stream seeds;
- `generations.jsonl`: one record per completed generation;
- `ancestry.jsonl`: every founder and birth, including density-rejected births.

## Inspect

```powershell
python -m unittest discover -v
python validate_v6_0.py
python verify_package.py
```

Validation covers the genotype-to-phenotype budget, costs, absence of direct
environmental genome updates, environment-independent mutation draws,
conservative redistribution, common ancestry, absence of predetermined types,
per-patch capacity, ancestry integrity, machine-readable outputs, absence of a
Cambrian trigger, and exact repeatability.

## Interpreting the strategy counts

`analysis_only_strategy_counts` classifies current phenotypes as
`light_dominant`, `substrate_dominant`, or `balanced`. This classification is
computed only after population dynamics. It never changes survival,
reproduction, mutation, dispersal, or partner choice. It is not a species
definition.

## Relationship to v5.8

No v5.8 file was modified. The local frozen baseline consulted for provenance
was:

```text
fusa_rootnet_v5_8_0_biological_model_royal_seal.zip
SHA-256 1C3C638414CFAB2A424EDE8D2FD42A8CE40FB7932494207962A72115A9490FB9
```

See `MODEL_SPEC.md` for equations and `RESEARCH_BOUNDARIES.md` for claim limits.
