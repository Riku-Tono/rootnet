from __future__ import annotations

import argparse
import sys
from pathlib import Path

from lineage_view import write_lineage_tree
from persistence import load_ecosystem, save_ecosystem_atomic


def configure_utf8_output() -> None:
    """Windowsのcp932端末でも絵文字と日本語を安全に出力する。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8", errors="replace")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="RootNet v5.7.1――環境の一日編")
    parser.add_argument("--days", type=int, default=12)
    parser.add_argument("--save", type=Path, default=Path("fusa_rootnet_v5_7_1.json"))
    parser.add_argument(
        "--tree",
        type=Path,
        default=Path("fusa_lineage_tree.html"),
        help="系統樹HTMLの保存先",
    )
    parser.add_argument("--seed", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    configure_utf8_output()
    args = parse_args()
    eco = load_ecosystem(args.save, args.seed)
    days = max(1, min(args.days, 3650))
    print("🌿🍄📜 RootNet v5.7.1――環境の一日編")
    print(
        f"群落: {eco.name} / 生存株数: {len(eco.living_plants())} "
        f"/ 歴代株数: {len(eco.plants)} / 第{eco.day}日から再開"
    )
    print("─" * 76)
    for _ in range(days):
        report = eco.step(); w = report.weather
        solar, sea = report.solar, report.marine
        print(
            f"第{report.day}日 | {solar.condition} 日長{solar.day_length:.1f}h "
            f"光{w.sunlight:.2f} 気温{w.temperature:.2f} 雨{w.rainfall:.2f}"
        )
        print(
            f"  {sea.moon_phase} 潮{sea.tide_level:.2f} 波{sea.wave_strength:.2f} "
            f"海温{sea.sea_temperature:.2f} 塩分{sea.salinity:.2f} 海栄養{sea.nutrients:.2f}"
        )
        for signal in report.signals:
            print(f"  ⚡ {signal.message}（{signal.signal_type} / 強度{signal.strength:.2f}）")
        for signal in report.marine_signals:
            print(f"  🌊 {signal.message}（海底RootNet / 強度{signal.strength:.2f}）")
        print(
            f"  💧浄水 +{report.water_cleaned:.3f}  🔥太陽・落葉燃料 +{report.fuel_collected:.3f} "
            f"🪸共生藻光合成 +{report.coral_energy:.3f}"
        )
        if report.stored_seed_ids:
            print(f"  🫘 本物の種子庫へ{len(report.stored_seed_ids)}粒を保存")
        if report.wave_moved_seed_ids:
            print(f"  🌊 波が種を{len(report.wave_moved_seed_ids)}粒、潮間帯へ運びました")
        for plant_id in report.new_plant_ids:
            plant = eco.plants[plant_id]
            handedness = "鏡像D型" if plant.chirality == "D" else "通常L型"
            traits = "・".join(plant.traits.active_names()) or "穏やかな基本形質"
            abilities = "・".join(plant.expressed_abilities.active_names())
            ability_text = f" / 発現:{abilities}" if abilities else " / 能力は弱く発現中"
            print(
                f"  🌱 新株「{plant.name}」誕生 "
                f"（第{plant.generation}世代 / {handedness} / {traits}{ability_text}）"
            )
        for plant_id, reason in report.deaths:
            plant = eco.plants[plant_id]
            print(f"  🍂 {plant.name}が{reason}（享年{plant.age}日）")
        if report.soil_returned > 0:
            print(f"  ♻️ 枯株から土へ栄養 +{report.soil_returned:.4f}")
        state = eco.infrastructure
        print(
            f"  基盤 | 水質{state.water_quality:.2f} 貯水{state.water_reserve:.2f} "
            f"土{state.soil_nutrients:.2f} 燃料{state.amber_fuel:.1f} "
            f"種子庫{state.seed_bank} 生存株{len(eco.living_plants())}"
        )
        print(
            f"  🏞️ 環境収容力{report.carrying_capacity} "
            f"人口圧{report.population_pressure:.2f}"
        )
        if report.elder_successor_id:
            successor = eco.plants[report.elder_successor_id]
            print(f"  👑 新長老「{successor.name}」をRootNet評議会が選出")
        if report.cambrian_started:
            print("  🧬🌊 フサカンブリア期、開始。能力の発現・変異速度が上がります")
        elif not eco.cambrian.active:
            audit = report.cambrian_audit
            ready = sum(
                bool(audit.get(name))
                for name in (
                    "generation_ready",
                    "population_ready",
                    "diversity_ready",
                    "stable_water_ready",
                    "rootnet_ready",
                )
            )
            print(
                f"  🧬 前兆 {ready}/5 | 世代{audit.get('max_generation', 0)} "
                f"株{audit.get('living_plants', 0)} 多様性{audit.get('genetic_diversity', 0):.2f} "
                f"網機能{audit.get('rootnet_functional_score', 0):.2f}"
            )
        if report.false_signals:
            print(f"  〰️ 偽信号 {len(report.false_signals)}件")
        if report.movements:
            counts = {
                kind: sum(move.get("type") == kind for move in report.movements)
                for kind in ("walk", "spore", "hypha", "reconnect")
            }
            print(
                f"  🧭 移動 | 歩行{counts['walk']} "
                f"胞子{counts['spore']} 菌糸伸長{counts['hypha']} "
                f"再接続{counts['reconnect']}"
            )
        if report.interactions:
            print(f"  🦠 寄生・捕食相互作用 {len(report.interactions)}件")
        for event in report.life_events:
            print(
                f"  📜 {event.narrative} "
                f"（理由: {event.reason} / {event.outcome}）"
            )
        net = report.network_metrics
        print(
            f"  🕸️ RootNet | 最大成分{net['largest_component_ratio']:.2f} "
            f"孤立{net['isolate_rate']:.2f} 平均路{net['average_path_length']:.2f} "
            f"クラスタ{net['clustering_coefficient']:.2f} 到達{net['reachability']:.2f} "
            f"成分{int(net['component_count'])}"
        )
        defense = report.biosecurity
        if defense["new_outbreaks"]:
            print(f"  ☠️ 猛毒変異 {len(defense['new_outbreaks'])}件")
        if defense["quarantines"] or defense["severed"]:
            print(
                f"  🛡️ 防疫 | 隔離{len(defense['quarantines'])}株 "
                f"切断{len(defense['severed'])}本"
            )
        if defense["reconnected"]:
            print(f"  🌱 回復後の再接続 {len(defense['reconnected'])}本")
        defense_metrics = defense["metrics"]
        print(
            f"  防疫指標 | 危険負荷率{defense_metrics['active_hazard_rate']:.2f} "
            f"隔離率{defense_metrics['quarantine_rate']:.2f} "
            f"封じ込め率{defense_metrics['mean_containment_rate']:.2f}"
        )
    save_ecosystem_atomic(eco, args.save)
    write_lineage_tree(eco, args.tree)
    print("─" * 76)
    print(f"💾 保存完了: {args.save}")
    print(f"🌳 系統樹更新: {args.tree}")
    print(f"📜 重要な生命日誌: 累計{len(eco.life_journal)}件")
    print("行動だけでなく、環境に耐えた一日も実際の変化として残る。")
    print("パフウリ・トフトフ。🌿🍄📜")


if __name__ == "__main__":
    main()
