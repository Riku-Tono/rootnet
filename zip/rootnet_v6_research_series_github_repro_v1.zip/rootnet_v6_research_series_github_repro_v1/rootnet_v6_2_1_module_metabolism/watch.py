from __future__ import annotations

import argparse
import os
import sys
import time
from collections import defaultdict

from rootnet_v62 import ModuleSimulation, SimulationConfig
from rootnet_v62.model import Coord, canonical_edge


RESET = "\033[0m"
DIM = "\033[2m"
BOLD = "\033[1m"
YELLOW = "\033[38;5;220m"
RED = "\033[38;5;203m"
DETRITUS = "\033[38;5;244m"
COLORS = ("\033[38;5;114m", "\033[38;5;81m", "\033[38;5;215m", "\033[38;5;183m", "\033[38;5;117m", "\033[38;5;221m")


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Watch local metabolism, weakening, pruning, and regrowth")
    parser.add_argument("--ticks", type=int, default=360)
    parser.add_argument("--seed", type=int, default=620)
    parser.add_argument("--delay", type=float, default=0.08)
    parser.add_argument("--width", type=int, default=42)
    parser.add_argument("--height", type=int, default=18)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--no-clear", action="store_true")
    parser.add_argument("--every-tick", action="store_true", help="静止tickもすべて描画する")
    return parser.parse_args()


def node_glyph(simulation: ModuleSimulation, ramet_id: str, coord: Coord) -> tuple[str, str]:
    ramet = simulation.ramets[ramet_id]
    node = ramet.nodes[coord]
    if node.vitality < 0.25:
        return RED, "×"
    if node.vitality < 0.55:
        return YELLOW, "!"
    if coord in ramet.tips:
        return "", "◆"
    if coord == ramet.origin:
        return "", "●"
    connected = [n for n in simulation.neighbors(coord) if canonical_edge(coord, n) in ramet.edges]
    horizontal = any(n[0] != coord[0] for n in connected)
    vertical = any(n[1] != coord[1] for n in connected)
    return "", "┼" if horizontal and vertical else "│" if vertical else "─"


def render(simulation: ModuleSimulation, record: dict[str, object], clear: bool) -> None:
    if clear:
        sys.stdout.write("\033[2J\033[H")
    lineage_ids = sorted({simulation.genets[r.genet_id].lineage_id for r in simulation.living_ramets()})
    lineage_color = {lineage: COLORS[i % len(COLORS)] for i, lineage in enumerate(lineage_ids)}
    spores: dict[Coord, int] = defaultdict(int)
    for spore in simulation.spores:
        spores[spore.position] += 1

    print(f"{BOLD}RootNet v6.2.1  🌿 局所代謝と部分壊死  tick {simulation.tick:>3}/{simulation.config.ticks}{RESET}")
    print(
        f"🧬 genet {record['living_genets']:>2}  🧩 ramet {record['living_ramets']:>2}  "
        f"🌱 modules {record['total_modules']:>3}  ◆ tips {record['total_tips']:>3}  "
        f"🫀平均健全度 {record['mean_vitality']:.2f}"
    )
    print(
        f"⚠ 衰弱 {record['weakened_modules']:>2}  ✂ 今回の壊死 {len(record['necrotic_modules']):>2}  "
        f"🧱 残渣 {record['detritus_cells']:>2}  🪓 ramet死亡 {len(record['ramet_deaths']):>2}  "
        f"🫧 胞子 {record['pending_spores']:>2}"
    )
    print(
        f"↔ energy転流 {record.get('energy_translocated', 0.0):.3f}  "
        f"💧 water転流 {record.get('water_translocated', 0.0):.3f}  "
        f"🧬非自己境界 {record.get('blocked_nonself_contacts', 0):>2}"
    )
    print(f"{DIM}☀ 光の強い表層  ┌{'─' * simulation.config.width}┐{RESET}")
    for y in range(simulation.config.height):
        row = []
        for x in range(simulation.config.width):
            coord = (x, y)
            ramet_id = simulation.occupancy.get(coord)
            if ramet_id is not None:
                ramet = simulation.ramets[ramet_id]
                lineage = simulation.genets[ramet.genet_id].lineage_id
                state_color, symbol = node_glyph(simulation, ramet_id, coord)
                row.append((state_color or lineage_color[lineage]) + symbol + RESET)
            elif coord in spores:
                row.append("\033[38;5;229m°" + RESET)
            elif simulation.detritus[y][x] > 0:
                value = simulation.detritus[y][x]
                row.append(DETRITUS + ("▓" if value > 0.70 else "▒" if value > 0.35 else "░") + RESET)
            else:
                row.append(DIM + "·" + RESET)
        print(" " * 14 + "│" + "".join(row) + "│")
    print(f"{DIM}🪨 基質の豊かな深部  └{'─' * simulation.config.width}┘{RESET}")
    events = []
    if record["germinated_genets"]:
        events.append("✨ 新genet: " + ", ".join(record["germinated_genets"]))
    if record["necrotic_modules"]:
        events.append(f"✂ {len(record['necrotic_modules'])}モジュール壊死（全体は即死しない）")
    if record["fragments_created"]:
        events.append("🧩 切断片が独立: " + ", ".join(record["fragments_created"]))
    if record["same_genet_fusions"]:
        events.append(f"🪢 同一genet再融合 {len(record['same_genet_fusions'])}件")
    if record["ramet_deaths"]:
        events.append("🪓 ramet死亡: " + ", ".join(record["ramet_deaths"]))
    if record["genet_extinctions"]:
        events.append("☠ genet絶滅: " + ", ".join(record["genet_extinctions"]))
    if record["failed_spores"]:
        events.append("× 胞子定着失敗: " + ", ".join(record["failed_spores"]))
    print("  " + ("  /  ".join(events) if events else f"{DIM}各モジュールが局所的に吸収・転流・維持中…{RESET}"))
    print(f"{DIM}凡例: ◆先端  !衰弱  ×壊死直前  ▓▒░残渣→再解放  色=創始系統{RESET}")
    sys.stdout.flush()


def initial_record(simulation: ModuleSimulation) -> dict[str, object]:
    return {
        "living_genets": len(simulation.living_genet_ids()), "living_ramets": len(simulation.living_ramets()),
        "total_modules": sum(len(r.nodes) for r in simulation.living_ramets()), "total_tips": sum(len(r.tips) for r in simulation.living_ramets()),
        "mean_vitality": 1.0, "weakened_modules": 0, "necrotic_modules": [], "detritus_cells": 0,
        "ramet_deaths": [], "pending_spores": 0, "energy_translocated": 0.0, "water_translocated": 0.0,
        "blocked_nonself_contacts": 0, "germinated_genets": [], "fragments_created": [], "same_genet_fusions": [],
        "genet_extinctions": [], "failed_spores": [],
    }


def visual_signature(simulation: ModuleSimulation) -> tuple[object, ...]:
    modules = tuple(
        sorted(
            (
                coord,
                ramet_id,
                0 if simulation.ramets[ramet_id].nodes[coord].vitality < 0.25
                else 1 if simulation.ramets[ramet_id].nodes[coord].vitality < 0.55
                else 2,
                coord in simulation.ramets[ramet_id].tips,
            )
            for coord, ramet_id in simulation.occupancy.items()
        )
    )
    residue = tuple(
        (x, y, 3 if value > 0.70 else 2 if value > 0.35 else 1)
        for y, row in enumerate(simulation.detritus)
        for x, value in enumerate(row)
        if value > 0.0
    )
    spores = tuple(sorted(spore.position for spore in simulation.spores))
    return modules, residue, spores


def main() -> None:
    options = args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if os.name == "nt": os.system("")
    simulation = ModuleSimulation(SimulationConfig(
        master_seed=options.seed, ticks=options.ticks, width=options.width,
        height=options.height, founder_count=options.founders,
    ))
    render(simulation, initial_record(simulation), not options.no_clear)
    time.sleep(max(0.0, options.delay))
    previous_signature = visual_signature(simulation)
    while simulation.tick < simulation.config.ticks and (simulation.living_ramets() or simulation.spores):
        record = simulation.step()
        signature = visual_signature(simulation)
        visible_change = signature != previous_signature
        important_event = any((
            record["necrotic_modules"], record["fragments_created"],
            record["ramet_deaths"], record["genet_extinctions"],
            record["germinated_genets"], record["failed_spores"],
            record["same_genet_fusions"],
        ))
        if options.every_tick or visible_change or important_event or simulation.tick == simulation.config.ticks:
            render(simulation, record, not options.no_clear)
            time.sleep(max(0.0, options.delay))
        previous_signature = signature
    print(f"\n{BOLD}終了。部分壊死とramet死亡、胞子失敗は別の事象です。{RESET}")


if __name__ == "__main__":
    main()
