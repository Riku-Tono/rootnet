from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

from rootnet_v63 import ModuleSimulation, SimulationConfig, TRANSPORT_MODES


PROTOCOL_ID = "rootnet-v6.3-transport-necessity-v1"
SEED_NAMESPACE = "rootnet-v6.3-preregistered-evaluation-v1"
PRIMARY_ENDPOINTS = {
    "mean_living_modules": 1,
    "ever_occupied_cells": 1,
    "growth_tick_fraction": 1,
    "longest_growth_gap": -1,
}


def derive_evaluation_seeds(count: int = 30) -> list[int]:
    seeds: list[int] = []
    for index in range(count):
        digest = hashlib.sha256(f"{SEED_NAMESPACE}|{index}".encode("utf-8")).digest()
        seed = int.from_bytes(digest[:8], "big") % (2**31 - 1)
        seeds.append(seed or 1)
    if len(seeds) != len(set(seeds)):
        raise AssertionError("evaluation seed derivation produced a collision")
    return seeds


def _longest_growth_gap(records: list[dict[str, Any]], requested_ticks: int) -> int:
    longest = current = 0
    grown_by_tick = {int(record["tick"]): int(record["grown_modules"]) for record in records}
    for tick in range(1, requested_ticks + 1):
        if grown_by_tick.get(tick, 0) > 0:
            current = 0
        else:
            current += 1
            longest = max(longest, current)
    return longest


def _correlation(left: list[float], right: list[float]) -> float | None:
    if len(left) != len(right) or len(left) < 3:
        return None
    left_mean = statistics.fmean(left)
    right_mean = statistics.fmean(right)
    numerator = sum((x - left_mean) * (y - right_mean) for x, y in zip(left, right))
    left_ss = sum((x - left_mean) ** 2 for x in left)
    right_ss = sum((y - right_mean) ** 2 for y in right)
    if left_ss <= 0.0 or right_ss <= 0.0:
        return None
    return round(numerator / math.sqrt(left_ss * right_ss), 9)


def summarize_run(simulation: ModuleSimulation, summary: dict[str, Any]) -> dict[str, Any]:
    records = simulation.tick_records
    requested = simulation.config.ticks
    total_growth = sum(int(record["grown_modules"]) for record in records)
    growth_ticks = sum(int(record["grown_modules"]) > 0 for record in records)
    module_ticks = sum(int(record["total_modules"]) for record in records)
    tip_ticks = sum(int(record["total_tips"]) for record in records)
    energy_tip = [float(record["tip_energy_received"]) for record in records]
    water_tip = [float(record["tip_water_received"]) for record in records]
    growth = [float(record["grown_modules"]) for record in records]
    lagged_growth = growth[1:]
    result = {
        "seed": simulation.config.master_seed,
        "transport_mode": simulation.config.transport_mode,
        "completed_ticks": summary["completed_ticks"],
        "ecosystem_extinct": summary["ecosystem_extinct"],
        "state_sha256": simulation.state_digest(),
        "mean_living_modules": round(module_ticks / max(1, requested), 9),
        "mean_living_tips": round(tip_ticks / max(1, requested), 9),
        "ever_occupied_cells": summary["ever_occupied_cells"],
        "growth_tick_fraction": round(growth_ticks / max(1, requested), 9),
        "longest_growth_gap": _longest_growth_gap(records, requested),
        "total_extensions": total_growth,
        "total_necrotic_modules": summary["total_necrotic_modules"],
        "necrosis_per_100_extensions": round(
            100.0 * summary["total_necrotic_modules"] / max(1, total_growth), 9
        ),
        "actual_ramet_deaths": summary["total_actual_ramet_deaths"],
        "genet_extinctions": summary["total_genet_extinctions"],
        "final_living_genets": summary["final_metrics"]["living_genets"],
        "final_living_ramets": summary["final_metrics"]["living_ramets"],
        "final_living_modules": summary["final_metrics"]["total_modules"],
        "final_living_tips": summary["final_metrics"]["total_tips"],
        "energy_translocated": round(sum(float(r["energy_translocated"]) for r in records), 9),
        "water_translocated": round(sum(float(r["water_translocated"]) for r in records), 9),
        "tip_energy_received": round(sum(energy_tip), 9),
        "tip_water_received": round(sum(water_tip), 9),
        "tip_energy_growth_correlation_same_tick": _correlation(energy_tip, growth),
        "tip_water_growth_correlation_same_tick": _correlation(water_tip, growth),
        "tip_energy_growth_correlation_lag_1": _correlation(energy_tip[:-1], lagged_growth),
        "tip_water_growth_correlation_lag_1": _correlation(water_tip[:-1], lagged_growth),
        "max_abs_energy_transport_error": summary["max_abs_energy_transport_error"],
        "max_abs_water_transport_error": summary["max_abs_water_transport_error"],
    }
    return result


def _median(values: list[float]) -> float:
    return float(statistics.median(values)) if values else 0.0


def _sign_test(values: list[float], tolerance: float = 1e-12) -> tuple[int, int, int, float]:
    positive = sum(value > tolerance for value in values)
    negative = sum(value < -tolerance for value in values)
    tied = len(values) - positive - negative
    n = positive + negative
    if n == 0:
        return positive, negative, tied, 1.0
    tail = min(positive, negative)
    probability = 2.0 * sum(math.comb(n, k) for k in range(tail + 1)) / (2**n)
    return positive, negative, tied, min(1.0, probability)


def _holm_adjust(raw: dict[str, float]) -> dict[str, float]:
    ordered = sorted(raw.items(), key=lambda item: item[1])
    adjusted: dict[str, float] = {}
    running = 0.0
    count = len(ordered)
    for rank, (name, value) in enumerate(ordered):
        running = max(running, (count - rank) * value)
        adjusted[name] = min(1.0, running)
    return adjusted


def compare_to_none(
    mode: str,
    runs_by_mode: dict[str, list[dict[str, Any]]],
) -> dict[str, Any]:
    baseline = {int(run["seed"]): run for run in runs_by_mode["none"]}
    condition = {int(run["seed"]): run for run in runs_by_mode[mode]}
    if set(baseline) != set(condition):
        raise AssertionError("paired conditions do not contain identical seeds")
    endpoints: dict[str, Any] = {}
    raw_p: dict[str, float] = {}
    for name, direction in PRIMARY_ENDPOINTS.items():
        raw_deltas = [
            float(condition[seed][name]) - float(baseline[seed][name])
            for seed in sorted(baseline)
        ]
        favorable_deltas = [direction * delta for delta in raw_deltas]
        favorable, unfavorable, tied, p_value = _sign_test(favorable_deltas)
        raw_p[name] = p_value
        endpoints[name] = {
            "direction": "higher" if direction > 0 else "lower",
            "median_raw_delta": round(_median(raw_deltas), 9),
            "median_favorable_delta": round(_median(favorable_deltas), 9),
            "favorable_replicates": favorable,
            "unfavorable_replicates": unfavorable,
            "tied_replicates": tied,
            "exact_sign_test_p_two_sided": round(p_value, 9),
        }
    adjusted = _holm_adjust(raw_p)
    for name in endpoints:
        endpoints[name]["holm_adjusted_p"] = round(adjusted[name], 9)

    favorable_medians = sum(endpoint["median_favorable_delta"] > 0.0 for endpoint in endpoints.values())
    unfavorable_medians = sum(endpoint["median_favorable_delta"] < 0.0 for endpoint in endpoints.values())
    supportive_significant = sum(
        endpoint["median_favorable_delta"] > 0.0 and endpoint["holm_adjusted_p"] <= 0.05
        for endpoint in endpoints.values()
    )
    adverse_significant = sum(
        endpoint["median_favorable_delta"] < 0.0 and endpoint["holm_adjusted_p"] <= 0.05
        for endpoint in endpoints.values()
    )
    baseline_extinctions = sum(bool(run["ecosystem_extinct"]) for run in baseline.values())
    condition_extinctions = sum(bool(run["ecosystem_extinct"]) for run in condition.values())
    baseline_necrosis = _median([
        float(run["necrosis_per_100_extensions"]) for run in baseline.values()
    ])
    condition_necrosis = _median([
        float(run["necrosis_per_100_extensions"]) for run in condition.values()
    ])
    safety_ok = (
        condition_extinctions <= baseline_extinctions
        and condition_necrosis <= baseline_necrosis * 1.25 + 1e-12
    )
    if favorable_medians >= 3 and supportive_significant >= 2 and safety_ok:
        classification = "SUPPORTED"
    elif unfavorable_medians >= 3 and adverse_significant >= 2:
        classification = "EVIDENCE_AGAINST"
    else:
        classification = "MIXED_OR_INCONCLUSIVE"
    return {
        "condition": mode,
        "baseline": "none",
        "classification": classification,
        "primary_endpoints": endpoints,
        "decision_diagnostics": {
            "favorable_median_endpoints": favorable_medians,
            "unfavorable_median_endpoints": unfavorable_medians,
            "holm_significant_favorable_endpoints": supportive_significant,
            "holm_significant_unfavorable_endpoints": adverse_significant,
            "baseline_ecosystem_extinctions": baseline_extinctions,
            "condition_ecosystem_extinctions": condition_extinctions,
            "baseline_median_necrosis_per_100_extensions": round(baseline_necrosis, 9),
            "condition_median_necrosis_per_100_extensions": round(condition_necrosis, 9),
            "safety_guard_passed": safety_ok,
        },
    }


def source_digest(root: Path) -> str:
    included = sorted(
        path for path in root.rglob("*")
        if path.is_file()
        and "__pycache__" not in path.parts
        and (path.suffix == ".py" or path.name == "V6_3_PREREGISTERED_PROTOCOL.md")
    )
    digest = hashlib.sha256()
    for path in included:
        digest.update(path.relative_to(root).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def run_experiment(
    seeds: list[int],
    ticks: int = 360,
    width: int = 42,
    height: int = 18,
    founders: int = 3,
) -> dict[str, Any]:
    started = time.perf_counter()
    runs_by_mode: dict[str, list[dict[str, Any]]] = {mode: [] for mode in TRANSPORT_MODES}
    for index, seed in enumerate(seeds, 1):
        for mode in TRANSPORT_MODES:
            simulation = ModuleSimulation(SimulationConfig(
                master_seed=seed,
                ticks=ticks,
                width=width,
                height=height,
                founder_count=founders,
                transport_mode=mode,
            ))
            summary = simulation.run()
            runs_by_mode[mode].append(summarize_run(simulation, summary))
        print(f"paired replicate {index}/{len(seeds)} complete", flush=True)
    root = Path(__file__).resolve().parent
    protocol = root / "V6_3_PREREGISTERED_PROTOCOL.md"
    result = {
        "schema": "rootnet-v6.3-paired-transport-evaluation-v1",
        "protocol_id": PROTOCOL_ID,
        "protocol_sha256": hashlib.sha256(protocol.read_bytes()).hexdigest(),
        "source_sha256": source_digest(root),
        "scope": (
            "Paired artificial-life test of resource translocation over an existing hyphal graph; "
            "not a test of every graph function or a claim about real fungal history."
        ),
        "settings": {
            "ticks": ticks,
            "width": width,
            "height": height,
            "founders": founders,
            "replicates": len(seeds),
            "modes": list(TRANSPORT_MODES),
            "seed_namespace": SEED_NAMESPACE if seeds == derive_evaluation_seeds(len(seeds)) else None,
            "seeds": seeds,
        },
        "runs": runs_by_mode,
        "comparisons": {
            mode: compare_to_none(mode, runs_by_mode)
            for mode in ("equalize", "demand")
        },
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the RootNet v6.3 paired transport experiment")
    parser.add_argument("--ticks", type=int, default=360)
    parser.add_argument("--replicates", type=int, default=30)
    parser.add_argument("--seeds", type=int, nargs="*")
    parser.add_argument("--width", type=int, default=42)
    parser.add_argument("--height", type=int, default=18)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path("evaluation_v6_3.json"))
    options = parser.parse_args()
    seeds = options.seeds if options.seeds else derive_evaluation_seeds(options.replicates)
    if not seeds:
        raise SystemExit("at least one seed is required")
    result = run_experiment(seeds, options.ticks, options.width, options.height, options.founders)
    options.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result["comparisons"], ensure_ascii=False, indent=2))
    print(f"Saved evaluation to: {options.output.resolve()}")


if __name__ == "__main__":
    main()
