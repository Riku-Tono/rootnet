# RootNet v6.0 model specification

## 1. State and time

Time is discrete and generations do not overlap. An individual contains only:

- organism ID;
- parent ID;
- founder-branch ID below one conceptual common ancestor;
- birth generation;
- current habitat patch;
- inherited genome.

There are no biological type, species, ecotype, sex, age, or acquired-memory
fields.

## 2. Genome

Each locus is bounded to `[0, 1]`:

- `light_investment` (`L`)
- `substrate_investment` (`S`)
- `desiccation_tolerance` (`D`)
- `resource_sharing` (`R`)
- `dispersal` (`M`)

The default ancestor is `(0.38, 0.38, 0.30, 0.24, 0.18)`.

## 3. Genotype-to-phenotype map

If `L + S <= 1`, light capture is `L` and substrate absorption is `S`.
If `L + S > 1`, both values are divided by `L + S`. Thus acquisition investment
cannot exceed one unit in total.

The other phenotype values equal their corresponding inherited loci. The daily
maintenance cost is:

```text
C = 0.20
  + 0.16 * (L_phenotype^2 + S_phenotype^2)
  + 0.13 * D^2
  + 0.055 * R^2
  + 0.075 * M^2
```

The map is deterministic. No environment value occurs in this map.

## 4. Habitats

The heterogeneous preset has three adjacent patches:

| Patch | Light | Substrate | Mean water |
|---|---:|---:|---:|
| `patch-0` | 0.95 | 0.20 | 0.42 |
| `patch-1` | 0.55 | 0.55 | 0.65 |
| `patch-2` | 0.05 | 0.95 | 0.90 |

The homogeneous preset gives all patches `(0.55, 0.55, 0.65)`. Each generation,
water receives independent mean-zero Gaussian noise using the environment RNG
stream. Light and substrate remain fixed in v6.0.

## 5. Gross energy

For habitat light `l`, substrate `s`, and water `w`:

```text
resource_input = 0.80 * (l * light_capture + s * substrate_absorption)
effective_water = w + D * (1 - w)
water_modifier = 0.55 + 0.45 * effective_water
gross_energy = 0.33 + resource_input * water_modifier
```

## 6. Conservative local redistribution

Redistribution occurs only between individuals in the same patch. Potential
donors have energy above `0.75`; potential receivers have energy below `0.58`.
For each deterministic donor-receiver traversal:

```text
transfer = min(
    donor_excess * donor.resource_sharing * 0.18,
    receiver_deficit,
    0.05,
)
```

The exact amount subtracted from the donor is added to the receiver. No energy
is created or destroyed by redistribution. Sharing has an inherited
maintenance cost whether or not a transfer occurs.

## 7. Survival and reproduction

After redistribution:

```text
net_energy = gross_energy_after_transfer - maintenance_cost
P(survive to reproduction) = logistic(7 * (net_energy - 0.18))
expected_offspring = min(4.0, 0.95 + 1.80 * max(0, net_energy))
```

Expected offspring are converted to an integer by stochastic rounding. Parents
do not persist into the next generation.

## 8. Inheritance and mutation

Offspring begin with the complete parent genome. Independently for each locus,
mutation occurs with configured probability `p`; a mutated locus receives
Gaussian change `Normal(0, sigma)` and is clamped to `[0, 1]`.

Mutation receives no habitat, energy, survival, or population argument.

## 9. Dispersal and density regulation

Offspring move to one adjacent patch with probability:

```text
0.03 + 0.55 * dispersal
```

If recruited offspring exceed a patch's fixed carrying capacity, a dedicated
density RNG stream selects the recruits. Rejected births remain in the ancestry
record with `recruited: false`.

## 10. Randomness

Five seeds are deterministically derived from the master seed:

- environment
- demography
- mutation
- dispersal
- density

Random draws are additionally keyed by generation and subject ID. Iteration
order therefore cannot silently advance an unrelated random stream.

## 11. Measurements

Measurements never feed back into dynamics:

- population and patch counts;
- extant founder branches (the surviving direct branches below the single
  conceptual common ancestor);
- per-locus mean and population variance;
- phenotypic disparity: square root of the mean of the five locus variances;
- within-patch disparity and between-patch divergence of trait means;
- per-patch trait means;
- generation-to-generation disparity change;
- analysis-only light-dominant, substrate-dominant, and balanced counts;
- births, survival to reproduction, density deaths, and mutation events;
- conservative-transfer amount and balance error.

No threshold in v6.0 declares speciation or a radiation event.
