from __future__ import annotations

import hashlib
import io
import json
import sys
import unittest

from make_manifest import MANIFEST, ROOT, included_files
from validate_v6_8 import run_validation


def verify_manifest() -> tuple[bool, list[str]]:
    expected = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(" *", 1)
        expected[relative] = digest
    current = {path.relative_to(ROOT).as_posix(): path for path in included_files()}
    messages = []
    if set(expected) != set(current):
        messages.append("file set mismatch")
    for relative in sorted(set(expected) & set(current)):
        actual = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if actual != expected[relative]:
            messages.append(f"hash mismatch: {relative}")
    return not messages, messages


def main() -> None:
    manifest_ok, messages = verify_manifest()
    buffer = io.StringIO()
    tests = unittest.TextTestRunner(stream=buffer, verbosity=1).run(
        unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_v6_8.py")
    )
    current = run_validation()
    sealed = json.loads((ROOT / "validation_v6_8.json").read_text(encoding="utf-8"))
    validation_ok = current == sealed
    report = {
        "schema": "rootnet-v6.8-lift-0.035-package-verification-v1",
        "manifest": "PASS" if manifest_ok else "FAIL",
        "unit_tests": "PASS" if tests.wasSuccessful() else "FAIL",
        "tests_run": tests.testsRun,
        "sealed_validation_reproduced": "PASS" if validation_ok else "FAIL",
        "artifact_integrity": "PASS" if manifest_ok else "FAIL",
        "reference_runtime_regression": (
            "PASS"
            if current["checks"]["v66_control_core_regression"]
            else "WARN_RUNTIME_DIFFERENCE"
        ),
        "details": messages,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not tests.wasSuccessful():
        print(buffer.getvalue())
    if not (manifest_ok and tests.wasSuccessful() and validation_ok):
        sys.exit(1)


if __name__ == "__main__":
    main()
