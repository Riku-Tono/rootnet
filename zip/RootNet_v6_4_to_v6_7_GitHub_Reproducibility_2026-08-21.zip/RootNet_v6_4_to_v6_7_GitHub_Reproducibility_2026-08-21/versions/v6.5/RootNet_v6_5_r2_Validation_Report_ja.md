# RootNet v6.5 validation report

## 判定

`PASS` — 機構検証とdevelopment seedのみ。本評価は未実行。

## 確認事項

- 52 unit tests: PASS
- v6.3 `none` / `fixed-equalize` legacy semantic regression: PASS
- 4環境を実行: PASS
- 緩慢移動パッチが複数座標を通る: PASS
- 急移動後を含む全16 development runで活動パッチ吸収を観測: PASS
- 損傷環境の全development runで辺切断を観測: PASS
- 辺損傷はmodule死亡と別記録: PASS
- 同一seed・同一構成のexact replay: PASS
- energy/water輸送保存誤差 `< 1e-12`: PASS
- adaptive伝導度予算誤差 `< 1e-12`: PASS
- 8主比較とHolm補正: PASS
- evaluation入口のmanifest不一致拒否: PASS
- evaluation入口の封印validation不一致拒否: PASS
- `2e-10`の正差を事前丸めでtie化しないraw解析回帰: PASS
- 30 pairのraw中央値差`+2e-10`を表示上`0.0`へ丸めても利益分類を維持: PASS
- 評価seed 30個、重複なし、development seedと非重複: PASS

背景基質0.60とパッチboost 0.50は、急移動後の新パッチが全development runで実際に吸収されるという機械的作動条件で固定した。2 seedの条件差を最大化する目的では選んでいない。

正式な機械可読結果は`validation_v6_5.json`を参照する。
