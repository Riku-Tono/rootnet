from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_mycelium import MyceliumSimulation, SimulationConfig


def run_validation() -> dict[str, object]:
    config = SimulationConfig(master_seed=610, ticks=80)
    first = MyceliumSimulation(config)
    first_summary = first.run()
    second = MyceliumSimulation(config)
    second.run()

    founders = [record["colony_id"] for record in first.ancestry_records if record["birth_tick"] == 0]
    living_ids = {colony.colony_id for colony in first.living_colonies()}
    established_children = [record for record in first.ancestry_records if record["birth_tick"] > 0]
    parent_child_overlap_events = [
        record for record in first.spore_records
        if record["event"] == "germinated" and record["parent_alive_at_germination"]
    ]
    occupied = [coord for colony in first.living_colonies() for coord in colony.cells]
    local_edges = all(
        abs(left[0] - right[0]) + abs(left[1] - right[1]) == 1
        for colony in first.living_colonies()
        for left, right in colony.edges
    )
    immutable_lifetime_genomes = all(
        first.colonies[record["colony_id"]].genome.to_dict() == record["genome"]
        for record in first.ancestry_records
    )
    checks = {
        "exact_seed_replay": first.state_digest() == second.state_digest(),
        "all_founders_still_living_at_tick_80": set(founders) <= living_ids,
        "at_least_one_established_child": len(established_children) >= 1,
        "parent_alive_when_child_germinated": len(parent_child_overlap_events) >= 1,
        "no_cell_overlap": len(occupied) == len(set(occupied)),
        "all_edges_are_local": local_edges,
        "lifetime_genomes_immutable": immutable_lifetime_genomes,
        "fusion_transfer_conservative": first.max_abs_fusion_balance_error < 1e-12,
        "actual_deaths_separate_from_spore_failures": (
            len(first.death_records) == first_summary["total_actual_colony_deaths"]
            and sum(record["event"] == "establishment_failed" for record in first.spore_records)
            == first_summary["spore_establishment_failures"]
        ),
    }
    if not all(checks.values()):
        failed = [name for name, passed in checks.items() if not passed]
        raise AssertionError(f"validation failed: {failed}")
    return {
        "schema": "rootnet-v6.1-validation-v1",
        "status": "PASS",
        "scope": "single deterministic mechanism-validation run; not a replicated research result",
        "checks": checks,
        "state_sha256": first.state_digest(),
        "observed_tick_80": {
            "living_colonies": first_summary["final_metrics"]["living_colonies"],
            "total_hyphal_cells": first_summary["final_metrics"]["total_hyphal_cells"],
            "oldest_colony_age": first_summary["final_metrics"]["oldest_colony_age"],
            "parent_child_pairs_alive_together": first_summary["final_metrics"]["parent_child_pairs_alive_together"],
            "total_actual_colony_deaths": first_summary["total_actual_colony_deaths"],
            "spore_establishment_failures": first_summary["spore_establishment_failures"],
            "fusion_links": first_summary["final_metrics"]["fusion_links"],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("validation_v6_1.json"))
    args = parser.parse_args()
    result = run_validation()
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
