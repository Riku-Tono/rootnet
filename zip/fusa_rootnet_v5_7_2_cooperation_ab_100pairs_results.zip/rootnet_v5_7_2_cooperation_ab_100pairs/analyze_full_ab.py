from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import statistics
from pathlib import Path
from typing import Any


BOOTSTRAP_SEED = 20260801
BOOTSTRAP_DRAWS = 10_000
KEY_METRICS = (
    ("help_successes_per_1000_plant_days", "援助成功／1,000株日"),
    ("help_requests_per_1000_plant_days", "援助要求／1,000株日"),
    ("help_success_rate", "援助成功率"),
    ("mean_trust", "平均信頼"),
    ("final_living", "320日目生存株"),
    ("mean_isolate_rate", "平均孤立率"),
    ("final_largest_component_ratio", "最終最大成分比"),
    ("final_reachability", "最終到達率"),
    ("max_attack_rate", "最大感染率"),
    ("severed_per_1000_edge_days", "切断／1,000辺日"),
    ("reconnected_per_1000_edge_days", "再接続／1,000辺日"),
)


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def bootstrap_ci(values: list[float], statistic, draws: int, seed_offset: int) -> list[float]:
    rng = random.Random(BOOTSTRAP_SEED + seed_offset)
    count = len(values)
    samples = []
    for _ in range(draws):
        sample = [values[rng.randrange(count)] for _ in range(count)]
        samples.append(float(statistic(sample)))
    return [percentile(samples, 0.025), percentile(samples, 0.975)]


def rank_biserial(values: list[float]) -> float:
    nonzero = [value for value in values if value != 0.0]
    indexed = sorted(enumerate(nonzero), key=lambda item: abs(item[1]))
    ranks = [0.0] * len(nonzero)
    position = 0
    while position < len(indexed):
        end = position + 1
        while end < len(indexed) and abs(indexed[end][1]) == abs(indexed[position][1]):
            end += 1
        average_rank = ((position + 1) + end) / 2.0
        for rank_index in range(position, end):
            ranks[indexed[rank_index][0]] = average_rank
        position = end
    positive = sum(rank for rank, value in zip(ranks, nonzero) if value > 0.0)
    negative = sum(rank for rank, value in zip(ranks, nonzero) if value < 0.0)
    total = positive + negative
    return (positive - negative) / total if total else 0.0


def exact_two_sided_sign_p(positive: int, negative: int) -> float:
    count = positive + negative
    if count == 0:
        return 1.0
    extreme = min(positive, negative)
    tail = sum(math.comb(count, index) for index in range(extreme + 1)) / (2**count)
    return min(1.0, 2.0 * tail)


def wilson_interval(successes: int, count: int, z: float = 1.959963984540054) -> list[float]:
    if count == 0:
        return [0.0, 1.0]
    proportion = successes / count
    denominator = 1.0 + z * z / count
    center = (proportion + z * z / (2.0 * count)) / denominator
    margin = z * math.sqrt(
        proportion * (1.0 - proportion) / count + z * z / (4.0 * count * count)
    ) / denominator
    return [center - margin, center + margin]


def paired_summary(pairs: list[dict[str, Any]], metric: str, seed_offset: int) -> dict[str, Any]:
    low = [float(pair["low"]["metrics"][metric]) for pair in pairs]
    high = [float(pair["high"]["metrics"][metric]) for pair in pairs]
    delta = [right - left for left, right in zip(low, high)]
    positive = sum(value > 0.0 for value in delta)
    negative = sum(value < 0.0 for value in delta)
    equal = len(delta) - positive - negative
    standard_deviation = statistics.stdev(delta) if len(delta) > 1 else 0.0
    return {
        "low_mean": statistics.fmean(low),
        "low_median": statistics.median(low),
        "high_mean": statistics.fmean(high),
        "high_median": statistics.median(high),
        "delta_mean": statistics.fmean(delta),
        "delta_mean_bootstrap_95ci": bootstrap_ci(
            delta, statistics.fmean, BOOTSTRAP_DRAWS, seed_offset
        ),
        "delta_median": statistics.median(delta),
        "delta_median_bootstrap_95ci": bootstrap_ci(
            delta, statistics.median, BOOTSTRAP_DRAWS, 10_000 + seed_offset
        ),
        "delta_p25": percentile(delta, 0.25),
        "delta_p75": percentile(delta, 0.75),
        "delta_min": min(delta),
        "delta_max": max(delta),
        "positive_pairs": positive,
        "equal_pairs": equal,
        "negative_pairs": negative,
        "positive_fraction": positive / len(delta),
        "positive_fraction_wilson_95ci": wilson_interval(positive, len(delta)),
        "paired_standardized_effect_dz": (
            statistics.fmean(delta) / standard_deviation if standard_deviation else 0.0
        ),
        "paired_rank_biserial": rank_biserial(delta),
        "exact_two_sided_sign_p": exact_two_sided_sign_p(positive, negative),
        "relative_change_of_arm_means": (
            statistics.fmean(high) / statistics.fmean(low) - 1.0
            if statistics.fmean(low) != 0.0
            else None
        ),
    }


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def compare_repeat(full: dict[str, Any], repeat: dict[str, Any]) -> dict[str, Any]:
    matches = []
    for repeated in repeat["pairs"]:
        original = next(pair for pair in full["pairs"] if pair["seed"] == repeated["seed"])
        checks = {
            "initial_audit": canonical(original["initial_audit"]) == canonical(repeated["initial_audit"]),
            "low_metrics": canonical(original["low"]["metrics"]) == canonical(repeated["low"]["metrics"]),
            "high_metrics": canonical(original["high"]["metrics"]) == canonical(repeated["high"]["metrics"]),
            "low_weather_hash": (
                original["low"]["external_weather_sha256"]
                == repeated["low"]["external_weather_sha256"]
            ),
            "high_weather_hash": (
                original["high"]["external_weather_sha256"]
                == repeated["high"]["external_weather_sha256"]
            ),
            "deltas": canonical(original["delta_high_minus_low"])
            == canonical(repeated["delta_high_minus_low"]),
        }
        matches.append({
            "seed": repeated["seed"],
            "pass": all(checks.values()),
            "checks": checks,
        })
    return {"all_pass": all(item["pass"] for item in matches), "seeds": matches}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--repeat", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    args = parser.parse_args()

    full = json.loads(args.input.read_text(encoding="utf-8"))
    repeat = json.loads(args.repeat.read_text(encoding="utf-8"))
    pairs = full["pairs"]
    runs = [pair[arm] for pair in pairs for arm in ("low", "high")]
    quality = {
        "pairs": len(pairs),
        "trajectories": len(runs),
        "single_source_difference_pass": sum(
            pair["initial_audit"]["only_cooperation_differs"] for pair in pairs
        ),
        "weather_exact_pass": sum(pair["weather_exact_match"] for pair in pairs),
        "world_rng_exact_pass": sum(pair["final_world_rng_state_match"] for pair in pairs),
        "completed_320": sum(run["metrics"]["completed_days"] == 320 for run in runs),
        "errors": sum(run["metrics"]["error"] is not None for run in runs),
        "help_reconciled": sum(
            run["metrics"]["help_count_reconciled"]
            and run["metrics"]["help_request_reconciled"]
            for run in runs
        ),
    }
    metrics = {
        metric: paired_summary(pairs, metric, index * 101)
        for index, (metric, _) in enumerate(KEY_METRICS, start=1)
    }
    primary_deltas = [
        float(pair["delta_high_minus_low"]["help_successes_per_1000_plant_days"])
        for pair in pairs
    ]
    largest_positive = sorted(
        zip((pair["seed"] for pair in pairs), primary_deltas),
        key=lambda item: (-item[1], item[0]),
    )[:10]
    largest_negative = sorted(
        zip((pair["seed"] for pair in pairs), primary_deltas),
        key=lambda item: (item[1], item[0]),
    )[:10]
    repeat_result = compare_repeat(full, repeat)
    analysis = {
        "protocol_id": full["experiment"]["protocol_id"],
        "status": "ab_complete_sensitivity_not_started",
        "intervention": {
            "target_id": full["experiment"]["target_id"],
            "low": full["experiment"]["low"],
            "high": full["experiment"]["high"],
            "seeds": [0, 99],
            "days": full["experiment"]["days"],
            "world_days": 64_000,
        },
        "runtime_seconds": full["experiment"]["elapsed_seconds"],
        "raw_input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "bootstrap": {"seed": BOOTSTRAP_SEED, "draws": BOOTSTRAP_DRAWS},
        "quality": quality,
        "repeat_verification": repeat_result,
        "metrics": metrics,
        "primary_extremes": {
            "largest_positive": [
                {"seed": seed, "delta": value} for seed, value in largest_positive
            ],
            "largest_negative": [
                {"seed": seed, "delta": value} for seed, value in largest_negative
            ],
        },
    }
    args.output_json.write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    primary = metrics["help_successes_per_1000_plant_days"]
    lines = [
        "# RootNet v5.7.2 協調性A/B 100組 結果",
        "",
        "## 結論",
        "",
        (
            "この人工世界では、フサリ姫一株の協調性を0.10から0.90へ上げると、"
            f"援助成功／1,000株日は平均{primary['delta_mean']:+.3f}変化した。"
            f"A/Bの群平均比では{primary['relative_change_of_arm_means'] * 100:+.1f}%である。"
            f"対応差の95%ブートストラップCIは"
            f"[{primary['delta_mean_bootstrap_95ci'][0]:+.3f}, "
            f"{primary['delta_mean_bootstrap_95ci'][1]:+.3f}]。"
        ),
        (
            f"100組中、増加{primary['positive_pairs']}組、同値{primary['equal_pairs']}組、"
            f"減少{primary['negative_pairs']}組。これはRootNet内の総効果であり、"
            "現実生物への一般化や直接効果の証明ではない。"
        ),
        "",
        "## 実行と品質",
        "",
        f"- seed 0〜99、A/B 200世界、各320日、計64,000世界日",
        f"- 実時間: {full['experiment']['elapsed_seconds']:.2f}秒",
        f"- 単一実状態差分: {quality['single_source_difference_pass']}/100 PASS",
        f"- 外部天候一致: {quality['weather_exact_pass']}/100 PASS",
        f"- world乱数状態一致: {quality['world_rng_exact_pass']}/100 PASS",
        f"- 320日完走: {quality['completed_320']}/200、エラー{quality['errors']}件",
        f"- 援助集計照合: {quality['help_reconciled']}/200 PASS",
        f"- seed 0・29・81再実行: {'PASS' if repeat_result['all_pass'] else 'FAIL'}",
        "",
        "## 対応付き効果量",
        "",
        "| 指標 | A平均 | B平均 | 平均Δ B−A | 95% CI | 中央値Δ | B>A / = / B<A | dz | 順位双列 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    labels = dict(KEY_METRICS)
    for metric, _ in KEY_METRICS:
        item = metrics[metric]
        ci = item["delta_mean_bootstrap_95ci"]
        lines.append(
            f"| {labels[metric]} | {item['low_mean']:.4f} | {item['high_mean']:.4f} | "
            f"{item['delta_mean']:+.4f} | [{ci[0]:+.4f}, {ci[1]:+.4f}] | "
            f"{item['delta_median']:+.4f} | {item['positive_pairs']} / {item['equal_pairs']} / {item['negative_pairs']} | "
            f"{item['paired_standardized_effect_dz']:+.3f} | {item['paired_rank_biserial']:+.3f} |"
        )
    lines.extend([
        "",
        "## 主評価の詳細",
        "",
        f"- A平均: {primary['low_mean']:.3f}／1,000株日",
        f"- B平均: {primary['high_mean']:.3f}／1,000株日",
        f"- 平均差: {primary['delta_mean']:+.3f}",
        f"- A/B群平均比の変化: {primary['relative_change_of_arm_means'] * 100:+.1f}%",
        f"- 中央値差: {primary['delta_median']:+.3f}",
        f"- 四分位範囲: {primary['delta_p25']:+.3f}〜{primary['delta_p75']:+.3f}",
        f"- 対応付き標準化効果量 dz: {primary['paired_standardized_effect_dz']:+.3f}",
        f"- 順位双列相関: {primary['paired_rank_biserial']:+.3f}",
        f"- 補助的な両側符号検定p: {primary['exact_two_sided_sign_p']:.3g}",
        "",
        "## 最大差seed",
        "",
        "- 増加側: " + ", ".join(
            f"seed {item['seed']} ({item['delta']:+.3f})"
            for item in analysis["primary_extremes"]["largest_positive"][:5]
        ),
        "- 減少側: " + ", ".join(
            f"seed {item['seed']} ({item['delta']:+.3f})"
            for item in analysis["primary_extremes"]["largest_negative"][:5]
        ),
        "",
        "## 解釈上の境界",
        "",
        "- 測定したのは協調性変更から下流へ広がる総効果。個体数や接続条件が変わった結果、変異事件が分岐することを含む。",
        "- 外部天候は全ペアで固定した。変異の発生日・対象株まで固定する直接効果実験ではない。",
        "- 一株・一モデル・320日という範囲の結果であり、現実の植物や社会へ一般化しない。",
        "- A/B両群とも死亡は0。320日目の生存株差は、この条件では死亡差ではなく主に増殖差を表す。",
        "- 感度解析1,100世界はまだ開始していない。A/B結果確定後の別バッチとして扱う。",
    ])
    args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"saved={args.output_json}")
    print(f"saved={args.output_md}")


if __name__ == "__main__":
    main()
