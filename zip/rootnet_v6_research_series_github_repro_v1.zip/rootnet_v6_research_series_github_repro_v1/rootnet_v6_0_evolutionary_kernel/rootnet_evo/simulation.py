from __future__ import annotations

import hashlib
import json
import math
import random
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .metrics import population_metrics
from .model import Genome, Habitat, Individual, Phenotype, TRAIT_NAMES, clamp
from .rng import derive_seed, make_streams


COMMON_ANCESTOR_ID = "ancestor-000000"


def habitat_preset(name: str, capacity: int) -> tuple[Habitat, ...]:
    if name == "homogeneous":
        return tuple(
            Habitat(patch_id, 0.55, 0.55, 0.65, capacity)
            for patch_id in ("patch-0", "patch-1", "patch-2")
        )
    if name == "heterogeneous":
        return (
            Habitat("patch-0", light=0.95, substrate=0.20, water=0.42, capacity=capacity),
            Habitat("patch-1", light=0.55, substrate=0.55, water=0.65, capacity=capacity),
            Habitat("patch-2", light=0.05, substrate=0.95, water=0.90, capacity=capacity),
        )
    raise ValueError(f"unknown habitat preset: {name}")


@dataclass(frozen=True)
class SimulationConfig:
    master_seed: int = 600
    generations: int = 120
    founder_count: int = 48
    capacity_per_patch: int = 80
    habitat_preset: str = "heterogeneous"
    mutation_probability: float = 0.24
    mutation_sigma: float = 0.035
    environmental_noise_sigma: float = 0.025
    founder_genome: Genome = field(default_factory=Genome)

    def normalized(self) -> "SimulationConfig":
        if self.habitat_preset not in {"homogeneous", "heterogeneous"}:
            raise ValueError("habitat_preset must be homogeneous or heterogeneous")
        return SimulationConfig(
            master_seed=int(self.master_seed),
            generations=max(0, int(self.generations)),
            founder_count=max(1, int(self.founder_count)),
            capacity_per_patch=max(2, int(self.capacity_per_patch)),
            habitat_preset=self.habitat_preset,
            mutation_probability=clamp(self.mutation_probability),
            mutation_sigma=max(0.0, float(self.mutation_sigma)),
            environmental_noise_sigma=max(0.0, float(self.environmental_noise_sigma)),
            founder_genome=self.founder_genome.normalized(),
        )

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self.normalized())
        result["founder_genome"] = self.founder_genome.normalized().to_dict()
        return result


class EvolutionSimulation:
    """Minimal Darwinian kernel with no environment-directed trait updates."""

    def __init__(self, config: SimulationConfig) -> None:
        self.config = config.normalized()
        self.stream_seeds, _ = make_streams(self.config.master_seed)
        self.habitats = habitat_preset(
            self.config.habitat_preset,
            self.config.capacity_per_patch,
        )
        self.habitat_by_id = {habitat.patch_id: habitat for habitat in self.habitats}
        self.patch_order = tuple(habitat.patch_id for habitat in self.habitats)
        self.generation = 0
        self._next_serial = 1
        self.population = self._make_founders()
        self.generation_records: list[dict[str, Any]] = []
        self.ancestry_records: list[dict[str, Any]] = [
            {
                **individual.to_dict(),
                "mutated_loci": [],
                "recruited": True,
            }
            for individual in self.population
        ]
        self.max_abs_transfer_balance_error = 0.0

    def _make_founders(self) -> list[Individual]:
        founders = []
        central_patch = self.patch_order[len(self.patch_order) // 2]
        for index in range(self.config.founder_count):
            organism_id = f"org-{self._next_serial:09d}"
            self._next_serial += 1
            founders.append(Individual(
                organism_id=organism_id,
                parent_id=COMMON_ANCESTOR_ID,
                root_lineage_id=organism_id,
                birth_generation=0,
                patch_id=central_patch,
                genome=self.config.founder_genome,
            ))
        return founders

    def _rng_for(self, stream_name: str, subject: str) -> random.Random:
        subject_seed = derive_seed(self.stream_seeds[stream_name], subject)
        return random.Random(subject_seed)

    def _environment_for_generation(self, generation: int) -> dict[str, Habitat]:
        states = {}
        for habitat in self.habitats:
            rng = self._rng_for(
                "environment",
                f"generation:{generation}|patch:{habitat.patch_id}",
            )
            water = clamp(rng.gauss(habitat.water, self.config.environmental_noise_sigma))
            states[habitat.patch_id] = Habitat(
                patch_id=habitat.patch_id,
                light=habitat.light,
                substrate=habitat.substrate,
                water=water,
                capacity=habitat.capacity,
            )
        return states

    @staticmethod
    def _gross_energy(individual: Individual, habitat: Habitat) -> float:
        phenotype = Phenotype.from_genome(individual.genome)
        resource_input = 0.80 * (
            habitat.light * phenotype.light_capture
            + habitat.substrate * phenotype.substrate_absorption
        )
        effective_water = habitat.water + phenotype.desiccation_tolerance * (1.0 - habitat.water)
        water_modifier = 0.55 + 0.45 * effective_water
        return 0.33 + resource_input * water_modifier

    @staticmethod
    def _redistribute_energy(
        population: list[Individual],
        energies: dict[str, float],
    ) -> tuple[float, float]:
        before = sum(energies.values())
        transferred = 0.0
        by_patch: dict[str, list[Individual]] = defaultdict(list)
        for individual in population:
            by_patch[individual.patch_id].append(individual)

        for patch_id in sorted(by_patch):
            members = sorted(by_patch[patch_id], key=lambda item: item.organism_id)
            donors = sorted(
                members,
                key=lambda item: (-energies[item.organism_id], item.organism_id),
            )
            receivers = sorted(
                members,
                key=lambda item: (energies[item.organism_id], item.organism_id),
            )
            for donor in donors:
                sharing = Phenotype.from_genome(donor.genome).resource_sharing
                for receiver in receivers:
                    if receiver.organism_id == donor.organism_id:
                        continue
                    excess = max(0.0, energies[donor.organism_id] - 0.75)
                    deficit = max(0.0, 0.58 - energies[receiver.organism_id])
                    amount = min(excess * sharing * 0.18, deficit, 0.05)
                    if amount <= 0.0:
                        continue
                    energies[donor.organism_id] -= amount
                    energies[receiver.organism_id] += amount
                    transferred += amount

        after = sum(energies.values())
        return transferred, after - before

    def _mutate(self, parent: Individual, birth_key: str) -> tuple[Genome, list[str]]:
        rng = self._rng_for("mutation", birth_key)
        values = parent.genome.to_dict()
        mutated_loci: list[str] = []
        for trait_name in TRAIT_NAMES:
            if rng.random() < self.config.mutation_probability:
                values[trait_name] += rng.gauss(0.0, self.config.mutation_sigma)
                mutated_loci.append(trait_name)
        return Genome.from_dict(values), mutated_loci

    def _offspring_patch(self, parent: Individual, birth_key: str) -> str:
        phenotype = Phenotype.from_genome(parent.genome)
        rng = self._rng_for("dispersal", birth_key)
        dispersal_probability = 0.03 + 0.55 * phenotype.dispersal
        if rng.random() >= dispersal_probability:
            return parent.patch_id
        index = self.patch_order.index(parent.patch_id)
        neighbors = []
        if index > 0:
            neighbors.append(self.patch_order[index - 1])
        if index + 1 < len(self.patch_order):
            neighbors.append(self.patch_order[index + 1])
        return rng.choice(neighbors) if neighbors else parent.patch_id

    @staticmethod
    def _stochastic_round(expected: float, rng: random.Random) -> int:
        expected = max(0.0, expected)
        whole = int(expected)
        return whole + int(rng.random() < expected - whole)

    def _density_regulation(
        self,
        candidates: list[Individual],
        generation: int,
    ) -> tuple[list[Individual], set[str]]:
        by_patch: dict[str, list[Individual]] = defaultdict(list)
        for candidate in candidates:
            by_patch[candidate.patch_id].append(candidate)

        recruited: list[Individual] = []
        rejected: set[str] = set()
        for patch_id in self.patch_order:
            patch_candidates = sorted(
                by_patch.get(patch_id, []),
                key=lambda item: item.organism_id,
            )
            capacity = self.habitat_by_id[patch_id].capacity
            if len(patch_candidates) <= capacity:
                recruited.extend(patch_candidates)
                continue
            rng = self._rng_for("density", f"generation:{generation}|patch:{patch_id}")
            selected_ids = {
                individual.organism_id
                for individual in rng.sample(patch_candidates, capacity)
            }
            recruited.extend(
                individual for individual in patch_candidates
                if individual.organism_id in selected_ids
            )
            rejected.update(
                individual.organism_id for individual in patch_candidates
                if individual.organism_id not in selected_ids
            )
        return sorted(recruited, key=lambda item: item.organism_id), rejected

    def step(self) -> dict[str, Any]:
        if not self.population:
            raise RuntimeError("cannot step an extinct population")

        next_generation = self.generation + 1
        environment = self._environment_for_generation(next_generation)
        parent_genomes_before = {
            individual.organism_id: individual.genome
            for individual in self.population
        }
        energies = {
            individual.organism_id: self._gross_energy(
                individual,
                environment[individual.patch_id],
            )
            for individual in self.population
        }
        transferred, transfer_error = self._redistribute_energy(self.population, energies)
        self.max_abs_transfer_balance_error = max(
            self.max_abs_transfer_balance_error,
            abs(transfer_error),
        )

        survivors: list[tuple[Individual, float]] = []
        candidates: list[Individual] = []
        pending_ancestry: list[dict[str, Any]] = []
        mutation_events = 0

        for parent in sorted(self.population, key=lambda item: item.organism_id):
            phenotype = Phenotype.from_genome(parent.genome)
            net_energy = energies[parent.organism_id] - phenotype.maintenance_cost
            survival_probability = 1.0 / (1.0 + math.exp(-7.0 * (net_energy - 0.18)))
            demographic_rng = self._rng_for(
                "demography",
                f"generation:{next_generation}|parent:{parent.organism_id}",
            )
            if demographic_rng.random() >= survival_probability:
                continue
            survivors.append((parent, net_energy))
            expected_offspring = min(4.0, 0.95 + 1.80 * max(0.0, net_energy))
            offspring_count = self._stochastic_round(expected_offspring, demographic_rng)

            for child_index in range(offspring_count):
                birth_key = (
                    f"generation:{next_generation}|parent:{parent.organism_id}"
                    f"|child:{child_index}"
                )
                genome, mutated_loci = self._mutate(parent, birth_key)
                organism_id = f"org-{self._next_serial:09d}"
                self._next_serial += 1
                child = Individual(
                    organism_id=organism_id,
                    parent_id=parent.organism_id,
                    root_lineage_id=parent.root_lineage_id,
                    birth_generation=next_generation,
                    patch_id=self._offspring_patch(parent, birth_key),
                    genome=genome,
                )
                candidates.append(child)
                mutation_events += len(mutated_loci)
                pending_ancestry.append({
                    **child.to_dict(),
                    "mutated_loci": mutated_loci,
                })

        if parent_genomes_before != {
            individual.organism_id: individual.genome
            for individual in self.population
        }:
            raise AssertionError("parent genomes changed during environmental evaluation")

        recruited, density_rejected = self._density_regulation(candidates, next_generation)
        recruited_ids = {individual.organism_id for individual in recruited}
        for record in pending_ancestry:
            record["recruited"] = record["organism_id"] in recruited_ids
        self.ancestry_records.extend(pending_ancestry)

        previous_metrics = population_metrics(self.population)
        self.population = recruited
        self.generation = next_generation
        current_metrics = population_metrics(self.population)
        disparity_change = (
            float(current_metrics["phenotypic_disparity"])
            - float(previous_metrics["phenotypic_disparity"])
        )
        record = {
            "generation": self.generation,
            "environment": {
                patch_id: habitat.to_dict()
                for patch_id, habitat in sorted(environment.items())
            },
            "parents": int(previous_metrics["population"]),
            "survivors_to_reproduction": len(survivors),
            "offspring_produced": len(candidates),
            "density_deaths": len(density_rejected),
            "mutation_events": mutation_events,
            "resource_transferred": round(transferred, 12),
            "transfer_balance_error": transfer_error,
            "disparity_change": round(disparity_change, 9),
            **current_metrics,
        }
        self.generation_records.append(record)
        return record

    def run(self, output_directory: str | Path | None = None) -> dict[str, Any]:
        while self.generation < self.config.generations and self.population:
            self.step()

        initial_metrics = population_metrics([
            Individual(
                organism_id=f"initial-{index}",
                parent_id=COMMON_ANCESTOR_ID,
                root_lineage_id=f"initial-{index}",
                birth_generation=0,
                patch_id=self.patch_order[len(self.patch_order) // 2],
                genome=self.config.founder_genome,
            )
            for index in range(self.config.founder_count)
        ])
        final_metrics = population_metrics(self.population)
        summary = {
            "schema": "rootnet-evo-v6.0-summary-v1",
            "completed_generations": self.generation,
            "requested_generations": self.config.generations,
            "extinct": not bool(self.population),
            "stream_seeds": self.stream_seeds,
            "config": self.config.to_dict(),
            "initial_metrics": initial_metrics,
            "final_metrics": final_metrics,
            "max_abs_transfer_balance_error": self.max_abs_transfer_balance_error,
            "ancestry_records": len(self.ancestry_records),
            "claim_boundary": (
                "Mechanism output from an artificial evolutionary system; "
                "not a reconstruction of fungal evolution or a species prediction."
            ),
        }
        if output_directory is not None:
            self.write_outputs(Path(output_directory), summary)
        return summary

    def write_outputs(self, output_directory: Path, summary: dict[str, Any]) -> None:
        output_directory.mkdir(parents=True, exist_ok=True)
        (output_directory / "config.json").write_text(
            json.dumps(self.config.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        (output_directory / "summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        with (output_directory / "generations.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for record in self.generation_records:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        with (output_directory / "ancestry.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for record in self.ancestry_records:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    def state_digest(self) -> str:
        payload = {
            "generation": self.generation,
            "population": [individual.to_dict() for individual in self.population],
            "records": self.generation_records,
            "ancestry": self.ancestry_records,
        }
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()
