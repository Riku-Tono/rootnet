from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .metrics import network_metrics
from .model import (
    Coord,
    Genet,
    Genome,
    HyphalNode,
    Ramet,
    Spore,
    TRAIT_NAMES,
    canonical_edge,
    clamp,
)
from .rng import keyed_rng, stream_seeds


COMMON_ANCESTOR_ID = "ancestor-000000"


@dataclass(frozen=True)
class SimulationConfig:
    master_seed: int = 620
    ticks: int = 360
    width: int = 42
    height: int = 18
    founder_count: int = 3
    max_modules_per_ramet: int = 180
    mutation_probability: float = 0.20
    mutation_sigma: float = 0.032
    substrate_recovery: float = 0.026
    water_recovery: float = 0.060
    detritus_decay: float = 0.11
    detritus_growth_threshold: float = 0.20
    recycling_efficiency: float = 0.35
    vitality_decay: float = 0.22
    vitality_recovery: float = 0.045
    transport_rounds: int = 2
    internal_anastomosis_scale: float = 0.16
    same_genet_fusion_scale: float = 0.38
    growth_energy_reserve: float = 0.004
    growth_water_reserve: float = 0.0
    spore_viability_ticks: int = 20
    reproduction_min_age: int = 18
    reproduction_min_modules: int = 12
    founder_genome: Genome = field(default_factory=Genome)

    def normalized(self) -> "SimulationConfig":
        width = max(8, int(self.width))
        height = max(6, int(self.height))
        return SimulationConfig(
            master_seed=int(self.master_seed),
            ticks=max(0, int(self.ticks)),
            width=width,
            height=height,
            founder_count=max(1, min(int(self.founder_count), width - 2)),
            max_modules_per_ramet=max(2, int(self.max_modules_per_ramet)),
            mutation_probability=clamp(self.mutation_probability),
            mutation_sigma=max(0.0, float(self.mutation_sigma)),
            substrate_recovery=clamp(self.substrate_recovery),
            water_recovery=clamp(self.water_recovery),
            detritus_decay=clamp(self.detritus_decay),
            detritus_growth_threshold=clamp(self.detritus_growth_threshold),
            recycling_efficiency=clamp(self.recycling_efficiency),
            vitality_decay=max(0.0, float(self.vitality_decay)),
            vitality_recovery=max(0.0, float(self.vitality_recovery)),
            transport_rounds=max(1, int(self.transport_rounds)),
            internal_anastomosis_scale=clamp(self.internal_anastomosis_scale),
            same_genet_fusion_scale=clamp(self.same_genet_fusion_scale),
            growth_energy_reserve=max(0.0, float(self.growth_energy_reserve)),
            growth_water_reserve=max(0.0, float(self.growth_water_reserve)),
            spore_viability_ticks=max(1, int(self.spore_viability_ticks)),
            reproduction_min_age=max(1, int(self.reproduction_min_age)),
            reproduction_min_modules=max(2, int(self.reproduction_min_modules)),
            founder_genome=self.founder_genome.normalized(),
        )

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self.normalized())
        result["founder_genome"] = self.founder_genome.normalized().to_dict()
        return result


class ModuleSimulation:
    def __init__(self, config: SimulationConfig) -> None:
        self.config = config.normalized()
        self.stream_seeds = stream_seeds(self.config.master_seed)
        self.tick = 0
        self._next_genet_serial = 1
        self._next_ramet_serial = 1
        self._next_spore_serial = 1
        self.substrate_capacity, self.water_capacity = self._make_resource_capacities()
        self.substrate = [row[:] for row in self.substrate_capacity]
        self.water = [row[:] for row in self.water_capacity]
        self.detritus = [[0.0] * self.config.width for _ in range(self.config.height)]
        self.genets: dict[str, Genet] = {}
        self.ramets: dict[str, Ramet] = {}
        self.occupancy: dict[Coord, str] = {}
        self.spores: list[Spore] = []
        self.tick_records: list[dict[str, Any]] = []
        self.genet_records: list[dict[str, Any]] = []
        self.ramet_records: list[dict[str, Any]] = []
        self.necrosis_records: list[dict[str, Any]] = []
        self.spore_records: list[dict[str, Any]] = []
        self.extinct_genets: set[str] = set()
        self.max_abs_energy_transport_error = 0.0
        self.max_abs_water_transport_error = 0.0
        self._make_founders()

    def _rng(self, stream: str, subject: str):
        return keyed_rng(self.stream_seeds[stream], subject)

    def _new_genet_id(self) -> str:
        result = f"genet-{self._next_genet_serial:07d}"
        self._next_genet_serial += 1
        return result

    def _new_ramet_id(self) -> str:
        result = f"ramet-{self._next_ramet_serial:07d}"
        self._next_ramet_serial += 1
        return result

    def _make_resource_capacities(self) -> tuple[list[list[float]], list[list[float]]]:
        substrate: list[list[float]] = []
        water: list[list[float]] = []
        for y in range(self.config.height):
            depth = y / max(1, self.config.height - 1)
            s_row, w_row = [], []
            for x in range(self.config.width):
                patch = 0.13 * math.sin((x + 1) * 0.53) * math.cos((y + 1) * 0.39)
                dry_patch = 0.08 * math.sin((x + y + 2) * 0.31)
                s_row.append(clamp(0.17 + 0.70 * depth + patch, 0.05, 1.0))
                w_row.append(clamp(0.29 + 0.57 * depth - patch * 0.25 + dry_patch, 0.08, 1.0))
            substrate.append(s_row)
            water.append(w_row)
        return substrate, water

    def light_at(self, coord: Coord) -> float:
        depth = coord[1] / max(1, self.config.height - 1)
        return clamp(1.0 - depth * 0.95, 0.03, 1.0)

    def in_bounds(self, coord: Coord) -> bool:
        x, y = coord
        return 0 <= x < self.config.width and 0 <= y < self.config.height

    def neighbors(self, coord: Coord) -> list[Coord]:
        x, y = coord
        return [c for c in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)) if self.in_bounds(c)]

    def _make_founders(self) -> None:
        y = self.config.height // 2
        for index in range(self.config.founder_count):
            x = round((index + 1) * (self.config.width - 1) / (self.config.founder_count + 1))
            origin = (x, y)
            genet_id = self._new_genet_id()
            genet = Genet(
                genet_id=genet_id,
                parent_genet_id=COMMON_ANCESTOR_ID,
                lineage_id=genet_id,
                birth_tick=0,
                genome=self.config.founder_genome,
                origin=origin,
            )
            ramet_id = self._new_ramet_id()
            node = HyphalNode(origin, 0, energy=0.72, water=0.52)
            ramet = Ramet(ramet_id, genet_id, 0, origin, nodes={origin: node}, created_by="founder")
            self.genets[genet_id] = genet
            self.ramets[ramet_id] = ramet
            self.occupancy[origin] = ramet_id
            self.genet_records.append({"event": "established", **genet.to_dict(), "mutated_loci": []})
            self.ramet_records.append({"event": "created", "tick": 0, **self._ramet_identity(ramet)})

    @staticmethod
    def _ramet_identity(ramet: Ramet) -> dict[str, Any]:
        return {
            "ramet_id": ramet.ramet_id,
            "genet_id": ramet.genet_id,
            "birth_tick": ramet.birth_tick,
            "origin": list(ramet.origin),
            "parent_ramet_id": ramet.parent_ramet_id,
            "created_by": ramet.created_by,
        }

    def living_ramets(self) -> list[Ramet]:
        return sorted(
            (r for r in self.ramets.values() if r.alive and r.nodes),
            key=lambda r: r.ramet_id,
        )

    def living_genet_ids(self) -> set[str]:
        return {r.genet_id for r in self.living_ramets()}

    def _replenish_and_decay(self) -> None:
        for y in range(self.config.height):
            for x in range(self.config.width):
                self.substrate[y][x] += (self.substrate_capacity[y][x] - self.substrate[y][x]) * self.config.substrate_recovery
                self.water[y][x] += (self.water_capacity[y][x] - self.water[y][x]) * self.config.water_recovery
                self.detritus[y][x] = max(0.0, self.detritus[y][x] - self.config.detritus_decay)

    def _absorb_local(self, ramet: Ramet) -> tuple[float, float, float]:
        phenotype = self.genets[ramet.genet_id].phenotype
        substrate_taken = water_taken = light_energy = 0.0
        for coord, node in sorted(ramet.nodes.items()):
            x, y = coord
            s_take = min(
                self.substrate[y][x],
                0.012 * phenotype.substrate_absorption * (0.22 + self.substrate[y][x]),
            )
            w_take = min(
                self.water[y][x],
                0.007 * (0.32 + phenotype.desiccation_tolerance) * (0.30 + self.water[y][x]),
            )
            l_gain = 0.0048 * self.light_at(coord) * phenotype.light_capture
            self.substrate[y][x] -= s_take
            self.water[y][x] -= w_take
            node.energy = min(1.60, node.energy + s_take * 2.45 + l_gain)
            node.water = min(1.10, node.water + w_take)
            substrate_taken += s_take
            water_taken += w_take
            light_energy += l_gain
        return substrate_taken, water_taken, light_energy

    def _transport_field(self, ramet: Ramet, field_name: str, conductance: float, max_edge_flux: float) -> tuple[float, float]:
        before = sum(getattr(node, field_name) for node in ramet.nodes.values())
        proposals: list[tuple[Coord, Coord, float]] = []
        outgoing: dict[Coord, float] = {}
        for left, right in sorted(ramet.edges):
            if left not in ramet.nodes or right not in ramet.nodes:
                continue
            difference = getattr(ramet.nodes[left], field_name) - getattr(ramet.nodes[right], field_name)
            if abs(difference) < 1e-15:
                continue
            donor, receiver = (left, right) if difference > 0 else (right, left)
            amount = min(abs(difference) * conductance, max_edge_flux)
            proposals.append((donor, receiver, amount))
            outgoing[donor] = outgoing.get(donor, 0.0) + amount
        scale = {
            donor: min(1.0, getattr(ramet.nodes[donor], field_name) / total) if total > 0 else 1.0
            for donor, total in outgoing.items()
        }
        delta = {coord: 0.0 for coord in ramet.nodes}
        moved = 0.0
        for donor, receiver, amount in proposals:
            actual = amount * scale[donor]
            delta[donor] -= actual
            delta[receiver] += actual
            moved += actual
        for coord, change in delta.items():
            setattr(ramet.nodes[coord], field_name, max(0.0, getattr(ramet.nodes[coord], field_name) + change))
        after = sum(getattr(node, field_name) for node in ramet.nodes.values())
        return moved, after - before

    def _transport(self, ramet: Ramet) -> tuple[float, float, float, float]:
        phenotype = self.genets[ramet.genet_id].phenotype
        energy_moved = water_moved = energy_error = water_error = 0.0
        for _ in range(self.config.transport_rounds):
            moved, error = self._transport_field(ramet, "energy", phenotype.energy_conductance, 0.060)
            energy_moved += moved
            energy_error += error
            moved, error = self._transport_field(ramet, "water", phenotype.water_conductance, 0.035)
            water_moved += moved
            water_error += error
        self.max_abs_energy_transport_error = max(self.max_abs_energy_transport_error, abs(energy_error))
        self.max_abs_water_transport_error = max(self.max_abs_water_transport_error, abs(water_error))
        return energy_moved, water_moved, energy_error, water_error

    def _maintain(self, ramet: Ramet) -> None:
        phenotype = self.genets[ramet.genet_id].phenotype
        for node in ramet.nodes.values():
            energy_paid = min(node.energy, phenotype.maintenance_energy)
            water_paid = min(node.water, phenotype.maintenance_water)
            node.energy -= energy_paid
            node.water -= water_paid
            energy_deficit = 1.0 - energy_paid / phenotype.maintenance_energy
            water_deficit = 1.0 - water_paid / phenotype.maintenance_water
            deficit = max(energy_deficit, water_deficit)
            if deficit > 1e-12:
                node.starvation_ticks += 1
                node.vitality = max(0.0, node.vitality - self.config.vitality_decay * deficit)
            else:
                node.starvation_ticks = max(0, node.starvation_ticks - 1)
                node.vitality = min(1.0, node.vitality + self.config.vitality_recovery)
            node.age += 1

    def _connected_components(self, ramet: Ramet) -> list[set[Coord]]:
        adjacency = {coord: set() for coord in ramet.nodes}
        for left, right in ramet.edges:
            if left in adjacency and right in adjacency:
                adjacency[left].add(right)
                adjacency[right].add(left)
        remaining = set(adjacency)
        components = []
        while remaining:
            start = min(remaining)
            stack = [start]
            component = {start}
            remaining.remove(start)
            while stack:
                current = stack.pop()
                for neighbor in sorted(adjacency[current]):
                    if neighbor in remaining:
                        remaining.remove(neighbor)
                        component.add(neighbor)
                        stack.append(neighbor)
            components.append(component)
        return sorted(components, key=lambda c: (-len(c), min(c)))

    def _end_ramet(self, ramet: Ramet, reason: str, *, is_death: bool) -> None:
        ramet.alive = False
        ramet.end_tick = self.tick
        ramet.end_reason = reason
        self.ramet_records.append({
            "event": "died" if is_death else "ended",
            "tick": self.tick,
            "reason": reason,
            **self._ramet_identity(ramet),
        })

    def _split_if_disconnected(self, ramet: Ramet) -> list[str]:
        if not ramet.alive or len(ramet.nodes) < 2:
            return []
        components = self._connected_components(ramet)
        if len(components) <= 1:
            return []
        old_nodes = ramet.nodes
        old_edges = ramet.edges
        old_tips = ramet.tips
        keep = components[0]
        ramet.nodes = {coord: old_nodes[coord] for coord in keep}
        ramet.edges = {edge for edge in old_edges if edge[0] in keep and edge[1] in keep}
        ramet.tips = (old_tips & keep) | {coord for coord in keep if sum(coord in e for e in ramet.edges) <= 1}
        ramet.origin = min(keep)
        created = []
        for component in components[1:]:
            ramet_id = self._new_ramet_id()
            fragment = Ramet(
                ramet_id=ramet_id,
                genet_id=ramet.genet_id,
                birth_tick=self.tick,
                origin=min(component),
                parent_ramet_id=ramet.ramet_id,
                created_by="fragmentation",
                nodes={coord: old_nodes[coord] for coord in component},
                edges={edge for edge in old_edges if edge[0] in component and edge[1] in component},
                tips=(old_tips & component),
            )
            fragment.tips |= {coord for coord in component if sum(coord in e for e in fragment.edges) <= 1}
            self.ramets[ramet_id] = fragment
            for coord in component:
                self.occupancy[coord] = ramet_id
            self.ramet_records.append({"event": "created", "tick": self.tick, **self._ramet_identity(fragment)})
            created.append(ramet_id)
        return created

    def _prune_necrotic(self, ramet: Ramet) -> tuple[list[Coord], list[str], bool]:
        dead_coords = sorted(coord for coord, node in ramet.nodes.items() if node.vitality <= 0.0)
        if not dead_coords:
            return [], [], False
        for coord in dead_coords:
            node = ramet.nodes.pop(coord)
            self.occupancy.pop(coord, None)
            x, y = coord
            structural_biomass = 0.055
            requested_recycling = structural_biomass * self.config.recycling_efficiency
            before_recycling = self.substrate[y][x]
            self.substrate[y][x] = min(
                self.substrate_capacity[y][x],
                before_recycling + requested_recycling,
            )
            recycled = self.substrate[y][x] - before_recycling
            self.detritus[y][x] = 1.0
            self.necrosis_records.append({
                "tick": self.tick,
                "ramet_id": ramet.ramet_id,
                "genet_id": ramet.genet_id,
                "coord": list(coord),
                "node_age": node.age,
                "starvation_ticks": node.starvation_ticks,
                "recycled_substrate": recycled,
            })
        ramet.edges = {edge for edge in ramet.edges if edge[0] in ramet.nodes and edge[1] in ramet.nodes}
        ramet.tips &= set(ramet.nodes)
        for coord in ramet.nodes:
            degree = sum(coord in edge for edge in ramet.edges)
            if degree <= 1:
                ramet.tips.add(coord)
        if not ramet.nodes:
            self._end_ramet(ramet, "all_modules_necrotic", is_death=True)
            return dead_coords, [], True
        fragments = self._split_if_disconnected(ramet)
        return dead_coords, fragments, False

    def _growth_score(self, coord: Coord, phenotype) -> float:
        x, y = coord
        return (
            self.substrate[y][x] * phenotype.substrate_absorption
            + self.water[y][x] * phenotype.desiccation_tolerance * 0.45
            + self.light_at(coord) * phenotype.light_capture
        )

    def _grow(self, ramet: Ramet) -> tuple[int, int]:
        if not ramet.alive or len(ramet.nodes) >= self.config.max_modules_per_ramet:
            return 0, 0
        phenotype = self.genets[ramet.genet_id].phenotype
        rng = self._rng("growth", f"tick:{self.tick}|ramet:{ramet.ramet_id}")
        attempts = 1 + int(rng.random() < phenotype.extension_rate * 0.55)
        grown = new_loops = 0
        for attempt in range(attempts):
            eligible = [
                coord for coord in sorted(ramet.tips)
                if ramet.nodes[coord].energy > phenotype.extension_cost + self.config.growth_energy_reserve
                and ramet.nodes[coord].water > phenotype.extension_water + self.config.growth_water_reserve
                and ramet.nodes[coord].vitality > 0.35
            ]
            if not eligible:
                break
            tip = eligible[rng.randrange(len(eligible))]
            candidates = [
                coord for coord in self.neighbors(tip)
                if coord not in self.occupancy
                and self.detritus[coord[1]][coord[0]] < self.config.detritus_growth_threshold
            ]
            if not candidates:
                ramet.tips.discard(tip)
                continue
            scored = [(self._growth_score(c, phenotype) + rng.uniform(0.0, 0.14), c) for c in candidates]
            _, new_coord = max(scored, key=lambda item: (item[0], item[1]))
            parent = ramet.nodes[tip]
            parent.energy -= phenotype.extension_cost
            parent.water -= phenotype.extension_water
            ramet.nodes[new_coord] = HyphalNode(new_coord, self.tick, energy=0.065, water=0.035)
            ramet.edges.add(canonical_edge(tip, new_coord))
            self.occupancy[new_coord] = ramet.ramet_id
            if rng.random() >= phenotype.branching_rate:
                ramet.tips.discard(tip)
            ramet.tips.add(new_coord)
            for neighbor in sorted(self.neighbors(new_coord)):
                if neighbor == tip or neighbor not in ramet.nodes:
                    continue
                edge = canonical_edge(new_coord, neighbor)
                if edge in ramet.edges:
                    continue
                join_rng = self._rng(
                    "anastomosis",
                    f"internal:{self.tick}|{ramet.ramet_id}|{edge}",
                )
                if join_rng.random() < self.config.internal_anastomosis_scale * phenotype.anastomosis_tendency:
                    ramet.edges.add(edge)
                    new_loops += 1
            grown += 1
            if len(ramet.nodes) >= self.config.max_modules_per_ramet:
                break
        return grown, new_loops

    def _merge_ramets(self, left: Ramet, right: Ramet, bridge: tuple[Coord, Coord]) -> str:
        keep, absorbed = sorted((left, right), key=lambda r: (-len(r.nodes), r.ramet_id))
        keep.nodes.update(absorbed.nodes)
        keep.edges.update(absorbed.edges)
        keep.edges.add(canonical_edge(*bridge))
        keep.tips.update(absorbed.tips)
        for coord in absorbed.nodes:
            self.occupancy[coord] = keep.ramet_id
        absorbed.merged_into = keep.ramet_id
        self._end_ramet(absorbed, "same_genet_anastomosis", is_death=False)
        return keep.ramet_id

    def _same_genet_fusions(self) -> tuple[list[list[str]], int]:
        contacts: dict[tuple[str, str], tuple[Coord, Coord]] = {}
        blocked_nonself: set[tuple[str, str]] = set()
        for coord, ramet_id in sorted(self.occupancy.items()):
            for neighbor in self.neighbors(coord):
                other_id = self.occupancy.get(neighbor)
                if other_id is None or other_id == ramet_id:
                    continue
                pair = tuple(sorted((ramet_id, other_id)))
                left, right = self.ramets[pair[0]], self.ramets[pair[1]]
                if left.genet_id == right.genet_id:
                    contacts.setdefault(pair, (coord, neighbor))
                else:
                    blocked_nonself.add(pair)
        fused = []
        for pair, bridge in sorted(contacts.items()):
            left, right = self.ramets[pair[0]], self.ramets[pair[1]]
            if not left.alive or not right.alive or left.genet_id != right.genet_id:
                continue
            phenotype = self.genets[left.genet_id].phenotype
            rng = self._rng("anastomosis", f"ramet-fusion:{self.tick}|{pair}")
            if rng.random() < self.config.same_genet_fusion_scale * phenotype.anastomosis_tendency:
                retained = self._merge_ramets(left, right, bridge)
                fused.append([pair[0], pair[1], retained])
        return fused, len(blocked_nonself)

    def _mutate_genome(self, parent_genet: Genet, subject: str) -> tuple[Genome, list[str]]:
        rng = self._rng("mutation", subject)
        values = parent_genet.genome.to_dict()
        mutated = []
        for name in TRAIT_NAMES:
            if rng.random() < self.config.mutation_probability:
                values[name] += rng.gauss(0.0, self.config.mutation_sigma)
                mutated.append(name)
        return Genome.from_dict(values), mutated

    def release_spore(self, ramet: Ramet, position: Coord | None = None, *, force: bool = False) -> Spore | None:
        if not ramet.alive or not ramet.nodes:
            return None
        genet = self.genets[ramet.genet_id]
        phenotype = genet.phenotype
        sources = sorted(ramet.nodes.values(), key=lambda n: (-n.energy, n.coord))
        source = sources[0]
        if source.energy <= phenotype.spore_cost + 0.04:
            return None
        ramet_age = self.tick - ramet.birth_tick
        if not force and (ramet_age < self.config.reproduction_min_age or len(ramet.nodes) < self.config.reproduction_min_modules):
            return None
        spore_id = f"spore-{self._next_spore_serial:08d}"
        self._next_spore_serial += 1
        subject = f"tick:{self.tick}|parent:{genet.genet_id}|spore:{spore_id}"
        genome, mutated = self._mutate_genome(genet, subject)
        rng = self._rng("spore", subject)
        if position is None:
            radius = 1 + int(round(6 * phenotype.spore_dispersal))
            position = (
                max(0, min(self.config.width - 1, source.coord[0] + rng.randint(-radius, radius))),
                max(0, min(self.config.height - 1, source.coord[1] + rng.randint(-radius, radius))),
            )
        source.energy -= phenotype.spore_cost
        spore = Spore(spore_id, genet.genet_id, genet.lineage_id, genome, position, self.tick, self.tick + self.config.spore_viability_ticks)
        self.spores.append(spore)
        self.spore_records.append({"event": "released", "tick": self.tick, **spore.to_dict(), "mutated_loci": mutated})
        return spore

    def _reproduce(self, ramet: Ramet) -> Spore | None:
        rng = self._rng("spore", f"reproduce:{self.tick}|{ramet.ramet_id}")
        probability = 0.012 + 0.036 * self.genets[ramet.genet_id].phenotype.spore_dispersal
        return self.release_spore(ramet) if rng.random() < probability else None

    def _germinate_spores(self) -> tuple[list[str], list[str]]:
        germinated, failed, remaining = [], [], []
        for spore in sorted(self.spores, key=lambda s: s.spore_id):
            x, y = spore.position
            if self.tick > spore.expires_tick:
                failed.append(spore.spore_id)
                self.spore_records.append({"event": "establishment_failed", "tick": self.tick, **spore.to_dict(), "reason": "viability_expired"})
                continue
            if spore.position in self.occupancy or self.detritus[y][x] >= self.config.detritus_growth_threshold:
                remaining.append(spore)
                continue
            score = (self.substrate[y][x] + self.water[y][x] + self.light_at(spore.position) * 0.30) / 2.30
            rng = self._rng("germination", f"tick:{self.tick}|{spore.spore_id}")
            if score < 0.25 or rng.random() >= 0.22 + 0.42 * score:
                remaining.append(spore)
                continue
            genet_id = self._new_genet_id()
            genet = Genet(genet_id, spore.parent_genet_id, spore.lineage_id, self.tick, spore.genome, spore.position)
            ramet_id = self._new_ramet_id()
            node = HyphalNode(spore.position, self.tick, energy=0.48, water=0.34)
            ramet = Ramet(ramet_id, genet_id, self.tick, spore.position, nodes={spore.position: node})
            self.genets[genet_id] = genet
            self.ramets[ramet_id] = ramet
            self.occupancy[spore.position] = ramet_id
            release = next(r for r in reversed(self.spore_records) if r["event"] == "released" and r["spore_id"] == spore.spore_id)
            self.genet_records.append({"event": "established", **genet.to_dict(), "mutated_loci": release["mutated_loci"]})
            self.ramet_records.append({"event": "created", "tick": self.tick, **self._ramet_identity(ramet)})
            parent_alive = spore.parent_genet_id in self.living_genet_ids()
            self.spore_records.append({"event": "germinated", "tick": self.tick, **spore.to_dict(), "child_genet_id": genet_id, "child_ramet_id": ramet_id, "parent_genet_alive": parent_alive})
            germinated.append(genet_id)
        self.spores = remaining
        return germinated, failed

    def _record_new_genet_extinctions(self) -> list[str]:
        living = self.living_genet_ids()
        newly_extinct = []
        for genet_id in sorted(self.genets):
            if genet_id not in living and genet_id not in self.extinct_genets:
                self.extinct_genets.add(genet_id)
                self.genet_records.append({"event": "extinct", "tick": self.tick, "genet_id": genet_id})
                newly_extinct.append(genet_id)
        return newly_extinct

    def step(self) -> dict[str, Any]:
        if not self.living_ramets() and not self.spores:
            raise RuntimeError("no living ramets or viable spores remain")
        self.tick += 1
        self._replenish_and_decay()
        germinated, failed_spores = self._germinate_spores()
        genome_snapshot = {gid: genet.genome for gid, genet in self.genets.items()}
        substrate_taken = water_taken = light_energy = 0.0
        energy_moved = water_moved = 0.0
        energy_error = water_error = 0.0
        for ramet in self.living_ramets():
            s, w, l = self._absorb_local(ramet)
            substrate_taken += s
            water_taken += w
            light_energy += l
        for ramet in self.living_ramets():
            em, wm, ee, we = self._transport(ramet)
            energy_moved += em
            water_moved += wm
            energy_error += ee
            water_error += we
            self._maintain(ramet)
        necrotic_modules: list[list[int]] = []
        fragments: list[str] = []
        ramet_deaths: list[str] = []
        for ramet in list(self.living_ramets()):
            dead, created, died = self._prune_necrotic(ramet)
            necrotic_modules.extend([list(coord) for coord in dead])
            fragments.extend(created)
            if died:
                ramet_deaths.append(ramet.ramet_id)
        grown = new_loops = 0
        spores_released = []
        for ramet in list(self.living_ramets()):
            count, loops = self._grow(ramet)
            grown += count
            new_loops += loops
            spore = self._reproduce(ramet)
            if spore is not None:
                spores_released.append(spore.spore_id)
        fusions, nonself_contacts = self._same_genet_fusions()
        genet_extinctions = self._record_new_genet_extinctions()
        for genet_id, genome in genome_snapshot.items():
            if self.genets[genet_id].genome != genome:
                raise AssertionError("a genet genome changed during its lifetime")
        metrics = network_metrics(self.living_ramets(), self.genets, self.detritus)
        record = {
            "tick": self.tick,
            "germinated_genets": germinated,
            "failed_spores": failed_spores,
            "spores_released": spores_released,
            "necrotic_modules": necrotic_modules,
            "fragments_created": fragments,
            "ramet_deaths": ramet_deaths,
            "genet_extinctions": genet_extinctions,
            "same_genet_fusions": fusions,
            "blocked_nonself_contacts": nonself_contacts,
            "grown_modules": grown,
            "new_internal_anastomoses": new_loops,
            "pending_spores": len(self.spores),
            "substrate_taken": round(substrate_taken, 12),
            "water_taken": round(water_taken, 12),
            "light_energy": round(light_energy, 12),
            "energy_translocated": round(energy_moved, 12),
            "water_translocated": round(water_moved, 12),
            "energy_transport_balance_error": energy_error,
            "water_transport_balance_error": water_error,
            **metrics,
        }
        self.tick_records.append(record)
        return record

    def run(self, output_directory: str | Path | None = None) -> dict[str, Any]:
        while self.tick < self.config.ticks and (self.living_ramets() or self.spores):
            self.step()
        metrics = network_metrics(self.living_ramets(), self.genets, self.detritus)
        summary = {
            "schema": "rootnet-v6.2.1-module-metabolism-summary-v1",
            "completed_ticks": self.tick,
            "requested_ticks": self.config.ticks,
            "ecosystem_extinct": not bool(self.living_ramets() or self.spores),
            "config": self.config.to_dict(),
            "stream_seeds": self.stream_seeds,
            "final_metrics": metrics,
            "genets_ever_established": len(self.genets),
            "ramets_ever_created": sum(r["event"] == "created" for r in self.ramet_records),
            "total_necrotic_modules": len(self.necrosis_records),
            "total_actual_ramet_deaths": sum(r["event"] == "died" for r in self.ramet_records),
            "total_genet_extinctions": len(self.extinct_genets),
            "spore_establishment_failures": sum(r["event"] == "establishment_failed" for r in self.spore_records),
            "max_abs_energy_transport_error": self.max_abs_energy_transport_error,
            "max_abs_water_transport_error": self.max_abs_water_transport_error,
            "claim_boundary": "Artificial local-module mechanism output; not a reconstruction of fungal history or proof of optimal transport.",
        }
        if output_directory is not None:
            self.write_outputs(Path(output_directory), summary)
        return summary

    def write_outputs(self, output: Path, summary: dict[str, Any]) -> None:
        output.mkdir(parents=True, exist_ok=True)
        for filename, payload in (("config.json", self.config.to_dict()), ("summary.json", summary)):
            (output / filename).write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        for filename, records in (
            ("ticks.jsonl", self.tick_records),
            ("genets.jsonl", self.genet_records),
            ("ramets.jsonl", self.ramet_records),
            ("necrosis.jsonl", self.necrosis_records),
            ("spores.jsonl", self.spore_records),
        ):
            with (output / filename).open("w", encoding="utf-8", newline="\n") as handle:
                for record in records:
                    handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    def state_digest(self) -> str:
        payload = {
            "tick": self.tick,
            "genets": [self.genets[k].to_dict() for k in sorted(self.genets)],
            "ramets": [self.ramets[k].to_dict() for k in sorted(self.ramets)],
            "spores": [spore.to_dict() for spore in self.spores],
            "substrate": self.substrate,
            "water": self.water,
            "detritus": self.detritus,
            "ticks": self.tick_records,
            "genet_records": self.genet_records,
            "ramet_records": self.ramet_records,
            "necrosis": self.necrosis_records,
            "spore_records": self.spore_records,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
