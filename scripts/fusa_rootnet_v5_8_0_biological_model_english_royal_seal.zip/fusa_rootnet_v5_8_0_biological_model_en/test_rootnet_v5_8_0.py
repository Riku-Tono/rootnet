from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from biological import BiologicalTraits, RESOURCE_NAMES, ResourceState
from ecosystem import FusaEcosystem
from persistence import SCHEMA_VERSION, ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV580BiologicalTests(unittest.TestCase):
    def test_demo_contains_fungi_algae_and_symbiotic_organisms(self) -> None:
        eco = FusaEcosystem.demo(rng_seed=580)
        groups = {plant.biological_traits.functional_group for plant in eco.living_plants()}
        self.assertEqual({"fungus", "alga", "symbiotic"}, groups)
        self.assertEqual(0.0, eco.plants["elder-001"].biological_traits.photosynthetic_efficiency)
        self.assertGreater(eco.plants["aqua-001"].biological_traits.photosynthetic_efficiency, 0.0)

    def test_personality_actions_no_longer_drive_daily_cycle(self) -> None:
        eco = FusaEcosystem.demo(rng_seed=581)
        for _ in range(20):
            eco.step()
        self.assertEqual({}, eco.life_action_counts)
        self.assertTrue(all(plant.last_life_action is None for plant in eco.plants.values()))

    def test_fungus_uses_substrate_not_sunlight_and_alga_uses_sunlight(self) -> None:
        dark = FusaEcosystem.demo(rng_seed=582)
        bright = FusaEcosystem.demo(rng_seed=582)
        dark.day = bright.day = 1
        solar_dark = replace(dark.generate_solar_state(), quantum_harvest=1.0)
        solar_bright = replace(bright.generate_solar_state(), quantum_harvest=1.0)
        weather = dark.generate_shared_weather(solar_dark)
        dark_weather = replace(weather, sunlight=0.0)
        bright_weather = replace(weather, sunlight=1.0)
        dark_flux = dark._biological_cycle(
            dark.living_plants(), dark_weather, solar_dark, dark.marine_state
        )["fluxes"]
        bright_flux = bright._biological_cycle(
            bright.living_plants(), bright_weather, solar_bright, bright.marine_state
        )["fluxes"]
        dark_by_id = {item["plant_id"]: item for item in dark_flux}
        bright_by_id = {item["plant_id"]: item for item in bright_flux}
        self.assertAlmostEqual(
            dark_by_id["elder-001"]["carbon_input"],
            bright_by_id["elder-001"]["carbon_input"],
        )
        self.assertGreater(
            bright_by_id["aqua-001"]["carbon_input"],
            dark_by_id["aqua-001"]["carbon_input"],
        )

    def test_rootnet_transfer_is_conservative(self) -> None:
        eco = FusaEcosystem.demo(rng_seed=583)
        left = eco.plants["elder-001"]
        right = eco.plants["aqua-001"]
        for plant in eco.living_plants():
            plant.biological_traits.photosynthetic_efficiency = 0.0
            plant.biological_traits.substrate_uptake = 0.0
            plant.biological_traits.nitrogen_uptake = 0.0
            plant.biological_traits.water_uptake = 0.0
            plant.resources = ResourceState(carbon=0.5, water=0.5, nitrogen=0.5)
        left.resources.carbon = 1.30
        right.resources.carbon = 0.10
        eco.day = 1
        solar = eco.generate_solar_state()
        weather = replace(eco.generate_shared_weather(solar), rainfall=0.0, sunlight=0.0)
        result = eco._biological_cycle(eco.living_plants(), weather, solar, eco.marine_state)
        self.assertGreater(result["transported"]["carbon"], 0.0)
        carbon_import = sum(item["carbon_import"] for item in result["fluxes"])
        carbon_export = sum(item["carbon_export"] for item in result["fluxes"])
        self.assertAlmostEqual(carbon_import, carbon_export, places=14)
        for error in result["mass_balance_error"].values():
            self.assertAlmostEqual(0.0, error, places=12)

    def test_prolonged_resource_deprivation_causes_death(self) -> None:
        eco = FusaEcosystem(rng_seed=584)
        organism = FusaPlant(plant_id="test-fungus", lineage="elder", rng_seed=584)
        organism.biological_traits = BiologicalTraits(
            functional_group="fungus",
            photosynthetic_efficiency=0.0,
            substrate_uptake=0.0,
            nitrogen_uptake=0.0,
            water_uptake=0.0,
            maintenance_rate=0.080,
            resource_sharing=0.0,
            fusion_compatibility=0.0,
            desiccation_tolerance=0.0,
        )
        organism.resources = ResourceState(carbon=0.0, water=0.0, nitrogen=0.0)
        eco.add_plant(organism)
        eco.infrastructure.soil_nutrients = 0.0
        eco.infrastructure.water_reserve = 0.0
        solar = eco.generate_solar_state()
        weather = replace(eco.generate_shared_weather(solar), rainfall=0.0, sunlight=0.0)
        for day in range(1, 50):
            eco.day = day
            eco._biological_cycle([organism], weather, solar, eco.marine_state)
            if not organism.alive:
                break
        self.assertFalse(organism.alive)
        self.assertIn("deficit", organism.death_reason or "")

    def test_mass_balance_and_normal_survival_in_120_day_smoke(self) -> None:
        eco = FusaEcosystem.demo(rng_seed=585)
        for _ in range(120):
            eco.step()
        maximum_error = max(
            abs(error)
            for record in eco.biological_history
            for error in record["mass_balance_error"].values()
        )
        self.assertLess(maximum_error, 1e-10)
        self.assertGreater(len(eco.living_plants()), 0)
        self.assertFalse(any(
            plant.death_reason and "deficit" in plant.death_reason
            for plant in eco.plants.values()
        ))

    def test_schema11_migrates_to_biological_defaults(self) -> None:
        source = FusaEcosystem.demo(rng_seed=586)
        legacy = ecosystem_to_dict(source)
        legacy["schema_version"] = 11
        legacy.pop("biological_history", None)
        for plant in legacy["plants"]:
            plant.pop("biological_traits", None)
            plant.pop("resources", None)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "schema11.json"
            path.write_text(json.dumps(legacy, ensure_ascii=False), encoding="utf-8")
            loaded = load_ecosystem(path, rng_seed=999)
        self.assertEqual(12, SCHEMA_VERSION)
        self.assertEqual({"fungus", "alga", "symbiotic"}, {
            plant.biological_traits.functional_group for plant in loaded.living_plants()
        })

    def test_biological_state_survives_save_resume_exactly(self) -> None:
        continuous = FusaEcosystem.demo(rng_seed=587)
        split = FusaEcosystem.demo(rng_seed=587)
        for _ in range(60):
            continuous.step()
        for _ in range(23):
            split.step()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "biological.json"
            save_ecosystem_atomic(split, path)
            resumed = load_ecosystem(path)
        for _ in range(37):
            resumed.step()
        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))


if __name__ == "__main__":
    unittest.main()

