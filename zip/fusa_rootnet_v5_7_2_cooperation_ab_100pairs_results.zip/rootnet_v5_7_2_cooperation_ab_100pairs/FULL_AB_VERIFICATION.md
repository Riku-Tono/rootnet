# RootNet v5.7.2 協調性A/B 100組 検証記録

## 実行

- protocol: `rootnet-v5.7.2-cooperation-paired-v1`
- seed: 0〜99
- A: `memory-001.temperament.cooperation = 0.10`
- B: `memory-001.temperament.cooperation = 0.90`
- 100組、200世界、各320日、64,000世界日
- 実時間: 634.438908秒

## 品質判定

- 単一実状態差分: 100/100 PASS
- 外部天候一致: 100/100 PASS
- 最終world乱数状態一致: 100/100 PASS
- 320日完走: 200/200 PASS
- 実行エラー: 0
- 援助成功・要求集計照合: 200/200 PASS
- seed 0・29・81の独立再実行: 全指標・差分・天候hash一致
- A/B両群の死亡: 0

## 解析

- 対応付き差 `B - A`
- 主評価: 援助成功／1,000株日
- ブートストラップ: seed `20260801`、10,000回、ペア単位再抽出
- 効果量: 対応付き`dz`、順位双列相関
- 補助検定: 両側符号検定

## SHA-256

- `full_ab_100pairs_320days.json`: `F314CCE11D5B21559CCC7E2CED96F5BE2FB9ED3F6F707970DF45C446D54C70EE`
- `full_ab_100pairs_analysis.json`: `7F3C6E81A43FF41495F964AA8F78BA6ABDFD72D1767A5DCA2A7C80E4011B874E`
- `FULL_AB_REPORT.md`: `D4FB76FE4628A8EEFF459FE519BBCEE07032700E84A8422CC32DC6BE679FA165`

## 停止位置

感度解析100 seed×11水準＝1,100世界は未実行。A/B結果確定後の別バッチとして保留。
