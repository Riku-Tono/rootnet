from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

from models import clamp


@dataclass
class RootSignal:
    day: int
    signal_type: str
    message: str
    strength: float
    origin_id: str
    ttl: int = 4

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RootSignal":
        return cls(**data)


@dataclass
class SignalReceipt:
    plant_id: str
    signal_type: str
    strength: float
    distance: int


class RootNet:
    """環境信号と炭素・水・窒素を運ぶ分散接続網。"""

    def __init__(self) -> None:
        self.links: dict[str, dict[str, float]] = {}
        self.signal_history: list[RootSignal] = []

    def add_node(self, plant_id: str) -> None:
        self.links.setdefault(plant_id, {})

    def connect(self, left: str, right: str, conductivity: float = 0.85) -> None:
        if left == right:
            return
        self.add_node(left)
        self.add_node(right)
        value = clamp(conductivity, 0.05, 1.0)
        self.links[left][right] = value
        self.links[right][left] = value

    def remove_node(self, plant_id: str) -> None:
        """死亡株を通信網から外す。履歴と個体記録そのものは残す。"""
        for neighbor in list(self.links.get(plant_id, {})):
            self.links.get(neighbor, {}).pop(plant_id, None)
        self.links.pop(plant_id, None)

    def disconnect(self, left: str, right: str) -> float | None:
        """一本だけ切断し、再接続用に以前の伝導率を返す。"""
        value = self.links.get(left, {}).pop(right, None)
        self.links.get(right, {}).pop(left, None)
        return value

    def broadcast(self, signal: RootSignal) -> list[SignalReceipt]:
        self.signal_history.append(signal)
        receipts: list[SignalReceipt] = []
        queue = deque([(signal.origin_id, signal.strength, 0)])
        strongest = {signal.origin_id: signal.strength}

        while queue:
            node, strength, distance = queue.popleft()
            receipts.append(SignalReceipt(node, signal.signal_type, strength, distance))
            if distance >= signal.ttl:
                continue
            for neighbor, conductivity in self.links.get(node, {}).items():
                propagated = strength * conductivity * 0.82
                if propagated < 0.05 or propagated <= strongest.get(neighbor, 0.0):
                    continue
                strongest[neighbor] = propagated
                queue.append((neighbor, propagated, distance + 1))
        return receipts

    def metrics(self, active_nodes: set[str] | None = None) -> dict[str, float]:
        """外部ライブラリなしで、網が実際に機能する度合いを測る。"""
        nodes = set(active_nodes) if active_nodes is not None else set(self.links)
        if not nodes:
            return {
                "largest_component_ratio": 0.0,
                "isolate_rate": 0.0,
                "average_path_length": 0.0,
                "clustering_coefficient": 0.0,
                "reachability": 0.0,
                "functional_score": 0.0,
                "component_count": 0.0,
            }

        adjacency = {
            node: {neighbor for neighbor in self.links.get(node, {}) if neighbor in nodes}
            for node in nodes
        }
        isolates = sum(not neighbors for neighbors in adjacency.values())

        components: list[set[str]] = []
        unseen = set(nodes)
        while unseen:
            start = min(unseen)
            component = {start}
            queue = deque([start])
            unseen.remove(start)
            while queue:
                node = queue.popleft()
                for neighbor in adjacency[node]:
                    if neighbor in unseen:
                        unseen.remove(neighbor)
                        component.add(neighbor)
                        queue.append(neighbor)
            components.append(component)

        pair_distances: list[int] = []
        for start in sorted(nodes):
            distance = {start: 0}
            queue = deque([start])
            while queue:
                node = queue.popleft()
                for neighbor in adjacency[node]:
                    if neighbor not in distance:
                        distance[neighbor] = distance[node] + 1
                        queue.append(neighbor)
            pair_distances.extend(
                distance[target]
                for target in sorted(nodes)
                if target > start and target in distance
            )

        clustering_values: list[float] = []
        for node, neighbors in adjacency.items():
            degree = len(neighbors)
            if degree < 2:
                clustering_values.append(0.0)
                continue
            linked_pairs = sum(
                right in adjacency[left]
                for left in neighbors
                for right in neighbors
                if left < right
            )
            clustering_values.append(linked_pairs / (degree * (degree - 1) / 2))

        possible_pairs = len(nodes) * (len(nodes) - 1) / 2
        reachable_pairs = len(pair_distances)
        average_path = (
            sum(pair_distances) / reachable_pairs if reachable_pairs else 0.0
        )
        reachability = reachable_pairs / possible_pairs if possible_pairs else 1.0
        largest_component = max((len(component) for component in components), default=0)
        largest_ratio = largest_component / len(nodes)
        isolate_rate = isolates / len(nodes)
        clustering = sum(clustering_values) / len(clustering_values)
        path_efficiency = 1.0 / average_path if average_path > 0.0 else 0.0
        functional_score = (
            largest_ratio * 0.30
            + (1.0 - isolate_rate) * 0.15
            + clustering * 0.15
            + reachability * 0.25
            + path_efficiency * 0.15
        )
        return {
            "largest_component_ratio": largest_ratio,
            "isolate_rate": isolate_rate,
            "average_path_length": average_path,
            "clustering_coefficient": clustering,
            "reachability": reachability,
            "functional_score": functional_score,
            "component_count": float(len(components)),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "links": self.links,
            "signal_history": [item.to_dict() for item in self.signal_history],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RootNet":
        network = cls()
        network.links = {
            str(node): {str(other): float(value) for other, value in edges.items()}
            for node, edges in data.get("links", {}).items()
        }
        network.signal_history = [
            RootSignal.from_dict(item) for item in data.get("signal_history", [])
        ]
        return network
