from __future__ import annotations

import math
import random
import statistics
from dataclasses import dataclass, replace
from typing import Any

from models import (
    CoralColony,
    CambrianAbilities,
    CambrianState,
    FusaTraits,
    InfrastructureState,
    MarineState,
    SolarState,
    StoredSeed,
    Weather,
    clamp,
)
from network import RootNet, RootSignal
from simulation import DailyReport, FusaPlant


LINEAGE_NAMES = {
    "aqua": "💧 Aqua Fusa",
    "amber": "🔥 Amber Fusa",
    "memory": "🌿 Memory Fusa",
    "elder": "⚡ 長老フサ",
    "coastal": "🏝️ 沿岸フサ",
    "sea": "🌊 海フサ",
}


@dataclass
class EcosystemReport:
    day: int
    weather: Weather
    solar: SolarState
    marine: MarineState
    signals: list[RootSignal]
    marine_signals: list[RootSignal]
    plant_reports: list[DailyReport]
    water_cleaned: float
    fuel_collected: float
    pests_removed: float
    coral_energy: float
    stored_seed_ids: list[str]
    wave_moved_seed_ids: list[str]
    new_plant_ids: list[str]
    deaths: list[tuple[str, str]]
    soil_returned: float
    carrying_capacity: int
    population_pressure: float
    elder_successor_id: str | None
    cambrian_started: bool
    cambrian_audit: dict[str, Any]
    false_signals: list[RootSignal]
    movements: list[dict[str, Any]]
    interactions: list[str]
    network_metrics: dict[str, float]


class FusaEcosystem:
    MAX_LIVING_PLANTS = 200
    MIN_GERMINATION_AGE = 3

    def __init__(self, name: str = "王立フサ生態基盤", rng_seed: int | None = None) -> None:
        self.name = name
        self.day = 0
        self.plants: dict[str, FusaPlant] = {}
        self.rootnet = RootNet()
        self.undersea_rootnet = RootNet()
        self.infrastructure = InfrastructureState()
        self.solar_state = SolarState()
        self.marine_state = MarineState()
        self.corals: dict[str, CoralColony] = {}
        self.seed_inventory: list[StoredSeed] = []
        self.event_history: list[dict[str, Any]] = []
        self.next_plant_serial = 1
        self.next_seed_serial = 1
        self.capacity_history: list[int] = []
        self.water_quality_history: list[float] = []
        self.movement_history: list[dict[str, Any]] = []
        self.cambrian = CambrianState()
        self._rng = random.Random(rng_seed)

    @classmethod
    def demo(cls, rng_seed: int | None = None) -> "FusaEcosystem":
        eco = cls(rng_seed=rng_seed)
        specs = [
            ("elder-001", "北境の長老フサ", "elder", "北の森", True, "L"),
            ("aqua-001", "水路守アクア", "aqua", "水門区", False, "L"),
            ("aqua-002", "澄根ミズハ", "aqua", "下流水路", False, "L"),
            ("amber-001", "琥珀葉アンバー", "amber", "陽だまり丘", False, "L"),
            ("memory-001", "フサリ姫", "memory", "中央庭園", False, "L"),
            ("memory-002", "風聞きトフトフ", "memory", "西の野", False, "L"),
            ("coast-001", "潮聞きナギフサ", "coastal", "珊瑚海岸", False, "L"),
            ("sea-001", "青海フサ・ミオ", "sea", "浅海庭園", False, "L"),
            ("mirror-001", "鏡界の裏フサ", "memory", "鏡潮洞", False, "D"),
        ]
        for index, (pid, name, lineage, district, elder, chirality) in enumerate(specs):
            plant = FusaPlant(
                name=name,
                plant_id=pid,
                lineage=lineage,
                district=district,
                elder=elder,
                ancestor_id=pid,
                chirality=chirality,
                rng_seed=None if rng_seed is None else rng_seed + index,
            )
            if elder:
                plant.age = 300 * 365
                plant.fusa_level = 100.0
            eco.add_plant(plant)

        for left, right, conductivity in [
            ("elder-001", "aqua-001", 0.95),
            ("elder-001", "memory-001", 0.92),
            ("aqua-001", "aqua-002", 0.88),
            ("aqua-001", "amber-001", 0.72),
            ("memory-001", "memory-002", 0.84),
            ("memory-002", "amber-001", 0.76),
            ("aqua-002", "coast-001", 0.66),
        ]:
            eco.connect_plants(eco.rootnet, left, right, conductivity)

        eco.connect_plants(eco.undersea_rootnet, "coast-001", "sea-001", 0.91)
        eco.connect_plants(eco.rootnet, "elder-001", "mirror-001", 0.70)
        eco.corals["coral-001"] = CoralColony(
            colony_id="coral-001",
            name="王立アサヒ珊瑚群",
            district="珊瑚海岸",
        )
        return eco

    def add_plant(self, plant: FusaPlant) -> None:
        self.plants[plant.plant_id] = plant
        if not plant.alive:
            return
        self.rootnet.add_node(plant.plant_id)
        if plant.lineage in {"sea", "coastal"}:
            self.undersea_rootnet.add_node(plant.plant_id)

    def living_plants(self) -> list[FusaPlant]:
        return [plant for plant in self.plants.values() if plant.alive]

    def connect_plants(
        self,
        network: RootNet,
        left: str,
        right: str,
        conductivity: float,
    ) -> None:
        left_plant = self.plants.get(left)
        right_plant = self.plants.get(right)
        adjusted = conductivity
        if (
            left_plant is not None
            and right_plant is not None
            and left_plant.chirality != right_plant.chirality
        ):
            left_bridge = left_plant.traits.signal_bridge
            right_bridge = right_plant.traits.signal_bridge
            left_bridge = max(
                left_bridge,
                left_plant.expressed_abilities.mirror_bridge,
            )
            right_bridge = max(
                right_bridge,
                right_plant.expressed_abilities.mirror_bridge,
            )
            bridge = (left_bridge + right_bridge) / 2.0
            adjusted *= 0.16 + bridge * 0.42
        network.connect(left, right, adjusted)

    def season_index(self) -> int:
        return ((self.day - 1) // FusaPlant.DAYS_PER_SEASON) % 4

    def generate_solar_state(self) -> SolarState:
        day_lengths = [12.4, 14.5, 11.4, 9.4]
        roll = self._rng.random()
        if roll < 0.012:
            condition, modifier = "🌑 日食", 0.10
        elif roll < 0.18:
            condition, modifier = "🌇 夕照", 0.62
        elif roll < 0.48:
            condition, modifier = "🌤️ 薄曇り", 0.72
        else:
            condition, modifier = "☀️ 晴天", 1.00
        irradiance = clamp(self._rng.gauss(0.86, 0.10) * modifier, 0.05, 1.10)
        # 量子生物風の光捕集指標。量子状態そのものを解く科学計算ではない。
        quantum_harvest = clamp(0.68 + irradiance * 0.27, 0.60, 0.98)
        return SolarState(
            condition=condition,
            day_length=day_lengths[self.season_index()],
            irradiance=irradiance,
            sunset_glow=clamp(self._rng.gauss(0.55 if condition == "🌇 夕照" else 0.28, 0.10), 0.0, 1.0),
            quantum_harvest=quantum_harvest,
        )

    def generate_shared_weather(self, solar: SolarState) -> Weather:
        living = self.living_plants()
        if not living:
            raise RuntimeError("生存株がなく、共有天候を生成できません。")
        base = living[0].generate_weather(self.season_index())
        sunlight = clamp(
            base.sunlight * solar.irradiance * (solar.day_length / 12.0),
            0.0,
            1.2,
        )
        return replace(base, sunlight=sunlight)

    def generate_marine_state(self, weather: Weather) -> MarineState:
        lunar_fraction = (self.day % 29.53) / 29.53
        if lunar_fraction < 0.125 or lunar_fraction >= 0.875:
            moon_phase = "🌑 新月"
        elif lunar_fraction < 0.375:
            moon_phase = "🌓 上弦"
        elif lunar_fraction < 0.625:
            moon_phase = "🌕 満月"
        else:
            moon_phase = "🌗 下弦"

        spring_tide = (1.0 + math.cos(4.0 * math.pi * lunar_fraction)) / 2.0
        tide = clamp(0.34 + spring_tide * 0.50 + self._rng.gauss(0.0, 0.04), 0.05, 1.0)
        sea_temperature = clamp(
            self.marine_state.sea_temperature * 0.82 + weather.temperature * 0.18,
            0.05,
            1.0,
        )
        salinity = clamp(
            self.marine_state.salinity
            + self._rng.gauss(0.0, 0.012)
            - weather.rainfall * 0.006,
            0.35,
            0.95,
        )
        nutrients = clamp(
            self.marine_state.nutrients
            + self._rng.uniform(-0.018, 0.022)
            + tide * 0.010,
            0.05,
            1.0,
        )
        wave = clamp(weather.wind_speed * 0.55 + tide * 0.32 + self._rng.gauss(0.0, 0.06), 0.0, 1.0)
        return MarineState(
            moon_phase=moon_phase,
            moon_fraction=lunar_fraction,
            tide_level=tide,
            sea_temperature=sea_temperature,
            salinity=salinity,
            nutrients=nutrients,
            wave_strength=wave,
        )

    def _elder_signals(self, weather: Weather) -> list[RootSignal]:
        elders = [plant for plant in self.living_plants() if plant.elder]
        if not elders:
            return []
        origin = elders[0].plant_id
        candidates: list[RootSignal] = []
        if weather.rainfall > 0.72:
            candidates.append(RootSignal(self.day, "rain_coming", "北から雨。", weather.rainfall, origin, 5))
        if weather.rainfall < 0.22:
            candidates.append(RootSignal(self.day, "water_shortage", "水、浅し。", 1.0 - weather.rainfall, origin, 5))
        if self.infrastructure.pest_pressure > 0.58:
            candidates.append(RootSignal(self.day, "pest_alert", "葉裏、動く。", self.infrastructure.pest_pressure, origin, 4))
        if (self.day - 1) % FusaPlant.DAYS_PER_SEASON == 0:
            candidates.append(RootSignal(self.day, "season_shift", "季、移る。", 0.55, origin, 5))
        return candidates[:2]

    def _marine_signals(self, marine: MarineState) -> list[RootSignal]:
        origin = next(
            (plant.plant_id for plant in self.living_plants() if plant.lineage == "sea"),
            None,
        )
        if origin is None:
            return []
        signals: list[RootSignal] = []
        if marine.tide_level > 0.72:
            signals.append(RootSignal(self.day, "high_tide", "満ち潮、近し。", marine.tide_level, origin, 5))
        if marine.nutrients > 0.68:
            signals.append(RootSignal(self.day, "sea_nutrients", "青き栄養、来る。", marine.nutrients, origin, 4))
        return signals[:1]

    def _broadcast(self, network: RootNet, signals: list[RootSignal]) -> None:
        for signal in signals:
            for receipt in network.broadcast(signal):
                plant = self.plants.get(receipt.plant_id)
                if plant is not None and plant.alive and receipt.distance > 0:
                    signal_type = receipt.signal_type
                    strength = receipt.strength
                    origin = self.plants.get(signal.origin_id)
                    if origin is not None and origin.chirality != plant.chirality:
                        bridge = plant.traits.signal_bridge
                        if self.cambrian.active:
                            bridge = max(bridge, plant.abilities.mirror_bridge)
                        strength *= 0.45 + bridge * 0.55
                        if bridge < 0.62 and self._rng.random() < 0.28:
                            signal_type = {
                                "rain_coming": "water_shortage",
                                "water_shortage": "rain_coming",
                                "high_tide": "water_shortage",
                            }.get(signal_type, signal_type)
                    plant.receive_signal(signal_type, strength)

    def _coral_cycle(self, solar: SolarState, marine: MarineState) -> float:
        total_energy = 0.0
        for coral in self.corals.values():
            if not coral.alive:
                continue
            light_energy = (
                solar.irradiance
                * solar.quantum_harvest
                * coral.symbiotic_algae
                * 0.055
            )
            coral.stored_energy = clamp(coral.stored_energy + light_energy - 0.018, 0.0, 1.0)
            coral.touch_response = marine.wave_strength
            temperature_stress = max(0.0, marine.sea_temperature - 0.82) + max(
                0.0, 0.20 - marine.sea_temperature
            )
            if temperature_stress > 0:
                coral.health -= temperature_stress * 0.08
                coral.symbiotic_algae -= temperature_stress * 0.05
            else:
                coral.health += 0.004 * marine.nutrients
                coral.symbiotic_algae += 0.002
            coral.health = clamp(coral.health, 0.0, 1.0)
            coral.symbiotic_algae = clamp(coral.symbiotic_algae, 0.0, 1.0)
            coral.alive = coral.health > 0.02
            total_energy += light_energy
        self.marine_state.nutrients = clamp(
            self.marine_state.nutrients + total_energy * 0.04,
            0.0,
            1.0,
        )
        return total_energy

    def _infrastructure_cycle(
        self,
        weather: Weather,
        solar: SolarState,
    ) -> tuple[float, float, float]:
        living = self.living_plants()
        aqua = [plant for plant in living if plant.lineage == "aqua"]
        amber = [plant for plant in living if plant.lineage == "amber"]
        healthy = lambda plant: plant.condition.health * plant.condition.energy

        water_cleaned = sum(0.012 * healthy(plant) * plant.mean_gene.dew_affinity for plant in aqua)
        water_cost = sum(0.010 * (1.25 - plant.condition.hydration) for plant in aqua)
        self.infrastructure.water_quality += water_cleaned
        self.infrastructure.water_reserve += weather.rainfall * 0.06 - water_cost

        autumn = self.season_index() == 2
        fuel_collected = 0.0
        if autumn:
            solar_factor = solar.irradiance * (solar.day_length / 12.0)
            fuel_collected = sum(
                0.10 * healthy(plant) * plant.mean_gene.sunlight_love * solar_factor
                for plant in amber
            )
            self.infrastructure.amber_fuel += fuel_collected

        ladybeetle_activity = 0.020 * len(living) * self.infrastructure.pollination
        spider_warning_bonus = 0.008 * len(self.rootnet.signal_history[-3:])
        pests_removed = ladybeetle_activity + spider_warning_bonus
        self.infrastructure.pest_pressure += self._rng.uniform(-0.015, 0.045) - pests_removed
        self.infrastructure.pollination += 0.006 * len(amber) - 0.004 * self.infrastructure.pest_pressure
        self.infrastructure.normalize()
        return water_cleaned, fuel_collected, pests_removed

    def _store_new_seeds(
        self,
        parents: list[FusaPlant],
        reports: list[DailyReport],
    ) -> list[str]:
        stored_ids: list[str] = []
        for parent, report in zip(parents, reports):
            if report.seed is None:
                continue
            seed_id = f"seed-{self.next_seed_serial:07d}"
            self.next_seed_serial += 1
            packet = StoredSeed(
                seed_id=seed_id,
                seed=report.seed,
                parent_id=parent.plant_id,
                lineage=parent.lineage,
                district=parent.district,
                stored_day=self.day,
                chirality=parent.chirality,
                traits=self._inherit_traits(parent),
                abilities=self._inherit_abilities(parent),
                propagule_kind=(
                    "spore"
                    if parent.lineage in {"sea", "coastal"}
                    or parent.expressed_abilities.bioluminescence >= 0.42
                    else "seed"
                ),
            )
            self.seed_inventory.append(packet)
            stored_ids.append(seed_id)
        self.infrastructure.seed_bank = len(self.seed_inventory)
        return stored_ids

    def _inherit_traits(self, parent: FusaPlant) -> FusaTraits:
        values = {}
        for name, value in parent.traits.to_dict().items():
            mutation = self._rng.gauss(0.0, 0.035)
            if self._rng.random() < 0.018:
                mutation += self._rng.gauss(0.0, 0.12)
            values[name] = value + mutation
        inherited = FusaTraits.from_dict(values)
        inherited.normalize()
        return inherited

    def _inherit_abilities(self, parent: FusaPlant) -> CambrianAbilities:
        values = {}
        for name, value in parent.abilities.to_dict().items():
            sigma = 0.045 if self.cambrian.active else 0.015
            mutation = self._rng.gauss(0.0, sigma)
            if self.cambrian.active and self._rng.random() < 0.025:
                mutation += self._rng.gauss(0.0, 0.14)
            values[name] = value + mutation
        return CambrianAbilities.from_dict(values)

    def _wave_transport_seeds(self, marine: MarineState) -> list[str]:
        moved: list[str] = []
        if marine.wave_strength < 0.55:
            return moved
        for packet in self.seed_inventory:
            coastal_source = packet.lineage in {"sea", "coastal", "aqua"} or "海岸" in packet.district
            if coastal_source and self._rng.random() < marine.wave_strength * 0.45:
                mobility_bonus = (
                    packet.traits.mobility * 0.20
                    if packet.traits is not None
                    else 0.0
                )
                if self._rng.random() >= clamp(0.55 + mobility_bonus, 0.0, 0.95):
                    continue
                packet.location = "shore"
                packet.district = "潮間帯"
                moved.append(packet.seed_id)
                self.movement_history.append({
                    "day": self.day,
                    "type": "seed",
                    "subject_id": packet.seed_id,
                    "from": "seed_bank",
                    "to": "潮間帯",
                })
        return moved

    def carrying_capacity(self) -> int:
        coral_health = (
            sum(coral.health for coral in self.corals.values()) / len(self.corals)
            if self.corals
            else 0.0
        )
        capacity = (
            16
            + int(self.infrastructure.water_quality * 35)
            + int(self.infrastructure.water_reserve * 25)
            + int(self.infrastructure.soil_nutrients * 45)
            + int(self.marine_state.nutrients * 20)
            + int(coral_health * 14)
            + int(self.solar_state.irradiance * 10)
            - int(self.infrastructure.pest_pressure * 12)
        )
        return min(self.MAX_LIVING_PLANTS, max(16, capacity))

    def _seed_can_germinate(self, packet: StoredSeed) -> bool:
        age = self.day - packet.stored_day
        if age < self.MIN_GERMINATION_AGE:
            return False
        if len(self.living_plants()) >= self.carrying_capacity():
            return False
        if self.infrastructure.water_quality < 0.35:
            return False
        if self.infrastructure.water_reserve < 0.25:
            return False
        if self.infrastructure.pest_pressure >= 0.75:
            return False
        if packet.lineage == "sea":
            return 0.45 <= self.marine_state.salinity <= 0.90 and self.marine_state.nutrients >= 0.25
        if packet.lineage == "coastal":
            return self.marine_state.tide_level >= 0.25
        return self.infrastructure.soil_nutrients >= 0.20

    def _germinate_seed_inventory(self) -> list[str]:
        germinated_seed_ids: set[str] = set()
        new_ids: list[str] = []
        for packet in list(self.seed_inventory):
            if not self._seed_can_germinate(packet):
                continue
            chance = 0.28 + self.infrastructure.soil_nutrients * 0.32
            if packet.location == "shore":
                chance += self.marine_state.nutrients * 0.16
            if self._rng.random() >= clamp(chance, 0.15, 0.88):
                continue

            parent = self.plants.get(packet.parent_id)
            plant_id = f"sprout-{self.next_plant_serial:06d}"
            self.next_plant_serial += 1
            ancestor_id = (
                parent.ancestor_id if parent is not None else packet.parent_id
            )
            child = FusaPlant(
                name=packet.seed.name,
                plant_id=plant_id,
                lineage=packet.lineage,
                district=packet.district,
                elder=False,
                generation=packet.seed.generation,
                genes=packet.seed.genes,
                memory=packet.seed.memory.primed_copy(1.0),
                parent_id=packet.parent_id,
                ancestor_id=ancestor_id,
                birth_day=self.day,
                chirality=packet.chirality,
                traits=packet.traits,
                abilities=packet.abilities,
                rng_seed=self._rng.randrange(0, 2**63),
            )
            # 季節は個体年齢ではなく王国暦へ同期させる。
            child.day = self.day
            self.add_plant(child)
            if parent is not None:
                parent.child_ids.append(child.plant_id)
                if parent.alive:
                    self.connect_plants(self.rootnet, parent.plant_id, child.plant_id, 0.72)
            if child.lineage in {"sea", "coastal"}:
                marine_neighbor = next(
                    (
                        plant.plant_id
                        for plant in self.living_plants()
                        if plant.plant_id != child.plant_id
                        and plant.lineage in {"sea", "coastal"}
                    ),
                    None,
                )
                if marine_neighbor is not None:
                    self.connect_plants(
                        self.undersea_rootnet,
                        marine_neighbor,
                        child.plant_id,
                        0.82,
                    )
            germinated_seed_ids.add(packet.seed_id)
            new_ids.append(child.plant_id)

        self.seed_inventory = [
            packet
            for packet in self.seed_inventory
            if packet.seed_id not in germinated_seed_ids
        ]
        self.infrastructure.seed_bank = len(self.seed_inventory)
        return new_ids

    def _decomposition_cycle(self, weather: Weather) -> float:
        returned_total = 0.0
        for plant in self.plants.values():
            if plant.alive or plant.corpse_stage == "台帳のみ":
                continue
            moisture = (weather.rainfall + self.infrastructure.water_reserve) / 2.0
            speed = clamp(0.012 + weather.temperature * 0.012 + moisture * 0.010, 0.008, 0.040)
            if plant.chirality == "D":
                speed *= 0.28
            previous = plant.decomposition_progress
            plant.decomposition_progress = clamp(previous + speed, 0.0, 1.0)
            decomposed = plant.decomposition_progress - previous
            soil_gain = decomposed * (0.10 + plant.fusa_level / 1000.0)
            plant.soil_returned += soil_gain
            returned_total += soil_gain
            self.infrastructure.soil_nutrients += soil_gain
            if plant.lineage == "amber":
                self.infrastructure.amber_fuel += decomposed * 0.30
            if plant.lineage in {"sea", "coastal"}:
                self.marine_state.nutrients += decomposed * 0.05
            if plant.decomposition_progress >= 1.0:
                plant.corpse_stage = "台帳のみ"
            elif plant.decomposition_progress >= 0.55:
                plant.corpse_stage = "土へ還る途中"
            else:
                plant.corpse_stage = "枯株"
        self.infrastructure.normalize()
        self.marine_state.nutrients = clamp(self.marine_state.nutrients, 0.0, 1.0)
        return returned_total

    def lineage_tree_data(self) -> list[dict[str, Any]]:
        return [
            {
                "plant_id": plant.plant_id,
                "name": plant.name,
                "parent_id": plant.parent_id,
                "ancestor_id": plant.ancestor_id,
                "child_ids": list(plant.child_ids),
                "generation": plant.generation,
                "lineage": plant.lineage,
                "chirality": plant.chirality,
                "traits": plant.traits.to_dict(),
                "active_traits": plant.traits.active_names(),
                "abilities": plant.abilities.to_dict(),
                "expressed_abilities": plant.expressed_abilities.to_dict(),
                "active_abilities": plant.expressed_abilities.active_names(),
                "elder": plant.elder,
                "birth_day": plant.birth_day,
                "death_day": plant.death_day,
                "alive": plant.alive,
            }
            for plant in self.plants.values()
        ]

    def diversity_metrics(self) -> dict[str, float]:
        living = self.living_plants()
        if len(living) < 2:
            return {
                "category_entropy": 0.0,
                "mean_pairwise_distance": 0.0,
                "composite": 0.0,
            }

        def normalized_entropy(values: list[str], possible_categories: int) -> float:
            counts = {value: values.count(value) for value in set(values)}
            entropy = -sum(
                (count / len(values)) * math.log(count / len(values))
                for count in counts.values()
            )
            return entropy / math.log(possible_categories) if possible_categories > 1 else 0.0

        rows: list[list[float]] = []
        for plant in living:
            gene = plant.mean_gene
            rows.append([
                gene.growth_speed / 1.8,
                gene.dew_affinity / 1.8,
                gene.wind_resistance / 1.8,
                gene.sunlight_love / 2.0,
                gene.patience / 2.0,
                *plant.traits.to_dict().values(),
                *plant.abilities.to_dict().values(),
            ])
        pairwise_distances = [
            math.sqrt(sum((left[index] - right[index]) ** 2 for index in range(len(left))))
            / math.sqrt(len(left))
            for left_index, left in enumerate(rows)
            for right in rows[left_index + 1:]
        ]
        numeric_distance = clamp(statistics.fmean(pairwise_distances) * 2.4, 0.0, 1.0)
        category_entropy = (
            normalized_entropy([plant.lineage for plant in living], len(LINEAGE_NAMES))
            + normalized_entropy([plant.chirality for plant in living], 2)
        ) / 2.0
        composite = clamp(
            category_entropy * 0.50 + numeric_distance * 0.50,
            0.0,
            1.0,
        )
        return {
            "category_entropy": category_entropy,
            "mean_pairwise_distance": numeric_distance,
            "composite": composite,
        }

    def genetic_diversity(self) -> float:
        return self.diversity_metrics()["composite"]

    def rootnet_metrics(self) -> dict[str, float]:
        living_ids = {plant.plant_id for plant in self.living_plants()}
        return self.rootnet.metrics(living_ids)

    def _cambrian_audit(self) -> dict[str, Any]:
        living = self.living_plants()
        max_generation = max((plant.generation for plant in living), default=0)
        diversity_metrics = self.diversity_metrics()
        diversity = diversity_metrics["composite"]
        network_metrics = self.rootnet_metrics()
        recent_water = self.water_quality_history[-10:]
        stable_water = (
            len(recent_water) >= 10
            and min(recent_water) >= 0.55
            and max(recent_water) - min(recent_water) <= 0.18
        )
        return {
            "max_generation": max_generation,
            "generation_ready": max_generation >= 3,
            "living_plants": len(living),
            "population_ready": len(living) >= 18,
            "genetic_diversity": round(diversity, 6),
            "diversity_metrics": {
                name: round(value, 6)
                for name, value in diversity_metrics.items()
            },
            "diversity_ready": diversity >= 0.45,
            "water_quality": round(self.infrastructure.water_quality, 6),
            "stable_water_ready": stable_water,
            "rootnet_metrics": {
                name: round(value, 6)
                for name, value in network_metrics.items()
            },
            "rootnet_functional_score": round(network_metrics["functional_score"], 6),
            "rootnet_ready": (
                network_metrics["largest_component_ratio"] >= 0.75
                and network_metrics["isolate_rate"] <= 0.20
                and network_metrics["reachability"] >= 0.60
            ),
        }

    def _check_cambrian_start(self) -> bool:
        audit = self._cambrian_audit()
        self.cambrian.last_audit = audit
        if self.cambrian.active:
            return False
        ready = all([
            audit["generation_ready"],
            audit["population_ready"],
            audit["diversity_ready"],
            audit["stable_water_ready"],
            audit["rootnet_ready"],
        ])
        if not ready:
            return False
        self.cambrian.active = True
        self.cambrian.started_day = self.day
        self.cambrian.unlocked_abilities = list(CambrianAbilities().to_dict())
        return True

    def _false_signal_cycle(self) -> list[RootSignal]:
        if not self.cambrian.active:
            return []
        generated: list[RootSignal] = []
        choices = [
            ("water_shortage", "水、消えたり。"),
            ("rain_coming", "雨、逆より来る。"),
            ("pest_alert", "葉裏、影あり。"),
        ]
        for plant in self.living_plants():
            ability = plant.expressed_abilities.false_signal
            if ability < 0.10 or self._rng.random() >= ability * 0.045:
                continue
            signal_type, message = choices[self._rng.randrange(len(choices))]
            signal = RootSignal(
                self.day,
                signal_type,
                f"偽信号「{message}」",
                ability * 0.55,
                plant.plant_id,
                3,
            )
            generated.append(signal)
            self._broadcast(self.rootnet, [signal])
        return generated

    def _movement_cycle(self) -> list[dict[str, Any]]:
        land_districts = ["中央庭園", "西の野", "水門区", "陽だまり丘", "珊瑚海岸"]
        sea_districts = ["浅海庭園", "潮間帯", "珊瑚海岸"]
        movements: list[dict[str, Any]] = []
        for plant in self.living_plants():
            ability = plant.expressed_abilities.mobility
            if ability < 0.25 or self._rng.random() >= ability * 0.055:
                continue
            choices = sea_districts if plant.lineage in {"sea", "coastal"} else land_districts
            destination = choices[self._rng.randrange(len(choices))]
            if destination == plant.district:
                continue
            movement = {
                "type": "walk",
                "subject_id": plant.plant_id,
                "from": plant.district,
                "to": destination,
            }
            plant.district = destination
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})

        for packet in self.seed_inventory:
            if packet.propagule_kind != "spore":
                continue
            if self._rng.random() >= 0.025 + self.marine_state.wave_strength * 0.035:
                continue
            choices = sea_districts if packet.lineage in {"sea", "coastal"} else land_districts
            destination = choices[self._rng.randrange(len(choices))]
            if destination == packet.district:
                continue
            movement = {
                "type": "spore",
                "subject_id": packet.seed_id,
                "from": packet.district,
                "to": destination,
            }
            packet.district = destination
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})

        living = self.living_plants()
        for plant in living:
            ability = plant.expressed_abilities.deep_rooting
            if ability < 0.32 or self._rng.random() >= ability * 0.020:
                continue
            candidates = [
                other
                for other in living
                if other.plant_id != plant.plant_id
                and other.plant_id not in self.rootnet.links.get(plant.plant_id, {})
                and other.district == plant.district
            ]
            if not candidates:
                continue
            other = candidates[self._rng.randrange(len(candidates))]
            self.connect_plants(
                self.rootnet,
                plant.plant_id,
                other.plant_id,
                0.42 + ability * 0.35,
            )
            movement = {
                "type": "hypha",
                "subject_id": plant.plant_id,
                "from": plant.plant_id,
                "to": other.plant_id,
            }
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})
        return movements

    def _cambrian_interactions(self) -> list[str]:
        if not self.cambrian.active:
            return []
        living = self.living_plants()
        notes: list[str] = []
        for actor in list(living):
            neighbors = [
                self.plants[plant_id]
                for plant_id in self.rootnet.links.get(actor.plant_id, {})
                if plant_id in self.plants and self.plants[plant_id].alive
            ]
            if not neighbors:
                continue
            parasite = actor.expressed_abilities.parasitism
            if parasite >= 0.18 and self._rng.random() < parasite * 0.075:
                host = neighbors[self._rng.randrange(len(neighbors))]
                defense = host.expressed_abilities.armor
                requested = 0.035 * parasite * (1.0 - defense * 0.65)
                transfer = min(requested, host.condition.energy)
                host.condition.energy -= transfer
                actor.condition.energy = clamp(actor.condition.energy + transfer * 0.75, 0.0, 1.0)
                notes.append(f"{actor.plant_id}が{host.plant_id}へ寄生")

            predator = actor.expressed_abilities.predation
            if predator >= 0.18 and self._rng.random() < predator * 0.060:
                prey = min(neighbors, key=lambda plant: plant.expressed_abilities.armor)
                defense = prey.expressed_abilities.armor
                requested = 0.030 * predator * (1.0 - defense * 0.78)
                damage = min(requested, prey.condition.health)
                prey.condition.health -= damage
                actor.condition.energy = clamp(actor.condition.energy + damage * 0.55, 0.0, 1.0)
                if prey.condition.health <= 0.02:
                    prey.mark_dead("捕食による損耗")
                notes.append(f"{actor.plant_id}が{prey.plant_id}を捕食")

        glow = sum(
            plant.expressed_abilities.bioluminescence
            for plant in living
            if plant.expressed_abilities.bioluminescence >= 0.18
        )
        self.infrastructure.pollination += glow * 0.0015
        self.infrastructure.normalize()
        return notes

    def _elect_new_elder(self) -> str | None:
        if any(plant.elder for plant in self.living_plants()):
            return None
        candidates = self.living_plants()
        if not candidates:
            return None

        def score(plant: FusaPlant) -> tuple[float, str]:
            memory_total = sum(plant.memory.to_dict().values())
            degree = len(self.rootnet.links.get(plant.plant_id, {}))
            value = (
                min(plant.age, 1000) * 0.018
                + plant.condition.health * 24.0
                + degree * 3.5
                + memory_total * 4.0
                + plant.mean_gene.patience * 5.0
                + plant.traits.signal_bridge * 8.0
            )
            return value, plant.plant_id

        successor = max(candidates, key=score)
        successor.elder = True
        return successor.plant_id

    def step(self) -> EcosystemReport:
        self.day += 1
        parents = self.living_plants()
        if not parents:
            raise RuntimeError("生存株がありません。王国の系統は途絶えました。")

        self.solar_state = self.generate_solar_state()
        weather = self.generate_shared_weather(self.solar_state)
        self.marine_state = self.generate_marine_state(weather)
        signals = self._elder_signals(weather)
        marine_signals = self._marine_signals(self.marine_state)
        self._broadcast(self.rootnet, signals)
        self._broadcast(self.undersea_rootnet, marine_signals)

        capacity = self.carrying_capacity()
        pressure = len(parents) / max(1, capacity)
        self.capacity_history.append(capacity)
        reports = [
            plant.daily_growth(
                weather=weather,
                solar=self.solar_state,
                marine=self.marine_state,
                population_pressure=pressure,
                cambrian_active=self.cambrian.active,
            )
            for plant in parents
        ]
        water, fuel, pests = self._infrastructure_cycle(weather, self.solar_state)
        coral_energy = self._coral_cycle(self.solar_state, self.marine_state)
        stored_seed_ids = self._store_new_seeds(parents, reports)
        wave_moved_seed_ids = self._wave_transport_seeds(self.marine_state)
        new_plant_ids = self._germinate_seed_inventory()
        self.water_quality_history.append(self.infrastructure.water_quality)
        cambrian_started = self._check_cambrian_start()
        false_signals = self._false_signal_cycle()
        movements = self._movement_cycle()
        interactions = self._cambrian_interactions()

        deaths: list[tuple[str, str]] = []
        for plant in parents:
            if plant.alive:
                continue
            reason = plant.death_reason or "不明"
            deaths.append((plant.plant_id, reason))
            self.rootnet.remove_node(plant.plant_id)
            self.undersea_rootnet.remove_node(plant.plant_id)

        elder_successor_id = self._elect_new_elder()
        soil_returned = self._decomposition_cycle(weather)
        network_metrics = self.rootnet_metrics()
        self.event_history.append({
            "day": self.day,
            "solar": self.solar_state.to_dict(),
            "marine": self.marine_state.to_dict(),
            "signals": [signal.to_dict() for signal in signals],
            "marine_signals": [signal.to_dict() for signal in marine_signals],
            "water_quality": self.infrastructure.water_quality,
            "water_reserve": self.infrastructure.water_reserve,
            "soil_nutrients": self.infrastructure.soil_nutrients,
            "amber_fuel": self.infrastructure.amber_fuel,
            "pest_pressure": self.infrastructure.pest_pressure,
            "seed_bank": self.infrastructure.seed_bank,
            "stored_seed_ids": stored_seed_ids,
            "wave_moved_seed_ids": wave_moved_seed_ids,
            "new_plant_ids": new_plant_ids,
            "deaths": [
                {"plant_id": plant_id, "reason": reason}
                for plant_id, reason in deaths
            ],
            "soil_returned": soil_returned,
            "carrying_capacity": capacity,
            "population_pressure": pressure,
            "elder_successor_id": elder_successor_id,
            "cambrian_started": cambrian_started,
            "cambrian_audit": dict(self.cambrian.last_audit),
            "false_signals": [signal.to_dict() for signal in false_signals],
            "movements": movements,
            "interactions": interactions,
            "network_metrics": network_metrics,
        })
        return EcosystemReport(
            day=self.day,
            weather=weather,
            solar=self.solar_state,
            marine=self.marine_state,
            signals=signals,
            marine_signals=marine_signals,
            plant_reports=reports,
            water_cleaned=water,
            fuel_collected=fuel,
            pests_removed=pests,
            coral_energy=coral_energy,
            stored_seed_ids=stored_seed_ids,
            wave_moved_seed_ids=wave_moved_seed_ids,
            new_plant_ids=new_plant_ids,
            deaths=deaths,
            soil_returned=soil_returned,
            carrying_capacity=capacity,
            population_pressure=pressure,
            elder_successor_id=elder_successor_id,
            cambrian_started=cambrian_started,
            cambrian_audit=dict(self.cambrian.last_audit),
            false_signals=false_signals,
            movements=movements,
            interactions=interactions,
            network_metrics=network_metrics,
        )
