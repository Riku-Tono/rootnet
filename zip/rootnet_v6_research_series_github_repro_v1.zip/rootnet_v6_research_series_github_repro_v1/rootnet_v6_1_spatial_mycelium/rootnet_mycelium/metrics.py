from __future__ import annotations

import math
import statistics
from collections import Counter
from typing import Iterable

from .model import Colony, TRAIT_NAMES


def _mean(values: Iterable[float]) -> float:
    values = list(values)
    return statistics.fmean(values) if values else 0.0


def colony_branch_points(colony: Colony) -> int:
    degrees: Counter[tuple[int, int]] = Counter()
    for left, right in colony.edges:
        degrees[left] += 1
        degrees[right] += 1
    return sum(1 for degree in degrees.values() if degree >= 3)


def colony_cycle_rank(colony: Colony) -> int:
    if not colony.cells:
        return 0
    return max(0, len(colony.edges) - len(colony.cells) + 1)


def population_metrics(
    colonies: list[Colony],
    fusion_links: set[tuple[str, str]],
) -> dict[str, object]:
    living = [colony for colony in colonies if colony.alive]
    if not living:
        return {
            "living_colonies": 0,
            "total_hyphal_cells": 0,
            "total_tips": 0,
            "total_branch_points": 0,
            "total_cycle_rank": 0,
            "fusion_links": 0,
            "mean_colony_size": 0.0,
            "oldest_colony_age": 0,
            "parent_child_pairs_alive_together": 0,
            "mean_depth": 0.0,
            "extant_founder_branches": 0,
            "trait_means": {name: 0.0 for name in TRAIT_NAMES},
            "trait_variances": {name: 0.0 for name in TRAIT_NAMES},
            "phenotypic_disparity": 0.0,
        }

    living_ids = {colony.colony_id for colony in living}
    trait_means = {
        name: _mean(getattr(colony.genome, name) for colony in living)
        for name in TRAIT_NAMES
    }
    trait_variances = {
        name: _mean(
            (getattr(colony.genome, name) - trait_means[name]) ** 2
            for colony in living
        )
        for name in TRAIT_NAMES
    }
    cells = [coord for colony in living for coord in colony.cells]
    active_fusions = {
        pair for pair in fusion_links
        if pair[0] in living_ids and pair[1] in living_ids
    }
    return {
        "living_colonies": len(living),
        "total_hyphal_cells": len(cells),
        "total_tips": sum(len(colony.tips) for colony in living),
        "total_branch_points": sum(colony_branch_points(colony) for colony in living),
        "total_cycle_rank": sum(colony_cycle_rank(colony) for colony in living),
        "fusion_links": len(active_fusions),
        "mean_colony_size": round(_mean(len(colony.cells) for colony in living), 9),
        "oldest_colony_age": max(colony.age for colony in living),
        "parent_child_pairs_alive_together": sum(
            1 for colony in living if colony.parent_id in living_ids
        ),
        "mean_depth": round(_mean(y for _, y in cells), 9),
        "extant_founder_branches": len({colony.root_branch_id for colony in living}),
        "trait_means": {
            name: round(value, 9) for name, value in trait_means.items()
        },
        "trait_variances": {
            name: round(value, 9) for name, value in trait_variances.items()
        },
        "phenotypic_disparity": round(
            math.sqrt(_mean(trait_variances.values())),
            9,
        ),
    }
