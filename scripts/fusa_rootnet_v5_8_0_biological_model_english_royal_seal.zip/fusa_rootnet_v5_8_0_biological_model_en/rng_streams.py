from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any


STREAM_NAMES = ("world", "individual", "mutation", "action")
_MASK_64 = (1 << 64) - 1


def derive_seed(base_seed: int, label: str) -> int:
    """Create a stable, independent 64-bit seed from the same base seed and label."""
    payload = f"RootNet-v5.7.2|{int(base_seed) & _MASK_64}|{label}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def resolve_seed_bundle(
    master_seed: int | None,
    *,
    world_seed: int | None = None,
    individual_seed: int | None = None,
    mutation_seed: int | None = None,
    action_seed: int | None = None,
) -> dict[str, int]:
    """Prefer explicit seeds and derive the remaining seeds deterministically from the master."""
    explicit = {
        "world": world_seed,
        "individual": individual_seed,
        "mutation": mutation_seed,
        "action": action_seed,
    }
    resolved: dict[str, int] = {}
    for name in STREAM_NAMES:
        value = explicit[name]
        if value is not None:
            resolved[name] = int(value) & _MASK_64
        elif master_seed is not None:
            resolved[name] = derive_seed(master_seed, name)
        else:
            resolved[name] = secrets.randbits(64)
    return resolved


def spawn_seed(stream_seed: int, subject_id: str) -> int:
    """Derive an organism-specific seed without consuming an ecosystem stream."""
    return derive_seed(stream_seed, f"plant:{subject_id}")


def seed_from_legacy_state(state: Any, stream_name: str) -> int:
    """Reproducibly create independent migration seeds from a legacy single random-number state."""
    payload = json.dumps(state, ensure_ascii=True, separators=(",", ":"))
    digest = hashlib.sha256(
        f"RootNet-v5.7.2-migration|{stream_name}|{payload}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big")

