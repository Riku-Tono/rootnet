@echo off
chcp 65001 > nul
set PYTHONUTF8=1
cd /d "%~dp0"

where py > nul 2> nul
if not errorlevel 1 goto run_with_py

where python > nul 2> nul
if not errorlevel 1 goto run_with_python

echo Pythonが見つかりません。
echo VS CodeでPythonを使える状態にしてから、もう一度開いてください。
goto finish

:run_with_py
py -3 main.py --days 10 --seed 42
goto finish

:run_with_python
python main.py --days 10 --seed 42

:finish
echo.
echo fusa_lineage_tree.htmlをブラウザで開くと系統樹を見られます。
echo もう一度実行すると、保存した続きから10日進みます。
pause
