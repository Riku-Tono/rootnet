from __future__ import annotations

import argparse
import hashlib
import json
import statistics
import time
from pathlib import Path
from typing import Any

from rootnet_v68 import EXPERIMENT_TRANSPORT_MODES, ModuleSimulation, SimulationConfig
from seal_evaluation_critical import SEAL_FILE, verify_critical_seal


ROOT = Path(__file__).resolve().parent
SEED_NAMESPACE = "rootnet-v6.8-lift-0.035-confirmatory-v1"
SEED_COUNT = 30
SEED_FILE = ROOT / "confirmatory_seeds_v6_8.json"
CRITERIA_FILE = ROOT / "EVALUATION_ACCEPTANCE_CRITERIA.json"
TICKS = 360
SIZE = 42
FOUNDERS = 3
ANGLE = 0.0
CONDITIONS = {
    "control_v66_radial": "v66-radial",
    "candidate_v68_lift_0_035": "v68-radial-lift-0.035",
}
PRIOR_DERIVED_NAMESPACES = {
    "rootnet-v6.8-water-field-development-v1": 20,
    "rootnet-v6.8-water-lift-calibration-exploratory-v1": 8,
    "rootnet-v6.8-water-lift-calibration-refine-v1": 8,
    "rootnet-v6.8-water-lift-calibration-holdout-v1": 20,
    "rootnet-v6.8-water-lift-calibration-holdout-v2": 20,
    "rootnet-v6.8-water-lift-calibration-holdout-v3": 20,
}


def derive_seeds(namespace: str = SEED_NAMESPACE, count: int = SEED_COUNT) -> list[int]:
    seeds = [
        int.from_bytes(hashlib.sha256(f"{namespace}|{index}".encode()).digest()[:8], "big")
        & 0x7FFFFFFF
        for index in range(count)
    ]
    if len(seeds) != len(set(seeds)):
        raise AssertionError(f"seed collision in namespace {namespace}")
    return seeds


def prior_seeds() -> set[int]:
    values: set[int] = {660, 661}
    for filename in ("development_seeds_v6_7.json", "evaluation_seeds_v6_6.json"):
        values.update(
            map(int, json.loads((ROOT / filename).read_text(encoding="utf-8"))["seeds"])
        )
    for namespace, count in PRIOR_DERIVED_NAMESPACES.items():
        values.update(derive_seeds(namespace, count))
    return values


def lock_confirmatory_seeds() -> Path:
    if not verify_critical_seal():
        raise AssertionError("critical-file seal is missing or does not match")
    if SEED_FILE.exists():
        raise FileExistsError(f"refusing to overwrite locked seed file: {SEED_FILE}")
    seeds = derive_seeds()
    overlap = set(seeds) & prior_seeds()
    if overlap:
        raise AssertionError(f"confirmatory seeds overlap prior seeds: {sorted(overlap)}")
    payload = {
        "schema": "rootnet-v6.8-locked-confirmatory-seeds-v1",
        "namespace": SEED_NAMESPACE,
        "count": len(seeds),
        "seeds": seeds,
        "seed_list_sha256": hashlib.sha256(
            json.dumps(seeds, separators=(",", ":")).encode()
        ).hexdigest(),
        "critical_seal_sha256": hashlib.sha256(SEAL_FILE.read_bytes()).hexdigest(),
        "locked_before_run": True,
        "prior_seed_overlap_count": 0,
    }
    SEED_FILE.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return SEED_FILE


def locked_confirmatory_seeds() -> list[int]:
    if not verify_critical_seal():
        raise AssertionError("critical-file seal no longer matches")
    payload = json.loads(SEED_FILE.read_text(encoding="utf-8"))
    seeds = list(map(int, payload["seeds"]))
    if payload.get("namespace") != SEED_NAMESPACE or seeds != derive_seeds():
        raise AssertionError("locked confirmatory seeds do not match derivation")
    if payload.get("locked_before_run") is not True:
        raise AssertionError("confirmatory seeds were not marked locked-before-run")
    if set(seeds) & prior_seeds():
        raise AssertionError("confirmatory seeds overlap prior seed sets")
    if payload.get("critical_seal_sha256") != hashlib.sha256(SEAL_FILE.read_bytes()).hexdigest():
        raise AssertionError("seed file does not reference current critical seal")
    return seeds


def _mean(values) -> float:
    values = list(values)
    return float(statistics.fmean(values)) if values else 0.0


def _median(values) -> float:
    values = list(values)
    return float(statistics.median(values)) if values else 0.0


def run_one(seed: int, mode: str, condition: str) -> dict[str, Any]:
    simulation = ModuleSimulation(
        SimulationConfig(
            master_seed=seed,
            ticks=TICKS,
            width=SIZE,
            height=SIZE,
            founder_count=FOUNDERS,
            transport_mode=mode,
            environment_profile="persistent-patch",
            rotation_angle_degrees=ANGLE,
            water_field_profile=CONDITIONS[condition],
            necrosis_grace_ticks=0,
        )
    )
    summary = simulation.run()
    records = simulation.tick_records
    module_ticks = sum(int(record.get("maintenance_module_ticks", 0)) for record in records)
    water_limited = sum(int(record.get("water_limited_module_ticks", 0)) for record in records)
    return {
        "seed": seed,
        "transport_mode": mode,
        "condition": condition,
        "water_field_profile": CONDITIONS[condition],
        "ecosystem_extinct": summary["ecosystem_extinct"],
        "dynamics_stopped_tick": summary["dynamics_stopped_tick"],
        "mean_living_modules": _mean(float(record["total_modules"]) for record in records),
        "mean_total_hyphal_length": _mean(float(record["total_hyphal_length"]) for record in records),
        "mean_tips": _mean(float(record["total_tips"]) for record in records),
        "mean_branch_modules": _mean(float(record["branch_modules"]) for record in records),
        "total_extensions": sum(int(record.get("grown_modules", 0)) for record in records),
        "generated_modules": summary["ever_created_nodes"],
        "total_necrotic_modules": summary["total_necrotic_modules"],
        "cumulative_necrosis_fraction": summary["cumulative_necrosis_fraction"],
        "water_limited_module_tick_fraction": water_limited / module_ticks if module_ticks else 0.0,
        "fragmentation_events": sum(len(record.get("fragments_created", [])) for record in records),
        "total_actual_ramet_deaths": summary["total_actual_ramet_deaths"],
        "total_genet_extinctions": summary["total_genet_extinctions"],
        "spore_establishment_failures": summary["spore_establishment_failures"],
        "max_abs_energy_transport_error": summary["max_abs_energy_transport_error"],
        "max_abs_water_transport_error": summary["max_abs_water_transport_error"],
        "max_abs_conductance_budget_error": summary["max_abs_conductance_budget_error"],
    }


def _selected_summary(selected: list[dict[str, Any]]) -> dict[str, Any]:
    generated = sum(int(run["generated_modules"]) for run in selected)
    return {
        "runs": len(selected),
        "extinct_runs": sum(bool(run["ecosystem_extinct"]) for run in selected),
        "extinction_rate": _mean(float(run["ecosystem_extinct"]) for run in selected),
        "median_mean_living_modules": _median(run["mean_living_modules"] for run in selected),
        "median_mean_total_hyphal_length": _median(run["mean_total_hyphal_length"] for run in selected),
        "median_mean_tips": _median(run["mean_tips"] for run in selected),
        "median_mean_branch_modules": _median(run["mean_branch_modules"] for run in selected),
        "median_total_extensions": _median(run["total_extensions"] for run in selected),
        "median_water_limited_fraction": _median(
            run["water_limited_module_tick_fraction"] for run in selected
        ),
        "pooled_cumulative_necrosis_fraction": (
            sum(int(run["total_necrotic_modules"]) for run in selected) / generated
            if generated else 0.0
        ),
    }


def condition_summary(runs: list[dict[str, Any]], condition: str) -> dict[str, Any]:
    selected = [run for run in runs if run["condition"] == condition]
    return {
        "condition": condition,
        "water_field_profile": CONDITIONS[condition],
        **_selected_summary(selected),
        "by_transport": {
            mode: _selected_summary(
                [run for run in selected if run["transport_mode"] == mode]
            )
            for mode in EXPERIMENT_TRANSPORT_MODES
        },
    }


def evaluate_acceptance(
    runs: list[dict[str, Any]],
    summaries: list[dict[str, Any]],
) -> dict[str, Any]:
    criteria = json.loads(CRITERIA_FILE.read_text(encoding="utf-8"))
    lookup = {summary["condition"]: summary for summary in summaries}
    control = lookup["control_v66_radial"]
    candidate = lookup["candidate_v68_lift_0_035"]
    endpoints = tuple(criteria["minimum_ratio_of_medians"])
    ratio_of_medians = {
        endpoint: (
            float(candidate[f"median_{endpoint}"]) / float(control[f"median_{endpoint}"])
            if float(control[f"median_{endpoint}"]) > 0.0 else float("inf")
        )
        for endpoint in endpoints
    }
    run_lookup = {
        (int(run["seed"]), str(run["transport_mode"]), str(run["condition"])): run
        for run in runs
    }
    paired_improvement = {}
    for mode in EXPERIMENT_TRANSPORT_MODES:
        mode_result = {}
        mode_seeds = sorted(
            int(run["seed"])
            for run in runs
            if run["condition"] == "control_v66_radial" and run["transport_mode"] == mode
        )
        for endpoint in endpoints:
            improved = sum(
                float(run_lookup[(seed, mode, "candidate_v68_lift_0_035")][endpoint])
                > float(run_lookup[(seed, mode, "control_v66_radial")][endpoint])
                for seed in mode_seeds
            )
            mode_result[endpoint] = {
                "improved_pairs": improved,
                "total_pairs": len(mode_seeds),
                "improvement_fraction": improved / len(mode_seeds),
            }
        paired_improvement[mode] = mode_result
    maximum_error = max(
        max(
            float(run["max_abs_energy_transport_error"]),
            float(run["max_abs_water_transport_error"]),
            float(run["max_abs_conductance_budget_error"]),
        )
        for run in runs
    )
    checks = {
        "candidate_extinction_rate_in_0_10_to_0_50": (
            criteria["candidate_extinction_rate_min_inclusive"]
            <= candidate["extinction_rate"]
            <= criteria["candidate_extinction_rate_max_inclusive"]
        ),
        "extinction_reduction_vs_control_ge_0_25": (
            control["extinction_rate"] - candidate["extinction_rate"]
            >= criteria["minimum_extinction_rate_reduction_vs_control"]
        ),
        "transport_extinction_direction_not_reversed": all(
            candidate["by_transport"][mode]["extinction_rate"]
            <= control["by_transport"][mode]["extinction_rate"]
            for mode in EXPERIMENT_TRANSPORT_MODES
        ),
        "candidate_necrosis_fraction_in_0_10_to_0_90": (
            criteria["candidate_necrosis_fraction_min_inclusive"]
            <= candidate["pooled_cumulative_necrosis_fraction"]
            <= criteria["candidate_necrosis_fraction_max_inclusive"]
        ),
        "mechanical_errors_within_tolerance": maximum_error <= criteria["maximum_mechanical_error"],
        "fluffiness_ratio_of_medians_thresholds": all(
            ratio_of_medians[endpoint] >= criteria["minimum_ratio_of_medians"][endpoint]
            for endpoint in endpoints
        ),
        "paired_fluffiness_improvement_fraction_per_transport": all(
            paired_improvement[mode][endpoint]["improvement_fraction"]
            >= criteria["minimum_paired_improvement_fraction_per_transport"]
            for mode in EXPERIMENT_TRANSPORT_MODES
            for endpoint in endpoints
        ),
        "death_concepts_separately_recorded": all(
            all(
                key in run
                for key in (
                    "total_necrotic_modules",
                    "total_actual_ramet_deaths",
                    "total_genet_extinctions",
                    "fragmentation_events",
                    "spore_establishment_failures",
                )
            )
            for run in runs
        ),
    }
    passed = all(checks.values())
    return {
        "verdict": "V6_8_LIFT_0_035_CONFIRMED" if passed else "V6_8_LIFT_0_035_NOT_REPRODUCED",
        "checks": checks,
        "ratio_of_medians": ratio_of_medians,
        "paired_improvement_by_transport": paired_improvement,
        "maximum_mechanical_error": maximum_error,
        "criteria_sha256": hashlib.sha256(CRITERIA_FILE.read_bytes()).hexdigest(),
        "failure_rule": criteria["failure_rule"],
    }


def run_confirmatory(output: Path) -> dict[str, Any]:
    seeds = locked_confirmatory_seeds()
    started = time.perf_counter()
    runs = [
        run_one(seed, mode, condition)
        for seed in seeds
        for mode in EXPERIMENT_TRANSPORT_MODES
        for condition in CONDITIONS
    ]
    summaries = [condition_summary(runs, condition) for condition in CONDITIONS]
    report = {
        "schema": "rootnet-v6.8-lift-0.035-confirmatory-result-v1",
        "stage": "confirmatory",
        "status": "COMPLETED",
        "candidate_water_capacity_lift": 0.035,
        "seed_namespace": SEED_NAMESPACE,
        "seed_count": len(seeds),
        "run_count": len(runs),
        "ticks": TICKS,
        "conditions": CONDITIONS,
        "transport_modes": list(EXPERIMENT_TRANSPORT_MODES),
        "condition_summaries": summaries,
        "acceptance": evaluate_acceptance(runs, summaries),
        "runs": runs,
        "runtime_seconds": time.perf_counter() - started,
        "critical_seal_sha256": hashlib.sha256(SEAL_FILE.read_bytes()).hexdigest(),
        "seed_file_sha256": hashlib.sha256(SEED_FILE.read_bytes()).hexdigest(),
        "claim_boundary": (
            "Confirmatory only for the fixed artificial-system criteria; not real-fungus calibration."
        ),
    }
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="RootNet v6.8 +0.035 confirmatory evaluation")
    parser.add_argument("--lock-seeds-only", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("confirmatory_evaluation_v6_8.json"))
    args = parser.parse_args()
    if args.lock_seeds_only:
        print(f"Locked: {lock_confirmatory_seeds()}")
        return
    report = run_confirmatory(args.output)
    print(json.dumps({
        "status": report["status"],
        "run_count": report["run_count"],
        "runtime_seconds": report["runtime_seconds"],
        "verdict": report["acceptance"]["verdict"],
    }, indent=2))
    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
