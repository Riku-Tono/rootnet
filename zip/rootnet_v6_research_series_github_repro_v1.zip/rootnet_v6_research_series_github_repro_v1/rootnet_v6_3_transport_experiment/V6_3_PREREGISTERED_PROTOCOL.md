# RootNet v6.3 preregistered transport experiment

Protocol ID: `rootnet-v6.3-transport-necessity-v1`

This file fixes the question, conditions, endpoints, seed derivation, and decision rule before evaluation runs are inspected.

## Question and claim boundary

Question: does mass-conserving resource translocation over the existing hyphal graph contribute to persistent growth and spatial exploration?

This experiment does **not** remove the graph itself. Even the no-transport condition retains edges for connectedness, fragmentation, and morphology. Therefore the experiment tests the contribution of the graph's resource-translocation function, not whether all aspects of a mycelial graph are necessary for life. It is an artificial-life mechanism experiment, not evidence about the evolutionary history or optimality of real fungi.

## Fixed conditions

All conditions use identical model parameters and the same seed within each paired replicate. Only `transport_mode` changes.

- `none`: no energy or water is moved between modules.
- `equalize`: v6.2.1 fixed-conductance movement down local stock differences.
- `demand`: fixed-conductance source-sink movement. A non-tip target is two ticks of maintenance. A tip target additionally contains the full cost and reserve for one extension. Only stock above the donor target can be exported, only a deficit below the receiver target can be filled, all proposed donor outflows are proportionally capped, and changes are applied simultaneously.

Energy and water are computed independently. Conductance does not adapt. Growth thresholds, uptake, maintenance, necrosis, mutation, reproduction, environment, and random-stream construction are unchanged from v6.2.1.

## Evaluation set

- Development seed 620 remains a seen calibration/demo seed and is excluded.
- Evaluation seeds are derived without model output from the first eight bytes of `SHA256("rootnet-v6.3-preregistered-evaluation-v1|INDEX")`, reduced to the positive 31-bit range, for indices 0 through 29.
- Each evaluation seed is run once in each of the three conditions for 360 ticks on the default 42 by 18 world with three founders.
- No parameter tuning is permitted after evaluation begins. Any later change creates a new protocol ID and a new evaluation set.

## Primary endpoints

The four paired primary endpoints are:

1. mean living modules across ticks, higher is favorable;
2. cumulative distinct cells ever occupied, higher is favorable;
3. fraction of completed ticks with at least one extension, higher is favorable;
4. longest consecutive run without extension, lower is favorable.

For each transport condition versus `none`, the report gives paired deltas, favorable/unfavorable/tied replicate counts, the median paired delta in the favorable direction, and a two-sided exact sign-test p-value. Holm correction is applied across the four endpoints.

The preregistered classification is:

- `SUPPORTED`: at least three of four median effects are favorable, at least two endpoints pass Holm-adjusted 0.05, extinction count is not higher than `none`, and median necrosis per 100 extensions is not more than 25% worse than `none`.
- `EVIDENCE_AGAINST`: at least three of four median effects are unfavorable and at least two endpoints pass Holm-adjusted 0.05 in the unfavorable direction.
- `MIXED_OR_INCONCLUSIVE`: all other outcomes.

The rule is deliberately conservative. A visually lively run does not determine the classification.

## Secondary diagnostics

- final living genets, ramets, modules, and tips;
- total extensions and necrotic modules;
- necrosis per 100 extensions;
- actual ramet deaths and genet extinctions;
- energy and water moved;
- energy and water delivered to tips;
- same-tick and one-tick-lag correlations between tip delivery and extension;
- maximum transport balance error, negative-stock checks, exact replay, and edge-order invariance.

Secondary results explain mechanisms but cannot override the primary classification.
