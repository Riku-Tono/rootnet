@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 main.py --days 10 --seed 42
) else (
  python main.py --days 10 --seed 42
)

echo.
echo RootNet v5.8.0 Biological Model.
echo Open fusa_lineage_tree.html to inspect physiological resources and lineages.
echo Run this file again to resume the saved simulation for another 10 days.
pause

