# 配布ZIPの再作成

Python 3.10以降で、ルートに収録された `build_archives.py` を使います。

```bash
python build_archives.py sources/fusa_memory_v1_genetic_growth_reconstructed releases/fusa_memory_v1_genetic_growth_reconstructed.zip
python build_archives.py sources/fusa_memory_v2_environmental_memory_reconstructed releases/fusa_memory_v2_environmental_memory_reconstructed.zip
```

このビルダーは、ファイル順、ZIP内時刻、権限値を固定します。同じソースから作るv1・v2 ZIPは同じSHA-256になります。

v3は歴史的な原本ZIPをそのまま保存する方針なので、再圧縮しません。
