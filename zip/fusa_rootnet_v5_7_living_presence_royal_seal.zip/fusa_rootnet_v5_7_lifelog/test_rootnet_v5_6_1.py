from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from ecosystem import FusaEcosystem
from lineage_view import write_lineage_tree
from models import StoredSeed
from network import RootNet
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV561Tests(unittest.TestCase):
    def make_networked_ecosystem(self, modular: bool) -> FusaEcosystem:
        ecosystem = FusaEcosystem(rng_seed=1)
        for index in range(8):
            plant = FusaPlant(
                f"検査株{index}",
                plant_id=str(index),
                district="検査区",
                rng_seed=index,
            )
            ecosystem.add_plant(plant)
        if modular:
            for group in (range(4), range(4, 8)):
                values = list(group)
                for left_index, left in enumerate(values):
                    for right in values[left_index + 1:]:
                        ecosystem.connect_plants(
                            ecosystem.rootnet,
                            str(left),
                            str(right),
                            0.80,
                        )
            ecosystem.connect_plants(ecosystem.rootnet, "3", "4", 0.30)
        else:
            for left in range(8):
                for right in range(left + 1, 8):
                    ecosystem.connect_plants(
                        ecosystem.rootnet,
                        str(left),
                        str(right),
                        0.80,
                    )
        return ecosystem

    def test_network_metrics_include_components(self) -> None:
        network = RootNet()
        for node in ("A", "B", "C", "D"):
            network.add_node(node)
        network.connect("A", "B", 1.0)
        network.connect("B", "C", 1.0)
        metrics = network.metrics({"A", "B", "C", "D"})
        self.assertEqual(2.0, metrics["component_count"])
        self.assertAlmostEqual(0.75, metrics["largest_component_ratio"])
        self.assertAlmostEqual(0.25, metrics["isolate_rate"])
        self.assertAlmostEqual(0.50, metrics["reachability"])

    def test_new_sprout_starts_without_automatic_parent_link(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=7)
        parent = FusaPlant("親株", plant_id="parent", rng_seed=8)
        parent.day = 10
        ecosystem.day = 10
        ecosystem.add_plant(parent)
        packet = StoredSeed(
            seed_id="seed-test",
            seed=parent.create_seed(),
            parent_id=parent.plant_id,
            lineage=parent.lineage,
            district=parent.district,
            stored_day=0,
            traits=parent.traits,
            abilities=parent.abilities,
        )
        ecosystem.seed_inventory.append(packet)
        ecosystem.infrastructure.water_quality = 1.0
        ecosystem.infrastructure.water_reserve = 1.0
        ecosystem.infrastructure.soil_nutrients = 1.0
        ecosystem.infrastructure.pest_pressure = 0.0
        with patch.object(ecosystem._rng, "random", return_value=0.0):
            new_ids = ecosystem._germinate_seed_inventory()
        self.assertEqual(1, len(new_ids))
        self.assertNotIn(new_ids[0], ecosystem.rootnet.links[parent.plant_id])
        self.assertEqual({}, ecosystem.rootnet.links[new_ids[0]])

    def test_modular_network_contains_toxic_mutation(self) -> None:
        complete = self.make_networked_ecosystem(modular=False)
        modular = self.make_networked_ecosystem(modular=True)
        for ecosystem in (complete, modular):
            ecosystem.introduce_toxic_mutation("0")
            ecosystem._biosecurity_cycle(allow_new_mutations=False)
        complete_affected = complete.outbreak_history[0]["max_affected"]
        modular_affected = modular.outbreak_history[0]["max_affected"]
        self.assertEqual(8, complete_affected)
        self.assertEqual(4, modular_affected)
        self.assertGreater(
            modular._biosecurity_metrics()["mean_containment_rate"],
            complete._biosecurity_metrics()["mean_containment_rate"],
        )

    def test_quarantine_severs_then_reconnects_after_recovery(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=3)
        left = FusaPlant("左株", plant_id="left", rng_seed=1)
        right = FusaPlant("右株", plant_id="right", rng_seed=2)
        ecosystem.add_plant(left)
        ecosystem.add_plant(right)
        ecosystem.connect_plants(ecosystem.rootnet, "left", "right", 0.80)
        ecosystem.introduce_toxic_mutation("left")

        ecosystem.day = 1
        first = ecosystem._biosecurity_cycle(allow_new_mutations=False)
        self.assertTrue(first["severed"])
        self.assertNotIn("right", ecosystem.rootnet.links["left"])

        reconnected = []
        for day in range(2, 41):
            ecosystem.day = day
            result = ecosystem._biosecurity_cycle(allow_new_mutations=False)
            reconnected.extend(result["reconnected"])
        self.assertTrue(reconnected)
        self.assertIn("right", ecosystem.rootnet.links["left"])
        self.assertEqual(0.0, left.biohazard_load)
        self.assertEqual(0.0, right.biohazard_load)

    def test_diversity_still_combines_entropy_and_distance(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        metrics = ecosystem.diversity_metrics()
        self.assertAlmostEqual(
            metrics["composite"],
            0.5 * metrics["category_entropy"]
            + 0.5 * metrics["mean_pairwise_distance"],
        )

    def test_long_run_records_fragmentation_and_hyphal_reconnection(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(260):
            ecosystem.step()
        modes = {item.get("type") for item in ecosystem.movement_history}
        self.assertIn("hypha", modes)
        self.assertGreater(ecosystem.rootnet_metrics()["component_count"], 1.0)
        self.assertGreater(len(ecosystem.severed_links), 0)

    def test_save_resume_matches_continuous_run(self) -> None:
        continuous = FusaEcosystem.demo(123)
        for _ in range(180):
            continuous.step()
        split = FusaEcosystem.demo(123)
        for _ in range(90):
            split.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet_v5_6_1.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 123)
            for _ in range(90):
                resumed.step()
        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_schema8_save_migrates_with_safe_defaults(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        data = ecosystem_to_dict(ecosystem)
        data["schema_version"] = 8
        for key in ("severed_links", "outbreak_history", "biosecurity_history"):
            data.pop(key, None)
        for plant in data["plants"]:
            for key in (
                "biohazard_load",
                "biohazard_origin",
                "toxin_potential",
                "biosecurity_resistance",
                "quarantine_until",
            ):
                plant.pop(key, None)
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "v56.json"
            path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            migrated = load_ecosystem(path, 123)
        self.assertTrue(all(
            plant.biohazard_load == 0.0
            for plant in migrated.plants.values()
        ))
        self.assertEqual([], migrated.outbreak_history)

    def test_lineage_tree_contains_biosecurity_state(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        ecosystem.introduce_toxic_mutation("memory-001")
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "tree.html"
            write_lineage_tree(ecosystem, output)
            html = output.read_text(encoding="utf-8")
        self.assertIn("RootNet v5.7 暮らしと気配", html)
        self.assertIn("biohazard_load", html)
        self.assertIn("outbreaks", html)


if __name__ == "__main__":
    unittest.main()
