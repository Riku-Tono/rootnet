from __future__ import annotations

import hashlib
import io
import json
import sys
import unittest
from pathlib import Path

from make_manifest import MANIFEST, ROOT, included_files
from validate_v6_1 import run_validation


def verify_manifest() -> tuple[bool, list[str]]:
    expected: dict[str, str] = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(" *", 1)
        expected[relative] = digest
    current = {path.relative_to(ROOT).as_posix(): path for path in included_files()}
    messages: list[str] = []
    if set(expected) != set(current):
        messages.append(f"file set mismatch: expected={sorted(expected)} current={sorted(current)}")
    for relative in sorted(set(expected) & set(current)):
        actual = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if actual != expected[relative]:
            messages.append(f"hash mismatch: {relative}")
    return not messages, messages


def run_tests() -> tuple[bool, int, str]:
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    buffer = io.StringIO()
    result = unittest.TextTestRunner(stream=buffer, verbosity=1).run(suite)
    return result.wasSuccessful(), result.testsRun, buffer.getvalue()


def main() -> None:
    manifest_ok, messages = verify_manifest()
    tests_ok, tests_run, test_output = run_tests()
    current_validation = run_validation()
    sealed_validation = json.loads((ROOT / "validation_v6_1.json").read_text(encoding="utf-8"))
    validation_ok = current_validation == sealed_validation
    report = {
        "manifest": "PASS" if manifest_ok else "FAIL",
        "unit_tests": "PASS" if tests_ok else "FAIL",
        "tests_run": tests_run,
        "sealed_validation_reproduced": "PASS" if validation_ok else "FAIL",
        "details": messages,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not tests_ok:
        print(test_output)
    if not (manifest_ok and tests_ok and validation_ok):
        sys.exit(1)


if __name__ == "__main__":
    main()
