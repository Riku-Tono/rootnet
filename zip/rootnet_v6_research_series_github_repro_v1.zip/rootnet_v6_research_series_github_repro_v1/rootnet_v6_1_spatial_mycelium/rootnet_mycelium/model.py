from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


Coord = tuple[int, int]
Edge = tuple[Coord, Coord]

TRAIT_NAMES = (
    "extension_rate",
    "branching_rate",
    "light_investment",
    "substrate_investment",
    "desiccation_tolerance",
    "resource_sharing",
    "fusion_tendency",
    "spore_dispersal",
)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def canonical_edge(left: Coord, right: Coord) -> Edge:
    return (left, right) if left <= right else (right, left)


@dataclass(frozen=True)
class Genome:
    extension_rate: float = 0.46
    branching_rate: float = 0.28
    light_investment: float = 0.22
    substrate_investment: float = 0.58
    desiccation_tolerance: float = 0.34
    resource_sharing: float = 0.24
    fusion_tendency: float = 0.36
    spore_dispersal: float = 0.30

    def normalized(self) -> "Genome":
        return Genome(**{
            name: clamp(getattr(self, name))
            for name in TRAIT_NAMES
        })

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Genome":
        defaults = cls()
        return cls(**{
            name: float(data.get(name, getattr(defaults, name)))
            for name in TRAIT_NAMES
        }).normalized()


@dataclass(frozen=True)
class Phenotype:
    extension_rate: float
    branching_rate: float
    light_capture: float
    substrate_absorption: float
    desiccation_tolerance: float
    resource_sharing: float
    fusion_tendency: float
    spore_dispersal: float
    base_maintenance: float
    segment_maintenance: float
    extension_cost: float
    spore_cost: float

    @classmethod
    def from_genome(cls, genome: Genome) -> "Phenotype":
        genome = genome.normalized()
        light = genome.light_investment
        substrate = genome.substrate_investment
        acquisition_total = light + substrate
        if acquisition_total > 1.0:
            light /= acquisition_total
            substrate /= acquisition_total
        return cls(
            extension_rate=genome.extension_rate,
            branching_rate=genome.branching_rate,
            light_capture=light,
            substrate_absorption=substrate,
            desiccation_tolerance=genome.desiccation_tolerance,
            resource_sharing=genome.resource_sharing,
            fusion_tendency=genome.fusion_tendency,
            spore_dispersal=genome.spore_dispersal,
            base_maintenance=(
                0.018
                + 0.010 * genome.desiccation_tolerance**2
                + 0.006 * genome.resource_sharing**2
                + 0.006 * genome.fusion_tendency**2
            ),
            segment_maintenance=(
                0.0032
                + 0.0028 * genome.extension_rate**2
                + 0.0018 * genome.branching_rate**2
            ),
            extension_cost=(
                0.040
                + 0.020 * genome.extension_rate
                + 0.014 * genome.branching_rate
            ),
            spore_cost=0.34 + 0.14 * genome.spore_dispersal,
        )


@dataclass
class Colony:
    colony_id: str
    parent_id: str
    root_branch_id: str
    birth_tick: int
    genome: Genome
    origin: Coord
    cells: set[Coord] = field(default_factory=set)
    tips: set[Coord] = field(default_factory=set)
    edges: set[Edge] = field(default_factory=set)
    energy: float = 2.4
    hydration: float = 1.6
    age: int = 0
    alive: bool = True
    death_tick: int | None = None
    death_reason: str | None = None
    spores_released: int = 0

    def __post_init__(self) -> None:
        if not self.cells:
            self.cells.add(self.origin)
        if not self.tips:
            self.tips.add(self.origin)

    @property
    def phenotype(self) -> Phenotype:
        return Phenotype.from_genome(self.genome)

    def to_dict(self) -> dict[str, Any]:
        return {
            "colony_id": self.colony_id,
            "parent_id": self.parent_id,
            "root_branch_id": self.root_branch_id,
            "birth_tick": self.birth_tick,
            "genome": self.genome.to_dict(),
            "origin": list(self.origin),
            "cells": [list(coord) for coord in sorted(self.cells)],
            "tips": [list(coord) for coord in sorted(self.tips)],
            "edges": [
                [list(left), list(right)]
                for left, right in sorted(self.edges)
            ],
            "energy": self.energy,
            "hydration": self.hydration,
            "age": self.age,
            "alive": self.alive,
            "death_tick": self.death_tick,
            "death_reason": self.death_reason,
            "spores_released": self.spores_released,
        }


@dataclass
class Spore:
    spore_id: str
    parent_id: str
    root_branch_id: str
    genome: Genome
    position: Coord
    released_tick: int
    expires_tick: int

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["genome"] = self.genome.to_dict()
        result["position"] = list(self.position)
        return result
