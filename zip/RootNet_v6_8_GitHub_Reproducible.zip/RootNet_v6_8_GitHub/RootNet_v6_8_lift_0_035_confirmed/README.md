# RootNet v6.8 — confirmed `+0.035` water-field repair

## Status

`V6_8_LIFT_0_035_CONFIRMED`

The water-capacity lift, criteria, critical code, and protocol were sealed
before 30 completely unused confirmatory seeds were generated. All 120 paired
runs completed, and all eight predeclared acceptance checks passed.

The sole dynamics change from `v66-radial` is:

```text
v68_water = clamp(v66_water + 0.035, 0.08, 1.00)
```

## Confirmatory result

| endpoint | v6.6 control | v6.8 +0.035 |
|---|---:|---:|
| ecosystem extinction | 50/60 (83.3%) | 12/60 (20.0%) |
| median mean living modules | 8.96 | 12.80 |
| median mean hyphal length | 7.40 | 10.71 |
| median mean tips | 3.65 | 5.03 |
| median mean branch modules | 0.95 | 1.68 |
| pooled cumulative necrosis | 0.978 | 0.822 |

Candidate extinction was 7/30 under fixed transport and 5/30 under adaptive
transport. Candidate/control ratios of medians were 1.447 for hyphal length,
1.380 for tips, and 1.768 for branch modules. All transport-specific paired
improvement fractions exceeded the fixed 70% threshold.

## Run and observe

```powershell
python watch.py
python main.py --ticks 360 --seed 680 --output run_output
```

The terminal observer draws hyphal edges and modules and is read-only.

## Verify

```powershell
python -m unittest discover -s tests -p test_v6_8.py -v
python validate_v6_8.py
python verify_package.py
```

The reference validation runtime was Windows 11 x86-64 / CPython 3.14.5.
Manifest integrity and numerical/runtime regression are reported separately.

This result confirms fixed artificial-system engineering criteria. It is not
calibration to a real fungal species or natural mortality rate.
