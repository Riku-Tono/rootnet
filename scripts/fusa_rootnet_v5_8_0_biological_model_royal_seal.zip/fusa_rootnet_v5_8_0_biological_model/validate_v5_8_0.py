from __future__ import annotations

import json
import tempfile
import time
import unittest
from collections import Counter
from pathlib import Path

from ecosystem import FusaEcosystem
from persistence import SCHEMA_VERSION, ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic


ROOT = Path(__file__).resolve().parent


def run_tests() -> tuple[int, int, bool]:
    suite = unittest.defaultTestLoader.discover(str(ROOT), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    return result.testsRun, len(result.failures) + len(result.errors), result.wasSuccessful()


def run_validation() -> dict[str, object]:
    started = time.perf_counter()
    tests_run, test_failures, tests_passed = run_tests()

    continuous = FusaEcosystem.demo(rng_seed=580)
    split = FusaEcosystem.demo(rng_seed=580)
    for _ in range(320):
        continuous.step()
    for _ in range(137):
        split.step()
    with tempfile.TemporaryDirectory() as folder:
        save_path = Path(folder) / "split_day_137.json"
        save_ecosystem_atomic(split, save_path)
        resumed = load_ecosystem(save_path, rng_seed=999999)
    for _ in range(183):
        resumed.step()

    exact_resume = ecosystem_to_dict(continuous) == ecosystem_to_dict(resumed)
    maximum_balance_error = max(
        abs(error)
        for record in continuous.biological_history
        for error in record["mass_balance_error"].values()
    )
    transported = {
        resource: sum(record["transported"][resource] for record in continuous.biological_history)
        for resource in ("carbon", "water", "nitrogen")
    }
    deaths = Counter(
        plant.death_reason or "unknown"
        for plant in continuous.plants.values()
        if not plant.alive
    )
    death_groups = Counter(
        plant.biological_traits.functional_group
        for plant in continuous.plants.values()
        if not plant.alive
    )
    groups = Counter(
        plant.biological_traits.functional_group
        for plant in continuous.living_plants()
    )
    checks = {
        "tests_passed": tests_passed,
        "save_resume_exact": exact_resume,
        "mass_balance_within_1e_10": maximum_balance_error < 1e-10,
        "personality_actions_inactive": continuous.life_action_counts == {},
        "all_functional_groups_present": set(groups) == {"fungus", "alga", "symbiotic"},
        "resource_transport_observed": sum(transported.values()) > 0.0,
    }
    return {
        "version": "RootNet v5.8.0 Biological Model",
        "schema_version": SCHEMA_VERSION,
        "seed": 580,
        "days": 320,
        "split": {"before_save": 137, "after_resume": 183},
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "tests": {"run": tests_run, "failures_or_errors": test_failures},
        "population": {
            "living": len(continuous.living_plants()),
            "historical": len(continuous.plants),
            "deaths_by_reason": dict(sorted(deaths.items())),
            "deaths_by_functional_group": dict(sorted(death_groups.items())),
            "death_records": [
                {
                    "plant_id": plant.plant_id,
                    "name": plant.name,
                    "functional_group": plant.biological_traits.functional_group,
                    "day": plant.death_day,
                    "reason": plant.death_reason,
                }
                for plant in continuous.plants.values()
                if not plant.alive
            ],
            "living_functional_groups": dict(sorted(groups.items())),
        },
        "biology": {
            "maximum_absolute_mass_balance_error": maximum_balance_error,
            "cumulative_network_transport": transported,
            "final_total_resources": {
                resource: sum(
                    getattr(plant.resources, resource)
                    for plant in continuous.living_plants()
                )
                for resource in ("carbon", "water", "nitrogen")
            },
        },
        "elapsed_seconds": time.perf_counter() - started,
    }


def write_report(result: dict[str, object]) -> None:
    (ROOT / "validation_v5_8_0.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    checks = result["checks"]
    population = result["population"]
    biology = result["biology"]
    lines = [
        "# RootNet v5.8.0 検証報告",
        "",
        f"総合判定: **{'PASS' if result['all_checks_passed'] else 'FAIL'}**",
        "",
        f"- 自動検査: {result['tests']['run']}件、失敗・エラー{result['tests']['failures_or_errors']}件",
        f"- 320日連続と137日保存＋183日再開: {'完全一致' if checks['save_resume_exact'] else '不一致'}",
        f"- 最大物質収支誤差: `{biology['maximum_absolute_mass_balance_error']:.3e}`",
        f"- 擬人的行動の通常日次実行: {'停止' if checks['personality_actions_inactive'] else '残存'}",
        f"- 320日後の生存個体: {population['living']}（歴代{population['historical']}）",
        f"- 生存機能群: {population['living_functional_groups']}",
        f"- 死因: {population['deaths_by_reason']}",
        f"- 死亡機能群: {population['deaths_by_functional_group']}",
        f"- 累積網内移送: {biology['cumulative_network_transport']}",
        "",
        "通常環境の320日は安定性確認であり、現実の死亡率を再現した結果ではありません。欠乏死は外部入力を遮断した専用試験で確認しています。",
    ]
    (ROOT / "VALIDATION_V5_8_0.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    validation = run_validation()
    write_report(validation)
    print(json.dumps(validation, ensure_ascii=False, indent=2))
    raise SystemExit(0 if validation["all_checks_passed"] else 1)
