# RootNet v6.1 — Spatial Mycelium

RootNet v6.1 is a small artificial-life model in which persistent mycelial colonies occupy and grow through a two-dimensional environment. It is a new model series; v6.0 is not overwritten.

## 見る

VS Codeでこのフォルダーを開き、ターミナルに次を貼り付けます。

```powershell
python watch.py
```

色付きの菌糸体が伸びます。`Ctrl+C` で止められます。速さや長さを変える例:

```powershell
python watch.py --ticks 200 --delay 0.05
```

記録を保存する実験用コマンド:

```powershell
python main.py --ticks 80 --seed 610 --output run_output
```

検証:

```powershell
python -m unittest discover -s tests -v
python validate_v6_1.py
python verify_package.py
```

Python 3.10以降の標準ライブラリだけを使います。

## 何が生きているのか

このモデルの個体は、単一セルではなく複数セルからなる「菌糸体コロニー」です。コロニーはtickをまたいで残り、先端を伸ばし、分岐し、別の菌糸と融合することがあります。胞子を出しても親は消えません。子が定着すれば親子が同時に生きます。

コロニーの実死亡はエネルギー枯渇または水分枯渇だけです。場所が塞がった胞子や寿命切れ胞子は「定着失敗」であって、死亡個体数には数えません。老化死はv6.1にはありません。

## 研究上の境界

これは空間菌糸・重複世代・局所資源・遺伝変異という機構を検査する人工生態系です。現実の菌類史、種、カンブリア爆発を再現したとは主張しません。初期コロニーに fungus / alga などの型名は与えません。

v6.1の短い既定runは動作確認用であり、多様化の研究結果ではありません。研究上の比較には、先に仮説・主要指標・反復seed・除外基準を固定してください。

詳しい規則は `MODEL_SPEC.md`、主張範囲は `RESEARCH_BOUNDARIES.md` にあります。
