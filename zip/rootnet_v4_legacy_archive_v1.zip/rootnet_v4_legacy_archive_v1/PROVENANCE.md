# Provenance

この外側アーカイブは、2026-08-18に提供された二つの封印ZIPから作成しました。元ZIPは展開・編集・再圧縮せず、バイト列をそのまま `sealed_packages/` に収録しています。

## 元ZIP

```text
7c10f9484530fb27dee1279c436ef4dae791406d9e5bf6bd0a204a8ed254c79a  sealed_packages/v4_fixed/fusa_rootnet_v4_fixed_royal_seal.zip
72d5527e5554e4f84ef0332ad2f3750de3ee2bc189bf18c1e9105d430c184de1  sealed_packages/v4_1_sun_sea/fusa_rootnet_v4_1_sun_sea_royal_seal.zip
```

元ファイルサイズ:

- `fusa_rootnet_v4_fixed_royal_seal.zip`: 16,441 bytes
- `fusa_rootnet_v4_1_sun_sea_royal_seal.zip`: 23,065 bytes

## 外側に追加したもの

- 系列READMEと版索引;
- 元ZIP用 `SHA256SUMS.txt`;
- 全外側ファイル用 `MANIFEST_SHA256.txt`;
- ハッシュ、CRC、コンパイル、テストを確認する `verify_archive.py`;
- manifest生成用 `make_manifest.py`;
- 決定的な外側ZIPを作る `build_release.py`;
- Git用設定とGitHub Actionsワークフロー。

外側の追加物は内側モデルの力学を変更しません。
