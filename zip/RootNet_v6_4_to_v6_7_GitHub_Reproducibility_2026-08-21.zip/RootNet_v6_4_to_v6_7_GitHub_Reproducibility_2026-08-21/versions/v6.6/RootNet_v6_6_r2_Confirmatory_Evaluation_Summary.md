# RootNet v6.6 r2 confirmatory evaluation summary

## Execution status

- Status: `COMPLETED`
- Sealed manifest verification: `PASS`
- Sealed validation reproduction: `PASS`
- Locked evaluation seeds: 30/30 exact match
- Condition runs: 300/300
- Geometry: 360 ticks, 42×42 arena, 3 founders
- Runtime: 326.069842700032 seconds

## Preregistered primary results

All 24 preregistered comparisons were classified
`EQUIVALENT_WITHIN_5_PERCENT`.

| Primary endpoint | Comparisons within margin | Total comparisons |
|---|---:|---:|
| `mean_living_modules` | 8 | 8 |
| `mean_total_hyphal_length` | 8 | 8 |
| `mean_convex_hull_area` | 8 | 8 |

Each transport mode contributed 12/12 comparisons within the preregistered
engineering margin.

## Conservation diagnostics

- Maximum absolute energy transport error: `4.44089209850063e-16`
- Maximum absolute water transport error: `1.11022302462516e-16`
- Maximum absolute conductance-budget error: `1.77635683940025e-15`

## Auxiliary observation

`cumulative_active_patch_uptake` was zero in 290/300 runs and positive in 10/300
runs. All ten positive runs belonged to seed `1792943312`, across both transport
modes and all five angles. Uptake was preregistered as auxiliary only, so it is not
included in the confirmatory equivalence verdict and no post-hoc equivalence test
is added.

## Claim boundary

This is evidence of engineering rotation equivalence for the three primary
endpoints in this artificial continuous-coordinate assay. It is not biological
validation or evidence that every auxiliary mechanism is rotation invariant.

## Result integrity

- Result file: `RootNet_v6_6_r2_Confirmatory_Evaluation.json`
- SHA-256: `538BDEAAB1C8E52A75EF82ADFFD876456A994D943E60505FFB716571175AEB8E`
