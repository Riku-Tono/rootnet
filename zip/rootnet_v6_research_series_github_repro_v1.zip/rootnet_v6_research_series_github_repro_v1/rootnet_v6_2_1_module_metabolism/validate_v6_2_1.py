from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_v62 import ModuleSimulation, SimulationConfig
from watch import visual_signature


def run_validation() -> dict[str, object]:
    config = SimulationConfig(master_seed=620, ticks=360)
    first = ModuleSimulation(config)
    previous = visual_signature(first)
    visual_changes = 0
    current_quiet = 0
    longest_quiet = 0
    while first.tick < config.ticks and (first.living_ramets() or first.spores):
        first.step()
        signature = visual_signature(first)
        if signature == previous:
            current_quiet += 1
            longest_quiet = max(longest_quiet, current_quiet)
        else:
            visual_changes += 1
            current_quiet = 0
        previous = signature
    summary = first.run()
    replay = ModuleSimulation(config)
    replay.run()
    germinations = [r for r in first.spore_records if r.get("event") == "germinated"]
    fragments = [r for r in first.ramet_records if r.get("created_by") == "fragmentation"]
    checks = {
        "exact_seed_replay": first.state_digest() == replay.state_digest(),
        "energy_transport_conserved": summary["max_abs_energy_transport_error"] < 1e-12,
        "water_transport_conserved": summary["max_abs_water_transport_error"] < 1e-12,
        "visual_changes_are_frequent_enough_for_observer": visual_changes >= 100,
        "longest_unchanged_visual_run_is_bounded": longest_quiet <= 30,
        "partial_necrosis_still_occurs": summary["total_necrotic_modules"] > 0,
        "fragmentation_still_occurs": len(fragments) > 0,
        "offspring_establish_with_parent_alive": bool(germinations) and all(r["parent_genet_alive"] for r in germinations),
        "ecosystem_remains_living": not summary["ecosystem_extinct"],
    }
    if not all(checks.values()):
        raise AssertionError([name for name, passed in checks.items() if not passed])
    return {
        "schema": "rootnet-v6.2.1-validation-v1",
        "status": "PASS",
        "scope": "observer-usability and deterministic mechanism validation; not a replicated research result",
        "checks": checks,
        "state_sha256": first.state_digest(),
        "observer_diagnostics": {
            "visual_state_changes": visual_changes,
            "longest_unchanged_visual_run_ticks": longest_quiet,
            "v6_2_0_previous_longest_unchanged_run_ticks": 84,
            "default_behavior": "unchanged visual ticks are simulated but not redrawn",
        },
        "observed_tick_360": {
            "living_genets": summary["final_metrics"]["living_genets"],
            "living_ramets": summary["final_metrics"]["living_ramets"],
            "living_modules": summary["final_metrics"]["total_modules"],
            "genets_ever_established": summary["genets_ever_established"],
            "total_necrotic_modules": summary["total_necrotic_modules"],
            "total_actual_ramet_deaths": summary["total_actual_ramet_deaths"],
            "fragment_ramets_created": len(fragments),
            "successful_germinations": len(germinations),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("validation_v6_2_1.json"))
    options = parser.parse_args()
    result = run_validation()
    options.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
