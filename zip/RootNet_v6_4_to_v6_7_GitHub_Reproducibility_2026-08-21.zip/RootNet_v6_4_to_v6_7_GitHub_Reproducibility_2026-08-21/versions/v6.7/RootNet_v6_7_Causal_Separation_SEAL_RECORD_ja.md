# RootNet v6.7 原因分離 development 封印記録

## 封印判定

`SEALED_COMPLETE_DEVELOPMENT_ARTIFACT`

封印日: 2026-08-21（Asia/Tokyo）

RootNet v6.7を、事前固定した160-run原因分離development試験の完了物として
封印する。封印対象の機械的分類は `WATER_FIELD_DOMINANT` である。

この封印は、v6.7を最終生態モデルとして採用する判定ではない。v6.5相当水場は
診断用反実仮想であり、v6.7のconfirmatory evaluationは未設計、実行数0である。

## 封印結果

| 条件 | 水場 | 壊死応答 | 360 tick全滅 |
|---|---|---|---:|
| A | v6.6現行 | 即時 | 32/40 = 0.800 |
| B | v6.5相当 | 即時 | 6/40 = 0.150 |
| C | v6.6現行 | 5-tick猶予 | 31/40 = 0.775 |
| D | v6.5相当 | 5-tick猶予 | 6/40 = 0.150 |

- A→Bの水場単独効果: 全滅率 `-0.65`
- A→Cの壊死猶予単独効果: 全滅率 `-0.025`
- B→D: 全滅率差 `0`
- 判定閾値: Aより絶対値で0.25以上の全滅率低下

したがって、今回の人工系ではv6.6の生態的崩壊は壊死猶予より水場変更に強く
追随した。ただし、これは事前定義したengineering分類であり、生物学的因果の
証明ではない。

## 現在実施した独立再監査

封印元ZIPを別ディレクトリへ展開し、同梱の `verify_package.py` を実行した。

| 検査 | 結果 |
|---|---|
| ZIP SHA-256照合 | PASS |
| package manifest | PASS |
| unit tests | PASS（17/17） |
| sealed validation reproduction | PASS |
| 160 predeclared runs | PASS |
| v6.6 r2 core regression | PASS |
| energy / water / conductance誤差 `<= 1e-12` | PASS |

主な再現識別子:

- v6.7 package ZIP: `bd21398c6f262257cb3e5b9fdec6a84339adaddcc974e4ad3f82861d406b5f49`
- development result: `2b29350751dac38f6715203f4e17adc41d289ed2db6780433a7807961eabc944`
- canonical development seed list: `e8b4fcdb6544cbec3f023cd430fadb9d0abfbdd29eb6ecdf21a22567570eb2f8`
- condition A v6.6 core regression: `6aa2f371ac225ef7a69fd724705d51d1c0a004ad06945129b3a25624cc4e419f`
- immutable v6.6 r2 baseline ZIP: `ac6cfb094d5c14a263e1c9a39b3c946b7e6eca61b022239c8f3aa1643db804e2`

## 不変条件

1. この封印束内のファイルを上書きしない。
2. v6.7の結果を見て条件、seed、閾値、endpointを変更しない。
3. v6.5相当水場を「採用済みv6.7モデル」と記述しない。
4. v6.7 evaluationを実施済み、または設計済みと記述しない。
5. v6.8以降の変更は別パッケージ、別manifest、別seed namespaceで行う。
6. module necrosis、actual ramet death、genet extinction、environmental damage、
   spore establishment failureを一つの死亡数へ合算しない。

## 主張境界

- 支持される: 指定した人工系development条件で、水場単独変更が固定閾値を越える
  回復を示したこと。
- 支持されない: 現実の菌類への外挿、v6.5水場の生物学的妥当性、最終モデルの
  選定、confirmatoryな因果推論、adaptive conductanceの実測的妥当性。

