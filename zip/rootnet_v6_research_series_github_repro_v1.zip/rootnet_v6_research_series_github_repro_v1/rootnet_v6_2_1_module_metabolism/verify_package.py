from __future__ import annotations

import hashlib
import io
import json
import sys
import unittest

from make_manifest import MANIFEST, ROOT, included_files
from validate_v6_2_1 import run_validation


def verify_manifest():
    expected = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(" *", 1); expected[relative] = digest
    current = {p.relative_to(ROOT).as_posix(): p for p in included_files()}
    messages = []
    if set(expected) != set(current): messages.append("file set mismatch")
    for relative in sorted(set(expected) & set(current)):
        if hashlib.sha256(current[relative].read_bytes()).hexdigest() != expected[relative]: messages.append(f"hash mismatch: {relative}")
    return not messages, messages


def main() -> None:
    manifest_ok, messages = verify_manifest()
    buffer = io.StringIO()
    result = unittest.TextTestRunner(stream=buffer, verbosity=1).run(unittest.defaultTestLoader.discover(str(ROOT / "tests")))
    current = run_validation()
    sealed = json.loads((ROOT / "validation_v6_2_1.json").read_text(encoding="utf-8"))
    validation_ok = current == sealed
    report = {"manifest": "PASS" if manifest_ok else "FAIL", "unit_tests": "PASS" if result.wasSuccessful() else "FAIL", "tests_run": result.testsRun, "sealed_validation_reproduced": "PASS" if validation_ok else "FAIL", "details": messages}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not result.wasSuccessful(): print(buffer.getvalue())
    if not (manifest_ok and result.wasSuccessful() and validation_ok): sys.exit(1)


if __name__ == "__main__": main()
