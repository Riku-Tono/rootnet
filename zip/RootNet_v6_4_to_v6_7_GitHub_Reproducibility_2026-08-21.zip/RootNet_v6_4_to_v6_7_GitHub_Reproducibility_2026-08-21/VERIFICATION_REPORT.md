# Bundle Verification Report

**Build date:** 2026-08-21  
**Environment:** Windows 11 x86-64, CPython 3.14.5

Each final package was extracted into a fresh directory and its packaged `verify_package.py` was run without modifying the package.

| Version | Package verification schema | Tests | Manifest | Sealed validation | Exit code |
|---|---|---:|---|---|---:|
| v6.4 r2 | `rootnet-v6.4-simple-package-verification-v1` | 42/42 PASS | PASS | PASS | 0 |
| v6.5 r2 | `rootnet-v6.5-dynamic-environment-package-verification-v1` | 52/52 PASS | PASS | PASS | 0 |
| v6.6 r2 | `rootnet-v6.6-r2-continuous-package-verification-v1` | 25/25 PASS | PASS | PASS | 0 |
| v6.7 | `rootnet-v6.7-causal-separation-package-verification-v1` | 17/17 PASS | PASS | PASS | 0 |

The verification above does not rerun the 90-, 240-, 300-, or 160-run assays. Their published machine-readable results and companion records are included in the bundle. Use `REPRODUCIBILITY.md` for the exact rerun entry points and interpretation limits.
