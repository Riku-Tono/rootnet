from __future__ import annotations

import math
import random
import statistics
from dataclasses import dataclass, replace
from typing import Any

from biological import BiologicalFlux, RESOURCE_NAMES, deficit_reason
from models import (
    CoralColony,
    CambrianAbilities,
    CambrianState,
    FusaTraits,
    InfrastructureState,
    MarineState,
    LifeEvent,
    SolarState,
    StoredSeed,
    Weather,
    clamp,
)
from network import RootNet, RootSignal
from rng_streams import resolve_seed_bundle, spawn_seed
from simulation import DailyReport, FusaPlant


LINEAGE_NAMES = {
    "aqua": "💧 Aqua Fusa",
    "amber": "🔥 Amber Fusa",
    "memory": "🌿 Memory Fusa",
    "elder": "⚡ Elder Fusa",
    "coastal": "🏝️ Coastal Fusa",
    "sea": "🌊 Sea Fusa",
}


@dataclass
class EcosystemReport:
    day: int
    weather: Weather
    solar: SolarState
    marine: MarineState
    signals: list[RootSignal]
    marine_signals: list[RootSignal]
    plant_reports: list[DailyReport]
    water_cleaned: float
    fuel_collected: float
    pests_removed: float
    coral_energy: float
    stored_seed_ids: list[str]
    wave_moved_seed_ids: list[str]
    new_plant_ids: list[str]
    deaths: list[tuple[str, str]]
    soil_returned: float
    carrying_capacity: int
    population_pressure: float
    elder_successor_id: str | None
    cambrian_started: bool
    cambrian_audit: dict[str, Any]
    false_signals: list[RootSignal]
    movements: list[dict[str, Any]]
    interactions: list[str]
    network_metrics: dict[str, float]
    biosecurity: dict[str, Any]
    life_events: list[LifeEvent]
    biological: dict[str, Any]


class FusaEcosystem:
    MAX_LIVING_PLANTS = 200
    MIN_GERMINATION_AGE = 3
    JOURNAL_IMPORTANCE_THRESHOLD = 0.62
    MAX_JOURNAL_EVENTS_PER_DAY = 3
    JOURNAL_REPEAT_COOLDOWN = 10
    JOURNAL_ENVIRONMENT_COOLDOWN = 5

    def __init__(
        self,
        name: str = "RootNet Fungal-Algal Community",
        rng_seed: int | None = None,
        *,
        world_seed: int | None = None,
        individual_seed: int | None = None,
        mutation_seed: int | None = None,
        action_seed: int | None = None,
    ) -> None:
        self.name = name
        self.day = 0
        self.plants: dict[str, FusaPlant] = {}
        self.rootnet = RootNet()
        self.undersea_rootnet = RootNet()
        self.infrastructure = InfrastructureState()
        self.solar_state = SolarState()
        self.marine_state = MarineState()
        self.corals: dict[str, CoralColony] = {}
        self.seed_inventory: list[StoredSeed] = []
        self.event_history: list[dict[str, Any]] = []
        self.next_plant_serial = 1
        self.next_seed_serial = 1
        self.capacity_history: list[int] = []
        self.water_quality_history: list[float] = []
        self.movement_history: list[dict[str, Any]] = []
        self.severed_links: list[dict[str, Any]] = []
        self.outbreak_history: list[dict[str, Any]] = []
        self.biosecurity_history: list[dict[str, Any]] = []
        self.biological_history: list[dict[str, Any]] = []
        self.life_journal: list[LifeEvent] = []
        self.life_action_counts: dict[str, int] = {}
        self.cambrian = CambrianState()
        self.rng_seeds = resolve_seed_bundle(
            rng_seed,
            world_seed=world_seed,
            individual_seed=individual_seed,
            mutation_seed=mutation_seed,
            action_seed=action_seed,
        )
        self._world_rng = random.Random(self.rng_seeds["world"])
        self._individual_rng = random.Random(self.rng_seeds["individual"])
        self._mutation_rng = random.Random(self.rng_seeds["mutation"])
        self._action_rng = random.Random(self.rng_seeds["action"])
        # Compatibility alias for tests and extensions through v5.7.1.
        self._rng = self._action_rng

    def plant_stream_seeds(self, plant_id: str) -> dict[str, int]:
        """Create four organism-specific streams without consuming any ecosystem stream."""
        return {
            name: spawn_seed(seed, plant_id)
            for name, seed in self.rng_seeds.items()
        }

    @classmethod
    def demo(
        cls,
        rng_seed: int | None = None,
        *,
        world_seed: int | None = None,
        individual_seed: int | None = None,
        mutation_seed: int | None = None,
        action_seed: int | None = None,
    ) -> "FusaEcosystem":
        eco = cls(
            rng_seed=rng_seed,
            world_seed=world_seed,
            individual_seed=individual_seed,
            mutation_seed=mutation_seed,
            action_seed=action_seed,
        )
        specs = [
            ("elder-001", "Elder Fusa of the Northern Reach", "elder", "Northern Forest", True, "L"),
            ("aqua-001", "Aqua, Keeper of the Waterway", "aqua", "Watergate District", False, "L"),
            ("aqua-002", "Mizuha of the Clear Roots", "aqua", "Lower Waterway", False, "L"),
            ("amber-001", "Amber of the Golden Leaves", "amber", "Sunlit Hill", False, "L"),
            ("memory-001", "Lady Fusari", "memory", "Central Garden", False, "L"),
            ("memory-002", "Toftof, Listener to the Wind", "memory", "Western Field", False, "L"),
            ("coast-001", "Nagifusa, Listener to the Tide", "coastal", "Coral Coast", False, "L"),
            ("sea-001", "Mio, Fusa of the Blue Sea", "sea", "Shallow-Sea Garden", False, "L"),
            ("mirror-001", "Mirror-Realm Fusa", "memory", "Mirror-Tide Cave", False, "D"),
        ]
        for index, (pid, name, lineage, district, elder, chirality) in enumerate(specs):
            plant = FusaPlant(
                name=name,
                plant_id=pid,
                lineage=lineage,
                district=district,
                elder=elder,
                ancestor_id=pid,
                chirality=chirality,
                **{
                    f"{stream_name}_seed": stream_seed
                    for stream_name, stream_seed in eco.plant_stream_seeds(pid).items()
                },
            )
            if elder:
                plant.age = 300 * 365
                plant.fusa_level = 100.0
            eco.add_plant(plant)

        for left, right, conductivity in [
            ("elder-001", "aqua-001", 0.95),
            ("elder-001", "memory-001", 0.92),
            ("aqua-001", "aqua-002", 0.88),
            ("aqua-001", "amber-001", 0.72),
            ("memory-001", "memory-002", 0.84),
            ("memory-002", "amber-001", 0.76),
            ("aqua-002", "coast-001", 0.66),
        ]:
            eco.connect_plants(eco.rootnet, left, right, conductivity)

        eco.connect_plants(eco.undersea_rootnet, "coast-001", "sea-001", 0.91)
        eco.connect_plants(eco.rootnet, "elder-001", "mirror-001", 0.70)
        eco.corals["coral-001"] = CoralColony(
            colony_id="coral-001",
            name="Royal Asahi Coral Colony",
            district="Coral Coast",
        )
        return eco

    def add_plant(self, plant: FusaPlant) -> None:
        self.plants[plant.plant_id] = plant
        if not plant.alive:
            return
        self.rootnet.add_node(plant.plant_id)
        if plant.lineage in {"sea", "coastal"}:
            self.undersea_rootnet.add_node(plant.plant_id)

    def living_plants(self) -> list[FusaPlant]:
        return [plant for plant in self.plants.values() if plant.alive]

    def connect_plants(
        self,
        network: RootNet,
        left: str,
        right: str,
        conductivity: float,
    ) -> None:
        left_plant = self.plants.get(left)
        right_plant = self.plants.get(right)
        adjusted = conductivity
        if (
            left_plant is not None
            and right_plant is not None
            and left_plant.chirality != right_plant.chirality
        ):
            left_bridge = left_plant.traits.signal_bridge
            right_bridge = right_plant.traits.signal_bridge
            left_bridge = max(
                left_bridge,
                left_plant.expressed_abilities.mirror_bridge,
            )
            right_bridge = max(
                right_bridge,
                right_plant.expressed_abilities.mirror_bridge,
            )
            bridge = (left_bridge + right_bridge) / 2.0
            adjusted *= 0.16 + bridge * 0.42
        network.connect(left, right, adjusted)

    def season_index(self) -> int:
        return ((self.day - 1) // FusaPlant.DAYS_PER_SEASON) % 4

    def generate_solar_state(self) -> SolarState:
        day_lengths = [12.4, 14.5, 11.4, 9.4]
        roll = self._world_rng.random()
        if roll < 0.012:
            condition, modifier = "🌑 Eclipse", 0.10
        elif roll < 0.18:
            condition, modifier = "🌇 Sunset Glow", 0.62
        elif roll < 0.48:
            condition, modifier = "🌤️ Light Cloud", 0.72
        else:
            condition, modifier = "☀️ Clear Sky", 1.00
        irradiance = clamp(self._world_rng.gauss(0.86, 0.10) * modifier, 0.05, 1.10)
        # A quantum-biology-inspired light-harvesting index; this is not a scientific calculation that solves quantum states.
        quantum_harvest = clamp(0.68 + irradiance * 0.27, 0.60, 0.98)
        return SolarState(
            condition=condition,
            day_length=day_lengths[self.season_index()],
            irradiance=irradiance,
            sunset_glow=clamp(self._world_rng.gauss(0.55 if condition == "🌇 Sunset Glow" else 0.28, 0.10), 0.0, 1.0),
            quantum_harvest=quantum_harvest,
        )

    def generate_shared_weather(self, solar: SolarState) -> Weather:
        living = self.living_plants()
        if not living:
            raise RuntimeError("there are no living organisms, so shared weather cannot be generated.")
        base = living[0].generate_weather(self.season_index())
        sunlight = clamp(
            base.sunlight * solar.irradiance * (solar.day_length / 12.0),
            0.0,
            1.2,
        )
        return replace(base, sunlight=sunlight)

    def generate_marine_state(self, weather: Weather) -> MarineState:
        lunar_fraction = (self.day % 29.53) / 29.53
        if lunar_fraction < 0.125 or lunar_fraction >= 0.875:
            moon_phase = "🌑 New Moon"
        elif lunar_fraction < 0.375:
            moon_phase = "🌓 First Quarter"
        elif lunar_fraction < 0.625:
            moon_phase = "🌕 Full Moon"
        else:
            moon_phase = "🌗 Last Quarter"

        spring_tide = (1.0 + math.cos(4.0 * math.pi * lunar_fraction)) / 2.0
        tide = clamp(0.34 + spring_tide * 0.50 + self._world_rng.gauss(0.0, 0.04), 0.05, 1.0)
        sea_temperature = clamp(
            self.marine_state.sea_temperature * 0.82 + weather.temperature * 0.18,
            0.05,
            1.0,
        )
        salinity = clamp(
            self.marine_state.salinity
            + self._world_rng.gauss(0.0, 0.012)
            - weather.rainfall * 0.006,
            0.35,
            0.95,
        )
        nutrients = clamp(
            self.marine_state.nutrients
            + self._world_rng.uniform(-0.018, 0.022)
            + tide * 0.010,
            0.05,
            1.0,
        )
        wave = clamp(weather.wind_speed * 0.55 + tide * 0.32 + self._world_rng.gauss(0.0, 0.06), 0.0, 1.0)
        return MarineState(
            moon_phase=moon_phase,
            moon_fraction=lunar_fraction,
            tide_level=tide,
            sea_temperature=sea_temperature,
            salinity=salinity,
            nutrients=nutrients,
            wave_strength=wave,
        )

    def _elder_signals(self, weather: Weather) -> list[RootSignal]:
        elders = [plant for plant in self.living_plants() if plant.elder]
        if not elders:
            return []
        origin = elders[0].plant_id
        candidates: list[RootSignal] = []
        if weather.rainfall > 0.72:
            candidates.append(RootSignal(self.day, "rain_coming", "Rain from the north.", weather.rainfall, origin, 5))
        if weather.rainfall < 0.22:
            candidates.append(RootSignal(self.day, "water_shortage", "Water runs low.", 1.0 - weather.rainfall, origin, 5))
        if self.infrastructure.pest_pressure > 0.58:
            candidates.append(RootSignal(self.day, "pest_alert", "Movement beneath the leaves.", self.infrastructure.pest_pressure, origin, 4))
        if (self.day - 1) % FusaPlant.DAYS_PER_SEASON == 0:
            candidates.append(RootSignal(self.day, "season_shift", "The season is turning.", 0.55, origin, 5))
        return candidates[:2]

    def _marine_signals(self, marine: MarineState) -> list[RootSignal]:
        origin = next(
            (plant.plant_id for plant in self.living_plants() if plant.lineage == "sea"),
            None,
        )
        if origin is None:
            return []
        signals: list[RootSignal] = []
        if marine.tide_level > 0.72:
            signals.append(RootSignal(self.day, "high_tide", "High tide approaches.", marine.tide_level, origin, 5))
        if marine.nutrients > 0.68:
            signals.append(RootSignal(self.day, "sea_nutrients", "Nutrients arrive from the blue sea.", marine.nutrients, origin, 4))
        return signals[:1]

    def _broadcast(self, network: RootNet, signals: list[RootSignal]) -> None:
        for signal in signals:
            for receipt in network.broadcast(signal):
                plant = self.plants.get(receipt.plant_id)
                if plant is not None and plant.alive and receipt.distance > 0:
                    signal_type = receipt.signal_type
                    strength = receipt.strength
                    origin = self.plants.get(signal.origin_id)
                    if origin is not None and origin.chirality != plant.chirality:
                        bridge = plant.traits.signal_bridge
                        if self.cambrian.active:
                            bridge = max(bridge, plant.abilities.mirror_bridge)
                        strength *= 0.45 + bridge * 0.55
                        if bridge < 0.62 and self._action_rng.random() < 0.28:
                            signal_type = {
                                "rain_coming": "water_shortage",
                                "water_shortage": "rain_coming",
                                "high_tide": "water_shortage",
                            }.get(signal_type, signal_type)
                    plant.receive_signal(signal_type, strength)

    def _coral_cycle(self, solar: SolarState, marine: MarineState) -> float:
        total_energy = 0.0
        for coral in self.corals.values():
            if not coral.alive:
                continue
            light_energy = (
                solar.irradiance
                * solar.quantum_harvest
                * coral.symbiotic_algae
                * 0.055
            )
            coral.stored_energy = clamp(coral.stored_energy + light_energy - 0.018, 0.0, 1.0)
            coral.touch_response = marine.wave_strength
            temperature_stress = max(0.0, marine.sea_temperature - 0.82) + max(
                0.0, 0.20 - marine.sea_temperature
            )
            if temperature_stress > 0:
                coral.health -= temperature_stress * 0.08
                coral.symbiotic_algae -= temperature_stress * 0.05
            else:
                coral.health += 0.004 * marine.nutrients
                coral.symbiotic_algae += 0.002
            coral.health = clamp(coral.health, 0.0, 1.0)
            coral.symbiotic_algae = clamp(coral.symbiotic_algae, 0.0, 1.0)
            coral.alive = coral.health > 0.02
            total_energy += light_energy
        self.marine_state.nutrients = clamp(
            self.marine_state.nutrients + total_energy * 0.04,
            0.0,
            1.0,
        )
        return total_energy

    def _infrastructure_cycle(
        self,
        weather: Weather,
        solar: SolarState,
    ) -> tuple[float, float, float]:
        living = self.living_plants()
        aqua = [plant for plant in living if plant.lineage == "aqua"]
        amber = [plant for plant in living if plant.lineage == "amber"]
        healthy = lambda plant: plant.condition.health * plant.condition.energy

        water_cleaned = sum(0.012 * healthy(plant) * plant.mean_gene.dew_affinity for plant in aqua)
        water_cost = sum(0.010 * (1.25 - plant.condition.hydration) for plant in aqua)
        self.infrastructure.water_quality += water_cleaned
        self.infrastructure.water_reserve += weather.rainfall * 0.06 - water_cost

        autumn = self.season_index() == 2
        fuel_collected = 0.0
        if autumn:
            solar_factor = solar.irradiance * (solar.day_length / 12.0)
            fuel_collected = sum(
                0.10 * healthy(plant) * plant.mean_gene.sunlight_love * solar_factor
                for plant in amber
            )
            self.infrastructure.amber_fuel += fuel_collected

        ladybeetle_activity = 0.020 * len(living) * self.infrastructure.pollination
        spider_warning_bonus = 0.008 * len(self.rootnet.signal_history[-3:])
        pests_removed = ladybeetle_activity + spider_warning_bonus
        self.infrastructure.pest_pressure += self._world_rng.uniform(-0.015, 0.045) - pests_removed
        self.infrastructure.pollination += 0.006 * len(amber) - 0.004 * self.infrastructure.pest_pressure
        self.infrastructure.normalize()
        return water_cleaned, fuel_collected, pests_removed

    def _store_new_seeds(
        self,
        parents: list[FusaPlant],
        reports: list[DailyReport],
    ) -> list[str]:
        stored_ids: list[str] = []
        for parent, report in zip(parents, reports):
            if report.seed is None:
                continue
            seed_id = f"seed-{self.next_seed_serial:07d}"
            self.next_seed_serial += 1
            packet = StoredSeed(
                seed_id=seed_id,
                seed=report.seed,
                parent_id=parent.plant_id,
                lineage=parent.lineage,
                district=parent.district,
                stored_day=self.day,
                chirality=parent.chirality,
                traits=self._inherit_traits(parent),
                abilities=self._inherit_abilities(parent),
                propagule_kind=(
                    "spore"
                    if parent.lineage in {"sea", "coastal"}
                    or parent.expressed_abilities.bioluminescence >= 0.42
                    else "seed"
                ),
            )
            self.seed_inventory.append(packet)
            stored_ids.append(seed_id)
        self.infrastructure.seed_bank = len(self.seed_inventory)
        return stored_ids

    def _inherit_traits(self, parent: FusaPlant) -> FusaTraits:
        values = {}
        for name, value in parent.traits.to_dict().items():
            mutation = self._mutation_rng.gauss(0.0, 0.035)
            if self._mutation_rng.random() < 0.018:
                mutation += self._mutation_rng.gauss(0.0, 0.12)
            values[name] = value + mutation
        inherited = FusaTraits.from_dict(values)
        inherited.normalize()
        return inherited

    def _inherit_abilities(self, parent: FusaPlant) -> CambrianAbilities:
        values = {}
        for name, value in parent.abilities.to_dict().items():
            sigma = 0.045 if self.cambrian.active else 0.015
            mutation = self._mutation_rng.gauss(0.0, sigma)
            if self.cambrian.active and self._mutation_rng.random() < 0.025:
                mutation += self._mutation_rng.gauss(0.0, 0.14)
            values[name] = value + mutation
        return CambrianAbilities.from_dict(values)

    def _wave_transport_seeds(self, marine: MarineState) -> list[str]:
        moved: list[str] = []
        if marine.wave_strength < 0.55:
            return moved
        for packet in self.seed_inventory:
            coastal_source = packet.lineage in {"sea", "coastal", "aqua"} or "coast" in packet.district.lower()
            if coastal_source and self._mutation_rng.random() < marine.wave_strength * 0.45:
                mobility_bonus = (
                    packet.traits.mobility * 0.20
                    if packet.traits is not None
                    else 0.0
                )
                if self._mutation_rng.random() >= clamp(0.55 + mobility_bonus, 0.0, 0.95):
                    continue
                packet.location = "shore"
                packet.district = "Intertidal Zone"
                moved.append(packet.seed_id)
                self.movement_history.append({
                    "day": self.day,
                    "type": "seed",
                    "subject_id": packet.seed_id,
                    "from": "seed_bank",
                    "to": "Intertidal Zone",
                })
        return moved

    @staticmethod
    def _life_state_snapshot(plant: FusaPlant) -> dict[str, float]:
        return {
            "health": plant.condition.health,
            "hydration": plant.condition.hydration,
            "energy": plant.condition.energy,
            "damage": plant.condition.damage,
            "hunger": plant.needs.hunger,
            "thirst": plant.needs.thirst,
            "security": plant.needs.security,
            "alert": plant.needs.alert,
            "drought_memory": plant.memory.drought,
            "shade_memory": plant.memory.shade,
            "cold_memory": plant.memory.cold,
            "heat_memory": plant.memory.heat,
            "salinity_memory": plant.memory.salinity,
            "biohazard_load": plant.biohazard_load,
        }

    @staticmethod
    def _report_state_snapshot(condition: Any, biohazard_load: float) -> dict[str, float]:
        return {
            "health": condition.health,
            "hydration": condition.hydration,
            "energy": condition.energy,
            "damage": condition.damage,
            "biohazard_load": biohazard_load,
        }

    @staticmethod
    def _condition_delta_text(before: Any, after: Any) -> str:
        labels = (
            ("vitality", "health"),
            ("water", "hydration"),
            ("energy", "energy"),
            ("damage", "damage"),
        )
        changes = [
            f"{label}{getattr(after, field) - getattr(before, field):+.3f}"
            for label, field in labels
            if abs(getattr(after, field) - getattr(before, field)) >= 0.0005
        ]
        return " / ".join(changes) if changes else "state change ±0.000"

    def _sync_life_needs(
        self,
        plant: FusaPlant,
        stress_intensity: float,
    ) -> None:
        degree = len(self.rootnet.links.get(plant.plant_id, {}))
        trust_values = [
            relation.trust for relation in plant.relationships.values()
        ]
        mean_trust = statistics.fmean(trust_values) if trust_values else 0.5
        security_target = clamp(
            0.18
            + min(degree, 4) * 0.12
            + mean_trust * 0.28
            - plant.biohazard_load * 0.55,
            0.0,
            1.0,
        )
        alert_target = clamp(
            max(
                stress_intensity,
                plant.condition.damage,
                plant.biohazard_load,
            ),
            0.0,
            1.0,
        )
        plant.needs.hunger = clamp(
            plant.needs.hunger * 0.58
            + (1.0 - plant.condition.energy) * 0.42,
            0.0,
            1.0,
        )
        plant.needs.thirst = clamp(
            plant.needs.thirst * 0.58
            + (1.0 - plant.condition.hydration) * 0.42,
            0.0,
            1.0,
        )
        plant.needs.security = clamp(
            plant.needs.security * 0.70 + security_target * 0.30,
            0.0,
            1.0,
        )
        plant.needs.alert = clamp(
            plant.needs.alert * 0.62 + alert_target * 0.38,
            0.0,
            1.0,
        )

    def choose_life_action(
        self,
        plant: FusaPlant,
        *,
        noise: bool = True,
    ) -> tuple[str, str, dict[str, float]]:
        needs = plant.needs
        temperament = plant.temperament
        scores = {
            "seek_water": (
                needs.thirst * 0.70
                + temperament.exploration * 0.25
                + plant.memory.drought * 0.08
            ),
            "rest": (
                needs.alert * 0.50
                + temperament.caution * 0.45
                + (1.0 - plant.condition.health) * 0.18
            ),
            "request_help": (
                max(needs.hunger, needs.thirst) * 0.30
                + temperament.cooperation * 0.35
                + (1.0 - needs.security) * 0.10
            ),
            "hoard": (
                needs.hunger * 0.55
                + needs.thirst * 0.10
                + temperament.hoarding * 0.35
            ),
            "return_home": (
                (1.0 - needs.security) * 0.35
                + temperament.homing * 0.55
                + (0.10 if plant.parent_id is not None else 0.0)
            ),
        }
        need_level = max(needs.hunger, needs.thirst)
        if need_level < 0.25:
            scores["request_help"] -= 0.35
            scores["hoard"] -= 0.35
        if plant.parent_id is None:
            scores["return_home"] = -1.0
        elif plant.parent_id in self.rootnet.links.get(plant.plant_id, {}):
            scores["return_home"] -= 0.55
        for action, score in list(scores.items()):
            memory = plant.decision_memory.get(action, {})
            success = min(3, int(memory.get("success", 0)))
            failure = min(3, int(memory.get("failure", 0)))
            history_adjustment = success * 0.010 - failure * 0.030
            random_adjustment = self._action_rng.uniform(-0.025, 0.025) if noise else 0.0
            scores[action] = score + history_adjustment + random_adjustment
        action = max(scores, key=lambda name: (scores[name], name))
        reasons = {
            "seek_water": (
                f"thirst {needs.thirst:.2f} / exploration {temperament.exploration:.2f}"
            ),
            "rest": (
                f"alertness {needs.alert:.2f} / caution {temperament.caution:.2f}"
            ),
            "request_help": (
                f"deficit {max(needs.hunger, needs.thirst):.2f} / "
                f"cooperation {temperament.cooperation:.2f}"
            ),
            "hoard": (
                f"hunger {needs.hunger:.2f} / hoarding {temperament.hoarding:.2f}"
            ),
            "return_home": (
                f"security deficit {1.0 - needs.security:.2f} / "
                f"homing {temperament.homing:.2f}"
            ),
        }
        return action, reasons[action], scores

    def _execute_life_action(
        self,
        plant: FusaPlant,
        action: str,
        reason: str,
        weather: Weather,
    ) -> LifeEvent:
        before = self._life_state_snapshot(plant)
        target_id: str | None = None
        outcome = "failure"
        importance = 0.65
        memory_changes: dict[str, float] = {}
        relationship_changes: dict[str, float] = {}
        narrative = ""

        if action == "seek_water":
            amount = min(
                0.12,
                max(0.0, 1.0 - plant.condition.hydration),
                weather.rainfall * 0.045
                + max(0.0, self.infrastructure.water_reserve - 0.10) * 0.080,
            )
            if amount >= 0.025:
                plant.condition.hydration = clamp(
                    plant.condition.hydration + amount,
                    0.0,
                    1.0,
                )
                plant.needs.thirst = clamp(
                    plant.needs.thirst - amount * 1.8,
                    0.0,
                    1.0,
                )
                self.infrastructure.water_reserve = clamp(
                    self.infrastructure.water_reserve - amount * 0.25,
                    0.0,
                    1.0,
                )
                outcome = "success"
                importance = 0.46 if amount < 0.08 else 0.64
                narrative = (
                    f"💧 {plant.name} searched for water and obtained "
                    f"{amount:.3f} water."
                )
            else:
                previous = plant.memory.drought
                plant.memory.learn("drought", 0.20)
                memory_changes["drought"] = plant.memory.drought - previous
                plant.needs.alert = clamp(plant.needs.alert + 0.06, 0.0, 1.0)
                importance = 0.70
                narrative = (
                    f"🌱 {plant.name} searched for water, but "
                    "could not find any."
                )

        elif action == "rest":
            plant.condition.health = clamp(
                plant.condition.health + 0.015,
                0.0,
                1.0,
            )
            plant.condition.energy = clamp(
                plant.condition.energy + 0.025,
                0.0,
                1.0,
            )
            plant.needs.alert = clamp(plant.needs.alert - 0.08, 0.0, 1.0)
            outcome = "success"
            importance = 0.24
            narrative = f"🍃 {plant.name} remained still and rested quietly."

        elif action == "request_help":
            candidates = [
                self.plants[neighbor_id]
                for neighbor_id in self.rootnet.links.get(plant.plant_id, {})
                if neighbor_id in self.plants
                and self.plants[neighbor_id].alive
                and self.plants[neighbor_id].biohazard_load < 0.08
            ]
            helper = max(
                candidates,
                key=lambda candidate: (
                    candidate.temperament.cooperation
                    + plant.relationship_with(candidate.plant_id).trust
                    + candidate.condition.energy
                    + candidate.condition.hydration,
                    candidate.plant_id,
                ),
                default=None,
            )
            if helper is not None:
                energy = min(
                    0.05,
                    max(0.0, helper.condition.energy - 0.35),
                    max(0.0, 1.0 - plant.condition.energy),
                )
                water = min(
                    0.05,
                    max(0.0, helper.condition.hydration - 0.35),
                    max(0.0, 1.0 - plant.condition.hydration),
                )
            else:
                energy = water = 0.0
            if helper is not None and energy + water >= 0.01:
                target_id = helper.plant_id
                helper.condition.energy -= energy
                helper.condition.hydration -= water
                plant.condition.energy = clamp(plant.condition.energy + energy, 0.0, 1.0)
                plant.condition.hydration = clamp(
                    plant.condition.hydration + water,
                    0.0,
                    1.0,
                )
                relation = plant.relationship_with(helper.plant_id)
                old_trust = relation.trust
                previous_help_day = relation.last_interaction_day
                relation.trust = clamp(relation.trust + 0.08, 0.0, 1.0)
                relation.debt = clamp(relation.debt + energy + water, 0.0, 1.0)
                relation.helped_count += 1
                relation.last_interaction_day = self.day
                helper_relation = helper.relationship_with(plant.plant_id)
                helper_relation.trust = clamp(helper_relation.trust + 0.03, 0.0, 1.0)
                helper_relation.last_interaction_day = self.day
                relationship_changes["trust"] = relation.trust - old_trust
                plant.needs.hunger = clamp(plant.needs.hunger - energy * 1.6, 0.0, 1.0)
                plant.needs.thirst = clamp(plant.needs.thirst - water * 1.6, 0.0, 1.0)
                plant.needs.security = clamp(plant.needs.security + 0.08, 0.0, 1.0)
                outcome = "success"
                repeated_recently = (
                    previous_help_day is not None
                    and self.day - previous_help_day <= 3
                )
                importance = (
                    0.54
                    if repeated_recently
                    else (0.80 if energy + water >= 0.04 else 0.60)
                )
                narrative = (
                    f"🌿 {plant.name} requested help from {helper.name} and received "
                    f"{energy:.3f} energy and {water:.3f} water."
                )
            else:
                plant.needs.alert = clamp(plant.needs.alert + 0.04, 0.0, 1.0)
                importance = 0.68
                narrative = (
                    f"🌿 {plant.name} requested help, but "
                    "no organism was able to respond."
                )

        elif action == "hoard":
            water = min(
                0.05,
                max(0.0, self.infrastructure.water_reserve - 0.20) * 0.060,
                max(0.0, 1.0 - plant.condition.hydration),
            )
            energy = min(
                0.07,
                max(0.0, 1.0 - plant.condition.energy),
                weather.sunlight * plant.mean_gene.sunlight_love * 0.060,
            )
            if energy + water >= 0.01:
                self.infrastructure.water_reserve -= water
                plant.condition.hydration = clamp(
                    plant.condition.hydration + water,
                    0.0,
                    1.0,
                )
                plant.condition.energy = clamp(
                    plant.condition.energy + energy,
                    0.0,
                    1.0,
                )
                plant.needs.thirst = clamp(plant.needs.thirst - water, 0.0, 1.0)
                plant.needs.hunger = clamp(plant.needs.hunger - energy * 1.5, 0.0, 1.0)
                outcome = "success"
                importance = 0.34
                narrative = (
                    f"🫙 {plant.name} stored {energy:.3f} light energy and "
                    f"{water:.3f} water as a personal reserve."
                )
            else:
                importance = 0.66
                narrative = f"🫙 {plant.name} could not build a reserve."

        elif action == "return_home":
            parent = self.plants.get(plant.parent_id or "")
            if parent is not None and parent.alive:
                target_id = parent.plant_id
                already_connected = (
                    parent.plant_id in self.rootnet.links.get(plant.plant_id, {})
                )
                compatibility = self.connection_compatibility(plant, parent)
                if already_connected:
                    plant.needs.security = clamp(
                        plant.needs.security + 0.04,
                        0.0,
                        1.0,
                    )
                    outcome = "success"
                    importance = 0.28
                    narrative = (
                        f"🌿 {plant.name} stayed near the hyphae of its parent, "
                        f"{parent.name}."
                    )
                elif (
                    compatibility >= 0.44
                    and parent.biohazard_load < 0.08
                    and plant.biohazard_load < 0.08
                ):
                    old_district = plant.district
                    plant.district = parent.district
                    self.connect_plants(
                        self.rootnet,
                        plant.plant_id,
                        parent.plant_id,
                        0.35 + compatibility * 0.35,
                    )
                    plant.needs.security = clamp(
                        plant.needs.security + 0.12,
                        0.0,
                        1.0,
                    )
                    outcome = "success"
                    importance = 0.68
                    if old_district == parent.district:
                        narrative = (
                            f"🌱 {plant.name} extended a hypha and connected to its "
                            f"parent, {parent.name}."
                        )
                    else:
                        narrative = (
                            f"🌱 {plant.name} returned from {old_district} to "
                            f"{parent.district}, where its parent {parent.name} lives, "
                            "and connected its hypha."
                        )
                else:
                    plant.needs.alert = clamp(
                        plant.needs.alert + 0.05,
                        0.0,
                        1.0,
                    )
                    importance = 0.70
                    narrative = (
                        f"🌱 {plant.name} tried to return to its parent, {parent.name}, "
                        "but its hypha could not reach."
                    )
            else:
                importance = 0.72
                narrative = (
                    f"🌱 {plant.name} searched for its parent but could not find it."
                )

        plant.condition.normalize()
        plant.needs.normalize()
        after = self._life_state_snapshot(plant)
        plant.remember_decision(action, outcome)
        return LifeEvent(
            day=self.day,
            plant_id=plant.plant_id,
            action=action,
            reason=reason,
            outcome=outcome,
            importance=importance,
            narrative=narrative,
            target_id=target_id,
            state_before=before,
            state_after=after,
            memory_changes=memory_changes,
            relationship_changes=relationship_changes,
        )

    def _life_cycle(
        self,
        parents: list[FusaPlant],
        reports: list[DailyReport],
        weather: Weather,
    ) -> list[LifeEvent]:
        candidates: list[LifeEvent] = []
        for plant, report in zip(parents, reports):
            if not plant.alive:
                continue
            stress_intensity = (
                report.stress.effective_intensity
                if report.stress is not None
                else 0.0
            )
            self._sync_life_needs(plant, stress_intensity)
            action, reason, _ = self.choose_life_action(plant)
            event = self._execute_life_action(plant, action, reason, weather)
            self.life_action_counts[action] = self.life_action_counts.get(action, 0) + 1
            if event.importance >= self.JOURNAL_IMPORTANCE_THRESHOLD:
                candidates.append(event)
        return candidates

    def _biological_cycle(
        self,
        organisms: list[FusaPlant],
        weather: Weather,
        solar: SolarState,
        marine: MarineState,
    ) -> dict[str, Any]:
        """Acquire, transport, and metabolize conserved biological resources."""
        active = {plant.plant_id: plant for plant in organisms if plant.alive}
        fluxes = {
            plant_id: BiologicalFlux(
                plant_id=plant_id,
                functional_group=plant.biological_traits.functional_group,
            )
            for plant_id, plant in active.items()
        }
        start = {
            resource: sum(getattr(plant.resources, resource) for plant in active.values())
            for resource in RESOURCE_NAMES
        }
        external = {resource: 0.0 for resource in RESOURCE_NAMES}
        overflow = {resource: 0.0 for resource in RESOURCE_NAMES}
        consumed = {resource: 0.0 for resource in RESOURCE_NAMES}
        transported = {resource: 0.0 for resource in RESOURCE_NAMES}

        for plant_id in sorted(active):
            plant = active[plant_id]
            plant.day = self.day
            traits = plant.biological_traits
            group = traits.functional_group
            photo = (
                weather.sunlight
                * solar.quantum_harvest
                * (solar.day_length / 12.0)
                * traits.photosynthetic_efficiency
                * 0.085
            )
            substrate = (
                self.infrastructure.soil_nutrients
                * traits.substrate_uptake
                * 0.090
            )
            carbon_input = (
                substrate if group == "fungus"
                else photo if group == "alga"
                else photo * 0.62 + substrate * 0.62
            )
            water_input = (
                weather.rainfall * traits.water_uptake * 0.090
                + self.infrastructure.water_reserve * traits.water_uptake * 0.018
            )
            if plant.lineage == "sea":
                water_input += 0.075
            elif plant.lineage == "coastal":
                water_input += marine.tide_level * 0.025
            nitrogen_input = (
                self.infrastructure.soil_nutrients
                * traits.nitrogen_uptake
                * 0.024
            )
            inputs = {
                "carbon": carbon_input,
                "water": water_input,
                "nitrogen": nitrogen_input,
            }
            for resource, amount in inputs.items():
                before = getattr(plant.resources, resource)
                accepted = min(amount, 1.5 - before)
                lost = amount - accepted
                setattr(plant.resources, resource, before + accepted)
                external[resource] += amount
                overflow[resource] += lost
                setattr(fluxes[plant_id], f"{resource}_input", amount)
                fluxes[plant_id].overflow += lost
                cumulative = f"cumulative_{resource}_input"
                setattr(plant.resources, cumulative, getattr(plant.resources, cumulative) + amount)

        edges: dict[tuple[str, str], float] = {}
        for network in (self.rootnet, self.undersea_rootnet):
            for left in sorted(network.links):
                for right, conductivity in sorted(network.links[left].items()):
                    edge = tuple(sorted((left, right)))
                    if left in active and right in active:
                        edges[edge] = max(edges.get(edge, 0.0), conductivity)
        for (left_id, right_id), conductivity in sorted(edges.items()):
            left = active[left_id]
            right = active[right_id]
            compatibility = min(
                left.biological_traits.fusion_compatibility,
                right.biological_traits.fusion_compatibility,
            )
            for resource in RESOURCE_NAMES:
                left_amount = getattr(left.resources, resource)
                right_amount = getattr(right.resources, resource)
                if abs(left_amount - right_amount) <= 0.10:
                    continue
                donor, receiver = (left, right) if left_amount > right_amount else (right, left)
                donor_id, receiver_id = donor.plant_id, receiver.plant_id
                gap = abs(left_amount - right_amount)
                amount = min(
                    (gap - 0.10)
                    * 0.10
                    * conductivity
                    * donor.biological_traits.resource_sharing
                    * compatibility,
                    max(0.0, getattr(donor.resources, resource) - 0.18),
                    max(0.0, 1.5 - getattr(receiver.resources, resource)),
                )
                if amount <= 0.0:
                    continue
                setattr(
                    donor.resources,
                    resource,
                    getattr(donor.resources, resource) - amount,
                )
                setattr(
                    receiver.resources,
                    resource,
                    getattr(receiver.resources, resource) + amount,
                )
                export_name = f"{resource}_export"
                import_name = f"{resource}_import"
                setattr(
                    fluxes[donor_id],
                    export_name,
                    getattr(fluxes[donor_id], export_name) + amount,
                )
                setattr(
                    fluxes[receiver_id],
                    import_name,
                    getattr(fluxes[receiver_id], import_name) + amount,
                )
                donor.resources.cumulative_export += amount
                receiver.resources.cumulative_import += amount
                transported[resource] += amount

        deaths: list[dict[str, str]] = []
        for plant_id in sorted(active):
            plant = active[plant_id]
            traits = plant.biological_traits
            size_factor = 0.72 + min(1.0, plant.fusa_level / 100.0) * 0.38
            demands = {
                "carbon": traits.maintenance_rate * size_factor,
                "water": 0.015 * size_factor * (1.0 - traits.desiccation_tolerance * 0.35),
                "nitrogen": 0.0055 * size_factor,
            }
            unmet: dict[str, float] = {}
            for resource, demand in demands.items():
                available = getattr(plant.resources, resource)
                used = min(available, demand)
                setattr(plant.resources, resource, available - used)
                consumed[resource] += used
                unmet[resource] = max(0.0, demand - used) / max(demand, 1e-12)
                setattr(fluxes[plant_id], f"{resource}_maintenance", used)
            plant.resources.cumulative_maintenance += sum(demands.values()) - sum(
                unmet[resource] * demands[resource] for resource in RESOURCE_NAMES
            )
            for resource in RESOURCE_NAMES:
                streak_name = f"{resource}_deficit_days"
                streak = getattr(plant.resources, streak_name)
                setattr(
                    plant.resources,
                    streak_name,
                    streak + 1 if unmet[resource] > 0.10 else max(0, streak - 1),
                )
            streaks = [
                plant.resources.carbon_deficit_days,
                plant.resources.water_deficit_days,
                plant.resources.nitrogen_deficit_days,
            ]
            damage = min(0.10, sum(max(0, days - 3) for days in streaks) * 0.0025)
            if damage:
                plant.condition.health -= damage
                plant.condition.damage += damage * 0.70
                fluxes[plant_id].deficiency_damage = damage
            plant.condition.energy = plant.resources.carbon / 1.5
            plant.condition.hydration = plant.resources.water / 1.5
            plant.condition.normalize()
            reason = deficit_reason(plant.resources)
            if reason is not None and plant.condition.health <= 0.18:
                plant.mark_dead(reason)
                deaths.append({"plant_id": plant_id, "reason": reason})

        end = {
            resource: sum(getattr(plant.resources, resource) for plant in active.values())
            for resource in RESOURCE_NAMES
        }
        balance_error = {
            resource: start[resource] + external[resource] - overflow[resource]
            - consumed[resource] - end[resource]
            for resource in RESOURCE_NAMES
        }
        summary = {
            "day": self.day,
            "functional_groups": {
                group: sum(
                    plant.biological_traits.functional_group == group
                    for plant in active.values()
                )
                for group in ("fungus", "alga", "symbiotic")
            },
            "start_pool": start,
            "external_input": external,
            "overflow": overflow,
            "maintenance_consumption": consumed,
            "end_pool_before_growth": end,
            "transported": transported,
            "transfer_balance_error": 0.0,
            "mass_balance_error": balance_error,
            "deaths": deaths,
            "fluxes": [fluxes[plant_id].to_dict() for plant_id in sorted(fluxes)],
        }
        self.biological_history.append(summary)
        return summary

    def _environment_life_events(
        self,
        reports: list[DailyReport],
    ) -> list[LifeEvent]:
        """Rather than impressions of the environment, create journal candidates from detected loads and actual differences."""
        events: list[LifeEvent] = []
        stress_narratives = {
            "drought": "endured drought",
            "strong_wind": "was buffeted by strong wind",
            "shade": "experienced a day of insufficient sunlight",
            "heat": "was exposed to extreme heat",
            "cold": "endured low temperature",
            "touch": "experienced strong contact",
            "salinity": "was exposed to unsuitable salinity",
        }
        for report in reports:
            plant = self.plants.get(report.plant_id)
            if plant is None:
                continue
            stress = report.stress
            if stress is not None:
                before = report.condition_before
                after = report.condition_after
                losses = sum(
                    max(0.0, getattr(before, field) - getattr(after, field))
                    for field in ("health", "hydration", "energy")
                )
                if stress.effective_intensity >= 0.58 or losses >= 0.080:
                    memory_before = report.memory_before.get(stress.stress_type)
                    memory_after = report.memory_after.get(stress.stress_type)
                    importance = clamp(
                        0.58 + stress.effective_intensity * 0.15 + losses * 0.35,
                        self.JOURNAL_IMPORTANCE_THRESHOLD,
                        0.84,
                    )
                    description = stress_narratives.get(
                        stress.stress_type,
                        f"{stress.display_name} experienced",
                    )
                    events.append(LifeEvent(
                        day=self.day,
                        plant_id=plant.plant_id,
                        action=f"environment_{stress.stress_type}",
                        reason=(
                            f"load {stress.intensity:.2f} / "
                            f"after tolerance {stress.effective_intensity:.2f}"
                        ),
                        outcome="stress",
                        importance=importance,
                        narrative=(
                            f"{stress.display_name} {plant.name} {description}."
                            f"Actual daily change: "
                            f"{self._condition_delta_text(before, after)}."
                        ),
                        state_before=self._report_state_snapshot(
                            before,
                            plant.biohazard_load,
                        ),
                        state_after=self._report_state_snapshot(
                            after,
                            plant.biohazard_load,
                        ),
                        memory_changes={
                            stress.stress_type: memory_after - memory_before,
                        },
                    ))

            if (
                plant.lineage == "coastal"
                and self.marine_state.tide_level < 0.20
                and (stress is None or stress.stress_type != "salinity")
            ):
                before = report.condition_before
                after = report.condition_after
                events.append(LifeEvent(
                    day=self.day,
                    plant_id=plant.plant_id,
                    action="environment_missed_tide",
                    reason=(
                        f"tide level {self.marine_state.tide_level:.2f} / "
                        f"sea salinity {self.marine_state.salinity:.2f}"
                    ),
                    outcome="failure",
                    importance=0.67,
                    narrative=(
                        f"🌊 The tide did not sufficiently reach {plant.name}. "
                        f"Actual daily change: "
                        f"{self._condition_delta_text(before, after)}."
                    ),
                    state_before=self._report_state_snapshot(
                        before,
                        plant.biohazard_load,
                    ),
                    state_after=self._report_state_snapshot(
                        after,
                        plant.biohazard_load,
                    ),
                ))
        representatives: dict[str, LifeEvent] = {}
        for event in events:
            previous = representatives.get(event.action)
            if previous is None or event.importance > previous.importance:
                representatives[event.action] = event
        return list(representatives.values())

    def _biosecurity_life_events(
        self,
        before_states: dict[str, dict[str, float]],
        result: dict[str, Any],
    ) -> list[LifeEvent]:
        """Create biosecurity journal candidates from measured hazard loads and severed links."""
        events: list[LifeEvent] = []
        outbreak_origins = {
            str(item["origin_id"]): str(item["outbreak_id"])
            for item in self.outbreak_history
            if item.get("started_day") == self.day
            and item.get("outbreak_id") in result["new_outbreaks"]
        }
        quarantined = set(result["quarantines"])
        severed_counts: dict[str, int] = {}
        for item in result["severed"]:
            if item.get("cause") != "biosecurity quarantine":
                continue
            for plant_id in (str(item["left"]), str(item["right"])):
                severed_counts[plant_id] = severed_counts.get(plant_id, 0) + 1

        for plant_id, before in before_states.items():
            plant = self.plants.get(plant_id)
            if plant is None:
                continue
            after = self._life_state_snapshot(plant)
            load_delta = after["biohazard_load"] - before["biohazard_load"]
            if plant_id in outbreak_origins:
                cuts = severed_counts.get(plant_id, 0)
                suffix = f" RootNet links: {cuts} severed." if cuts else ""
                events.append(LifeEvent(
                    day=self.day,
                    plant_id=plant_id,
                    action="biosecurity_toxic_mutation",
                    reason=f"origin {outbreak_origins[plant_id]}",
                    outcome="failure",
                    importance=0.97,
                    narrative=(
                        f"☠️ {plant.name} developed a highly toxic mutation, and its "
                        f"hazard load rose from {before['biohazard_load']:.3f} to "
                        f"{after['biohazard_load']:.3f}.{suffix}"
                    ),
                    state_before=before,
                    state_after=after,
                ))
            elif plant_id in quarantined:
                cuts = severed_counts.get(plant_id, 0)
                events.append(LifeEvent(
                    day=self.day,
                    plant_id=plant_id,
                    action="biosecurity_quarantine",
                    reason=f"hazard load {after['biohazard_load']:.3f}",
                    outcome="contained",
                    importance=0.92,
                    narrative=(
                        f"🛡️ {plant.name} received a hazardous load and was quarantined. "
                        f"To prevent spread, {cuts} RootNet links were severed."
                    ),
                    state_before=before,
                    state_after=after,
                ))
            elif load_delta >= 0.025:
                events.append(LifeEvent(
                    day=self.day,
                    plant_id=plant_id,
                    action="biosecurity_exposure",
                    reason=f"hazard-load difference {load_delta:+.3f}",
                    outcome="failure",
                    importance=0.82,
                    narrative=(
                        f"🦠 {plant.name} received a load that bypassed the biosecurity network, "
                        f"raising its hazard load from {before['biohazard_load']:.3f} to "
                        f"{after['biohazard_load']:.3f}."
                    ),
                    state_before=before,
                    state_after=after,
                ))

        for item in result["reconnected"]:
            left_id = str(item.get("left", item.get("from")))
            right_id = str(item.get("right", item.get("to")))
            left = self.plants.get(left_id)
            right = self.plants.get(right_id)
            if left is None or right is None:
                continue
            events.append(LifeEvent(
                day=self.day,
                plant_id=left_id,
                target_id=right_id,
                action="biosecurity_reconnection",
                reason="hazard load decreased after quarantine",
                outcome="success",
                importance=0.80,
                narrative=(
                    f"🌱 After recovering, {left.name} and {right.name} "
                    "reconnected their previously severed RootNet link."
                ),
                state_before=before_states.get(left_id, {}),
                state_after=self._life_state_snapshot(left),
            ))
        return events

    def _record_life_events(
        self,
        candidates: list[LifeEvent],
    ) -> list[LifeEvent]:
        candidates = [
            event
            for event in candidates
            if event.importance >= self.JOURNAL_IMPORTANCE_THRESHOLD
        ]
        recent_signatures = {
            (event.plant_id, event.action, event.outcome)
            for event in self.life_journal
            if self.day - event.day <= self.JOURNAL_REPEAT_COOLDOWN
        }
        recent_environment_actions = {
            event.action
            for event in self.life_journal
            if event.action.startswith("environment_")
            and self.day - event.day <= self.JOURNAL_ENVIRONMENT_COOLDOWN
        }
        candidates = [
            event
            for event in candidates
            if (
                (event.plant_id, event.action, event.outcome)
                not in recent_signatures
                or event.importance >= 0.85
            )
            and not (
                event.action.startswith("environment_")
                and event.action in recent_environment_actions
                and event.importance < 0.85
            )
        ]
        selected = sorted(
            candidates,
            key=lambda event: (-event.importance, event.plant_id),
        )[:self.MAX_JOURNAL_EVENTS_PER_DAY]
        self.life_journal.extend(selected)
        return selected

    def carrying_capacity(self) -> int:
        coral_health = (
            sum(coral.health for coral in self.corals.values()) / len(self.corals)
            if self.corals
            else 0.0
        )
        capacity = (
            16
            + int(self.infrastructure.water_quality * 35)
            + int(self.infrastructure.water_reserve * 25)
            + int(self.infrastructure.soil_nutrients * 45)
            + int(self.marine_state.nutrients * 20)
            + int(coral_health * 14)
            + int(self.solar_state.irradiance * 10)
            - int(self.infrastructure.pest_pressure * 12)
        )
        return min(self.MAX_LIVING_PLANTS, max(16, capacity))

    def _seed_can_germinate(self, packet: StoredSeed) -> bool:
        age = self.day - packet.stored_day
        if age < self.MIN_GERMINATION_AGE:
            return False
        if len(self.living_plants()) >= self.carrying_capacity():
            return False
        if self.infrastructure.water_quality < 0.35:
            return False
        if self.infrastructure.water_reserve < 0.25:
            return False
        if self.infrastructure.pest_pressure >= 0.75:
            return False
        if packet.lineage == "sea":
            return 0.45 <= self.marine_state.salinity <= 0.90 and self.marine_state.nutrients >= 0.25
        if packet.lineage == "coastal":
            return self.marine_state.tide_level >= 0.25
        return self.infrastructure.soil_nutrients >= 0.20

    def _germinate_seed_inventory(self) -> list[str]:
        germinated_seed_ids: set[str] = set()
        new_ids: list[str] = []
        for packet in list(self.seed_inventory):
            if not self._seed_can_germinate(packet):
                continue
            chance = 0.28 + self.infrastructure.soil_nutrients * 0.32
            if packet.location == "shore":
                chance += self.marine_state.nutrients * 0.16
            if self._action_rng.random() >= clamp(chance, 0.15, 0.88):
                continue

            parent = self.plants.get(packet.parent_id)
            plant_id = f"sprout-{self.next_plant_serial:06d}"
            self.next_plant_serial += 1
            ancestor_id = (
                parent.ancestor_id if parent is not None else packet.parent_id
            )
            child = FusaPlant(
                name=packet.seed.name,
                plant_id=plant_id,
                lineage=packet.lineage,
                district=packet.district,
                elder=False,
                generation=packet.seed.generation,
                genes=packet.seed.genes,
                memory=packet.seed.memory.primed_copy(1.0),
                parent_id=packet.parent_id,
                ancestor_id=ancestor_id,
                birth_day=self.day,
                chirality=packet.chirality,
                traits=packet.traits,
                abilities=packet.abilities,
                **{
                    f"{stream_name}_seed": stream_seed
                    for stream_name, stream_seed in self.plant_stream_seeds(plant_id).items()
                },
            )
            # Synchronize seasons with the community calendar, not organism age.
            child.day = self.day
            self.add_plant(child)
            if parent is not None:
                parent.child_ids.append(child.plant_id)
            if child.lineage in {"sea", "coastal"}:
                marine_neighbor = next(
                    (
                        plant.plant_id
                        for plant in self.living_plants()
                        if plant.plant_id != child.plant_id
                        and plant.lineage in {"sea", "coastal"}
                    ),
                    None,
                )
                if marine_neighbor is not None:
                    self.connect_plants(
                        self.undersea_rootnet,
                        marine_neighbor,
                        child.plant_id,
                        0.82,
                    )
            germinated_seed_ids.add(packet.seed_id)
            new_ids.append(child.plant_id)

        self.seed_inventory = [
            packet
            for packet in self.seed_inventory
            if packet.seed_id not in germinated_seed_ids
        ]
        self.infrastructure.seed_bank = len(self.seed_inventory)
        return new_ids

    def _decomposition_cycle(self, weather: Weather) -> float:
        returned_total = 0.0
        for plant in self.plants.values():
            if plant.alive or plant.corpse_stage == "record only":
                continue
            moisture = (weather.rainfall + self.infrastructure.water_reserve) / 2.0
            speed = clamp(0.012 + weather.temperature * 0.012 + moisture * 0.010, 0.008, 0.040)
            if plant.chirality == "D":
                speed *= 0.28
            previous = plant.decomposition_progress
            plant.decomposition_progress = clamp(previous + speed, 0.0, 1.0)
            decomposed = plant.decomposition_progress - previous
            soil_gain = decomposed * (0.10 + plant.fusa_level / 1000.0)
            plant.soil_returned += soil_gain
            returned_total += soil_gain
            self.infrastructure.soil_nutrients += soil_gain
            if plant.lineage == "amber":
                self.infrastructure.amber_fuel += decomposed * 0.30
            if plant.lineage in {"sea", "coastal"}:
                self.marine_state.nutrients += decomposed * 0.05
            if plant.decomposition_progress >= 1.0:
                plant.corpse_stage = "record only"
            elif plant.decomposition_progress >= 0.55:
                plant.corpse_stage = "returning to soil"
            else:
                plant.corpse_stage = "dead organism"
        self.infrastructure.normalize()
        self.marine_state.nutrients = clamp(self.marine_state.nutrients, 0.0, 1.0)
        return returned_total

    def lineage_tree_data(self) -> list[dict[str, Any]]:
        return [
            {
                "plant_id": plant.plant_id,
                "name": plant.name,
                "parent_id": plant.parent_id,
                "ancestor_id": plant.ancestor_id,
                "child_ids": list(plant.child_ids),
                "generation": plant.generation,
                "lineage": plant.lineage,
                "chirality": plant.chirality,
                "traits": plant.traits.to_dict(),
                "active_traits": plant.traits.active_names(),
                "abilities": plant.abilities.to_dict(),
                "expressed_abilities": plant.expressed_abilities.to_dict(),
                "active_abilities": plant.expressed_abilities.active_names(),
                "biohazard_load": plant.biohazard_load,
                "quarantine_until": plant.quarantine_until,
                "biological_traits": plant.biological_traits.to_dict(),
                "functional_group": plant.biological_traits.functional_group,
                "resources": plant.resources.to_dict(),
                "elder": plant.elder,
                "birth_day": plant.birth_day,
                "death_day": plant.death_day,
                "alive": plant.alive,
            }
            for plant in self.plants.values()
        ]

    def diversity_metrics(self) -> dict[str, float]:
        living = self.living_plants()
        if len(living) < 2:
            return {
                "category_entropy": 0.0,
                "mean_pairwise_distance": 0.0,
                "composite": 0.0,
            }

        def normalized_entropy(values: list[str], possible_categories: int) -> float:
            counts = {value: values.count(value) for value in set(values)}
            entropy = -sum(
                (count / len(values)) * math.log(count / len(values))
                for count in counts.values()
            )
            return entropy / math.log(possible_categories) if possible_categories > 1 else 0.0

        rows: list[list[float]] = []
        for plant in living:
            gene = plant.mean_gene
            rows.append([
                gene.growth_speed / 1.8,
                gene.dew_affinity / 1.8,
                gene.wind_resistance / 1.8,
                gene.sunlight_love / 2.0,
                gene.patience / 2.0,
                *plant.traits.to_dict().values(),
                *plant.abilities.to_dict().values(),
            ])
        pairwise_distances = [
            math.sqrt(sum((left[index] - right[index]) ** 2 for index in range(len(left))))
            / math.sqrt(len(left))
            for left_index, left in enumerate(rows)
            for right in rows[left_index + 1:]
        ]
        numeric_distance = clamp(statistics.fmean(pairwise_distances) * 2.4, 0.0, 1.0)
        category_entropy = (
            normalized_entropy([plant.lineage for plant in living], len(LINEAGE_NAMES))
            + normalized_entropy([plant.chirality for plant in living], 2)
        ) / 2.0
        composite = clamp(
            category_entropy * 0.50 + numeric_distance * 0.50,
            0.0,
            1.0,
        )
        return {
            "category_entropy": category_entropy,
            "mean_pairwise_distance": numeric_distance,
            "composite": composite,
        }

    def genetic_diversity(self) -> float:
        return self.diversity_metrics()["composite"]

    def rootnet_metrics(self) -> dict[str, float]:
        living_ids = {plant.plant_id for plant in self.living_plants()}
        return self.rootnet.metrics(living_ids)

    def connection_compatibility(self, left: FusaPlant, right: FusaPlant) -> float:
        same_lineage = 1.0 if left.lineage == right.lineage else 0.0
        same_chirality = 1.0 if left.chirality == right.chirality else 0.0
        symbiosis = (left.traits.symbiosis + right.traits.symbiosis) / 2.0
        bridge = (
            left.expressed_abilities.mirror_bridge
            + right.expressed_abilities.mirror_bridge
        ) / 2.0
        return clamp(
            0.22
            + same_lineage * 0.20
            + same_chirality * 0.20
            + symbiosis * 0.25
            + bridge * 0.13,
            0.0,
            1.0,
        )

    def _cambrian_audit(self) -> dict[str, Any]:
        living = self.living_plants()
        max_generation = max((plant.generation for plant in living), default=0)
        diversity_metrics = self.diversity_metrics()
        diversity = diversity_metrics["composite"]
        network_metrics = self.rootnet_metrics()
        recent_water = self.water_quality_history[-10:]
        stable_water = (
            len(recent_water) >= 10
            and min(recent_water) >= 0.55
            and max(recent_water) - min(recent_water) <= 0.18
        )
        return {
            "max_generation": max_generation,
            "generation_ready": max_generation >= 3,
            "living_plants": len(living),
            "population_ready": len(living) >= 18,
            "genetic_diversity": round(diversity, 6),
            "diversity_metrics": {
                name: round(value, 6)
                for name, value in diversity_metrics.items()
            },
            "diversity_ready": diversity >= 0.45,
            "water_quality": round(self.infrastructure.water_quality, 6),
            "stable_water_ready": stable_water,
            "rootnet_metrics": {
                name: round(value, 6)
                for name, value in network_metrics.items()
            },
            "rootnet_functional_score": round(network_metrics["functional_score"], 6),
            "rootnet_ready": (
                network_metrics["largest_component_ratio"] >= 0.60
                and network_metrics["isolate_rate"] <= 0.35
                and network_metrics["reachability"] >= 0.35
            ),
        }

    def _check_cambrian_start(self) -> bool:
        audit = self._cambrian_audit()
        self.cambrian.last_audit = audit
        if self.cambrian.active:
            return False
        ready = all([
            audit["generation_ready"],
            audit["population_ready"],
            audit["diversity_ready"],
            audit["stable_water_ready"],
            audit["rootnet_ready"],
        ])
        if not ready:
            return False
        self.cambrian.active = True
        self.cambrian.started_day = self.day
        self.cambrian.unlocked_abilities = list(CambrianAbilities().to_dict())
        return True

    def _false_signal_cycle(self) -> list[RootSignal]:
        if not self.cambrian.active:
            return []
        generated: list[RootSignal] = []
        choices = [
            ("water_shortage", "The water has vanished."),
            ("rain_coming", "Rain comes from the wrong direction."),
            ("pest_alert", "A shadow lies beneath the leaves."),
        ]
        for plant in self.living_plants():
            ability = plant.expressed_abilities.false_signal
            if ability < 0.10 or self._action_rng.random() >= ability * 0.045:
                continue
            signal_type, message = choices[self._action_rng.randrange(len(choices))]
            signal = RootSignal(
                self.day,
                signal_type,
                f"False signal: '{message}'",
                ability * 0.55,
                plant.plant_id,
                3,
            )
            generated.append(signal)
            self._broadcast(self.rootnet, [signal])
        return generated

    def _movement_cycle(self) -> list[dict[str, Any]]:
        land_districts = ["Central Garden", "Western Field", "Watergate District", "Sunlit Hill", "Coral Coast"]
        sea_districts = ["Shallow-Sea Garden", "Intertidal Zone", "Coral Coast"]
        movements: list[dict[str, Any]] = []
        for plant in self.living_plants():
            ability = plant.expressed_abilities.mobility
            if ability < 0.25 or self._action_rng.random() >= ability * 0.055:
                continue
            choices = sea_districts if plant.lineage in {"sea", "coastal"} else land_districts
            destination = choices[self._action_rng.randrange(len(choices))]
            if destination == plant.district:
                continue
            movement = {
                "type": "walk",
                "subject_id": plant.plant_id,
                "from": plant.district,
                "to": destination,
            }
            plant.district = destination
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})

        for packet in self.seed_inventory:
            if packet.propagule_kind != "spore":
                continue
            if self._action_rng.random() >= 0.025 + self.marine_state.wave_strength * 0.035:
                continue
            choices = sea_districts if packet.lineage in {"sea", "coastal"} else land_districts
            destination = choices[self._action_rng.randrange(len(choices))]
            if destination == packet.district:
                continue
            movement = {
                "type": "spore",
                "subject_id": packet.seed_id,
                "from": packet.district,
                "to": destination,
            }
            packet.district = destination
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})

        living = self.living_plants()
        for plant in living:
            if plant.biohazard_load >= 0.08 or self.day < plant.quarantine_until:
                continue
            ability = max(
                plant.expressed_abilities.deep_rooting,
                plant.traits.deep_rooting * 0.75,
            )
            isolated_bonus = 0.030 if not self.rootnet.links.get(plant.plant_id) else 0.0
            if ability < 0.18 or self._action_rng.random() >= isolated_bonus + ability * 0.040:
                continue
            candidates = [
                other
                for other in living
                if other.plant_id != plant.plant_id
                and other.plant_id not in self.rootnet.links.get(plant.plant_id, {})
                and other.district == plant.district
                and other.biohazard_load < 0.08
                and self.day >= other.quarantine_until
                and self.connection_compatibility(plant, other) >= 0.44
            ]
            if not candidates:
                continue
            other = candidates[self._action_rng.randrange(len(candidates))]
            self.connect_plants(
                self.rootnet,
                plant.plant_id,
                other.plant_id,
                0.42 + ability * 0.35,
            )
            movement = {
                "type": "hypha",
                "subject_id": plant.plant_id,
                "from": plant.plant_id,
                "to": other.plant_id,
            }
            movements.append(movement)
            self.movement_history.append({"day": self.day, **movement})
        return movements

    def _sever_link(
        self,
        left: str,
        right: str,
        cause: str,
        retry_after: int,
    ) -> dict[str, Any] | None:
        conductivity = self.rootnet.disconnect(left, right)
        if conductivity is None:
            return None
        pair = tuple(sorted((left, right)))
        if not any(
            tuple(sorted((item["left"], item["right"]))) == pair
            for item in self.severed_links
        ):
            self.severed_links.append({
                "left": pair[0],
                "right": pair[1],
                "conductivity": conductivity,
                "severed_day": self.day,
                "retry_day": self.day + retry_after,
                "cause": cause,
            })
        return {
            "left": pair[0],
            "right": pair[1],
            "cause": cause,
        }

    def introduce_toxic_mutation(
        self,
        plant_id: str,
        load: float = 1.0,
    ) -> str:
        """Introduce a highly toxic mutation into one organism for a test or narrative event."""
        plant = self.plants[plant_id]
        outbreak_id = f"outbreak-{len(self.outbreak_history) + 1:05d}"
        plant.biohazard_load = clamp(load, 0.0, 1.0)
        plant.biohazard_origin = outbreak_id
        self.outbreak_history.append({
            "outbreak_id": outbreak_id,
            "origin_id": plant_id,
            "started_day": self.day,
            "population_at_start": len(self.living_plants()),
            "affected_ids": [plant_id],
            "max_affected": 1,
            "resolved_day": None,
        })
        return outbreak_id

    def _link_maintenance_cycle(self, weather: Weather) -> list[dict[str, Any]]:
        severed: list[dict[str, Any]] = []
        edges = [
            (left, right, conductivity)
            for left, links in self.rootnet.links.items()
            for right, conductivity in links.items()
            if left < right
        ]
        dryness = max(0.0, 0.32 - weather.rainfall)
        for left, right, conductivity in edges:
            left_plant = self.plants.get(left)
            right_plant = self.plants.get(right)
            if left_plant is None or right_plant is None:
                continue
            damage = (left_plant.condition.damage + right_plant.condition.damage) / 2.0
            repair = (
                left_plant.traits.symbiosis + right_plant.traits.symbiosis
            ) * 0.00045
            next_value = conductivity + repair - dryness * 0.0022 - damage * 0.0007
            if weather.wind_speed > 1.05 and self._mutation_rng.random() < 0.018:
                next_value -= 0.22
            if next_value < 0.18:
                event = self._sever_link(left, right, "environmental damage", 10)
                if event is not None:
                    severed.append(event)
                continue
            value = clamp(next_value, 0.05, 1.0)
            self.rootnet.links[left][right] = value
            self.rootnet.links[right][left] = value
        return severed

    def _reconnection_cycle(self) -> list[dict[str, Any]]:
        reconnected: list[dict[str, Any]] = []
        remaining: list[dict[str, Any]] = []
        for item in self.severed_links:
            left = self.plants.get(item["left"])
            right = self.plants.get(item["right"])
            ready = (
                left is not None
                and right is not None
                and left.alive
                and right.alive
                and self.day >= int(item["retry_day"])
                and self.day >= left.quarantine_until
                and self.day >= right.quarantine_until
                and left.biohazard_load < 0.06
                and right.biohazard_load < 0.06
                and self.connection_compatibility(left, right) >= 0.44
            )
            if not ready:
                remaining.append(item)
                continue
            restored = clamp(float(item["conductivity"]) * 0.82, 0.20, 0.90)
            self.connect_plants(self.rootnet, left.plant_id, right.plant_id, restored)
            event = {
                "type": "reconnect",
                "subject_id": left.plant_id,
                "from": left.plant_id,
                "to": right.plant_id,
                "cause": item["cause"],
            }
            reconnected.append(event)
            self.movement_history.append({"day": self.day, **event})
        self.severed_links = remaining
        return reconnected

    def _biosecurity_metrics(self) -> dict[str, float]:
        living = self.living_plants()
        active = sum(plant.biohazard_load >= 0.05 for plant in living)
        quarantined = sum(self.day < plant.quarantine_until for plant in living)
        containment_values = [
            1.0 - (
                max(0, int(item["max_affected"]) - 1)
                / max(1, int(item["population_at_start"]) - 1)
            )
            for item in self.outbreak_history
        ]
        return {
            "active_hazard_rate": active / max(1, len(living)),
            "quarantine_rate": quarantined / max(1, len(living)),
            "pending_severed_links": float(len(self.severed_links)),
            "mean_containment_rate": (
                statistics.fmean(containment_values)
                if containment_values
                else 1.0
            ),
        }

    def _biosecurity_cycle(
        self,
        allow_new_mutations: bool = True,
    ) -> dict[str, Any]:
        new_outbreaks: list[str] = []
        quarantines: list[str] = []
        severed: list[dict[str, Any]] = []

        if allow_new_mutations and self.cambrian.active:
            for plant in self.living_plants():
                chance = plant.toxin_potential * 0.00120
                if plant.biohazard_load < 0.02 and self._mutation_rng.random() < chance:
                    new_outbreaks.append(
                        self.introduce_toxic_mutation(
                            plant.plant_id,
                            self._mutation_rng.uniform(0.62, 0.92),
                        )
                    )

        exposures: dict[str, tuple[float, str]] = {}
        for source in self.living_plants():
            if source.biohazard_load < 0.10 or source.biohazard_origin is None:
                continue
            for neighbor_id, conductivity in self.rootnet.links.get(source.plant_id, {}).items():
                target = self.plants.get(neighbor_id)
                if target is None or not target.alive:
                    continue
                amount = (
                    source.biohazard_load
                    * conductivity
                    * 0.18
                    * (1.0 - target.biosecurity_resistance * 0.55)
                )
                previous = exposures.get(neighbor_id)
                if previous is None or amount > previous[0]:
                    exposures[neighbor_id] = (amount, source.biohazard_origin)

        for plant_id, (amount, origin) in exposures.items():
            plant = self.plants[plant_id]
            plant.biohazard_load = clamp(plant.biohazard_load + amount, 0.0, 1.0)
            plant.biohazard_origin = plant.biohazard_origin or origin
            for outbreak in self.outbreak_history:
                if outbreak["outbreak_id"] != origin:
                    continue
                affected = set(outbreak["affected_ids"])
                affected.add(plant_id)
                outbreak["affected_ids"] = sorted(affected)
                outbreak["max_affected"] = max(
                    int(outbreak["max_affected"]),
                    len(affected),
                )
                break

        for plant in self.living_plants():
            if plant.biohazard_load <= 0.0:
                continue
            harm = max(0.0, plant.biohazard_load - 0.12) * 0.012
            plant.condition.health = clamp(plant.condition.health - harm, 0.0, 1.0)
            plant.condition.energy = clamp(plant.condition.energy - harm * 0.8, 0.0, 1.0)
            if plant.biohazard_load >= 0.32 and self.rootnet.links.get(plant.plant_id):
                plant.quarantine_until = max(plant.quarantine_until, self.day + 12)
                quarantines.append(plant.plant_id)
                for neighbor_id in list(self.rootnet.links.get(plant.plant_id, {})):
                    event = self._sever_link(
                        plant.plant_id,
                        neighbor_id,
                        "biosecurity quarantine",
                        12,
                    )
                    if event is not None:
                        severed.append(event)
            recovery_factor = clamp(
                0.82 - plant.biosecurity_resistance * 0.18,
                0.58,
                0.82,
            )
            plant.biohazard_load *= recovery_factor
            if plant.biohazard_load < 0.02:
                plant.biohazard_load = 0.0
                plant.biohazard_origin = None
            if plant.condition.health <= 0.02:
                plant.mark_dead("toxic load")

        active_origins = {
            plant.biohazard_origin
            for plant in self.living_plants()
            if plant.biohazard_origin is not None
        }
        for outbreak in self.outbreak_history:
            if (
                outbreak["resolved_day"] is None
                and outbreak["outbreak_id"] not in active_origins
            ):
                outbreak["resolved_day"] = self.day

        reconnected = self._reconnection_cycle()
        result = {
            "new_outbreaks": new_outbreaks,
            "quarantines": quarantines,
            "severed": severed,
            "reconnected": reconnected,
            "metrics": self._biosecurity_metrics(),
        }
        self.biosecurity_history.append({"day": self.day, **result})
        return result

    def _cambrian_interactions(self) -> list[str]:
        if not self.cambrian.active:
            return []
        living = self.living_plants()
        notes: list[str] = []
        for actor in list(living):
            neighbors = [
                self.plants[plant_id]
                for plant_id in self.rootnet.links.get(actor.plant_id, {})
                if plant_id in self.plants and self.plants[plant_id].alive
            ]
            if not neighbors:
                continue
            parasite = actor.expressed_abilities.parasitism
            if parasite >= 0.18 and self._action_rng.random() < parasite * 0.075:
                host = neighbors[self._action_rng.randrange(len(neighbors))]
                defense = host.expressed_abilities.armor
                requested = 0.035 * parasite * (1.0 - defense * 0.65)
                transfer = min(requested, host.condition.energy)
                host.condition.energy -= transfer
                actor.condition.energy = clamp(actor.condition.energy + transfer * 0.75, 0.0, 1.0)
                notes.append(f"{actor.plant_id} parasitized {host.plant_id}")

            predator = actor.expressed_abilities.predation
            if predator >= 0.18 and self._action_rng.random() < predator * 0.060:
                prey = min(neighbors, key=lambda plant: plant.expressed_abilities.armor)
                defense = prey.expressed_abilities.armor
                requested = 0.030 * predator * (1.0 - defense * 0.78)
                damage = min(requested, prey.condition.health)
                prey.condition.health -= damage
                actor.condition.energy = clamp(actor.condition.energy + damage * 0.55, 0.0, 1.0)
                if prey.condition.health <= 0.02:
                    prey.mark_dead("loss caused by predation")
                notes.append(f"{actor.plant_id} -> {prey.plant_id} predation")

        glow = sum(
            plant.expressed_abilities.bioluminescence
            for plant in living
            if plant.expressed_abilities.bioluminescence >= 0.18
        )
        self.infrastructure.pollination += glow * 0.0015
        self.infrastructure.normalize()
        return notes

    def _elect_new_elder(self) -> str | None:
        if any(plant.elder for plant in self.living_plants()):
            return None
        candidates = self.living_plants()
        if not candidates:
            return None

        def score(plant: FusaPlant) -> tuple[float, str]:
            memory_total = sum(plant.memory.to_dict().values())
            degree = len(self.rootnet.links.get(plant.plant_id, {}))
            value = (
                min(plant.age, 1000) * 0.018
                + plant.condition.health * 24.0
                + degree * 3.5
                + memory_total * 4.0
                + plant.mean_gene.patience * 5.0
                + plant.traits.signal_bridge * 8.0
            )
            return value, plant.plant_id

        successor = max(candidates, key=score)
        successor.elder = True
        return successor.plant_id

    def step(self) -> EcosystemReport:
        self.day += 1
        parents = self.living_plants()
        if not parents:
            raise RuntimeError("There are no living organisms; the community lineage has ended.")

        self.solar_state = self.generate_solar_state()
        weather = self.generate_shared_weather(self.solar_state)
        self.marine_state = self.generate_marine_state(weather)
        signals = self._elder_signals(weather)
        marine_signals = self._marine_signals(self.marine_state)
        self._broadcast(self.rootnet, signals)
        self._broadcast(self.undersea_rootnet, marine_signals)

        capacity = self.carrying_capacity()
        pressure = len(parents) / max(1, capacity)
        self.capacity_history.append(capacity)
        biological_organisms = list(parents)
        biological = self._biological_cycle(
            biological_organisms,
            weather,
            self.solar_state,
            self.marine_state,
        )
        parents = [plant for plant in parents if plant.alive]
        reports = [
            plant.daily_growth(
                weather=weather,
                solar=self.solar_state,
                marine=self.marine_state,
                population_pressure=pressure,
                cambrian_active=self.cambrian.active,
            )
            for plant in parents
        ]
        growth_consumption = {
            "carbon": sum(report.growth for report in reports) * 0.012,
            "water": sum(report.growth for report in reports) * 0.006,
            "nitrogen": sum(report.growth for report in reports) * 0.003,
        }
        end_after_growth = {
            resource: sum(
                getattr(plant.resources, resource)
                for plant in biological_organisms
            )
            for resource in RESOURCE_NAMES
        }
        biological["growth_consumption"] = growth_consumption
        biological["end_pool"] = end_after_growth
        biological["mass_balance_error"] = {
            resource: biological["start_pool"][resource]
            + biological["external_input"][resource]
            - biological["overflow"][resource]
            - biological["maintenance_consumption"][resource]
            - growth_consumption[resource]
            - end_after_growth[resource]
            for resource in RESOURCE_NAMES
        }
        life_candidates = self._environment_life_events(reports)
        water, fuel, pests = self._infrastructure_cycle(weather, self.solar_state)
        coral_energy = self._coral_cycle(self.solar_state, self.marine_state)
        stored_seed_ids = self._store_new_seeds(parents, reports)
        wave_moved_seed_ids = self._wave_transport_seeds(self.marine_state)
        new_plant_ids = self._germinate_seed_inventory()
        self.water_quality_history.append(self.infrastructure.water_quality)
        cambrian_started = self._check_cambrian_start()
        false_signals = self._false_signal_cycle()
        movements = self._movement_cycle()
        interactions = self._cambrian_interactions()
        environment_severed = self._link_maintenance_cycle(weather)
        biosecurity_before = {
            plant.plant_id: self._life_state_snapshot(plant)
            for plant in self.living_plants()
        }
        biosecurity = self._biosecurity_cycle()
        biosecurity["severed"] = environment_severed + biosecurity["severed"]
        self.biosecurity_history[-1]["severed"] = list(biosecurity["severed"])
        movements.extend(biosecurity["reconnected"])
        life_candidates.extend(
            self._biosecurity_life_events(biosecurity_before, biosecurity)
        )
        life_events = self._record_life_events(life_candidates)

        deaths: list[tuple[str, str]] = []
        for plant in self.plants.values():
            if plant.alive or plant.death_day != self.day:
                continue
            reason = plant.death_reason or "unknown"
            deaths.append((plant.plant_id, reason))
            self.rootnet.remove_node(plant.plant_id)
            self.undersea_rootnet.remove_node(plant.plant_id)

        elder_successor_id = self._elect_new_elder()
        soil_returned = self._decomposition_cycle(weather)
        network_metrics = self.rootnet_metrics()
        self.event_history.append({
            "day": self.day,
            "solar": self.solar_state.to_dict(),
            "marine": self.marine_state.to_dict(),
            "signals": [signal.to_dict() for signal in signals],
            "marine_signals": [signal.to_dict() for signal in marine_signals],
            "water_quality": self.infrastructure.water_quality,
            "water_reserve": self.infrastructure.water_reserve,
            "soil_nutrients": self.infrastructure.soil_nutrients,
            "amber_fuel": self.infrastructure.amber_fuel,
            "pest_pressure": self.infrastructure.pest_pressure,
            "seed_bank": self.infrastructure.seed_bank,
            "stored_seed_ids": stored_seed_ids,
            "wave_moved_seed_ids": wave_moved_seed_ids,
            "new_plant_ids": new_plant_ids,
            "deaths": [
                {"plant_id": plant_id, "reason": reason}
                for plant_id, reason in deaths
            ],
            "soil_returned": soil_returned,
            "carrying_capacity": capacity,
            "population_pressure": pressure,
            "elder_successor_id": elder_successor_id,
            "cambrian_started": cambrian_started,
            "cambrian_audit": dict(self.cambrian.last_audit),
            "false_signals": [signal.to_dict() for signal in false_signals],
            "movements": movements,
            "interactions": interactions,
            "network_metrics": network_metrics,
            "biosecurity": biosecurity,
            "biological": biological,
            "life_events": [event.to_dict() for event in life_events],
        })
        return EcosystemReport(
            day=self.day,
            weather=weather,
            solar=self.solar_state,
            marine=self.marine_state,
            signals=signals,
            marine_signals=marine_signals,
            plant_reports=reports,
            water_cleaned=water,
            fuel_collected=fuel,
            pests_removed=pests,
            coral_energy=coral_energy,
            stored_seed_ids=stored_seed_ids,
            wave_moved_seed_ids=wave_moved_seed_ids,
            new_plant_ids=new_plant_ids,
            deaths=deaths,
            soil_returned=soil_returned,
            carrying_capacity=capacity,
            population_pressure=pressure,
            elder_successor_id=elder_successor_id,
            cambrian_started=cambrian_started,
            cambrian_audit=dict(self.cambrian.last_audit),
            false_signals=false_signals,
            movements=movements,
            interactions=interactions,
            network_metrics=network_metrics,
            biosecurity=biosecurity,
            life_events=life_events,
            biological=biological,
        )

