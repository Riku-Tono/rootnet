from __future__ import annotations

import math

from .model import Point

Grid = list[list[float]]


def bilinear_weights(point: Point, width: int, height: int) -> list[tuple[int, int, float]]:
    x = min(width - 1.0, max(0.0, float(point[0])))
    y = min(height - 1.0, max(0.0, float(point[1])))
    x0, y0 = math.floor(x), math.floor(y)
    x1, y1 = min(width - 1, x0 + 1), min(height - 1, y0 + 1)
    tx, ty = x - x0, y - y0
    raw = ((x0, y0, (1.0-tx)*(1.0-ty)), (x1, y0, tx*(1.0-ty)),
           (x0, y1, (1.0-tx)*ty), (x1, y1, tx*ty))
    merged: dict[tuple[int, int], float] = {}
    for ix, iy, weight in raw:
        merged[(ix, iy)] = merged.get((ix, iy), 0.0) + weight
    return [(ix, iy, weight) for (ix, iy), weight in sorted(merged.items()) if weight > 0.0]


def sample(grid: Grid, point: Point) -> float:
    height, width = len(grid), len(grid[0]) if grid else 0
    if width == 0:
        raise ValueError("cannot sample an empty field")
    return sum(grid[y][x] * weight for x, y, weight in bilinear_weights(point, width, height))


def withdraw(grid: Grid, point: Point, requested: float) -> float:
    """Withdraw conservatively from the four interpolation cells."""

    height, width = len(grid), len(grid[0]) if grid else 0
    taken = 0.0
    for x, y, weight in bilinear_weights(point, width, height):
        amount = min(grid[y][x], max(0.0, requested) * weight)
        grid[y][x] -= amount
        taken += amount
    return taken


def deposit(grid: Grid, point: Point, amount: float, capacity: Grid | float | None = None) -> float:
    height, width = len(grid), len(grid[0]) if grid else 0
    added = 0.0
    for x, y, weight in bilinear_weights(point, width, height):
        limit = (float("inf") if capacity is None else capacity[y][x]
                 if isinstance(capacity, list) else float(capacity))
        before = grid[y][x]
        grid[y][x] = min(limit, before + max(0.0, amount) * weight)
        added += grid[y][x] - before
    return added
