from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .conductance import (
    audit_edge_weights, normalized_flux_activity, project_bounded_sum,
    update_edge_weights, validate_budget_feasibility,
)
from .environment import (
    ENVIRONMENT_PROFILES, EnvironmentState, arena_center, arena_radius,
    edge_is_damaged, in_circular_arena, in_patch, patch_capacity, state_for_tick,
)
from .field import deposit, sample, withdraw
from .geometry import SpatialIndex, point_at, rotate_point, segments_cross
from .metrics import network_metrics
from .model import (
    Edge, Genet, Genome, HyphalNode, NodeId, Point, Ramet, Spore,
    TRAIT_NAMES, canonical_edge, clamp,
)
from .rng import keyed_rng, stream_seeds


COMMON_ANCESTOR_ID = "ancestor-000000"
TRANSPORT_MODES = ("none", "equalize", "demand", "fixed-equalize", "adaptive-equalize")
EXPERIMENT_TRANSPORT_MODES = ("fixed-equalize", "adaptive-equalize")
ROTATION_ANGLES_DEGREES = (0.0, 22.5, 45.0, 67.5, 90.0)
WATER_FIELD_PROFILES = (
    "v68-radial-lift-0.035",
    "v66-radial",
    "v65-depth-stretched",
)
V68_WATER_CAPACITY_LIFT = 0.035


@dataclass(frozen=True)
class SimulationConfig:
    master_seed: int = 660
    ticks: int = 360
    width: int = 42
    height: int = 42
    founder_count: int = 3
    max_modules_per_ramet: int = 180
    extension_length: float = 1.0
    collision_radius: float = 0.42
    anastomosis_radius: float = 1.08
    rotation_angle_degrees: float = 0.0
    mutation_probability: float = 0.20
    mutation_sigma: float = 0.032
    substrate_recovery: float = 0.026
    water_recovery: float = 0.060
    detritus_decay: float = 0.11
    detritus_growth_threshold: float = 0.20
    recycling_efficiency: float = 0.35
    vitality_decay: float = 0.22
    vitality_recovery: float = 0.045
    necrosis_grace_ticks: int = 0
    water_field_profile: str = "v68-radial-lift-0.035"
    transport_mode: str = "fixed-equalize"
    transport_rounds: int = 2
    conductance_alpha: float = 0.10
    conductance_weight_min: float = 0.25
    conductance_weight_max: float = 4.0
    conductance_flux_epsilon: float = 1e-15
    conductance_budget_tolerance: float = 1e-12
    environment_profile: str = "persistent-patch"
    environment_move_start_tick: int = 90
    environment_move_end_tick: int = 270
    environment_relocation_tick: int = 180
    environment_damage_tick: int = 180
    nutrient_patch_radius: float = 4.0
    nutrient_background_scale: float = 0.60
    nutrient_patch_boost: float = 0.50
    damage_edge_probability: float = 0.25
    demand_horizon_ticks: int = 2
    internal_anastomosis_scale: float = 0.16
    same_genet_fusion_scale: float = 0.38
    growth_energy_reserve: float = 0.004
    growth_water_reserve: float = 0.0
    spore_viability_ticks: int = 20
    reproduction_min_age: int = 18
    reproduction_min_modules: int = 12
    founder_genome: Genome = field(default_factory=Genome)

    def normalized(self) -> "SimulationConfig":
        width, height = max(12, int(self.width)), max(12, int(self.height))
        mode, profile = str(self.transport_mode).lower(), str(self.environment_profile).lower()
        if mode not in TRANSPORT_MODES:
            raise ValueError(f"transport_mode must be one of {TRANSPORT_MODES}, got {mode!r}")
        if profile not in ENVIRONMENT_PROFILES:
            raise ValueError(f"environment_profile must be one of {ENVIRONMENT_PROFILES}, got {profile!r}")
        water_field_profile = str(self.water_field_profile).lower()
        if water_field_profile not in WATER_FIELD_PROFILES:
            raise ValueError(
                f"water_field_profile must be one of {WATER_FIELD_PROFILES}, "
                f"got {water_field_profile!r}"
            )
        alpha = float(self.conductance_alpha)
        lower, upper = float(self.conductance_weight_min), float(self.conductance_weight_max)
        if not 0.0 <= alpha <= 1.0:
            raise ValueError("conductance_alpha must satisfy 0 <= alpha <= 1")
        if not 0.0 < lower <= 1.0 <= upper:
            raise ValueError("conductance bounds must satisfy 0 < w_min <= 1 <= w_max")
        validate_budget_feasibility(1, 1.0, lower, upper)
        extension_length = max(0.1, float(self.extension_length))
        collision_radius = max(0.01, float(self.collision_radius))
        anastomosis_radius = max(collision_radius, float(self.anastomosis_radius))
        if collision_radius >= extension_length:
            raise ValueError("collision_radius must be smaller than extension_length")
        move_start, move_end = max(0, int(self.environment_move_start_tick)), max(0, int(self.environment_move_end_tick))
        if move_end <= move_start:
            raise ValueError("environment_move_end_tick must be greater than move_start_tick")
        return SimulationConfig(
            master_seed=int(self.master_seed), ticks=max(0, int(self.ticks)),
            width=width, height=height,
            founder_count=max(1, min(int(self.founder_count), 8)),
            max_modules_per_ramet=max(2, int(self.max_modules_per_ramet)),
            extension_length=extension_length, collision_radius=collision_radius,
            anastomosis_radius=anastomosis_radius,
            rotation_angle_degrees=float(self.rotation_angle_degrees) % 360.0,
            mutation_probability=clamp(self.mutation_probability),
            mutation_sigma=max(0.0, float(self.mutation_sigma)),
            substrate_recovery=clamp(self.substrate_recovery),
            water_recovery=clamp(self.water_recovery),
            detritus_decay=clamp(self.detritus_decay),
            detritus_growth_threshold=clamp(self.detritus_growth_threshold),
            recycling_efficiency=clamp(self.recycling_efficiency),
            vitality_decay=max(0.0, float(self.vitality_decay)),
            vitality_recovery=max(0.0, float(self.vitality_recovery)),
            necrosis_grace_ticks=max(0, int(self.necrosis_grace_ticks)),
            water_field_profile=water_field_profile,
            transport_mode=mode, transport_rounds=max(1, int(self.transport_rounds)),
            conductance_alpha=alpha, conductance_weight_min=lower,
            conductance_weight_max=upper,
            conductance_flux_epsilon=max(0.0, float(self.conductance_flux_epsilon)),
            conductance_budget_tolerance=max(1e-15, float(self.conductance_budget_tolerance)),
            environment_profile=profile, environment_move_start_tick=move_start,
            environment_move_end_tick=move_end,
            environment_relocation_tick=max(1, int(self.environment_relocation_tick)),
            environment_damage_tick=max(1, int(self.environment_damage_tick)),
            nutrient_patch_radius=max(0.5, float(self.nutrient_patch_radius)),
            nutrient_background_scale=clamp(self.nutrient_background_scale),
            nutrient_patch_boost=clamp(self.nutrient_patch_boost),
            damage_edge_probability=clamp(self.damage_edge_probability),
            demand_horizon_ticks=max(1, int(self.demand_horizon_ticks)),
            internal_anastomosis_scale=clamp(self.internal_anastomosis_scale),
            same_genet_fusion_scale=clamp(self.same_genet_fusion_scale),
            growth_energy_reserve=max(0.0, float(self.growth_energy_reserve)),
            growth_water_reserve=max(0.0, float(self.growth_water_reserve)),
            spore_viability_ticks=max(1, int(self.spore_viability_ticks)),
            reproduction_min_age=max(1, int(self.reproduction_min_age)),
            reproduction_min_modules=max(2, int(self.reproduction_min_modules)),
            founder_genome=self.founder_genome.normalized(),
        )

    def to_dict(self) -> dict[str, Any]:
        normalized = self.normalized()
        result = asdict(normalized)
        result["founder_genome"] = normalized.founder_genome.to_dict()
        result["arena_shape"] = "circle"
        return result


class ModuleSimulation:
    def __init__(self, config: SimulationConfig) -> None:
        self.config = config.normalized()
        self.rotation_radians = math.radians(self.config.rotation_angle_degrees)
        self.center = arena_center(self.config.width, self.config.height)
        self.stream_seeds = stream_seeds(self.config.master_seed)
        self.tick = 0
        self._next_genet_serial = self._next_ramet_serial = self._next_node_serial = 1
        self._next_spore_serial = 1
        self.base_substrate_capacity, self.water_capacity = self._make_resource_capacities()
        self.substrate_capacity = [row[:] for row in self.base_substrate_capacity]
        self.environment_state = self._environment_state_for_tick(0)
        self._set_substrate_capacity(self.environment_state)
        self.substrate = [row[:] for row in self.substrate_capacity]
        self.water = [row[:] for row in self.water_capacity]
        self.detritus = [[0.0] * self.config.width for _ in range(self.config.height)]
        self.genets: dict[str, Genet] = {}
        self.ramets: dict[str, Ramet] = {}
        self.spatial = SpatialIndex(self.config.anastomosis_radius)
        self.ever_created_nodes: set[NodeId] = set()
        self.spores: list[Spore] = []
        self.tick_records: list[dict[str, Any]] = []
        self.genet_records: list[dict[str, Any]] = []
        self.ramet_records: list[dict[str, Any]] = []
        self.necrosis_records: list[dict[str, Any]] = []
        self.spore_records: list[dict[str, Any]] = []
        self.environment_records: list[dict[str, Any]] = []
        self.extinct_genets: set[str] = set()
        self.max_abs_energy_transport_error = 0.0
        self.max_abs_water_transport_error = 0.0
        self.max_abs_conductance_budget_error = 0.0
        self.conductance_update_count = 0
        self.conductance_strengthened_count = 0
        self.conductance_weakened_count = 0
        self.max_conductance_weight_variance = 0.0
        self.total_environmental_edges_removed = 0
        self.total_environmental_fragments_created = 0
        self.dynamics_stopped_tick: int | None = None
        self.founder_lineage_labels: dict[str, str] = {}
        self.founder_water_budgets: dict[str, dict[str, float | int | str]] = {}
        self.minimum_active_patch_edge_distance = math.inf
        self._make_founders()

    def _rng(self, stream: str, subject: str):
        return keyed_rng(self.stream_seeds[stream], subject)

    def _new_genet_id(self) -> str:
        value = f"genet-{self._next_genet_serial:07d}"
        self._next_genet_serial += 1
        return value

    def _new_ramet_id(self) -> str:
        value = f"ramet-{self._next_ramet_serial:07d}"
        self._next_ramet_serial += 1
        return value

    def _new_node_id(self) -> NodeId:
        value = f"node-{self._next_node_serial:09d}"
        self._next_node_serial += 1
        return value

    def _canonical_point(self, point: Point) -> Point:
        return rotate_point(point, self.center, -self.rotation_radians)

    def _environment_state_for_tick(self, tick: int) -> EnvironmentState:
        return state_for_tick(
            self.config.environment_profile, tick, width=self.config.width,
            height=self.config.height,
            move_start_tick=self.config.environment_move_start_tick,
            move_end_tick=self.config.environment_move_end_tick,
            relocation_tick=self.config.environment_relocation_tick,
            damage_tick=self.config.environment_damage_tick,
            rotation_angle=self.rotation_radians,
        )

    def _base_capacity_at(self, point: Point) -> tuple[float, float]:
        x, y = self._canonical_point(point)
        scale = max(1.0, arena_radius(self.config.width, self.config.height, 0.0))
        nx, ny = (x-self.center[0])/scale, (y-self.center[1])/scale
        radial = math.hypot(nx, ny)
        substrate = clamp(0.56 + 0.15*math.cos(2.3*nx-1.1*ny)
                          + 0.08*math.sin(3.1*(nx+ny)) - 0.08*radial, 0.05, 1.0)
        if self.config.water_field_profile == "v65-depth-stretched":
            reference_x = x * 41.0 / max(1, self.config.width - 1)
            reference_y = y * 17.0 / max(1, self.config.height - 1)
            depth = reference_y / 17.0
            patch = 0.13 * math.sin((reference_x + 1.0) * 0.53) * math.cos(
                (reference_y + 1.0) * 0.39
            )
            dry_patch = 0.08 * math.sin((reference_x + reference_y + 2.0) * 0.31)
            water = clamp(
                0.29 + 0.57 * depth - patch * 0.25 + dry_patch,
                0.08,
                1.0,
            )
        else:
            v66_water = clamp(
                0.55 + 0.12*math.sin(1.7*nx+2.5*ny)
                - 0.05*math.cos(3.3*ny) - 0.05*radial,
                0.08,
                1.0,
            )
            water = (
                clamp(v66_water + V68_WATER_CAPACITY_LIFT, 0.08, 1.0)
                if self.config.water_field_profile == "v68-radial-lift-0.035"
                else v66_water
            )
        return substrate, water

    def _make_resource_capacities(self) -> tuple[list[list[float]], list[list[float]]]:
        substrate, water = [], []
        for y in range(self.config.height):
            s_row, w_row = [], []
            for x in range(self.config.width):
                s, w = self._base_capacity_at((float(x), float(y)))
                s_row.append(s); w_row.append(w)
            substrate.append(s_row); water.append(w_row)
        return substrate, water

    def _set_substrate_capacity(self, state: EnvironmentState) -> None:
        if state.active_patch_center is None:
            self.substrate_capacity = [row[:] for row in self.base_substrate_capacity]
            return
        self.substrate_capacity = [[
            patch_capacity(self.base_substrate_capacity[y][x], (float(x), float(y)),
                           state.active_patch_center, radius=self.config.nutrient_patch_radius,
                           background_scale=self.config.nutrient_background_scale,
                           boost=self.config.nutrient_patch_boost)
            for x in range(self.config.width)] for y in range(self.config.height)]

    def light_at(self, point: Point) -> float:
        _, canonical_y = self._canonical_point(point)
        depth = canonical_y / max(1, self.config.height - 1)
        return clamp(1.0 - depth * 0.95, 0.03, 1.0)

    def in_bounds(self, point: Point, margin: float | None = None) -> bool:
        return in_circular_arena(point, self.config.width, self.config.height,
                                 self.config.collision_radius if margin is None else margin)

    def _register_node(self, ramet_id: str, node: HyphalNode) -> None:
        self.spatial.insert(node.node_id, node.position, ramet_id)
        self.ever_created_nodes.add(node.node_id)

    def _make_founders(self) -> None:
        radius = arena_radius(self.config.width, self.config.height, 2.0)
        for index in range(self.config.founder_count):
            offset = ((index+1)/(self.config.founder_count+1)-0.5) * radius
            canonical = (self.center[0] + offset, self.center[1])
            position = rotate_point(canonical, self.center, self.rotation_radians)
            genet_id, ramet_id, node_id = self._new_genet_id(), self._new_ramet_id(), self._new_node_id()
            heading = self.rotation_radians - math.pi/2.0 + index*math.pi/max(1, self.config.founder_count-1)
            genet = Genet(genet_id, COMMON_ANCESTOR_ID, genet_id, 0,
                          self.config.founder_genome, position)
            node = HyphalNode(node_id, position, 0, heading, energy=0.72, water=0.52)
            ramet = Ramet(ramet_id, genet_id, 0, node_id, nodes={node_id: node}, created_by="founder")
            self.genets[genet_id], self.ramets[ramet_id] = genet, ramet
            self._register_node(ramet_id, node)
            label = f"founder-{index + 1}"
            self.founder_lineage_labels[genet.lineage_id] = label
            self.founder_water_budgets[label] = {
                "founder_genet_id": genet_id,
                "lineage_id": genet.lineage_id,
                "module_ticks": 0,
                "water_required": 0.0,
                "water_paid": 0.0,
                "water_deficit": 0.0,
                "water_limited_module_ticks": 0,
            }
            self.genet_records.append({"event": "established", **genet.to_dict(), "mutated_loci": []})
            self.ramet_records.append({"event": "created", "tick": 0, **self._ramet_identity(ramet)})

    @staticmethod
    def _ramet_identity(ramet: Ramet) -> dict[str, Any]:
        return {
            "ramet_id": ramet.ramet_id, "genet_id": ramet.genet_id,
            "birth_tick": ramet.birth_tick, "origin_node_id": ramet.origin_node_id,
            "origin": list(ramet.origin), "parent_ramet_id": ramet.parent_ramet_id,
            "created_by": ramet.created_by,
        }

    def living_ramets(self) -> list[Ramet]:
        return sorted((r for r in self.ramets.values() if r.alive and r.nodes), key=lambda r: r.ramet_id)

    def living_genet_ids(self) -> set[str]:
        return {r.genet_id for r in self.living_ramets()}

    def _node(self, node_id: NodeId) -> HyphalNode:
        return self.ramets[self.spatial.owner(node_id)].nodes[node_id]

    def _edge_positions(self, ramet: Ramet, edge: Edge) -> tuple[Point, Point]:
        return ramet.nodes[edge[0]].position, ramet.nodes[edge[1]].position

    def _edge_length(self, ramet: Ramet, edge: Edge) -> float:
        return math.dist(*self._edge_positions(ramet, edge))

    def _replenish_and_decay(self) -> None:
        for y in range(self.config.height):
            for x in range(self.config.width):
                self.substrate[y][x] += (self.substrate_capacity[y][x]-self.substrate[y][x])*self.config.substrate_recovery
                self.water[y][x] += (self.water_capacity[y][x]-self.water[y][x])*self.config.water_recovery
                self.detritus[y][x] = max(0.0, self.detritus[y][x]-self.config.detritus_decay)

    def _absorb_local(self, ramet: Ramet) -> tuple[float, float, float, float]:
        phenotype = self.genets[ramet.genet_id].phenotype
        substrate_taken = water_taken = light_energy = active_patch_taken = 0.0
        for node_id in sorted(ramet.nodes):
            node = ramet.nodes[node_id]
            local_s, local_w = sample(self.substrate, node.position), sample(self.water, node.position)
            requested_s = 0.012*phenotype.substrate_absorption*(0.22+local_s)
            requested_w = 0.007*(0.32+phenotype.desiccation_tolerance)*(0.30+local_w)
            s_take = withdraw(self.substrate, node.position, requested_s)
            w_take = withdraw(self.water, node.position, requested_w)
            l_gain = 0.0048*self.light_at(node.position)*phenotype.light_capture
            node.energy, node.water = min(1.60, node.energy+s_take*2.45+l_gain), min(1.10, node.water+w_take)
            substrate_taken += s_take; water_taken += w_take; light_energy += l_gain
            if in_patch(node.position, self.environment_state.active_patch_center,
                        self.config.nutrient_patch_radius):
                active_patch_taken += s_take
        return substrate_taken, water_taken, light_energy, active_patch_taken

    def _demand_target(self, ramet: Ramet, node_id: NodeId, field_name: str) -> float:
        phenotype = self.genets[ramet.genet_id].phenotype
        if field_name == "energy":
            maintenance, extension = phenotype.maintenance_energy, phenotype.extension_cost+self.config.growth_energy_reserve
        elif field_name == "water":
            maintenance, extension = phenotype.maintenance_water, phenotype.extension_water+self.config.growth_water_reserve
        else:
            raise ValueError(f"unsupported transport field: {field_name}")
        return self.config.demand_horizon_ticks*maintenance + (extension if node_id in ramet.tips else 0.0)

    def _prepare_edge_weights(self, ramet: Ramet) -> None:
        current = {edge: float(ramet.edge_weights.get(edge, 1.0)) for edge in sorted(ramet.edges)
                   if edge[0] in ramet.nodes and edge[1] in ramet.nodes}
        if self.config.transport_mode == "adaptive-equalize":
            ramet.edge_weights = project_bounded_sum(current, float(len(current)),
                self.config.conductance_weight_min, self.config.conductance_weight_max,
                tolerance=self.config.conductance_budget_tolerance)
        else:
            ramet.edge_weights = {edge: 1.0 for edge in current}

    def _transport_field_detailed(self, ramet: Ramet, field_name: str,
                                  conductance: float, max_edge_flux: float
                                  ) -> tuple[float, float, float, dict[Edge, float]]:
        before = sum(getattr(node, field_name) for node in ramet.nodes.values())
        if self.config.transport_mode == "none":
            return 0.0, 0.0, 0.0, {}
        proposals: list[tuple[Edge, NodeId, NodeId, float]] = []
        outgoing: dict[NodeId, float] = {}
        for edge in sorted(ramet.edges):
            left, right = edge
            if left not in ramet.nodes or right not in ramet.nodes:
                continue
            left_stock, right_stock = getattr(ramet.nodes[left], field_name), getattr(ramet.nodes[right], field_name)
            length_factor = self.config.extension_length/max(self._edge_length(ramet, edge), 1e-12)
            if self.config.transport_mode in ("equalize", "fixed-equalize", "adaptive-equalize"):
                difference = left_stock-right_stock
                if abs(difference) < 1e-15:
                    continue
                donor, receiver = (left, right) if difference > 0.0 else (right, left)
                weight = ramet.edge_weights.get(edge, 1.0) if self.config.transport_mode == "adaptive-equalize" else 1.0
                amount = min(abs(difference)*conductance*weight*length_factor, max_edge_flux)
            else:
                left_balance = left_stock-self._demand_target(ramet, left, field_name)
                right_balance = right_stock-self._demand_target(ramet, right, field_name)
                if left_balance > 0.0 > right_balance:
                    donor, receiver, surplus, deficit = left, right, left_balance, -right_balance
                elif right_balance > 0.0 > left_balance:
                    donor, receiver, surplus, deficit = right, left, right_balance, -left_balance
                else:
                    continue
                amount = min((surplus+deficit)*conductance*length_factor, max_edge_flux, surplus, deficit)
            proposals.append((edge, donor, receiver, amount))
            outgoing[donor] = outgoing.get(donor, 0.0)+amount
        scale = {}
        for donor, total in outgoing.items():
            available = getattr(ramet.nodes[donor], field_name)
            if self.config.transport_mode == "demand":
                available = max(0.0, available-self._demand_target(ramet, donor, field_name))
            scale[donor] = min(1.0, available/total) if total > 0.0 else 1.0
        delta = {node_id: 0.0 for node_id in ramet.nodes}
        moved = tip_received = 0.0
        absolute_fluxes: dict[Edge, float] = {}
        for edge, donor, receiver, amount in proposals:
            actual = amount*scale[donor]
            delta[donor] -= actual; delta[receiver] += actual; moved += actual
            absolute_fluxes[edge] = absolute_fluxes.get(edge, 0.0)+abs(actual)
            if receiver in ramet.tips:
                tip_received += actual
        for node_id, change in delta.items():
            node = ramet.nodes[node_id]
            setattr(node, field_name, max(0.0, getattr(node, field_name)+change))
        after = sum(getattr(node, field_name) for node in ramet.nodes.values())
        return moved, after-before, tip_received, absolute_fluxes

    def _transport(self, ramet: Ramet) -> tuple[float, float, float, float, float, float]:
        phenotype = self.genets[ramet.genet_id].phenotype
        self._prepare_edge_weights(ramet)
        before_weights = dict(ramet.edge_weights)
        fluxes: dict[str, dict[Edge, float]] = {"energy": {}, "water": {}}
        energy_moved = water_moved = energy_error = water_error = 0.0
        tip_energy = tip_water = 0.0
        for _ in range(self.config.transport_rounds):
            moved, error, tip, edge_flux = self._transport_field_detailed(ramet, "energy", phenotype.energy_conductance, 0.060)
            energy_moved += moved; energy_error += error; tip_energy += tip
            for edge, value in edge_flux.items(): fluxes["energy"][edge] = fluxes["energy"].get(edge, 0.0)+value
            moved, error, tip, edge_flux = self._transport_field_detailed(ramet, "water", phenotype.water_conductance, 0.035)
            water_moved += moved; water_error += error; tip_water += tip
            for edge, value in edge_flux.items(): fluxes["water"][edge] = fluxes["water"].get(edge, 0.0)+value
        if self.config.transport_mode == "adaptive-equalize" and ramet.edges:
            activity = normalized_flux_activity(ramet.edges, fluxes, epsilon=self.config.conductance_flux_epsilon)
            ramet.edge_weights = update_edge_weights(ramet.edge_weights, activity,
                alpha=self.config.conductance_alpha, lower=self.config.conductance_weight_min,
                upper=self.config.conductance_weight_max,
                tolerance=self.config.conductance_budget_tolerance)
            self.conductance_update_count += 1
            self.conductance_strengthened_count += sum(ramet.edge_weights[e] > before_weights[e]+self.config.conductance_budget_tolerance for e in ramet.edge_weights)
            self.conductance_weakened_count += sum(ramet.edge_weights[e] < before_weights[e]-self.config.conductance_budget_tolerance for e in ramet.edge_weights)
            audit = audit_edge_weights(ramet.edge_weights, lower=self.config.conductance_weight_min,
                                       upper=self.config.conductance_weight_max,
                                       tolerance=self.config.conductance_budget_tolerance)
            self.max_abs_conductance_budget_error = max(self.max_abs_conductance_budget_error, abs(float(audit["budget_error"])))
            self.max_conductance_weight_variance = max(self.max_conductance_weight_variance, float(audit["weight_variance"]))
        self.max_abs_energy_transport_error = max(self.max_abs_energy_transport_error, abs(energy_error))
        self.max_abs_water_transport_error = max(self.max_abs_water_transport_error, abs(water_error))
        return energy_moved, water_moved, energy_error, water_error, tip_energy, tip_water

    def _maintain(self, ramet: Ramet) -> dict[str, float | int]:
        phenotype = self.genets[ramet.genet_id].phenotype
        lineage_id = self.genets[ramet.genet_id].lineage_id
        founder_label = self.founder_lineage_labels.get(lineage_id)
        totals: dict[str, float | int] = {
            "module_ticks": 0,
            "energy_required": 0.0,
            "energy_paid": 0.0,
            "water_required": 0.0,
            "water_paid": 0.0,
            "energy_limited_module_ticks": 0,
            "water_limited_module_ticks": 0,
            "grace_module_ticks": 0,
            "vitality_decay_module_ticks": 0,
        }
        for node in ramet.nodes.values():
            energy_paid, water_paid = min(node.energy, phenotype.maintenance_energy), min(node.water, phenotype.maintenance_water)
            node.energy -= energy_paid; node.water -= water_paid
            energy_deficit = 1.0-energy_paid/phenotype.maintenance_energy
            water_deficit = 1.0-water_paid/phenotype.maintenance_water
            deficit = max(energy_deficit, water_deficit)
            totals["module_ticks"] += 1
            totals["energy_required"] += phenotype.maintenance_energy
            totals["energy_paid"] += energy_paid
            totals["water_required"] += phenotype.maintenance_water
            totals["water_paid"] += water_paid
            if energy_deficit > 1e-12:
                totals["energy_limited_module_ticks"] += 1
            if water_deficit > 1e-12:
                totals["water_limited_module_ticks"] += 1
            if founder_label is not None:
                budget = self.founder_water_budgets[founder_label]
                budget["module_ticks"] = int(budget["module_ticks"]) + 1
                budget["water_required"] = float(budget["water_required"]) + phenotype.maintenance_water
                budget["water_paid"] = float(budget["water_paid"]) + water_paid
                budget["water_deficit"] = float(budget["water_deficit"]) + max(
                    0.0, phenotype.maintenance_water - water_paid
                )
                if water_deficit > 1e-12:
                    budget["water_limited_module_ticks"] = int(
                        budget["water_limited_module_ticks"]
                    ) + 1
            if deficit > 1e-12:
                node.starvation_ticks += 1
                if node.starvation_ticks <= self.config.necrosis_grace_ticks:
                    totals["grace_module_ticks"] += 1
                else:
                    totals["vitality_decay_module_ticks"] += 1
                    node.vitality = max(0.0, node.vitality-self.config.vitality_decay*deficit)
            else:
                if self.config.necrosis_grace_ticks > 0:
                    node.starvation_ticks = 0
                else:
                    node.starvation_ticks = max(0, node.starvation_ticks-1)
                node.vitality = min(1.0, node.vitality+self.config.vitality_recovery)
            node.age += 1
        return totals

    def _active_patch_edge_distance(self) -> float | None:
        center = self.environment_state.active_patch_center
        if center is None:
            return None
        distances = [
            max(0.0, math.dist(node.position, center) - self.config.nutrient_patch_radius)
            for ramet in self.living_ramets()
            for node in ramet.nodes.values()
        ]
        return min(distances, default=None)

    def _connected_components(self, ramet: Ramet) -> list[set[NodeId]]:
        adjacency = {node_id: set() for node_id in ramet.nodes}
        for left, right in ramet.edges:
            if left in adjacency and right in adjacency:
                adjacency[left].add(right); adjacency[right].add(left)
        remaining, components = set(adjacency), []
        while remaining:
            start = min(remaining); stack = [start]; component = {start}; remaining.remove(start)
            while stack:
                current = stack.pop()
                for neighbor in sorted(adjacency[current]):
                    if neighbor in remaining:
                        remaining.remove(neighbor); component.add(neighbor); stack.append(neighbor)
            components.append(component)
        return sorted(components, key=lambda c: (-len(c), min(c)))

    def _end_ramet(self, ramet: Ramet, reason: str, *, is_death: bool,
                   identity: dict[str, Any] | None = None) -> None:
        ramet.alive, ramet.end_tick, ramet.end_reason = False, self.tick, reason
        self.ramet_records.append({"event": "died" if is_death else "ended", "tick": self.tick,
                                   "reason": reason, **(identity or self._ramet_identity(ramet))})

    def _split_if_disconnected(self, ramet: Ramet, *, created_by: str = "fragmentation") -> list[str]:
        if not ramet.alive or len(ramet.nodes) < 2:
            return []
        components = self._connected_components(ramet)
        if len(components) <= 1:
            return []
        old_nodes, old_edges, old_weights, old_tips = ramet.nodes, ramet.edges, ramet.edge_weights, ramet.tips
        keep = components[0]
        ramet.nodes = {n: old_nodes[n] for n in keep}
        ramet.edges = {e for e in old_edges if e[0] in keep and e[1] in keep}
        ramet.edge_weights = {e: old_weights.get(e, 1.0) for e in ramet.edges}
        ramet.tips = (old_tips & keep) | {n for n in keep if sum(n in e for e in ramet.edges) <= 1}
        ramet.origin_node_id = min(keep)
        created = []
        for component in components[1:]:
            ramet_id = self._new_ramet_id()
            fragment = Ramet(ramet_id, ramet.genet_id, self.tick, min(component),
                parent_ramet_id=ramet.ramet_id, created_by=created_by,
                nodes={n: old_nodes[n] for n in component},
                edges={e for e in old_edges if e[0] in component and e[1] in component},
                edge_weights={e: old_weights.get(e, 1.0) for e in old_edges if e[0] in component and e[1] in component},
                tips=(old_tips & component))
            fragment.tips |= {n for n in component if sum(n in e for e in fragment.edges) <= 1}
            self.ramets[ramet_id] = fragment
            for node_id in component: self.spatial.set_owner(node_id, ramet_id)
            self.ramet_records.append({"event": "created", "tick": self.tick, **self._ramet_identity(fragment)})
            created.append(ramet_id)
        return created

    def _apply_environment_transition(self) -> tuple[list[dict[str, Any]], list[str]]:
        previous, current = self.environment_state, self._environment_state_for_tick(self.tick)
        self.environment_state = current; self._set_substrate_capacity(current)
        events: list[dict[str, Any]] = []; fragments: list[str] = []
        if current.profile != "legacy" and (current.active_patch_center != previous.active_patch_center or current.phase != previous.phase):
            events.append({"event": "resource_schedule_changed", "tick": self.tick,
                "profile": current.profile, "phase": current.phase,
                "previous_patch_center": list(previous.active_patch_center) if previous.active_patch_center else None,
                "active_patch_center": list(current.active_patch_center) if current.active_patch_center else None})
        if current.damage_due:
            removed_records = []
            for ramet in list(self.living_ramets()):
                removed = [e for e in sorted(ramet.edges) if edge_is_damaged(
                    self.stream_seeds["environment"], e, event_tick=self.tick,
                    probability=self.config.damage_edge_probability)]
                for edge in removed:
                    p1, p2 = self._edge_positions(ramet, edge)
                    ramet.edges.remove(edge); ramet.edge_weights.pop(edge, None)
                    removed_records.append({"ramet_id": ramet.ramet_id, "genet_id": ramet.genet_id,
                                            "edge": list(edge), "positions": [list(p1), list(p2)]})
                if removed:
                    fragments.extend(self._split_if_disconnected(ramet, created_by="environmental_edge_damage"))
            self.total_environmental_edges_removed += len(removed_records)
            self.total_environmental_fragments_created += len(fragments)
            events.append({"event": "environmental_edge_damage", "tick": self.tick,
                "profile": current.profile, "selection_rule": "stable-edge-id Bernoulli field",
                "probability": self.config.damage_edge_probability,
                "removed_edge_count": len(removed_records), "removed_edges": removed_records,
                "fragments_created": list(fragments), "module_deaths": 0})
        self.environment_records.extend(events)
        return events, fragments

    def _conductance_share_near(self, center: Point | None) -> float | None:
        if center is None:
            return None
        nearby = total = 0.0
        for ramet in self.living_ramets():
            for edge in sorted(ramet.edges):
                weight = ramet.edge_weights.get(edge, 1.0) if self.config.transport_mode == "adaptive-equalize" else 1.0
                total += weight
                if any(in_patch(ramet.nodes[n].position, center, self.config.nutrient_patch_radius) for n in edge):
                    nearby += weight
        return nearby/total if total else 0.0

    def _largest_ramet_fraction(self) -> float:
        sizes = [len(r.nodes) for r in self.living_ramets()]
        return max(sizes, default=0)/sum(sizes) if sum(sizes) else 0.0

    def _prune_necrotic(self, ramet: Ramet) -> tuple[list[NodeId], list[str], bool]:
        dead = sorted(n for n, node in ramet.nodes.items() if node.vitality <= 0.0)
        if not dead:
            return [], [], False
        identity_before_pruning = self._ramet_identity(ramet)
        for node_id in dead:
            node = ramet.nodes.pop(node_id); self.spatial.remove(node_id)
            recycled = deposit(self.substrate, node.position,
                               0.055*self.config.recycling_efficiency, self.substrate_capacity)
            deposit(self.detritus, node.position, 1.0, 1.0)
            self.necrosis_records.append({"tick": self.tick, "ramet_id": ramet.ramet_id,
                "genet_id": ramet.genet_id, "node_id": node_id, "position": list(node.position),
                "node_age": node.age, "starvation_ticks": node.starvation_ticks,
                "recycled_substrate": recycled})
        ramet.edges = {e for e in ramet.edges if e[0] in ramet.nodes and e[1] in ramet.nodes}
        ramet.edge_weights = {e: ramet.edge_weights.get(e, 1.0) for e in ramet.edges}
        ramet.tips &= set(ramet.nodes)
        ramet.tips |= {n for n in ramet.nodes if sum(n in e for e in ramet.edges) <= 1}
        if not ramet.nodes:
            self._end_ramet(ramet, "all_modules_necrotic", is_death=True,
                            identity=identity_before_pruning)
            return dead, [], True
        if ramet.origin_node_id not in ramet.nodes: ramet.origin_node_id = min(ramet.nodes)
        return dead, self._split_if_disconnected(ramet), False

    def _growth_score(self, point: Point, phenotype) -> float:
        return (sample(self.substrate, point)*phenotype.substrate_absorption
                + sample(self.water, point)*phenotype.desiccation_tolerance*0.45
                + self.light_at(point)*phenotype.light_capture)

    def _growth_candidate_draw(
        self,
        ramet_id: str,
        tip_id: NodeId,
        attempt: int,
        candidate_index: int,
    ) -> tuple[float, float]:
        """Return event-keyed heading offset and score jitter for one candidate."""

        subject = (
            f"candidate|tick:{self.tick}|ramet:{ramet_id}|tip:{tip_id}"
            f"|attempt:{attempt}|candidate:{candidate_index}"
        )
        candidate_rng = self._rng("growth", subject)
        return candidate_rng.gauss(0.0, math.pi/3.0), candidate_rng.uniform(0.0, 0.14)

    def _segment_clear(self, source_id: NodeId, target: Point) -> bool:
        source = self._node(source_id).position
        for ramet in self.living_ramets():
            for edge in ramet.edges:
                if source_id in edge:
                    continue
                left, right = self._edge_positions(ramet, edge)
                if segments_cross(source, target, left, right):
                    return False
        return True

    def _grow(self, ramet: Ramet) -> tuple[int, int]:
        if not ramet.alive or len(ramet.nodes) >= self.config.max_modules_per_ramet:
            return 0, 0
        phenotype = self.genets[ramet.genet_id].phenotype
        rng = self._rng("growth", f"tick:{self.tick}|ramet:{ramet.ramet_id}")
        attempts = 1+int(rng.random() < phenotype.extension_rate*0.55)
        grown = loops = 0
        for attempt in range(attempts):
            eligible = [n for n in sorted(ramet.tips)
                        if ramet.nodes[n].energy > phenotype.extension_cost+self.config.growth_energy_reserve
                        and ramet.nodes[n].water > phenotype.extension_water+self.config.growth_water_reserve
                        and ramet.nodes[n].vitality > 0.35]
            if not eligible: break
            tip_id = eligible[rng.randrange(len(eligible))]; tip = ramet.nodes[tip_id]
            candidates: list[tuple[float, float, Point]] = []
            for candidate_index in range(9):
                heading_offset, score_jitter = self._growth_candidate_draw(
                    ramet.ramet_id, tip_id, attempt, candidate_index
                )
                heading = tip.heading + heading_offset
                point = point_at(tip.position, heading, self.config.extension_length)
                if not self.in_bounds(point): continue
                if self.spatial.query(point, self.config.collision_radius, exclude=(tip_id,)): continue
                if sample(self.detritus, point) >= self.config.detritus_growth_threshold: continue
                if not self._segment_clear(tip_id, point): continue
                score = self._growth_score(point, phenotype)+score_jitter
                candidates.append((score, heading, point))
            if not candidates:
                ramet.tips.discard(tip_id); continue
            _, heading, position = max(candidates, key=lambda item: (item[0], -abs(item[1]-tip.heading)))
            length = math.dist(tip.position, position)
            tip.energy -= phenotype.extension_cost*(length/self.config.extension_length)
            tip.water -= phenotype.extension_water*(length/self.config.extension_length)
            node_id = self._new_node_id()
            node = HyphalNode(node_id, position, self.tick, heading, energy=0.065, water=0.035)
            ramet.nodes[node_id] = node
            edge = canonical_edge(tip_id, node_id)
            ramet.edges.add(edge); ramet.edge_weights[edge] = 1.0
            self._register_node(ramet.ramet_id, node)
            if rng.random() >= phenotype.branching_rate: ramet.tips.discard(tip_id)
            ramet.tips.add(node_id)
            for neighbor_id in self.spatial.query(position, self.config.anastomosis_radius,
                                                   exclude=(tip_id, node_id)):
                if self.spatial.owner(neighbor_id) != ramet.ramet_id: continue
                bridge = canonical_edge(node_id, neighbor_id)
                if bridge in ramet.edges: continue
                neighbor = ramet.nodes[neighbor_id]
                if not self._segment_clear(node_id, neighbor.position): continue
                join_rng = self._rng("anastomosis", f"internal:{self.tick}|{ramet.ramet_id}|{bridge}")
                if join_rng.random() < self.config.internal_anastomosis_scale*phenotype.anastomosis_tendency:
                    ramet.edges.add(bridge); ramet.edge_weights[bridge] = 1.0; loops += 1
                    break
            grown += 1
            if len(ramet.nodes) >= self.config.max_modules_per_ramet: break
        return grown, loops

    def _merge_ramets(self, left: Ramet, right: Ramet, bridge: tuple[NodeId, NodeId]) -> str:
        keep, absorbed = sorted((left, right), key=lambda r: (-len(r.nodes), r.ramet_id))
        keep.nodes.update(absorbed.nodes); keep.edges.update(absorbed.edges)
        keep.edge_weights.update(absorbed.edge_weights)
        edge = canonical_edge(*bridge); keep.edges.add(edge); keep.edge_weights[edge] = 1.0
        keep.tips.update(absorbed.tips)
        for node_id in absorbed.nodes: self.spatial.set_owner(node_id, keep.ramet_id)
        absorbed.merged_into = keep.ramet_id
        self._end_ramet(absorbed, "same_genet_anastomosis", is_death=False)
        return keep.ramet_id

    def _same_genet_fusions(self) -> tuple[list[list[str]], int]:
        contacts: dict[tuple[str, str], tuple[NodeId, NodeId]] = {}; nonself: set[tuple[str, str]] = set()
        for ramet in self.living_ramets():
            for node_id in sorted(ramet.nodes):
                point = ramet.nodes[node_id].position
                for other_node in self.spatial.query(point, self.config.anastomosis_radius, exclude=(node_id,)):
                    other_id = self.spatial.owner(other_node)
                    if other_id == ramet.ramet_id: continue
                    pair = tuple(sorted((ramet.ramet_id, other_id)))
                    other = self.ramets[other_id]
                    if ramet.genet_id == other.genet_id:
                        contacts.setdefault(pair, (node_id, other_node))
                    else: nonself.add(pair)
        fused = []
        for pair, bridge in sorted(contacts.items()):
            left, right = self.ramets[pair[0]], self.ramets[pair[1]]
            if not left.alive or not right.alive or left.genet_id != right.genet_id: continue
            probability = self.config.same_genet_fusion_scale*self.genets[left.genet_id].phenotype.anastomosis_tendency
            if self._rng("anastomosis", f"ramet-fusion:{self.tick}|{pair}").random() < probability:
                fused.append([pair[0], pair[1], self._merge_ramets(left, right, bridge)])
        return fused, len(nonself)

    def _mutate_genome(self, parent: Genet, subject: str) -> tuple[Genome, list[str]]:
        rng, values, mutated = self._rng("mutation", subject), parent.genome.to_dict(), []
        for name in TRAIT_NAMES:
            if rng.random() < self.config.mutation_probability:
                values[name] += rng.gauss(0.0, self.config.mutation_sigma); mutated.append(name)
        return Genome.from_dict(values), mutated

    def release_spore(self, ramet: Ramet, position: Point | None = None, *, force: bool = False) -> Spore | None:
        if not ramet.alive or not ramet.nodes: return None
        genet, phenotype = self.genets[ramet.genet_id], self.genets[ramet.genet_id].phenotype
        source = sorted(ramet.nodes.values(), key=lambda n: (-n.energy, n.node_id))[0]
        if source.energy <= phenotype.spore_cost+0.04: return None
        if not force and (self.tick-ramet.birth_tick < self.config.reproduction_min_age
                          or len(ramet.nodes) < self.config.reproduction_min_modules): return None
        spore_id = f"spore-{self._next_spore_serial:08d}"; self._next_spore_serial += 1
        subject = f"tick:{self.tick}|parent:{genet.genet_id}|spore:{spore_id}"
        genome, mutated = self._mutate_genome(genet, subject); rng = self._rng("spore", subject)
        if position is None:
            max_radius = 1.0+6.0*phenotype.spore_dispersal
            distance = max_radius*math.sqrt(rng.random())
            heading = self.rotation_radians+rng.uniform(0.0, 2.0*math.pi)
            position = point_at(source.position, heading, distance)
            if not self.in_bounds(position, 0.0):
                direction = math.atan2(position[1]-self.center[1], position[0]-self.center[0])
                position = point_at(self.center, direction, arena_radius(self.config.width, self.config.height, 0.05))
        source.energy -= phenotype.spore_cost
        spore = Spore(spore_id, genet.genet_id, genet.lineage_id, genome, position,
                      self.tick, self.tick+self.config.spore_viability_ticks)
        self.spores.append(spore)
        self.spore_records.append({"event": "released", "tick": self.tick, **spore.to_dict(), "mutated_loci": mutated})
        return spore

    def _reproduce(self, ramet: Ramet) -> Spore | None:
        rng = self._rng("spore", f"reproduce:{self.tick}|{ramet.ramet_id}")
        probability = 0.012+0.036*self.genets[ramet.genet_id].phenotype.spore_dispersal
        return self.release_spore(ramet) if rng.random() < probability else None

    def _germinate_spores(self) -> tuple[list[str], list[str]]:
        germinated, failed, remaining = [], [], []
        for spore in sorted(self.spores, key=lambda s: s.spore_id):
            if self.tick > spore.expires_tick:
                failed.append(spore.spore_id)
                self.spore_records.append({"event": "establishment_failed", "tick": self.tick,
                                           **spore.to_dict(), "reason": "viability_expired"}); continue
            if self.spatial.query(spore.position, self.config.collision_radius) or sample(self.detritus, spore.position) >= self.config.detritus_growth_threshold:
                remaining.append(spore); continue
            score = (sample(self.substrate, spore.position)+sample(self.water, spore.position)+self.light_at(spore.position)*0.30)/2.30
            rng = self._rng("germination", f"tick:{self.tick}|{spore.spore_id}")
            if score < 0.25 or rng.random() >= 0.22+0.42*score:
                remaining.append(spore); continue
            genet_id, ramet_id, node_id = self._new_genet_id(), self._new_ramet_id(), self._new_node_id()
            heading = self.rotation_radians+rng.uniform(0.0, 2.0*math.pi)
            genet = Genet(genet_id, spore.parent_genet_id, spore.lineage_id, self.tick, spore.genome, spore.position)
            node = HyphalNode(node_id, spore.position, self.tick, heading, energy=0.48, water=0.34)
            ramet = Ramet(ramet_id, genet_id, self.tick, node_id, nodes={node_id: node})
            self.genets[genet_id], self.ramets[ramet_id] = genet, ramet; self._register_node(ramet_id, node)
            release = next(r for r in reversed(self.spore_records) if r["event"] == "released" and r["spore_id"] == spore.spore_id)
            self.genet_records.append({"event": "established", **genet.to_dict(), "mutated_loci": release["mutated_loci"]})
            self.ramet_records.append({"event": "created", "tick": self.tick, **self._ramet_identity(ramet)})
            self.spore_records.append({"event": "germinated", "tick": self.tick, **spore.to_dict(),
                "child_genet_id": genet_id, "child_ramet_id": ramet_id,
                "parent_genet_alive": spore.parent_genet_id in self.living_genet_ids()})
            germinated.append(genet_id)
        self.spores = remaining
        return germinated, failed

    def _record_new_genet_extinctions(self) -> list[str]:
        living, newly = self.living_genet_ids(), []
        for genet_id in sorted(self.genets):
            if genet_id not in living and genet_id not in self.extinct_genets:
                self.extinct_genets.add(genet_id); newly.append(genet_id)
                self.genet_records.append({"event": "extinct", "tick": self.tick, "genet_id": genet_id})
        return newly

    def step(self) -> dict[str, Any]:
        if not self.living_ramets() and not self.spores:
            raise RuntimeError("no living ramets or viable spores remain")
        self.tick += 1
        environment_events, environment_fragments = self._apply_environment_transition()
        self._replenish_and_decay(); germinated, failed_spores = self._germinate_spores()
        genome_snapshot = {gid: genet.genome for gid, genet in self.genets.items()}
        substrate_taken = water_taken = light_energy = active_patch_taken = 0.0
        energy_moved = water_moved = energy_error = water_error = tip_energy = tip_water = 0.0
        for ramet in self.living_ramets():
            s, w, l, patch_s = self._absorb_local(ramet)
            substrate_taken += s; water_taken += w; light_energy += l; active_patch_taken += patch_s
        maintenance_totals: dict[str, float | int] = {
            "module_ticks": 0,
            "energy_required": 0.0,
            "energy_paid": 0.0,
            "water_required": 0.0,
            "water_paid": 0.0,
            "energy_limited_module_ticks": 0,
            "water_limited_module_ticks": 0,
            "grace_module_ticks": 0,
            "vitality_decay_module_ticks": 0,
        }
        for ramet in self.living_ramets():
            em, wm, ee, we, te, tw = self._transport(ramet)
            energy_moved += em; water_moved += wm; energy_error += ee; water_error += we
            tip_energy += te; tip_water += tw
            maintained = self._maintain(ramet)
            for key, value in maintained.items():
                maintenance_totals[key] += value
        necrotic_nodes, fragments, ramet_deaths = [], list(environment_fragments), []
        for ramet in list(self.living_ramets()):
            dead, created, died = self._prune_necrotic(ramet)
            necrotic_nodes.extend(dead); fragments.extend(created)
            if died: ramet_deaths.append(ramet.ramet_id)
        grown = loops = 0; spores_released = []
        for ramet in list(self.living_ramets()):
            count, loop_count = self._grow(ramet); grown += count; loops += loop_count
            spore = self._reproduce(ramet)
            if spore is not None: spores_released.append(spore.spore_id)
        fusions, nonself_contacts = self._same_genet_fusions()
        genet_extinctions = self._record_new_genet_extinctions()
        for genet_id, genome in genome_snapshot.items():
            if self.genets[genet_id].genome != genome: raise AssertionError("a genet genome changed during its lifetime")
        metrics = network_metrics(self.living_ramets(), self.genets, self.detritus)
        active_patch_edge_distance = self._active_patch_edge_distance()
        if active_patch_edge_distance is not None:
            self.minimum_active_patch_edge_distance = min(
                self.minimum_active_patch_edge_distance,
                active_patch_edge_distance,
            )
        patch_module_count = 0
        if self.environment_state.active_patch_center is not None:
            patch_module_count = sum(
                in_patch(
                    node.position,
                    self.environment_state.active_patch_center,
                    self.config.nutrient_patch_radius,
                )
                for ramet in self.living_ramets()
                for node in ramet.nodes.values()
            )
        record = {
            "tick": self.tick, "germinated_genets": germinated, "failed_spores": failed_spores,
            "spores_released": spores_released, "necrotic_node_ids": necrotic_nodes,
            "fragments_created": fragments, "ramet_deaths": ramet_deaths,
            "genet_extinctions": genet_extinctions, "same_genet_fusions": fusions,
            "blocked_nonself_contacts": nonself_contacts, "grown_modules": grown,
            "new_internal_anastomoses": loops, "pending_spores": len(self.spores),
            "substrate_taken": round(substrate_taken, 12), "water_taken": round(water_taken, 12),
            "light_energy": round(light_energy, 12), "energy_translocated": round(energy_moved, 12),
            "water_translocated": round(water_moved, 12), "tip_energy_received": round(tip_energy, 12),
            "tip_water_received": round(tip_water, 12), "energy_transport_balance_error": energy_error,
            "water_transport_balance_error": water_error, "ever_created_nodes": len(self.ever_created_nodes),
            "maintenance_module_ticks": maintenance_totals["module_ticks"],
            "maintenance_energy_required": maintenance_totals["energy_required"],
            "maintenance_energy_paid": maintenance_totals["energy_paid"],
            "maintenance_water_required": maintenance_totals["water_required"],
            "maintenance_water_paid": maintenance_totals["water_paid"],
            "energy_limited_module_ticks": maintenance_totals["energy_limited_module_ticks"],
            "water_limited_module_ticks": maintenance_totals["water_limited_module_ticks"],
            "necrosis_grace_module_ticks": maintenance_totals["grace_module_ticks"],
            "vitality_decay_module_ticks": maintenance_totals["vitality_decay_module_ticks"],
            **metrics,
        }
        if self.config.environment_profile != "legacy":
            damage_count = sum(int(e.get("removed_edge_count", 0)) for e in environment_events if e["event"] == "environmental_edge_damage")
            record.update({
                "environment_profile": self.environment_state.profile,
                "environment_phase": self.environment_state.phase,
                "active_patch_center": list(self.environment_state.active_patch_center) if self.environment_state.active_patch_center else None,
                "previous_patch_center": list(self.environment_state.previous_patch_center) if self.environment_state.previous_patch_center else None,
                "active_patch_substrate_taken": active_patch_taken,
                "active_patch_conductance_share": self._conductance_share_near(self.environment_state.active_patch_center),
                "previous_patch_conductance_share": self._conductance_share_near(self.environment_state.previous_patch_center),
                "active_patch_edge_distance": active_patch_edge_distance,
                "active_patch_module_count": patch_module_count,
                "environment_event_count": len(environment_events), "environmental_edges_removed": damage_count,
                "environmental_fragments_created": list(environment_fragments),
                "largest_ramet_module_fraction": self._largest_ramet_fraction(),
            })
        self.tick_records.append(record)
        return record

    def _append_extinct_tail(self) -> None:
        zero = network_metrics([], self.genets, self.detritus)
        while self.tick < self.config.ticks:
            self.tick += 1; self.environment_state = self._environment_state_for_tick(self.tick)
            record = {"tick": self.tick, "extinct_tail": True, "grown_modules": 0,
                      "pending_spores": 0, "substrate_taken": 0.0, "water_taken": 0.0,
                      "light_energy": 0.0, "energy_translocated": 0.0,
                      "water_translocated": 0.0, "active_patch_substrate_taken": 0.0,
                      "ever_created_nodes": len(self.ever_created_nodes), **zero}
            self.tick_records.append(record)

    def run(self, output_directory: str | Path | None = None) -> dict[str, Any]:
        while self.tick < self.config.ticks and (self.living_ramets() or self.spores): self.step()
        if self.tick < self.config.ticks:
            self.dynamics_stopped_tick = self.tick; self._append_extinct_tail()
        metrics = network_metrics(self.living_ramets(), self.genets, self.detritus)
        summary = {
            "schema": "rootnet-v6.8-water-field-repair-summary-v1", "completed_ticks": self.tick,
            "requested_ticks": self.config.ticks,
            "ecosystem_extinct": not bool(self.living_ramets() or self.spores),
            "dynamics_stopped_tick": self.dynamics_stopped_tick, "config": self.config.to_dict(),
            "stream_seeds": self.stream_seeds, "final_metrics": metrics,
            "genets_ever_established": len(self.genets),
            "ramets_ever_created": sum(r["event"] == "created" for r in self.ramet_records),
            "total_necrotic_modules": len(self.necrosis_records),
            "first_necrosis_tick": min(
                (int(record["tick"]) for record in self.necrosis_records),
                default=None,
            ),
            "cumulative_necrosis_fraction": (
                len(self.necrosis_records) / len(self.ever_created_nodes)
                if self.ever_created_nodes else 0.0
            ),
            "total_actual_ramet_deaths": sum(r["event"] == "died" for r in self.ramet_records),
            "total_genet_extinctions": len(self.extinct_genets),
            "spore_establishment_failures": sum(r["event"] == "establishment_failed" for r in self.spore_records),
            "max_abs_energy_transport_error": self.max_abs_energy_transport_error,
            "max_abs_water_transport_error": self.max_abs_water_transport_error,
            "max_abs_conductance_budget_error": self.max_abs_conductance_budget_error,
            "conductance_update_count": self.conductance_update_count,
            "conductance_strengthened_count": self.conductance_strengthened_count,
            "conductance_weakened_count": self.conductance_weakened_count,
            "max_conductance_weight_variance": self.max_conductance_weight_variance,
            "total_environmental_edges_removed": self.total_environmental_edges_removed,
            "total_environmental_fragments_created": self.total_environmental_fragments_created,
            "ever_created_nodes": len(self.ever_created_nodes),
            "minimum_active_patch_edge_distance": (
                self.minimum_active_patch_edge_distance
                if math.isfinite(self.minimum_active_patch_edge_distance)
                else None
            ),
            "founder_lineage_water_budgets": self.founder_water_budgets,
            "claim_boundary": (
                "Continuous-coordinate artificial assay and engineering rotation audit; "
                "v6.8 changes only the background water-capacity field by a fixed +0.035; "
                "growth candidate draws have local event-keyed pairing, not complete "
                "history-wide common-random-number pairing; not calibration to real "
                "fungal morphology and not proof of biological rotation invariance."
            ),
        }
        if output_directory is not None: self.write_outputs(Path(output_directory), summary)
        return summary

    def write_outputs(self, output: Path, summary: dict[str, Any]) -> None:
        output.mkdir(parents=True, exist_ok=True)
        for filename, payload in (("config.json", self.config.to_dict()), ("summary.json", summary)):
            (output/filename).write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)+"\n", encoding="utf-8")
        for filename, records in (("ticks.jsonl", self.tick_records), ("genets.jsonl", self.genet_records),
                                  ("ramets.jsonl", self.ramet_records), ("necrosis.jsonl", self.necrosis_records),
                                  ("spores.jsonl", self.spore_records), ("environment.jsonl", self.environment_records)):
            with (output/filename).open("w", encoding="utf-8", newline="\n") as handle:
                for record in records: handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True)+"\n")
        state = {"substrate": self.substrate, "water": self.water, "detritus": self.detritus,
                 "ramets": [self.ramets[k].to_dict() for k in sorted(self.ramets)]}
        (output/"final_state.json").write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True)+"\n", encoding="utf-8")

    def state_digest(self) -> str:
        payload = {
            "tick": self.tick, "genets": [self.genets[k].to_dict() for k in sorted(self.genets)],
            "ramets": [self.ramets[k].to_dict() for k in sorted(self.ramets)],
            "spores": [s.to_dict() for s in self.spores], "substrate": self.substrate,
            "water": self.water, "detritus": self.detritus, "ticks": self.tick_records,
            "genet_records": self.genet_records, "ramet_records": self.ramet_records,
            "necrosis": self.necrosis_records, "spore_records": self.spore_records,
            "environment_records": self.environment_records,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
