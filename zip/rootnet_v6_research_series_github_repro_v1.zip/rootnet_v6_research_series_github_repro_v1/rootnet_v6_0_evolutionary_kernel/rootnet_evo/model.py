from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


TRAIT_NAMES = (
    "light_investment",
    "substrate_investment",
    "desiccation_tolerance",
    "resource_sharing",
    "dispersal",
)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


@dataclass(frozen=True)
class Genome:
    """Heritable parameters. The environment never writes to this object."""

    light_investment: float = 0.38
    substrate_investment: float = 0.38
    desiccation_tolerance: float = 0.30
    resource_sharing: float = 0.24
    dispersal: float = 0.18

    def normalized(self) -> "Genome":
        return Genome(**{
            name: clamp(getattr(self, name))
            for name in TRAIT_NAMES
        })

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Genome":
        return cls(**{
            name: float(data.get(name, getattr(cls(), name)))
            for name in TRAIT_NAMES
        }).normalized()


@dataclass(frozen=True)
class Phenotype:
    """Deterministic phenotype derived only from the inherited genome."""

    light_capture: float
    substrate_absorption: float
    desiccation_tolerance: float
    resource_sharing: float
    dispersal: float
    maintenance_cost: float

    @classmethod
    def from_genome(cls, genome: Genome) -> "Phenotype":
        genome = genome.normalized()
        light = genome.light_investment
        substrate = genome.substrate_investment
        acquisition_total = light + substrate
        if acquisition_total > 1.0:
            light /= acquisition_total
            substrate /= acquisition_total

        maintenance_cost = (
            0.20
            + 0.16 * (light * light + substrate * substrate)
            + 0.13 * genome.desiccation_tolerance**2
            + 0.055 * genome.resource_sharing**2
            + 0.075 * genome.dispersal**2
        )
        return cls(
            light_capture=light,
            substrate_absorption=substrate,
            desiccation_tolerance=genome.desiccation_tolerance,
            resource_sharing=genome.resource_sharing,
            dispersal=genome.dispersal,
            maintenance_cost=maintenance_cost,
        )

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class Habitat:
    patch_id: str
    light: float
    substrate: float
    water: float
    capacity: int

    def normalized(self) -> "Habitat":
        return Habitat(
            patch_id=self.patch_id,
            light=clamp(self.light),
            substrate=clamp(self.substrate),
            water=clamp(self.water),
            capacity=max(1, int(self.capacity)),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Individual:
    organism_id: str
    parent_id: str
    root_lineage_id: str
    birth_generation: int
    patch_id: str
    genome: Genome

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["genome"] = self.genome.to_dict()
        return result
