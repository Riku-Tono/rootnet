# RootNet v6.3 model specification

## Scope

v6.3 changes one mechanism from v6.2.1: resource transport over edges. Geometry, local uptake, maintenance, vitality, partial necrosis, detritus, regrowth, reproduction, inheritance, and keyed random streams remain unchanged.

The tested causal sequence per tick is:

1. environmental replenishment and detritus decay;
2. spore establishment;
3. local substrate, water, and light acquisition;
4. condition-specific edge transport;
5. module maintenance and vitality change;
6. local necrosis and graph fragmentation;
7. extension, reproduction, and same-genet anastomosis;
8. read-only metric recording.

## Transport conditions

### none

No energy or water is moved. Edges remain present because they still define ramet connectedness, fragmentation, and morphology.

### equalize

For an edge `(i,j)` and resource stock `X`, direction follows the sign of `X_i - X_j`. Provisional magnitude is:

```text
q_ij = min(conductance_X * abs(X_i - X_j), edge_flux_cap_X)
```

All provisional exports from a donor are summed. If they exceed its stock, they are proportionally scaled. Deltas are then applied simultaneously.

### demand

Targets use quantities in the same units as the transported stock:

```text
target_X(i) = demand_horizon_ticks * maintenance_X
              + I(i is a tip) * (extension_cost_X + reserve_X)

surplus_X(i) = max(0, X_i - target_X(i))
deficit_X(i) = max(0, target_X(i) - X_i)
```

An edge proposes flow only when one endpoint has surplus and the other has deficit:

```text
q_ij = min(
    conductance_X * (donor_surplus + receiver_deficit),
    edge_flux_cap_X,
    donor_surplus,
    receiver_deficit,
)
```

All donor exports are again aggregated, proportionally capped by donor surplus, and applied simultaneously. Energy and water are independent. The fixed horizon is two ticks. Conductance does not adapt.

## Invariants

- Transport creates or destroys no energy or water, within floating-point tolerance.
- A transport update cannot make a stock negative.
- Results do not depend on edge iteration order.
- `none` transports exactly zero.
- Genome values do not change during a genet's lifetime.
- Parents persist after spore release; establishment failure is not a death.
- The terminal observer does not mutate simulation state.

## Experiment design

Thirty evaluation seeds are deterministically derived from the protocol namespace and paired across all three conditions. Seed 620 is excluded as a seen development seed. The four primary endpoints and decision rule are fixed in `V6_3_PREREGISTERED_PROTOCOL.md`.

The source hash sealed in `evaluation_v6_3.json` covers executable Python sources and the preregistered protocol. Documentation written after evaluation is intentionally excluded.
