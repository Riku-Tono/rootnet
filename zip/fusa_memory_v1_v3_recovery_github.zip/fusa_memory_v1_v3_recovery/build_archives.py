from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


FIXED_TIME = (2026, 7, 22, 0, 0, 0)


def add_tree(archive: ZipFile, source: Path, archive_root: str) -> None:
    for path in sorted(source.rglob("*"), key=lambda item: item.as_posix()):
        if (
            not path.is_file()
            or "__pycache__" in path.parts
            or "mplconfig" in path.parts
            or path.suffix == ".pyc"
        ):
            continue
        relative = path.relative_to(source).as_posix()
        info = ZipInfo(f"{archive_root}/{relative}", FIXED_TIME)
        info.compress_type = ZIP_DEFLATED
        info.external_attr = (0o100644 & 0xFFFF) << 16
        archive.writestr(info, path.read_bytes())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--root-name")
    args = parser.parse_args()

    source = args.source.resolve()
    destination = args.destination.resolve()
    root_name = args.root_name or source.name
    destination.parent.mkdir(parents=True, exist_ok=True)

    with ZipFile(destination, "w") as archive:
        add_tree(archive, source, root_name)

    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    print(f"{digest}  {destination.name}")


if __name__ == "__main__":
    main()
