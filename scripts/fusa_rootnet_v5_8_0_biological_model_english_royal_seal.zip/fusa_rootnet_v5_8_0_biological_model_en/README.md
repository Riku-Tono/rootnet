# RootNet v5.8.0 Biological Model

An artificial ecosystem model inspired by fungi, algae, and symbiotic organisms. It preserves the separated random-number streams, save/resume behavior, lineages, biosecurity, fragmentation, and reconnection of v5.7.2, while replacing anthropomorphic personality decisions in the central daily calculation with physiological resource accounting.

This is not a predictive model calibrated for any particular real Fusarium species. Its current scope is a testable, biologically inspired artificial ecosystem.

## Biological model

Initial organisms are assigned to one of three functional groups.

- `fungus`: uses substrate-derived carbon and does not photosynthesize
- `alga`: obtains carbon from light
- `symbiotic`: combines photosynthesis with substrate use

Each organism has internal carbon, water, and nitrogen pools. Every day, the model calculates environmental input, transport through RootNet, maintenance metabolism, and growth consumption in that order. Persistent deficits accumulate tissue damage and, without recovery, eventually cause resource-deficit death.

Resource transport through RootNet depends on conductivity, the donor's sharing trait, both organisms' fusion compatibility, and the resource concentration difference. Transport is conservative: the amount removed from the donor is added unchanged to the recipient.

See `BIOLOGICAL_MODEL_SPEC.md` for detailed variables and equations.

## Treatment of anthropomorphic variables

`Temperament`, `LifeNeeds`, and `RelationshipState` remain as compatibility data so that saves from schema v11 and earlier can still be loaded. However, normal daily calculations in v5.8.0 do not perform personality-based action selection, requests for help, or trust updates. These fields are also omitted from the lineage-tree view.

## Random-number streams and persistence

- `world`: sunlight, weather, tides, and the substrate environment
- `individual`: genes, physiological traits, and latent capabilities
- `mutation`: genetic mutations, damage, and toxic mutations
- `action`: discrete events such as germination, movement, and interaction

The save format is schema v12. It stores physiological traits, all resource pools, consecutive deficit days, cumulative inputs and outputs, and daily mass balances. When schema v11 data is loaded, biological traits and resource states are filled in deterministically.

## Run

~~~powershell
python main.py --days 10 --seed 42
~~~

The default save file is `fusa_rootnet_v5_8_0.json`, and the lineage tree is written to `fusa_lineage_tree.html`.

## Tests

~~~powershell
python -m unittest discover -v
python validate_v5_8_0.py
~~~

The new tests cover functional groups, removal of anthropomorphic behavior, differences in carbon acquisition between fungi and algae, conservative resource transport, resource-deficit death, 120-day mass balance, schema v11 migration, and exact save/resume equivalence.
