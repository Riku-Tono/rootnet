from __future__ import annotations

import argparse
import sys
from pathlib import Path

from persistence import load_ecosystem, save_ecosystem_atomic


def configure_utf8_output() -> None:
    """Windowsのcp932端末でも絵文字と日本語を安全に出力する。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8", errors="replace")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="環境記憶型フサリウム第4版――フサネット生態基盤編")
    parser.add_argument("--days", type=int, default=12)
    parser.add_argument("--save", type=Path, default=Path("fusa_rootnet_v4.json"))
    parser.add_argument("--seed", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    configure_utf8_output()
    args = parse_args()
    eco = load_ecosystem(args.save, args.seed)
    days = max(1, min(args.days, 3650))
    print("🌿⚡ 環境記憶型フサリウム第4版――フサネット生態基盤編")
    print(
        f"群落: {eco.name} / 生存株数: {len(eco.living_plants())} "
        f"/ 歴代株数: {len(eco.plants)} / 第{eco.day}日から再開"
    )
    print("─" * 76)
    for _ in range(days):
        report = eco.step(); w = report.weather
        print(f"第{report.day}日 | 気温{w.temperature:.2f} 光{w.sunlight:.2f} 雨{w.rainfall:.2f} 風{w.wind_speed:.2f}")
        for signal in report.signals:
            print(f"  ⚡ {signal.message}（{signal.signal_type} / 強度{signal.strength:.2f}）")
        print(f"  💧浄水 +{report.water_cleaned:.3f}  🔥落葉燃料 +{report.fuel_collected:.2f}  🐞害虫抑制 {report.pests_removed:.3f}")
        if report.seeds_distributed:
            print(f"  🐭 フサネズミが種を{report.seeds_distributed}粒、別区画へ運びました")
        for plant_id in report.new_plant_ids:
            plant = eco.plants[plant_id]
            print(
                f"  🌱 新株「{plant.name}」誕生 "
                f"（第{plant.generation}世代 / {plant.district}）"
            )
        for plant_id, reason in report.deaths:
            plant = eco.plants[plant_id]
            print(f"  🍂 {plant.name}が{reason}（享年{plant.age}日）")
        state = eco.infrastructure
        print(
            f"  基盤 | 水質{state.water_quality:.2f} 貯水{state.water_reserve:.2f} "
            f"燃料{state.amber_fuel:.1f} 害虫{state.pest_pressure:.2f} "
            f"種子庫{state.seed_bank} 生存株{len(eco.living_plants())}"
        )
    save_ecosystem_atomic(eco, args.save)
    print("─" * 76)
    print(f"💾 保存完了: {args.save}")
    print("フサは一本では育つ。フサリウムは、つながることで王国になる。")
    print("パフウリ・トフトフ。🌿⚡🌧️🧬")


if __name__ == "__main__":
    main()
