# RootNet v5.8.0 Biological Model Release Report

## Verdict

**PASS**. The biological model was created as a derived version in a separate directory, leaving v5.7.2 unchanged. Cooperation sensitivity analysis was not performed.

## Implementation scope

- Three functional groups: fungi, algae, and symbiotic organisms
- Physiological traits derived from genetic and morphological traits
- Internal carbon, water, and nitrogen pools
- Environmental inputs, maintenance metabolism, and growth consumption
- Conservative resource transport through RootNet
- Persistent deficits, tissue damage, and resource-deficit death
- Schema v12 persistence and schema v11 migration
- A lineage-tree view centered on physiological resources
- Normal daily execution of anthropomorphic personality actions, requests for help, and trust updates disabled

Legacy `Temperament`, `LifeNeeds`, and `RelationshipState` fields remain for reading old data. They are not used in the central v5.8.0 calculation.

## Validation

- 36 automated tests: 36 PASS / 0 FAIL
- A continuous 320-day run exactly matched a run saved after 137 days and resumed for 183 days across the complete ecosystem state
- Maximum absolute mass-balance error across carbon, water, and nitrogen: `7.105427357601002e-15`
- RootNet transport was observed for carbon, water, and nitrogen
- The external-input cutoff test confirmed the full path from persistent deficit to death
- Normal 320-day trial (seed 580): 24 living, 28 historical, 4 deaths from carbon deficit
- Anthropomorphic actions during normal daily calculations: 0

Individual values are recorded in `validation_v5_8_0.json`; a readable summary is provided in `VALIDATION_V5_8_0.md`.

## Interpretive limitations

The current coefficients have not been calibrated with measured data. The numbers of deaths and functional-group proportions therefore are not predictions for real Fusarium, algae, lichens, or other organisms. At this stage, the system is a biologically inspired artificial ecosystem with mass balance and a resource network.

Future experiments can target biological variables such as sharing traits, fusion compatibility, substrate uptake efficiency, and desiccation tolerance.
