from __future__ import annotations

import unittest

from cooperation_experiment import initial_pair, run_ab, run_trajectory
from ecosystem import FusaEcosystem


class CooperationExperimentTests(unittest.TestCase):
    def test_initial_pair_has_exactly_one_difference(self) -> None:
        low, high, audit = initial_pair(7, 0.10, 0.90, "memory-001")
        self.assertTrue(audit["only_cooperation_differs"])
        self.assertTrue(audit["rng_seeds_equal"])
        self.assertTrue(audit["rng_states_equal"])
        self.assertEqual(0.10, low.plants["memory-001"].temperament.cooperation)
        self.assertEqual(0.90, high.plants["memory-001"].temperament.cooperation)

    def test_plant_day_and_help_counters_reconcile(self) -> None:
        eco = FusaEcosystem.demo(rng_seed=8)
        result = run_trajectory(eco, 10, 8, eco.plants["memory-001"].temperament.cooperation)
        metrics = result["metrics"]
        self.assertEqual(10, metrics["completed_days"])
        self.assertGreaterEqual(metrics["plant_days"], 90)
        self.assertTrue(metrics["help_count_reconciled"])
        self.assertTrue(metrics["help_request_reconciled"])

    def test_short_pair_keeps_external_weather_exact(self) -> None:
        result = run_ab([9], 15, 0.10, 0.90, "memory-001")
        pair = result["pairs"][0]
        self.assertTrue(pair["weather_exact_match"])
        self.assertTrue(pair["final_world_rng_state_match"])


if __name__ == "__main__":
    unittest.main()
