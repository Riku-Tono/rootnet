from __future__ import annotations

import hashlib
import json
import platform
from pathlib import Path
from typing import Any

from confirmatory_v6_8 import (
    CONDITIONS,
    SEED_COUNT,
    condition_summary,
    evaluate_acceptance,
    locked_confirmatory_seeds,
)
from rootnet_v68 import ModuleSimulation, SimulationConfig, V68_WATER_CAPACITY_LIFT
from seal_evaluation_critical import verify_critical_seal
from tests.test_v6_8 import V66_CORE_REGRESSION_SHA256, projected_v66_digest


ROOT = Path(__file__).resolve().parent
RESULT_FILE = ROOT / "confirmatory_evaluation_v6_8.json"


def _mechanical_checks() -> tuple[dict[str, bool], dict[str, Any]]:
    control = ModuleSimulation(SimulationConfig(ticks=0, water_field_profile="v66-radial"))
    candidate = ModuleSimulation(
        SimulationConfig(ticks=0, water_field_profile="v68-radial-lift-0.035")
    )
    lift_error = max(
        abs(candidate.water_capacity[y][x] - min(1.0, value + 0.035))
        for y, row in enumerate(control.water_capacity)
        for x, value in enumerate(row)
    )
    regression = ModuleSimulation(
        SimulationConfig(
            master_seed=660, ticks=40, width=24, height=24, founder_count=2,
            transport_mode="fixed-equalize", rotation_angle_degrees=0.0,
            environment_profile="persistent-patch", environment_move_start_tick=10,
            environment_move_end_tick=30, environment_relocation_tick=20,
            environment_damage_tick=20, water_field_profile="v66-radial",
            necrosis_grace_ticks=0,
        )
    )
    regression.run()
    regression_digest = projected_v66_digest(regression)
    replay_config = SimulationConfig(
        master_seed=680, ticks=80, width=24, height=24, founder_count=2,
        water_field_profile="v68-radial-lift-0.035",
    )
    left, right = ModuleSimulation(replay_config), ModuleSimulation(replay_config)
    left.run(); right.run()
    checks = {
        "candidate_lift_fixed_at_0_035": V68_WATER_CAPACITY_LIFT == 0.035,
        "candidate_is_exact_clamped_lift": lift_error == 0.0,
        "candidate_changes_no_substrate": control.substrate == candidate.substrate,
        "v66_control_core_regression": regression_digest == V66_CORE_REGRESSION_SHA256,
        "candidate_exact_replay": left.state_digest() == right.state_digest(),
    }
    diagnostics = {
        "lift_max_abs_error": lift_error,
        "v66_core_regression_sha256": regression_digest,
    }
    return checks, diagnostics


def run_validation() -> dict[str, Any]:
    checks, diagnostics = _mechanical_checks()
    checks["critical_file_seal_matches"] = verify_critical_seal()
    result_details: dict[str, Any] = {"present": RESULT_FILE.is_file()}
    if RESULT_FILE.is_file():
        result_bytes = RESULT_FILE.read_bytes()
        result = json.loads(result_bytes)
        runs = list(result["runs"])
        seeds = locked_confirmatory_seeds()
        expected = {
            (seed, mode, condition)
            for seed in seeds
            for mode in ("fixed-equalize", "adaptive-equalize")
            for condition in CONDITIONS
        }
        observed = {
            (int(run["seed"]), str(run["transport_mode"]), str(run["condition"]))
            for run in runs
        }
        summaries = [condition_summary(runs, condition) for condition in CONDITIONS]
        acceptance = evaluate_acceptance(runs, summaries)
        checks.update({
            "all_120_confirmatory_runs_present_once": len(runs) == 120 and observed == expected,
            "thirty_locked_confirmatory_seeds": len(seeds) == SEED_COUNT == len(set(seeds)),
            "condition_summaries_reproduce": summaries == result["condition_summaries"],
            "acceptance_verdict_reproduces": acceptance == result["acceptance"],
            "result_schema_and_status": (
                result.get("schema") == "rootnet-v6.8-lift-0.035-confirmatory-result-v1"
                and result.get("stage") == "confirmatory"
                and result.get("status") == "COMPLETED"
            ),
        })
        result_details = {
            "present": True,
            "sha256": hashlib.sha256(result_bytes).hexdigest(),
            "runs": len(runs),
            "seeds": len(seeds),
            "verdict": acceptance["verdict"],
        }
    else:
        checks["confirmatory_result_present"] = False
    return {
        "schema": "rootnet-v6.8-lift-0.035-validation-v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "tests_expected": 17,
        "diagnostics": diagnostics,
        "confirmatory_result": result_details,
        "reference_runtime": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
        },
        "claim_boundary": (
            "Validation of the fixed artificial-system candidate and sealed confirmatory result; "
            "not calibration to a real fungus."
        ),
    }


def main() -> None:
    payload = run_validation()
    output = ROOT / "validation_v6_8.json"
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if payload["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
