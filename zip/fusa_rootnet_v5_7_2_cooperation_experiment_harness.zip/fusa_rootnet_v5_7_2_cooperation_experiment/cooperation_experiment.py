from __future__ import annotations

import argparse
import copy
import hashlib
import json
import statistics
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from ecosystem import FusaEcosystem
from persistence import ecosystem_to_dict


PROTOCOL_ID = "rootnet-v5.7.2-cooperation-paired-v1"
TARGET_PLANT_ID = "memory-001"
PRIMARY_METRIC = "help_successes_per_1000_plant_days"
DELTA_METRICS = (
    "final_living",
    "help_successes",
    "help_requests",
    "help_successes_per_1000_plant_days",
    "help_requests_per_1000_plant_days",
    "help_success_rate",
    "mean_trust",
    "mean_isolate_rate",
    "mean_largest_component_ratio",
    "final_largest_component_ratio",
    "final_isolate_rate",
    "final_reachability",
    "max_component_count",
    "outbreaks",
    "max_attack_rate",
    "severed_total",
    "reconnected_total",
    "severed_per_1000_edge_days",
    "reconnected_per_1000_edge_days",
    "pending_severed_final",
)


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def load_bearing_state(data: dict[str, Any]) -> dict[str, Any]:
    """読込時に使われない派生表示を除いた、再開可能な実状態。"""
    value = copy.deepcopy(data)
    value.pop("lineage_tree", None)
    return value


def parse_csv_ints(value: str) -> list[int]:
    return [int(item.strip()) for item in value.split(",") if item.strip()]


def parse_csv_floats(value: str) -> list[float]:
    return [float(item.strip()) for item in value.split(",") if item.strip()]


def diff_paths(left: Any, right: Any, path: str = "") -> list[str]:
    if type(left) is not type(right):
        return [path or "$"]
    if isinstance(left, dict):
        differences: list[str] = []
        for key in sorted(set(left) | set(right)):
            child = f"{path}.{key}" if path else str(key)
            if key not in left or key not in right:
                differences.append(child)
            else:
                differences.extend(diff_paths(left[key], right[key], child))
        return differences
    if isinstance(left, list):
        differences = []
        if len(left) != len(right):
            differences.append(f"{path}.length")
        for index, (left_item, right_item) in enumerate(zip(left, right)):
            differences.extend(diff_paths(left_item, right_item, f"{path}[{index}]"))
        return differences
    return [] if left == right else [path or "$"]


def target_cooperation_path(data: dict[str, Any], target_id: str) -> str:
    for index, plant in enumerate(data["plants"]):
        if plant["plant_id"] == target_id:
            return f"plants[{index}].temperament.cooperation"
    raise KeyError(target_id)


def set_cooperation(eco: FusaEcosystem, target_id: str, value: float) -> None:
    if target_id not in eco.plants:
        raise KeyError(f"target plant not found: {target_id}")
    eco.plants[target_id].temperament.cooperation = max(0.0, min(1.0, float(value)))


def initial_pair(seed: int, low: float, high: float, target_id: str) -> tuple[FusaEcosystem, FusaEcosystem, dict[str, Any]]:
    base = FusaEcosystem.demo(rng_seed=seed)
    base_data = ecosystem_to_dict(base)
    low_world = copy.deepcopy(base)
    high_world = copy.deepcopy(base)
    set_cooperation(low_world, target_id, low)
    set_cooperation(high_world, target_id, high)
    low_data = ecosystem_to_dict(low_world)
    high_data = ecosystem_to_dict(high_world)
    expected_path = target_cooperation_path(base_data, target_id)
    full_differences = diff_paths(low_data, high_data)
    source_differences = diff_paths(
        load_bearing_state(low_data),
        load_bearing_state(high_data),
    )
    audit = {
        "seed": seed,
        "target_id": target_id,
        "low": low,
        "high": high,
        "base_state_sha256": digest(base_data),
        "low_state_sha256": digest(low_data),
        "high_state_sha256": digest(high_data),
        "expected_difference_path": expected_path,
        "source_state_difference_paths": source_differences,
        "derived_display_difference_paths": [
            path for path in full_differences if path.startswith("lineage_tree")
        ],
        "only_cooperation_differs": source_differences == [expected_path],
        "rng_seeds_equal": low_world.rng_seeds == high_world.rng_seeds,
        "rng_states_equal": low_data["rng_states"] == high_data["rng_states"],
    }
    if not all((audit["only_cooperation_differs"], audit["rng_seeds_equal"], audit["rng_states_equal"])):
        raise RuntimeError(f"single-difference audit failed: {audit}")
    return low_world, high_world, audit


def external_weather_record(report) -> dict[str, Any]:
    return {
        "day": report.day,
        "solar": report.solar.to_dict(),
        "weather": report.weather.to_dict(),
        "moon_phase": report.marine.moon_phase,
        "tide_level": report.marine.tide_level,
        "wave_strength": report.marine.wave_strength,
    }


def undirected_edge_count(eco: FusaEcosystem) -> int:
    return sum(len(neighbors) for neighbors in eco.rootnet.links.values()) // 2


def run_trajectory(eco: FusaEcosystem, days: int, seed: int, cooperation: float) -> dict[str, Any]:
    started = time.perf_counter()
    plant_days = 0
    edge_days = 0
    isolate_rates: list[float] = []
    largest_component_ratios: list[float] = []
    reachabilities: list[float] = []
    component_counts: list[float] = []
    populations: list[int] = []
    weather_hash = hashlib.sha256()
    deaths = 0
    completed_days = 0
    error = None

    for _ in range(days):
        try:
            report = eco.step()
        except Exception as exc:  # recorded as a failed experimental trajectory
            error = f"{type(exc).__name__}: {exc}"
            break
        completed_days += 1
        plant_days += len(report.plant_reports)
        edge_days += undirected_edge_count(eco)
        deaths += len(report.deaths)
        populations.append(len(eco.living_plants()))
        isolate_rates.append(float(report.network_metrics["isolate_rate"]))
        largest_component_ratios.append(float(report.network_metrics["largest_component_ratio"]))
        reachabilities.append(float(report.network_metrics["reachability"]))
        component_counts.append(float(report.network_metrics["component_count"]))
        weather_hash.update(canonical_json(external_weather_record(report)).encode("utf-8"))

    relationships = []
    helpers: dict[str, int] = defaultdict(int)
    help_successes = 0
    help_memory_success = 0
    help_memory_failure = 0
    for requester in eco.plants.values():
        memory = requester.decision_memory.get("request_help", {})
        help_memory_success += int(memory.get("success", 0))
        help_memory_failure += int(memory.get("failure", 0))
        for helper_id, relation in requester.relationships.items():
            relationships.append(float(relation.trust))
            helped = int(relation.helped_count)
            help_successes += helped
            helpers[helper_id] += helped

    help_requests = int(eco.life_action_counts.get("request_help", 0))
    all_severed = [item for day in eco.biosecurity_history for item in day.get("severed", [])]
    all_reconnected = [item for day in eco.biosecurity_history for item in day.get("reconnected", [])]
    attack_rates = [
        int(item["max_affected"]) / max(1, int(item["population_at_start"]))
        for item in eco.outbreak_history
    ]
    final_network = eco.rootnet_metrics()
    ranked_helpers = sorted(helpers.items(), key=lambda item: (-item[1], item[0]))

    def per_1000(count: int, exposure: int) -> float:
        return count * 1000.0 / exposure if exposure else 0.0

    metrics = {
        "completed_days": completed_days,
        "error": error,
        "plant_days": plant_days,
        "edge_days": edge_days,
        "total_plants": len(eco.plants),
        "final_living": len(eco.living_plants()),
        "deaths": deaths,
        "population_mean": statistics.fmean(populations) if populations else 0.0,
        "population_min": min(populations, default=0),
        "population_max": max(populations, default=0),
        "help_successes": help_successes,
        "help_requests": help_requests,
        "help_memory_success": help_memory_success,
        "help_memory_failure": help_memory_failure,
        "help_count_reconciled": help_successes == help_memory_success,
        "help_request_reconciled": help_requests == help_memory_success + help_memory_failure,
        "help_successes_per_1000_plant_days": per_1000(help_successes, plant_days),
        "help_requests_per_1000_plant_days": per_1000(help_requests, plant_days),
        "help_success_rate": help_memory_success / help_requests if help_requests else 0.0,
        "mean_trust": statistics.fmean(relationships) if relationships else 0.0,
        "max_trust": max(relationships, default=0.0),
        "relationship_count_directed": len(relationships),
        "mean_isolate_rate": statistics.fmean(isolate_rates) if isolate_rates else 0.0,
        "mean_largest_component_ratio": statistics.fmean(largest_component_ratios) if largest_component_ratios else 0.0,
        "mean_reachability": statistics.fmean(reachabilities) if reachabilities else 0.0,
        "max_component_count": max(component_counts, default=0.0),
        "final_largest_component_ratio": float(final_network["largest_component_ratio"]),
        "final_isolate_rate": float(final_network["isolate_rate"]),
        "final_reachability": float(final_network["reachability"]),
        "final_component_count": float(final_network["component_count"]),
        "outbreaks": len(eco.outbreak_history),
        "max_attack_rate": max(attack_rates, default=0.0),
        "mean_attack_rate": statistics.fmean(attack_rates) if attack_rates else 0.0,
        "severed_total": len(all_severed),
        "reconnected_total": len(all_reconnected),
        "severed_per_1000_edge_days": per_1000(len(all_severed), edge_days),
        "reconnected_per_1000_edge_days": per_1000(len(all_reconnected), edge_days),
        "pending_severed_final": len(eco.severed_links),
        "journal_entries": len(eco.life_journal),
        "action_counts": dict(sorted(eco.life_action_counts.items())),
        "top_helpers": [
            {
                "plant_id": plant_id,
                "name": eco.plants[plant_id].name if plant_id in eco.plants else plant_id,
                "helps": count,
            }
            for plant_id, count in ranked_helpers[:5]
            if count > 0
        ],
    }
    return {
        "seed": seed,
        "cooperation": cooperation,
        "days_requested": days,
        "rng_seeds": dict(eco.rng_seeds),
        "external_weather_sha256": weather_hash.hexdigest(),
        "final_rng_state_sha256": {
            "world": digest(eco._world_rng.getstate()),
            "individual": digest(eco._individual_rng.getstate()),
            "mutation": digest(eco._mutation_rng.getstate()),
            "action": digest(eco._action_rng.getstate()),
        },
        "metrics": metrics,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }


def paired_deltas(low_run: dict[str, Any], high_run: dict[str, Any]) -> dict[str, float]:
    return {
        name: float(high_run["metrics"][name]) - float(low_run["metrics"][name])
        for name in DELTA_METRICS
    }


def run_ab(seeds: list[int], days: int, low: float, high: float, target_id: str) -> dict[str, Any]:
    started = time.perf_counter()
    pairs = []
    for position, seed in enumerate(seeds, start=1):
        low_world, high_world, audit = initial_pair(seed, low, high, target_id)
        low_run = run_trajectory(low_world, days, seed, low)
        high_run = run_trajectory(high_world, days, seed, high)
        pair = {
            "seed": seed,
            "initial_audit": audit,
            "weather_exact_match": low_run["external_weather_sha256"] == high_run["external_weather_sha256"],
            "final_world_rng_state_match": (
                low_run["final_rng_state_sha256"]["world"]
                == high_run["final_rng_state_sha256"]["world"]
            ),
            "low": low_run,
            "high": high_run,
            "delta_high_minus_low": paired_deltas(low_run, high_run),
        }
        if not pair["weather_exact_match"] or not pair["final_world_rng_state_match"]:
            raise RuntimeError(f"external-world control failed for seed {seed}")
        pairs.append(pair)
        print(f"A/B progress={position}/{len(seeds)} seed={seed}", flush=True)
    return {
        "experiment": {
            "protocol_id": PROTOCOL_ID,
            "mode": "paired_ab",
            "source_version": "RootNet v5.7.2 schema v11",
            "seeds": seeds,
            "days": days,
            "target_id": target_id,
            "low": low,
            "high": high,
            "primary_metric": PRIMARY_METRIC,
            "trajectory_count": len(seeds) * 2,
            "elapsed_seconds": round(time.perf_counter() - started, 6),
        },
        "pairs": pairs,
    }


def run_sensitivity(seeds: list[int], days: int, levels: list[float], target_id: str) -> dict[str, Any]:
    started = time.perf_counter()
    worlds = []
    for seed_position, seed in enumerate(seeds, start=1):
        base = FusaEcosystem.demo(rng_seed=seed)
        base_data = ecosystem_to_dict(base)
        expected_path = target_cooperation_path(base_data, target_id)
        runs = []
        for level in levels:
            world = copy.deepcopy(base)
            set_cooperation(world, target_id, level)
            changed_data = ecosystem_to_dict(world)
            full_differences = diff_paths(base_data, changed_data)
            differences = diff_paths(
                load_bearing_state(base_data),
                load_bearing_state(changed_data),
            )
            if any(path != expected_path for path in differences):
                raise RuntimeError(
                    f"sensitivity single-difference audit failed: seed={seed} level={level} paths={differences}"
                )
            runs.append({
                "initial_source_state_difference_paths": differences,
                "initial_derived_display_difference_paths": [
                    path for path in full_differences if path.startswith("lineage_tree")
                ],
                "run": run_trajectory(world, days, seed, level),
            })
        weather_hashes = {item["run"]["external_weather_sha256"] for item in runs}
        world_state_hashes = {item["run"]["final_rng_state_sha256"]["world"] for item in runs}
        if len(weather_hashes) != 1 or len(world_state_hashes) != 1:
            raise RuntimeError(f"sensitivity external-world control failed for seed {seed}")
        worlds.append({
            "seed": seed,
            "base_state_sha256": digest(base_data),
            "expected_difference_path": expected_path,
            "weather_exact_across_levels": True,
            "final_world_rng_state_exact_across_levels": True,
            "levels": runs,
        })
        print(f"sensitivity progress={seed_position}/{len(seeds)} seed={seed}", flush=True)
    return {
        "experiment": {
            "protocol_id": PROTOCOL_ID,
            "mode": "sensitivity",
            "source_version": "RootNet v5.7.2 schema v11",
            "seeds": seeds,
            "days": days,
            "target_id": target_id,
            "levels": levels,
            "primary_metric": PRIMARY_METRIC,
            "trajectory_count": len(seeds) * len(levels),
            "elapsed_seconds": round(time.perf_counter() - started, 6),
        },
        "worlds": worlds,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="RootNet v5.7.2 cooperation experiment")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    ab = subparsers.add_parser("ab")
    ab.add_argument("--seeds", required=True, help="comma-separated seeds")
    ab.add_argument("--days", type=int, default=320)
    ab.add_argument("--low", type=float, default=0.10)
    ab.add_argument("--high", type=float, default=0.90)
    ab.add_argument("--target-id", default=TARGET_PLANT_ID)
    ab.add_argument("--output", type=Path, required=True)

    sensitivity = subparsers.add_parser("sensitivity")
    sensitivity.add_argument("--seeds", required=True, help="comma-separated seeds")
    sensitivity.add_argument("--days", type=int, default=320)
    sensitivity.add_argument(
        "--levels",
        default="0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0",
    )
    sensitivity.add_argument("--target-id", default=TARGET_PLANT_ID)
    sensitivity.add_argument("--output", type=Path, required=True)

    args = parser.parse_args()
    seeds = parse_csv_ints(args.seeds)
    if not seeds:
        parser.error("at least one seed is required")
    if args.days < 1:
        parser.error("days must be positive")

    if args.mode == "ab":
        result = run_ab(seeds, args.days, args.low, args.high, args.target_id)
    else:
        levels = parse_csv_floats(args.levels)
        if not levels or any(level < 0.0 or level > 1.0 for level in levels):
            parser.error("levels must be within 0.0..1.0")
        result = run_sensitivity(seeds, args.days, levels, args.target_id)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"saved={args.output} bytes={args.output.stat().st_size}", flush=True)


if __name__ == "__main__":
    main()
