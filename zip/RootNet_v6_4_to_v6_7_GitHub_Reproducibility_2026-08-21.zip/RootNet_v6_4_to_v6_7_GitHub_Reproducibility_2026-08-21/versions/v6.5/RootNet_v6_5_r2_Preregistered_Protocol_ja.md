# RootNet v6.5 preregistered protocol

## 状態

実装・機構パイロット完了。本評価は`SEALED_NOT_RUN`。

## 条件

- transport: `fixed-equalize`, `adaptive-equalize`
- environment: `persistent-patch`, `slow-moving-patch`, `abrupt-relocation`, `edge-damage`
- 30 paired seeds
- 各run 360 tick、42×18、founder 3
- 合計240 run

全条件でv6.4の`alpha=0.10`, `w_min=0.25`, `w_max=4.0`を維持する。環境は開始90、イベント180、終了270、radius 4.0、background 0.60、boost 0.50、damage probability 0.25に固定する。

## 主指標と検定

各環境内で`adaptive - fixed`をseed対応差として計算する。

1. 変化後区間の平均生存module数（高い方が有利）
2. 変化後区間の活動パッチ累積基質吸収量（高い方が有利）

主指標は丸め前のraw floatでseed対応差を計算し、その符号を両側exact sign testへ渡す。4環境×2指標の8検定をHolm補正する。補正後`p <= 0.05`かつraw中央値差の符号により`BENEFIT_SUPPORTED`または`HARM_SUPPORTED`と分類し、それ以外は`NO_CLEAR_DIFFERENCE`とする。中央値を含む9桁丸めは、検定とclassificationの完了後にJSON報告用としてのみ行う。

## 補助指標

- `active_patch_first_uptake_tick`: 事前指定評価区間内で、活動中パッチからの基質吸収が初めて0を超えたtick。到達しなければnull
- `ever_occupied_new_cells`: run全期間で一度でも占有したセル数からfounder数を引いた累積新規占有セル数。最終時点の占有数ではない
- `mean_post_event_cycle_rank`: 事前指定評価区間のcycle rank平均
- `minimum_post_event_largest_ramet_fraction`: 評価区間各tickの「最大ramet module数 / 全生存module数」の最小値
- `environmental_edges_removed`: 外生的損傷で切断した辺の累積数
- `environmental_fragments_created`: 外生的損傷で新たに分離したramet数
- `necrotic_modules`, `actual_ramet_deaths`: 資源不足による壊死と実死亡。外生的辺損傷とは別集計

## 封印

評価seed namespaceは`rootnet-v6.5-dynamic-environment-evaluation-v1`。機械可読一覧は`evaluation_seeds_v6_5.json`に保存する。development seed 650–651と重複しない。

`--stage evaluation`は実行開始前に、現在の全配布ファイルが`MANIFEST_SHA256.txt`と一致し、`validation_v6_5.json`が現在コードから完全再現されることを必須とする。どちらかが失敗または欠落した場合はrunを1件も開始せず終了する。評価後に同じseedでパラメータを調整しない。
