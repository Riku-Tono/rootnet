from __future__ import annotations

import argparse
import os
import sys
import time

from rootnet_v68 import (
    ENVIRONMENT_PROFILES, ModuleSimulation, SimulationConfig, TRANSPORT_MODES,
    WATER_FIELD_PROFILES,
)
from rootnet_v68.environment import in_patch


RESET = "\033[0m"
COLORS = ("\033[38;5;82m", "\033[38;5;214m", "\033[38;5;45m",
          "\033[38;5;141m", "\033[38;5;203m")


def parse_args():
    parser = argparse.ArgumentParser(description="Observe RootNet v6.8 without changing its dynamics")
    parser.add_argument("--ticks", type=int, default=360)
    parser.add_argument("--seed", type=int, default=680)
    parser.add_argument("--size", type=int, default=42)
    parser.add_argument("--founders", type=int, default=3)
    parser.add_argument("--transport", choices=TRANSPORT_MODES, default="fixed-equalize")
    parser.add_argument("--environment", choices=ENVIRONMENT_PROFILES, default="persistent-patch")
    parser.add_argument("--rotation", type=float, default=0.0)
    parser.add_argument(
        "--water-field",
        choices=WATER_FIELD_PROFILES,
        default="v68-radial-lift-0.035",
    )
    parser.add_argument("--every", type=int, default=3)
    parser.add_argument("--delay", type=float, default=0.06)
    parser.add_argument("--no-clear", action="store_true")
    return parser.parse_args()


def render(simulation: ModuleSimulation, record: dict, *, clear: bool) -> None:
    if clear:
        os.system("cls" if os.name == "nt" else "clear")
    width, height = simulation.config.width, simulation.config.height
    canvas_width = width * 2 - 1
    canvas = [[" " for _ in range(canvas_width)] for _ in range(height)]
    center = simulation.environment_state.active_patch_center
    for y in range(height):
        for x in range(width):
            if not simulation.in_bounds((float(x), float(y)), 0.0):
                canvas[y][x * 2] = "·"
            elif in_patch((float(x), float(y)), center, simulation.config.nutrient_patch_radius):
                canvas[y][x * 2] = "░"

    def plot_line(left, right, color: str) -> None:
        x0, y0 = round(left[0] * 2), round(left[1])
        x1, y1 = round(right[0] * 2), round(right[1])
        dx, dy = x1 - x0, y1 - y0
        steps = max(abs(dx), abs(dy), 1)
        glyph = "─" if abs(dx) > abs(dy) * 1.8 else ("│" if abs(dy) > abs(dx) * 1.8 else ("╲" if dx * dy > 0 else "╱"))
        for step in range(steps + 1):
            x = round(x0 + dx * step / steps)
            y = round(y0 + dy * step / steps)
            if 0 <= x < canvas_width and 0 <= y < height:
                canvas[y][x] = f"{color}{glyph}{RESET}"

    for ramet in simulation.living_ramets():
        color = COLORS[(int(ramet.genet_id.split("-")[-1])-1) % len(COLORS)]
        for left_id, right_id in ramet.edges:
            plot_line(ramet.nodes[left_id].position, ramet.nodes[right_id].position, color)

    visible: dict[tuple[int, int], tuple[float, str, str]] = {}
    for ramet in simulation.living_ramets():
        color = COLORS[(int(ramet.genet_id.split("-")[-1])-1) % len(COLORS)]
        for node_id, node in ramet.nodes.items():
            x, y = round(node.position[0] * 2), round(node.position[1])
            if not (0 <= x < canvas_width and 0 <= y < height):
                continue
            glyph = "◆" if node_id in ramet.tips else "●"
            if node.vitality < 0.25: glyph = "×"
            elif node.vitality < 0.55: glyph = "+"
            current = visible.get((x, y))
            if current is None or node.vitality > current[0]:
                visible[(x, y)] = (node.vitality, color, glyph)
    for (x, y), (_, color, glyph) in visible.items():
        canvas[y][x] = f"{color}{glyph}{RESET}"
    print(f"RootNet v6.8  tick {record['tick']}/{simulation.config.ticks}  "
          f"rotation {simulation.config.rotation_angle_degrees:g}°  {simulation.config.transport_mode}")
    print(f"modules {record['total_modules']}  tips {record['total_tips']}  "
          f"length {record['total_hyphal_length']:.1f}  hull {record['convex_hull_area']:.1f}  "
          f"cycles {record['cycle_rank']}")
    print("┌"+"─"*canvas_width+"┐")
    for row in canvas:
        print("│"+"".join(row)+"│")
    print("└"+"─"*canvas_width+"┘")
    if record.get("necrotic_node_ids"):
        print(f"壊死 {len(record['necrotic_node_ids'])} modules")
    if record.get("same_genet_fusions"):
        print(f"同一genet吻合 {len(record['same_genet_fusions'])}")
    if record.get("environmental_edges_removed"):
        print(f"外生的辺損傷 {record['environmental_edges_removed']} edges")
    print("表示は観測専用で、simulation stateには書き戻しません。")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    args = parse_args()
    simulation = ModuleSimulation(SimulationConfig(
        master_seed=args.seed, ticks=args.ticks, width=args.size, height=args.size,
        founder_count=args.founders, transport_mode=args.transport,
        environment_profile=args.environment, rotation_angle_degrees=args.rotation,
        environment_move_start_tick=max(1, args.ticks//4),
        environment_move_end_tick=max(2, 3*args.ticks//4),
        environment_relocation_tick=max(1, args.ticks//2),
        environment_damage_tick=max(1, args.ticks//2),
        water_field_profile=args.water_field,
        necrosis_grace_ticks=0,
    ))
    while simulation.tick < simulation.config.ticks and (simulation.living_ramets() or simulation.spores):
        record = simulation.step()
        if record["tick"] % max(1, args.every) == 0 or record["tick"] == simulation.config.ticks:
            render(simulation, record, clear=not args.no_clear)
            time.sleep(max(0.0, args.delay))
    if not simulation.living_ramets() and not simulation.spores:
        print(f"生態系はtick {simulation.tick}で全滅しました。")


if __name__ == "__main__":
    main()
