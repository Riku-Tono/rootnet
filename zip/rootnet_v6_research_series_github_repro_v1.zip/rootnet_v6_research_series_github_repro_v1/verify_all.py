from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from make_manifest import MANIFEST, ROOT, included_files


VERSION_DIRECTORIES = (
    "rootnet_v6_0_evolutionary_kernel",
    "rootnet_v6_1_spatial_mycelium",
    "rootnet_v6_2_module_metabolism",
    "rootnet_v6_2_1_module_metabolism",
    "rootnet_v6_3_transport_experiment",
)


def verify_outer_manifest() -> list[str]:
    failures: list[str] = []
    if not MANIFEST.exists():
        return ["MANIFEST_SHA256.txt is missing"]

    expected: dict[str, str] = {}
    for line_number, line in enumerate(
        MANIFEST.read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not line.strip():
            continue
        try:
            digest, relative = line.split(" *", 1)
        except ValueError:
            failures.append(f"invalid manifest line {line_number}")
            continue
        expected[relative] = digest

    current = {
        path.relative_to(ROOT).as_posix(): path
        for path in included_files()
    }
    if set(expected) != set(current):
        missing = sorted(set(expected) - set(current))
        extra = sorted(set(current) - set(expected))
        if missing:
            failures.append(f"missing files: {missing}")
        if extra:
            failures.append(f"unmanifested files: {extra}")

    for relative in sorted(set(expected) & set(current)):
        digest = hashlib.sha256(current[relative].read_bytes()).hexdigest()
        if digest != expected[relative]:
            failures.append(f"hash mismatch: {relative}")
    return failures


def run_command(command: list[str], cwd: Path) -> None:
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    environment["PYTHONUTF8"] = "1"
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.stderr:
        print(completed.stderr.rstrip(), file=sys.stderr)
    if completed.returncode != 0:
        raise RuntimeError(
            f"command failed ({completed.returncode}): {' '.join(command)}"
        )


def verify_version_packages() -> None:
    for directory in VERSION_DIRECTORIES:
        package = ROOT / directory
        verifier = package / "verify_package.py"
        if not verifier.is_file():
            raise RuntimeError(f"missing package verifier: {verifier}")
        print(f"\n=== Verifying {directory} ===", flush=True)
        run_command([sys.executable, verifier.name], package)


def comparable_evaluation(payload: dict) -> dict:
    comparable = dict(payload)
    comparable.pop("elapsed_seconds", None)
    return comparable


def verify_full_v6_3_evaluation() -> None:
    package = ROOT / "rootnet_v6_3_transport_experiment"
    sealed_path = package / "evaluation_v6_3.json"
    print("\n=== Reproducing v6.3 30-seed evaluation ===", flush=True)
    with tempfile.TemporaryDirectory(prefix="rootnet-v63-evaluation-") as temp_dir:
        reproduced_path = Path(temp_dir) / "evaluation_v6_3.json"
        run_command(
            [
                sys.executable,
                "experiment_v6_3.py",
                "--ticks",
                "360",
                "--replicates",
                "30",
                "--output",
                str(reproduced_path),
            ],
            package,
        )
        sealed = json.loads(sealed_path.read_text(encoding="utf-8"))
        reproduced = json.loads(reproduced_path.read_text(encoding="utf-8"))
        if comparable_evaluation(sealed) != comparable_evaluation(reproduced):
            raise RuntimeError(
                "v6.3 evaluation differs from the sealed record after excluding elapsed_seconds"
            )
    print("V6.3 FULL EVALUATION REPRODUCTION: PASS")


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the RootNet v6 bundle")
    parser.add_argument(
        "--manifest-only",
        action="store_true",
        help="verify only the outer bundle manifest",
    )
    parser.add_argument(
        "--full-evaluation",
        action="store_true",
        help="also rerun and compare the sealed v6.3 30-seed evaluation",
    )
    options = parser.parse_args()

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V6 BUNDLE VERIFICATION: FAIL")
        return 1
    print("Outer manifest: PASS")

    if options.manifest_only:
        print("ROOTNET V6 BUNDLE MANIFEST VERIFICATION: PASS")
        return 0

    try:
        verify_version_packages()
        if options.full_evaluation:
            verify_full_v6_3_evaluation()
    except RuntimeError as error:
        print(f"FAIL: {error}")
        print("ROOTNET V6 BUNDLE VERIFICATION: FAIL")
        return 1

    failures = verify_outer_manifest()
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        print("ROOTNET V6 BUNDLE VERIFICATION: FAIL")
        return 1

    print("\nOuter manifest after execution: PASS")
    print("ROOTNET V6 BUNDLE VERIFICATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
