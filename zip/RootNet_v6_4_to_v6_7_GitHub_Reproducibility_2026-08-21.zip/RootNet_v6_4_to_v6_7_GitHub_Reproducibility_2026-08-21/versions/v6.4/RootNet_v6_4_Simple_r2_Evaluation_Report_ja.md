# RootNet v6.4 simple r2 evaluation report

## 実行状態

封印済みr2で本評価を完了した。

- 30 paired seeds
- 3条件
- 90 run
- 各360 tick
- 42×18、founder 3
- 全run完走
- code SHAと封印値が一致
- seed一覧と封印値が一致

評価結果JSON SHA-256:

```text
CA848A0784C04C4055D4F35FCAD09A17BD60817DD5A2222D3AB3E20AA8E34D94
```

## 事前固定した主比較

`adaptive-equalize`対`fixed-equalize`。

| 主指標 | median paired delta | favorable / unfavorable / tie | raw p | Holm p | 判定 |
|---|---:|---:|---:|---:|---|
| 平均生存module数 | -0.198611111 | 14 / 16 / 0 | 0.855535552 | 0.855535552 | `NO_CLEAR_DIFFERENCE` |
| 新規占有セル数 | +0.5 | 15 / 10 / 5 | 0.424356222 | 0.848712444 | `NO_CLEAR_DIFFERENCE` |

両主指標とも、事前規則で適応配分の利益または害を支持しなかった。

## 条件別の記述統計

| 条件 | 平均生存module数の中央値 | 新規占有セル数の中央値 | 生態系全滅 |
|---|---:|---:|---:|
| `none` | 8.0875 | 10.5 | 0/30 |
| `fixed-equalize` | 22.651388889 | 29.5 | 0/30 |
| `adaptive-equalize` | 21.023611112 | 21.5 | 0/30 |

`none`はprotocol上の記述的対照であり、正式検定や成功判定には使用していない。

## 機械監査

- 最大energy保存誤差: `7.105427357601e-15`
- 最大water保存誤差: `8.88178419700125e-16`
- 最大コンダクタンス予算誤差: `1.4210854715202e-14`
- adaptive conductance updates: 33,214
- strengthened edge observations: 101,550
- weakened edge observations: 120,997
- 最大weight variance: 1.17260264778627

いずれの保存誤差も事前の`1e-12`許容範囲内だった。

## 結論の範囲

指定した通常人工環境、固定パラメータ、360 tick、30 paired seedsでは、限られた総コンダクタンス予算の履歴依存的再配分は、一様固定配分に対して2つの主指標を明確には改善も悪化もさせなかった。

これは実在菌類が同じ更新則を使うか、他の環境やストレス下で効果があるかを示すものではない。
