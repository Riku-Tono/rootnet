# v6.2.1 release notes

- Preserved v6.2.0 unchanged.
- Reduced an unnecessary post-extension water reserve that caused 34–84 tick visual plateaus in the default seed.
- Added event-paced terminal rendering: ticks with no visible state change are still simulated but are not repeatedly redrawn.
- Added `--every-tick` for users who want the original one-frame-per-tick observer behavior.
- Changed no transport equation, death definition, mutation rule, or claim boundary.
