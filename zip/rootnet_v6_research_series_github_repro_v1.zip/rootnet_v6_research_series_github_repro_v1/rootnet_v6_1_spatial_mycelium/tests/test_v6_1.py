from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from rootnet_mycelium import Genome, MyceliumSimulation, SimulationConfig


class SpatialMyceliumTests(unittest.TestCase):
    def make_sim(self, **changes) -> MyceliumSimulation:
        values = dict(ticks=30, width=20, height=10, founder_count=2)
        values.update(changes)
        return MyceliumSimulation(SimulationConfig(**values))

    def test_founders_share_abstract_common_ancestor(self):
        simulation = self.make_sim()
        self.assertEqual({c.parent_id for c in simulation.living_colonies()}, {"ancestor-000000"})

    def test_parent_is_not_removed_when_spore_is_released(self):
        simulation = self.make_sim()
        parent = simulation.living_colonies()[0]
        energy_before = parent.energy
        spore = simulation.release_spore(parent, (0, 0), force=True)
        self.assertIsNotNone(spore)
        self.assertTrue(parent.alive)
        self.assertIn(parent.origin, parent.cells)
        self.assertLess(parent.energy, energy_before)

    def test_parent_and_child_can_live_at_same_time(self):
        simulation = self.make_sim(spore_viability_ticks=100)
        parent = simulation.living_colonies()[0]
        spore = simulation.release_spore(parent, (0, 0), force=True)
        self.assertIsNotNone(spore)
        for _ in range(100):
            simulation.tick += 1
            children, _ = simulation._germinate_spores()
            if children:
                child = simulation.colonies[children[0]]
                self.assertTrue(parent.alive)
                self.assertTrue(child.alive)
                self.assertEqual(child.parent_id, parent.colony_id)
                return
        self.fail("deterministic test spore did not germinate")

    def test_growth_is_local_bounded_and_nonoverlapping(self):
        simulation = self.make_sim(ticks=20)
        simulation.run()
        seen = set()
        for colony in simulation.living_colonies():
            for x, y in colony.cells:
                self.assertTrue(0 <= x < simulation.config.width)
                self.assertTrue(0 <= y < simulation.config.height)
                self.assertNotIn((x, y), seen)
                seen.add((x, y))
            for left, right in colony.edges:
                self.assertEqual(abs(left[0] - right[0]) + abs(left[1] - right[1]), 1)

    def test_colonies_persist_across_ticks(self):
        simulation = self.make_sim(ticks=8)
        original = {c.colony_id for c in simulation.living_colonies()}
        simulation.run()
        living = {c.colony_id for c in simulation.living_colonies()}
        self.assertTrue(original <= living)
        self.assertTrue(all(simulation.colonies[c].age == 8 for c in original))

    def test_death_records_only_actual_colony_deaths(self):
        simulation = self.make_sim(founder_count=1)
        colony = simulation.living_colonies()[0]
        colony.energy = 0.0
        simulation._kill_if_depleted(colony)
        self.assertEqual(simulation.death_records[0]["reason"], "energy_depletion")
        self.assertFalse(colony.alive)

    def test_failed_spore_is_not_a_colony_death(self):
        simulation = self.make_sim(founder_count=1, spore_viability_ticks=1)
        parent = simulation.living_colonies()[0]
        spore = simulation.release_spore(parent, parent.origin, force=True)
        simulation.tick = spore.expires_tick + 1
        _, failed = simulation._germinate_spores()
        self.assertEqual(failed, [spore.spore_id])
        self.assertEqual(simulation.death_records, [])
        self.assertTrue(parent.alive)

    def test_genome_is_constant_during_colony_lifetime(self):
        simulation = self.make_sim(ticks=20)
        initial = {c.colony_id: c.genome for c in simulation.living_colonies()}
        simulation.run()
        for colony_id, genome in initial.items():
            self.assertEqual(simulation.colonies[colony_id].genome, genome)

    def test_environment_does_not_control_mutation(self):
        left = self.make_sim(master_seed=77, founder_count=1)
        right = self.make_sim(master_seed=77, founder_count=1)
        right.substrate = [[0.0 for _ in row] for row in right.substrate]
        left_parent = left.living_colonies()[0]
        right_parent = right.living_colonies()[0]
        self.assertEqual(
            left._mutate_genome(left_parent, "same-offspring"),
            right._mutate_genome(right_parent, "same-offspring"),
        )

    def test_fusion_transfer_is_conservative(self):
        simulation = self.make_sim()
        left, right = simulation.living_colonies()
        simulation.fusion_links.add(tuple(sorted((left.colony_id, right.colony_id))))
        left.energy = 6.0
        right.energy = 1.0
        before = left.energy + right.energy
        transferred, error = simulation._transfer_across_fusions()
        self.assertGreater(transferred, 0.0)
        self.assertAlmostEqual(left.energy + right.energy, before, places=12)
        self.assertAlmostEqual(error, 0.0, places=12)

    def test_exact_seed_replay(self):
        left = self.make_sim(master_seed=123, ticks=25)
        right = self.make_sim(master_seed=123, ticks=25)
        left.run()
        right.run()
        self.assertEqual(left.state_digest(), right.state_digest())

    def test_different_seed_changes_state(self):
        left = self.make_sim(master_seed=123, ticks=25)
        right = self.make_sim(master_seed=124, ticks=25)
        left.run()
        right.run()
        self.assertNotEqual(left.state_digest(), right.state_digest())

    def test_output_separates_ancestry_deaths_and_spores(self):
        simulation = self.make_sim(ticks=5)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            simulation.run(output)
            expected = {"config.json", "summary.json", "ticks.jsonl", "ancestry.jsonl", "deaths.jsonl", "spores.jsonl"}
            self.assertEqual({p.name for p in output.iterdir()}, expected)
            json.loads((output / "summary.json").read_text(encoding="utf-8"))

    def test_no_preassigned_species_or_cambrian_switch(self):
        simulation = self.make_sim()
        config_text = json.dumps(simulation.config.to_dict()).lower()
        self.assertNotIn("cambrian", config_text)
        self.assertNotIn("species", config_text)
        self.assertNotIn("fungus", config_text)


if __name__ == "__main__":
    unittest.main()
