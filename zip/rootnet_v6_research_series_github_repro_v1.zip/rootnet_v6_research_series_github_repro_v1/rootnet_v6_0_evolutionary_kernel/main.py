from __future__ import annotations

import argparse
import json
from pathlib import Path

from rootnet_evo import EvolutionSimulation, SimulationConfig


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the RootNet v6.0 minimal evolutionary kernel.",
    )
    parser.add_argument("--generations", type=int, default=120)
    parser.add_argument("--seed", type=int, default=600)
    parser.add_argument("--founders", type=int, default=48)
    parser.add_argument("--capacity-per-patch", type=int, default=80)
    parser.add_argument(
        "--habitat-preset",
        choices=("homogeneous", "heterogeneous"),
        default="heterogeneous",
    )
    parser.add_argument("--mutation-probability", type=float, default=0.24)
    parser.add_argument("--mutation-sigma", type=float, default=0.035)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("run_output"),
        help="Output directory. Existing files with the same names are replaced.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    config = SimulationConfig(
        master_seed=args.seed,
        generations=args.generations,
        founder_count=args.founders,
        capacity_per_patch=args.capacity_per_patch,
        habitat_preset=args.habitat_preset,
        mutation_probability=args.mutation_probability,
        mutation_sigma=args.mutation_sigma,
    )
    simulation = EvolutionSimulation(config)
    summary = simulation.run(args.output)
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
