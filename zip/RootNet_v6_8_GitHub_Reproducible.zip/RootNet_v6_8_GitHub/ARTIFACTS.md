# Artifact record

## Confirmed result

- Status: `V6_8_LIFT_0_035_CONFIRMED`
- Candidate extinction: 12/60 (20.0%)
- v6.6 control extinction: 50/60 (83.3%)
- Confirmatory seeds: 30 completely unused seeds
- Paired runs: 120
- Predeclared acceptance checks: 8/8 passed
- Maximum mechanical error: `1.7763568394002505e-15`

## Source artifact hashes

- Original confirmed package ZIP:
  `771a0033ae13994990f9f53da0fb84b68db9abee04ee90f13d2a627bce0dd932`
- Sealed confirmatory result JSON:
  `ae62d63feb1b7f62e05508172dadc299a682948670f1590d7c7014caac8a004b`
- Series README used as this repository's root README:
  `04fa1d8a8df03cf6c0a5df17d8498201637ee789cfb25c77632ceaa7dbe6317a`

`SHA256SUMS.txt` records every file in this repository except itself.

## Licensing note

No license was supplied, so this archive does not invent one. Before making a
public GitHub repository, the copyright holder should add the intended
`LICENSE` file.

