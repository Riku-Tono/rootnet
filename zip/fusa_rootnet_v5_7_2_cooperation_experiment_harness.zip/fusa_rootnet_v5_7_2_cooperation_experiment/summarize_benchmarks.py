from __future__ import annotations

import hashlib
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
AB_PATH = ROOT / "benchmark_ab_5pairs_320days.json"
AB_ZIP_PATH = ROOT / "benchmark_ab_5pairs_320days.zip"
SENS_PATH = ROOT / "benchmark_sensitivity_2seeds_11levels_320days.json"
SENS_ZIP_PATH = ROOT / "benchmark_sensitivity_2seeds_11levels_320days.zip"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def duration(seconds: float) -> str:
    whole = round(seconds)
    hours, remainder = divmod(whole, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}時間{minutes}分{secs}秒"
    return f"{minutes}分{secs}秒"


def stats(values: list[float]) -> dict[str, float]:
    return {
        "min": min(values),
        "median": statistics.median(values),
        "mean": statistics.fmean(values),
        "max": max(values),
    }


def main() -> None:
    ab = json.loads(AB_PATH.read_text(encoding="utf-8"))
    sensitivity = json.loads(SENS_PATH.read_text(encoding="utf-8"))
    ab_runs = [pair[arm] for pair in ab["pairs"] for arm in ("low", "high")]
    sensitivity_runs = [
        level["run"]
        for world in sensitivity["worlds"]
        for level in world["levels"]
    ]

    ab_scale = 100 / len(ab["pairs"])
    sensitivity_scale = 100 / len(sensitivity["worlds"])
    ab_eta = float(ab["experiment"]["elapsed_seconds"]) * ab_scale
    sensitivity_eta = float(sensitivity["experiment"]["elapsed_seconds"]) * sensitivity_scale
    reserve_factor = 1.25

    report = {
        "status": "awaiting_confirmation_before_full_runs",
        "protocol_id": ab["experiment"]["protocol_id"],
        "benchmark_ab": {
            "pairs": len(ab["pairs"]),
            "trajectories": len(ab_runs),
            "world_days": len(ab_runs) * 320,
            "elapsed_seconds": ab["experiment"]["elapsed_seconds"],
            "trajectory_seconds": stats([float(run["elapsed_seconds"]) for run in ab_runs]),
            "json_bytes": AB_PATH.stat().st_size,
            "zip_bytes": AB_ZIP_PATH.stat().st_size,
            "sha256": sha256(AB_PATH),
            "quality": {
                "single_source_difference_pairs": sum(
                    pair["initial_audit"]["only_cooperation_differs"] for pair in ab["pairs"]
                ),
                "weather_exact_pairs": sum(pair["weather_exact_match"] for pair in ab["pairs"]),
                "world_rng_exact_pairs": sum(pair["final_world_rng_state_match"] for pair in ab["pairs"]),
                "complete_trajectories": sum(run["metrics"]["completed_days"] == 320 for run in ab_runs),
                "error_trajectories": sum(run["metrics"]["error"] is not None for run in ab_runs),
                "reconciled_trajectories": sum(
                    run["metrics"]["help_count_reconciled"]
                    and run["metrics"]["help_request_reconciled"]
                    for run in ab_runs
                ),
            },
        },
        "benchmark_sensitivity": {
            "seeds": len(sensitivity["worlds"]),
            "levels": 11,
            "trajectories": len(sensitivity_runs),
            "world_days": len(sensitivity_runs) * 320,
            "elapsed_seconds": sensitivity["experiment"]["elapsed_seconds"],
            "trajectory_seconds": stats([float(run["elapsed_seconds"]) for run in sensitivity_runs]),
            "json_bytes": SENS_PATH.stat().st_size,
            "zip_bytes": SENS_ZIP_PATH.stat().st_size,
            "sha256": sha256(SENS_PATH),
            "quality": {
                "weather_exact_seeds": sum(
                    world["weather_exact_across_levels"] for world in sensitivity["worlds"]
                ),
                "world_rng_exact_seeds": sum(
                    world["final_world_rng_state_exact_across_levels"]
                    for world in sensitivity["worlds"]
                ),
                "complete_trajectories": sum(
                    run["metrics"]["completed_days"] == 320 for run in sensitivity_runs
                ),
                "error_trajectories": sum(
                    run["metrics"]["error"] is not None for run in sensitivity_runs
                ),
                "reconciled_trajectories": sum(
                    run["metrics"]["help_count_reconciled"]
                    and run["metrics"]["help_request_reconciled"]
                    for run in sensitivity_runs
                ),
            },
        },
        "full_run_estimates": {
            "ab_100_pairs": {
                "seeds": [0, 99],
                "arms": 2,
                "trajectories": 200,
                "days_per_trajectory": 320,
                "world_days": 64_000,
                "eta_seconds_linear": ab_eta,
                "eta_seconds_with_25pct_reserve": ab_eta * reserve_factor,
                "estimated_json_bytes_linear": round(AB_PATH.stat().st_size * ab_scale),
                "estimated_zip_bytes_linear": round(AB_ZIP_PATH.stat().st_size * ab_scale),
            },
            "sensitivity_100_by_11": {
                "seeds": [0, 99],
                "levels": [round(index / 10, 1) for index in range(11)],
                "trajectories": 1_100,
                "days_per_trajectory": 320,
                "world_days": 352_000,
                "eta_seconds_linear": sensitivity_eta,
                "eta_seconds_with_25pct_reserve": sensitivity_eta * reserve_factor,
                "estimated_json_bytes_linear": round(SENS_PATH.stat().st_size * sensitivity_scale),
                "estimated_zip_bytes_linear": round(SENS_ZIP_PATH.stat().st_size * sensitivity_scale),
            },
        },
    }

    json_path = ROOT / "benchmark_eta_capacity.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    ab_full = report["full_run_estimates"]["ab_100_pairs"]
    sens_full = report["full_run_estimates"]["sensitivity_100_by_11"]
    ab_q = report["benchmark_ab"]["quality"]
    sens_q = report["benchmark_sensitivity"]["quality"]
    lines = [
        "# RootNet v5.7.2 協調性実験 ベンチマーク報告",
        "",
        "## 現在の停止位置",
        "",
        "実験ハーネスと小規模ベンチマークまで完了。200世界および1,100世界の本走は未実行で、確認待ち。",
        "",
        "## A/Bベンチマーク",
        "",
        f"- seed 0〜4、5組、10世界、各320日（3,200世界日）",
        f"- 実時間: {report['benchmark_ab']['elapsed_seconds']:.2f}秒",
        f"- 1世界: 平均{report['benchmark_ab']['trajectory_seconds']['mean']:.2f}秒、最小{report['benchmark_ab']['trajectory_seconds']['min']:.2f}秒、最大{report['benchmark_ab']['trajectory_seconds']['max']:.2f}秒",
        f"- 単一実状態差分: {ab_q['single_source_difference_pairs']}/5組 PASS",
        f"- 外部天候一致: {ab_q['weather_exact_pairs']}/5組 PASS",
        f"- world乱数状態一致: {ab_q['world_rng_exact_pairs']}/5組 PASS",
        f"- 320日完走: {ab_q['complete_trajectories']}/10世界、エラー{ab_q['error_trajectories']}件",
        f"- 援助集計照合: {ab_q['reconciled_trajectories']}/10世界 PASS",
        f"- JSON: {report['benchmark_ab']['json_bytes']:,} bytes / ZIP: {report['benchmark_ab']['zip_bytes']:,} bytes",
        "",
        "## 感度ベンチマーク",
        "",
        "- seed 0・1、11水準、22世界、各320日（7,040世界日）",
        f"- 実時間: {report['benchmark_sensitivity']['elapsed_seconds']:.2f}秒",
        f"- 1世界: 平均{report['benchmark_sensitivity']['trajectory_seconds']['mean']:.2f}秒、最小{report['benchmark_sensitivity']['trajectory_seconds']['min']:.2f}秒、最大{report['benchmark_sensitivity']['trajectory_seconds']['max']:.2f}秒",
        f"- 11水準の外部天候一致: {sens_q['weather_exact_seeds']}/2 seed PASS",
        f"- 11水準のworld乱数状態一致: {sens_q['world_rng_exact_seeds']}/2 seed PASS",
        f"- 320日完走: {sens_q['complete_trajectories']}/22世界、エラー{sens_q['error_trajectories']}件",
        f"- 援助集計照合: {sens_q['reconciled_trajectories']}/22世界 PASS",
        f"- JSON: {report['benchmark_sensitivity']['json_bytes']:,} bytes / ZIP: {report['benchmark_sensitivity']['zip_bytes']:,} bytes",
        "",
        "## 本走ETAと容量",
        "",
        "| バッチ | 世界数 | 世界日 | 線形ETA | 25%余裕込み | JSON見込 | ZIP見込 |",
        "|---|---:|---:|---:|---:|---:|---:|",
        f"| A/B 100組 | 200 | 64,000 | {duration(ab_full['eta_seconds_linear'])} | {duration(ab_full['eta_seconds_with_25pct_reserve'])} | {ab_full['estimated_json_bytes_linear'] / 1_000_000:.2f} MB | {ab_full['estimated_zip_bytes_linear'] / 1_000_000:.2f} MB |",
        f"| 感度100×11 | 1,100 | 352,000 | {duration(sens_full['eta_seconds_linear'])} | {duration(sens_full['eta_seconds_with_25pct_reserve'])} | {sens_full['estimated_json_bytes_linear'] / 1_000_000:.2f} MB | {sens_full['estimated_zip_bytes_linear'] / 1_000_000:.2f} MB |",
        "",
        "容量見込はベンチマーク成果物を世界数に比例させた値。集計報告書や検証記録の小容量ファイルは含まない。日別全状態は保存せず、日次集計と天候SHA-256、最終指標を保存する仕様。",
        "",
        "## 本走時の正確な再計算範囲",
        "",
        "### A/B 100組",
        "",
        "- seed 0〜99を全て新規計算（ベンチマークseedも再計算）",
        "- 各seedで初期世界を1回生成し、A=0.10とB=0.90へ複製",
        "- 200世界×320日＝64,000世界日",
        "- 各ペアで単一実状態差分、外部天候、world乱数状態を照合",
        "- 株日、辺日、行動、信頼、RootNet、防疫、日誌を再集計",
        "",
        "### 感度解析",
        "",
        "- A/B結果確定後に別バッチで実行",
        "- seed 0〜99を全て新規計算",
        "- 各seedで協調性0.00〜1.00の11水準",
        "- 1,100世界×320日＝352,000世界日",
        "- 各seed内の11水準で外部天候とworld乱数状態を照合",
        "",
        "## 注意",
        "",
        "ベンチマークseedの効果方向は解析対象にしない。本確認では100組の対応差と効果量を計算する。現在は確認待ちのため長時間本走を開始しない。",
    ]
    md_path = ROOT / "BENCHMARK_REPORT.md"
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"saved={json_path}")
    print(f"saved={md_path}")


if __name__ == "__main__":
    main()
