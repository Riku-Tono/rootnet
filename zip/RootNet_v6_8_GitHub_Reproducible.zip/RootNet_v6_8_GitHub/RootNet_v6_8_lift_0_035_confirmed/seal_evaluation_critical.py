from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SEAL_FILE = ROOT / "EVALUATION_CRITICAL_SEAL.json"
CRITICAL_FILES = (
    "EVALUATION_ACCEPTANCE_CRITERIA.json",
    "V6_8_CONFIRMATORY_PROTOCOL.md",
    "MODEL_SPEC.md",
    "RESEARCH_BOUNDARIES.md",
    "confirmatory_v6_8.py",
    "main.py",
    "watch.py",
    "validate_v6_8.py",
    "seal_evaluation_critical.py",
    "tests/test_v6_8.py",
    "rootnet_v68/__init__.py",
    "rootnet_v68/conductance.py",
    "rootnet_v68/environment.py",
    "rootnet_v68/field.py",
    "rootnet_v68/geometry.py",
    "rootnet_v68/metrics.py",
    "rootnet_v68/model.py",
    "rootnet_v68/regression.py",
    "rootnet_v68/rng.py",
    "rootnet_v68/simulation.py",
)


def current_hashes() -> dict[str, str]:
    return {
        relative: hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        for relative in CRITICAL_FILES
    }


def verify_critical_seal() -> bool:
    if not SEAL_FILE.is_file():
        return False
    payload = json.loads(SEAL_FILE.read_text(encoding="utf-8"))
    return payload.get("critical_file_sha256") == current_hashes()


def main() -> None:
    if SEAL_FILE.exists():
        raise SystemExit("refusing to overwrite existing critical-file seal")
    payload = {
        "schema": "rootnet-v6.8-evaluation-critical-seal-v1",
        "candidate_water_capacity_lift": 0.035,
        "status": "SEALED_BEFORE_CONFIRMATORY_SEED_GENERATION",
        "critical_file_sha256": current_hashes(),
    }
    SEAL_FILE.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Sealed {len(CRITICAL_FILES)} critical files: {SEAL_FILE}")


if __name__ == "__main__":
    main()
