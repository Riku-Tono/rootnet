from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from lineage_view import write_lineage_tree
from models import LifeNeeds, Temperament, Weather
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV57Tests(unittest.TestCase):
    def test_same_drought_different_temperaments_choose_differently(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=1)
        cases = {
            "explorer": (
                Temperament(exploration=1.0, caution=0.0, cooperation=0.0, hoarding=0.0, homing=0.0),
                "seek_water",
            ),
            "careful": (
                Temperament(exploration=0.0, caution=1.0, cooperation=0.0, hoarding=0.0, homing=0.0),
                "rest",
            ),
            "helper": (
                Temperament(exploration=0.0, caution=0.0, cooperation=1.0, hoarding=0.0, homing=0.0),
                "request_help",
            ),
            "hoarder": (
                Temperament(exploration=0.0, caution=0.0, cooperation=0.0, hoarding=1.0, homing=0.0),
                "hoard",
            ),
            "returner": (
                Temperament(exploration=0.0, caution=0.0, cooperation=0.0, hoarding=0.0, homing=1.0),
                "return_home",
            ),
        }
        chosen = {}
        for index, (name, (temperament, expected)) in enumerate(cases.items()):
            plant = FusaPlant(name, plant_id=name, rng_seed=index)
            plant.parent_id = "parent"
            plant.needs = LifeNeeds(
                hunger=0.40,
                thirst=0.80,
                security=0.30,
                alert=0.50,
            )
            plant.temperament = temperament
            action, _, _ = ecosystem.choose_life_action(plant, noise=False)
            chosen[name] = action
            self.assertEqual(expected, action)
        self.assertEqual(5, len(set(chosen.values())))

    def test_help_increases_trust_and_conserves_resources(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=2)
        receiver = FusaPlant("受け手", plant_id="receiver", rng_seed=3)
        helper = FusaPlant("助け手", plant_id="helper", rng_seed=4)
        receiver.condition.energy = 0.20
        receiver.condition.hydration = 0.20
        helper.condition.energy = 0.90
        helper.condition.hydration = 0.90
        ecosystem.add_plant(receiver)
        ecosystem.add_plant(helper)
        ecosystem.connect_plants(ecosystem.rootnet, "receiver", "helper", 0.90)
        weather = Weather(temperature=0.5, sunlight=0.5, rainfall=0.0, wind_speed=0.2)
        receiver_before = receiver.condition.energy + receiver.condition.hydration
        helper_before = helper.condition.energy + helper.condition.hydration

        event = ecosystem._execute_life_action(
            receiver,
            "request_help",
            "検査用の不足",
            weather,
        )

        receiver_gain = (
            receiver.condition.energy + receiver.condition.hydration - receiver_before
        )
        helper_loss = helper_before - (
            helper.condition.energy + helper.condition.hydration
        )
        relation = receiver.relationship_with("helper")
        self.assertEqual("success", event.outcome)
        self.assertAlmostEqual(receiver_gain, helper_loss)
        self.assertAlmostEqual(0.58, relation.trust)
        self.assertAlmostEqual(0.08, event.relationship_changes["trust"])

    def test_failure_updates_memory_and_is_kept_in_journal(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=5)
        plant = FusaPlant("探索株", plant_id="seeker", rng_seed=6)
        plant.condition.hydration = 0.20
        plant.needs.thirst = 0.90
        ecosystem.add_plant(plant)
        ecosystem.infrastructure.water_reserve = 0.0
        weather = Weather(temperature=0.7, sunlight=0.8, rainfall=0.0, wind_speed=0.2)

        event = ecosystem._execute_life_action(
            plant,
            "seek_water",
            "強い渇き",
            weather,
        )
        selected = ecosystem._record_life_events([event])

        self.assertEqual("failure", event.outcome)
        self.assertGreater(event.memory_changes["drought"], 0.0)
        self.assertEqual(1, plant.decision_memory["seek_water"]["failure"])
        self.assertEqual([event], selected)
        self.assertEqual(event, ecosystem.life_journal[-1])

    def test_journal_state_delta_matches_actual_result(self) -> None:
        ecosystem = FusaEcosystem(rng_seed=7)
        plant = FusaPlant("水探し株", plant_id="water", rng_seed=8)
        plant.condition.hydration = 0.30
        ecosystem.add_plant(plant)
        ecosystem.infrastructure.water_reserve = 0.80
        weather = Weather(temperature=0.6, sunlight=0.7, rainfall=0.5, wind_speed=0.2)

        event = ecosystem._execute_life_action(
            plant,
            "seek_water",
            "渇き0.70・探索心0.80",
            weather,
        )

        recorded_delta = (
            event.state_after["hydration"] - event.state_before["hydration"]
        )
        actual_delta = plant.condition.hydration - event.state_before["hydration"]
        self.assertEqual("success", event.outcome)
        self.assertAlmostEqual(actual_delta, recorded_delta)
        self.assertIn(f"{actual_delta:.3f}", event.narrative)

    def test_save_resume_repeats_same_choices_and_results(self) -> None:
        continuous = FusaEcosystem.demo(123)
        for _ in range(140):
            continuous.step()
        split = FusaEcosystem.demo(123)
        for _ in range(70):
            split.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet_v5_7.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 123)
            for _ in range(70):
                resumed.step()
        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_ordinary_days_keep_journal_sparse(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        daily_counts = []
        for _ in range(40):
            daily_counts.append(len(ecosystem.step().life_events))
        total_actions = sum(ecosystem.life_action_counts.values())
        self.assertLess(len(ecosystem.life_journal), total_actions * 0.20)
        self.assertLessEqual(max(daily_counts), ecosystem.MAX_JOURNAL_EVENTS_PER_DAY)
        self.assertTrue(all(
            event.importance >= ecosystem.JOURNAL_IMPORTANCE_THRESHOLD
            for event in ecosystem.life_journal
        ))

    def test_schema9_save_migrates_with_life_defaults(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        data = ecosystem_to_dict(ecosystem)
        data["schema_version"] = 9
        data.pop("life_journal", None)
        data.pop("life_action_counts", None)
        for plant in data["plants"]:
            for key in (
                "needs",
                "temperament",
                "relationships",
                "decision_memory",
                "last_life_action",
            ):
                plant.pop(key, None)
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "v561.json"
            path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            migrated = load_ecosystem(path, 123)
        self.assertEqual([], migrated.life_journal)
        self.assertTrue(all(
            plant.needs.security == 0.5
            for plant in migrated.plants.values()
        ))

    def test_lineage_view_contains_needs_relationships_and_factual_journal(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(5):
            ecosystem.step()
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "tree.html"
            write_lineage_tree(ecosystem, path)
            html = path.read_text(encoding="utf-8")
        self.assertIn("RootNet v5.7 暮らしと気配", html)
        self.assertIn("temperament_label", html)
        self.assertIn("relationships", html)
        self.assertIn("life_journal", html)


if __name__ == "__main__":
    unittest.main()
