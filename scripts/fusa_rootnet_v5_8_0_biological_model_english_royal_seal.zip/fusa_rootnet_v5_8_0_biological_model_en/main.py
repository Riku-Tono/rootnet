from __future__ import annotations

import argparse
import sys
from pathlib import Path

from lineage_view import write_lineage_tree
from persistence import load_ecosystem, save_ecosystem_atomic


def configure_utf8_output() -> None:
    """Safely print emoji and Unicode text even in Windows cp932 terminals."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8", errors="replace")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="RootNet v5.8.0 Biological Model")
    parser.add_argument("--days", type=int, default=12)
    parser.add_argument("--save", type=Path, default=Path("fusa_rootnet_v5_8_0.json"))
    parser.add_argument(
        "--tree",
        type=Path,
        default=Path("fusa_lineage_tree.html"),
        help="output path for the lineage-tree HTML",
    )
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--world-seed", type=int, default=None)
    parser.add_argument("--individual-seed", type=int, default=None)
    parser.add_argument("--mutation-seed", type=int, default=None)
    parser.add_argument("--action-seed", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    configure_utf8_output()
    args = parse_args()
    eco = load_ecosystem(
        args.save,
        args.seed,
        world_seed=args.world_seed,
        individual_seed=args.individual_seed,
        mutation_seed=args.mutation_seed,
        action_seed=args.action_seed,
    )
    days = max(1, min(args.days, 3650))
    print("🌿🍄🫧 RootNet v5.8.0――Biological Model")
    print(
        f"Community: {eco.name} / living organisms: {len(eco.living_plants())} "
        f"/ historical organisms: {len(eco.plants)} / resuming from day {eco.day}"
    )
    print(
        "Random-number streams: "
        + " / ".join(f"{name}={seed}" for name, seed in eco.rng_seeds.items())
    )
    print("─" * 76)
    for _ in range(days):
        report = eco.step(); w = report.weather
        solar, sea = report.solar, report.marine
        print(
            f"Day {report.day} | {solar.condition} day length {solar.day_length:.1f}h "
            f"light {w.sunlight:.2f} temperature {w.temperature:.2f} rain {w.rainfall:.2f}"
        )
        print(
            f"  {sea.moon_phase} tide {sea.tide_level:.2f} waves {sea.wave_strength:.2f} "
            f"sea temperature {sea.sea_temperature:.2f} salinity {sea.salinity:.2f} marine nutrients {sea.nutrients:.2f}"
        )
        for signal in report.signals:
            print(f"  ⚡ {signal.message} ({signal.signal_type} / strength {signal.strength:.2f})")
        for signal in report.marine_signals:
            print(f"  🌊 {signal.message} (Seafloor RootNet / strength {signal.strength:.2f})")
        print(
            f"  💧 Water purified +{report.water_cleaned:.3f}  🔥 Solar and leaf-litter fuel +{report.fuel_collected:.3f} "
            f"🪸 Symbiotic-algae photosynthesis +{report.coral_energy:.3f}"
        )
        if report.stored_seed_ids:
            print(f"  🫘 Stored {len(report.stored_seed_ids)} seeds in the physical seed bank")
        if report.wave_moved_seed_ids:
            print(f"  🌊 Waves carried {len(report.wave_moved_seed_ids)} seeds into the intertidal zone")
        for plant_id in report.new_plant_ids:
            plant = eco.plants[plant_id]
            handedness = "mirror-image D form" if plant.chirality == "D" else "standard L form"
            traits = " / ".join(plant.traits.active_names()) or "baseline traits"
            abilities = " / ".join(plant.expressed_abilities.active_names())
            ability_text = f" / expressed:{abilities}" if abilities else " / abilities weakly expressed"
            print(
                f"  🌱 New organism '{plant.name}' born "
                f"(generation {plant.generation} / {handedness} / {traits}{ability_text})"
            )
        for plant_id, reason in report.deaths:
            plant = eco.plants[plant_id]
            print(f"  🍂 {plant.name} -> {reason} (age at death: {plant.age} days)")
        if report.soil_returned > 0:
            print(f"  ♻️ nutrients returned from dead biomass to soil +{report.soil_returned:.4f}")
        state = eco.infrastructure
        print(
            f"  Substrate | water quality {state.water_quality:.2f} water reserve {state.water_reserve:.2f} "
            f"soil {state.soil_nutrients:.2f} fuel {state.amber_fuel:.1f} "
            f"seed bank {state.seed_bank} living {len(eco.living_plants())}"
        )
        print(
            f"  🏞️ carrying capacity {report.carrying_capacity} "
            f"population pressure {report.population_pressure:.2f}"
        )
        pools = report.biological["end_pool"]
        transport = report.biological["transported"]
        print(
            f"  🧪 Resources | carbon {pools['carbon']:.3f} water {pools['water']:.3f} "
            f"nitrogen {pools['nitrogen']:.3f} / network transport "
            f"C{transport['carbon']:.4f} W{transport['water']:.4f} N{transport['nitrogen']:.4f}"
        )
        if report.elder_successor_id:
            successor = eco.plants[report.elder_successor_id]
            print(f"  👑 New elder '{successor.name}' selected by the RootNet Council")
        if report.cambrian_started:
            print("  🧬🌊 The Fusacambrian period begins. Ability expression and mutation rates increase.")
        elif not eco.cambrian.active:
            audit = report.cambrian_audit
            ready = sum(
                bool(audit.get(name))
                for name in (
                    "generation_ready",
                    "population_ready",
                    "diversity_ready",
                    "stable_water_ready",
                    "rootnet_ready",
                )
            )
            print(
                f"  🧬 Readiness {ready}/5 | generation {audit.get('max_generation', 0)} "
                f"organisms {audit.get('living_plants', 0)} diversity {audit.get('genetic_diversity', 0):.2f} "
                f"network function {audit.get('rootnet_functional_score', 0):.2f}"
            )
        if report.false_signals:
            print(f"  〰️ False signals: {len(report.false_signals)}")
        if report.movements:
            counts = {
                kind: sum(move.get("type") == kind for move in report.movements)
                for kind in ("walk", "spore", "hypha", "reconnect")
            }
            print(
                f"  🧭 Movement | walking {counts['walk']} "
                f"spores {counts['spore']} hyphal extension {counts['hypha']} "
                f"reconnection {counts['reconnect']}"
            )
        if report.interactions:
            print(f"  🦠 Parasitic/predatory interactions: {len(report.interactions)}")
        for event in report.life_events:
            print(
                f"  📜 {event.narrative} "
                f" (reason: {event.reason} / {event.outcome})"
            )
        net = report.network_metrics
        print(
            f"  🕸️ RootNet | largest component {net['largest_component_ratio']:.2f} "
            f"isolation {net['isolate_rate']:.2f} mean path {net['average_path_length']:.2f} "
            f"clustering {net['clustering_coefficient']:.2f} reachability {net['reachability']:.2f} "
            f"components {int(net['component_count'])}"
        )
        defense = report.biosecurity
        if defense["new_outbreaks"]:
            print(f"  ☠️ Highly toxic mutations: {len(defense['new_outbreaks'])}")
        if defense["quarantines"] or defense["severed"]:
            print(
                f"  🛡️ Biosecurity | quarantined {len(defense['quarantines'])} organisms "
                f"/ severed {len(defense['severed'])} links"
            )
        if defense["reconnected"]:
            print(f"  🌱 post-recovery reconnection {len(defense['reconnected'])} links")
        defense_metrics = defense["metrics"]
        print(
            f"  Biosecurity metrics | active hazard rate {defense_metrics['active_hazard_rate']:.2f} "
            f"quarantine rate {defense_metrics['quarantine_rate']:.2f} "
            f"mean containment rate {defense_metrics['mean_containment_rate']:.2f}"
        )
    save_ecosystem_atomic(eco, args.save)
    write_lineage_tree(eco, args.tree)
    print("─" * 76)
    print(f"💾 Save complete: {args.save}")
    print(f"🌳 Lineage tree updated: {args.tree}")
    print(f"📜 Significant life-journal entries: {len(eco.life_journal)} total")
    print("Record actual differences in physiological resources and environmental stress, not anthropomorphic personality judgments.")
    print("Pafuri Toftof. 🌿🍄📜")


if __name__ == "__main__":
    main()

