from __future__ import annotations

import math
from typing import Any


def semantic_differences(
    actual: Any,
    expected: Any,
    *,
    abs_tol: float = 1e-9,
    path: str = "$",
    limit: int = 20,
) -> list[str]:
    """Compare nested model state: discrete values exact, floats by tolerance."""

    differences: list[str] = []

    def compare(left: Any, right: Any, current: str) -> None:
        if len(differences) >= limit:
            return
        if isinstance(left, bool) or isinstance(right, bool):
            if type(left) is not type(right) or left != right:
                differences.append(f"{current}: {left!r} != {right!r}")
            return
        if isinstance(left, float) or isinstance(right, float):
            if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
                differences.append(f"{current}: numeric type mismatch")
            elif not math.isclose(
                float(left),
                float(right),
                rel_tol=0.0,
                abs_tol=abs_tol,
            ):
                differences.append(
                    f"{current}: {left!r} != {right!r} (abs_tol={abs_tol})"
                )
            return
        if type(left) is not type(right):
            differences.append(
                f"{current}: type {type(left).__name__} != {type(right).__name__}"
            )
            return
        if isinstance(left, dict):
            if set(left) != set(right):
                missing = sorted(set(right) - set(left))
                extra = sorted(set(left) - set(right))
                differences.append(
                    f"{current}: key mismatch missing={missing} extra={extra}"
                )
                return
            for key in sorted(left):
                compare(left[key], right[key], f"{current}.{key}")
            return
        if isinstance(left, list):
            if len(left) != len(right):
                differences.append(
                    f"{current}: length {len(left)} != {len(right)}"
                )
                return
            for index, (left_item, right_item) in enumerate(zip(left, right)):
                compare(left_item, right_item, f"{current}[{index}]")
            return
        if left != right:
            differences.append(f"{current}: {left!r} != {right!r}")

    compare(actual, expected, path)
    return differences


def assert_semantic_equal(
    actual: Any,
    expected: Any,
    *,
    abs_tol: float = 1e-9,
) -> None:
    differences = semantic_differences(actual, expected, abs_tol=abs_tol)
    if differences:
        raise AssertionError("semantic regression mismatch:\n" + "\n".join(differences))
