from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.txt"
IGNORED_PARTS = {".git", ".pytest_cache", "__pycache__"}
IGNORED_SUFFIXES = {".pyc", ".pyo"}


def included_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == MANIFEST:
            continue
        relative = path.relative_to(ROOT)
        if any(part in IGNORED_PARTS for part in relative.parts):
            continue
        if path.suffix.lower() in IGNORED_SUFFIXES:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def manifest_text() -> str:
    lines = []
    for path in included_files():
        relative = path.relative_to(ROOT).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest} *{relative}")
    return "\n".join(lines) + "\n"


def main() -> None:
    with MANIFEST.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(manifest_text())
    print(f"Wrote {MANIFEST.name} for {len(included_files())} files")


if __name__ == "__main__":
    main()
