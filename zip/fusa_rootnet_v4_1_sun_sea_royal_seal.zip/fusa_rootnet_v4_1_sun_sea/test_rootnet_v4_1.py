from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ecosystem import FusaEcosystem
from models import StoredSeed
from persistence import ecosystem_to_dict, load_ecosystem, save_ecosystem_atomic
from simulation import FusaPlant


class RootNetV41Tests(unittest.TestCase):
    def test_three_initial_genes_are_distinct(self) -> None:
        plant = FusaPlant(rng_seed=42)
        variants = {tuple(gene.to_dict().values()) for gene in plant.genes}
        self.assertEqual(3, len(variants))

    def test_save_resume_matches_continuous_run(self) -> None:
        continuous = FusaEcosystem.demo(2718)
        for _ in range(60):
            continuous.step()

        split = FusaEcosystem.demo(2718)
        for _ in range(30):
            split.step()

        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = Path(temp_dir) / "rootnet_v4_1.json"
            save_ecosystem_atomic(split, save_path)
            resumed = load_ecosystem(save_path, 2718)
            for _ in range(30):
                resumed.step()

        self.assertEqual(ecosystem_to_dict(continuous), ecosystem_to_dict(resumed))

    def test_real_seed_waits_then_germinates_with_parent_link(self) -> None:
        ecosystem = FusaEcosystem.demo(1)
        parent = ecosystem.plants["memory-001"]
        seed = parent.create_seed()
        packet = StoredSeed(
            seed_id="seed-test",
            seed=seed,
            parent_id=parent.plant_id,
            lineage=parent.lineage,
            district=parent.district,
            stored_day=0,
        )
        ecosystem.seed_inventory.append(packet)
        ecosystem.infrastructure.seed_bank = 1

        ecosystem.day = 2
        self.assertEqual([], ecosystem._germinate_seed_inventory())
        self.assertEqual(1, len(ecosystem.seed_inventory))

        ecosystem.day = 3
        new_ids = ecosystem._germinate_seed_inventory()
        self.assertEqual(1, len(new_ids))
        child = ecosystem.plants[new_ids[0]]
        self.assertEqual(parent.plant_id, child.parent_id)
        self.assertIn(child.plant_id, parent.child_ids)
        self.assertEqual(0, len(ecosystem.seed_inventory))

    def test_death_becomes_corpse_and_returns_soil(self) -> None:
        ecosystem = FusaEcosystem.demo(7)
        plant = ecosystem.plants["memory-001"]
        plant.age = plant.natural_lifespan() - 1
        report = ecosystem.step()
        self.assertFalse(plant.alive)
        self.assertEqual("枯株", plant.corpse_stage)
        self.assertIn((plant.plant_id, "寿命を全うした"), report.deaths)
        before = ecosystem.infrastructure.soil_nutrients
        ecosystem._decomposition_cycle(report.weather)
        self.assertGreater(ecosystem.infrastructure.soil_nutrients, before)
        self.assertGreater(plant.soil_returned, 0.0)

    def test_sun_moon_sea_coral_and_undersea_rootnet_exist(self) -> None:
        ecosystem = FusaEcosystem.demo(42)
        report = ecosystem.step()
        self.assertIn(
            report.solar.condition,
            {"☀️ 晴天", "🌤️ 薄曇り", "🌇 夕照", "🌑 日食"},
        )
        self.assertGreater(report.solar.day_length, 0.0)
        self.assertGreaterEqual(report.marine.tide_level, 0.0)
        self.assertIn("coral-001", ecosystem.corals)
        self.assertIn("sea-001", ecosystem.undersea_rootnet.links)
        self.assertIn("coast-001", ecosystem.undersea_rootnet.links)

    def test_lineage_tree_records_next_generation(self) -> None:
        ecosystem = FusaEcosystem.demo(123)
        for _ in range(80):
            ecosystem.step()
        children = [node for node in ecosystem.lineage_tree_data() if node["generation"] > 1]
        self.assertGreaterEqual(len(children), 1)
        self.assertTrue(all(node["parent_id"] for node in children))


if __name__ == "__main__":
    unittest.main()
